#!/usr/bin/env bash
# JackSneider — Ultra Mega Super Installer v3 (Futurista)
set -euo pipefail

# Colores neón
R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'; C='\033[0;36m'; M='\033[0;35m'; W='\033[1;37m'; B='\033[1;34m'; N='\033[0m'; BG='\033[48;5;236m'

HERE="$(cd "$(dirname "$0")" && pwd)"
HWID_FAB="164a39606c1fdde0"
MACHINE_ID_FAB="164a39606c1fdde00000000000000000"
ARCH="$(uname -m)"

# ── Banner ──────────────────────────────────────────────────
clear
echo -e "${C}═══════════════════════════════════════════════════════════════════${N}"
echo -e "${M}   ██╗ █████╗  ██████╗██╗  ██╗███████╗███╗   ██╗███████╗██╗   ${N}"
echo -e "${M}   ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝████╗  ██║██╔════╝██║   ${N}"
echo -e "${C}   ██║███████║██║     █████╔╝ █████╗  ██╔██╗ ██║█████╗  ██║   ${N}"
echo -e "${C}   ██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██║╚██╗██║██╔══╝  ██║   ${N}"
echo -e "${G}   ██║██║  ██║╚██████╗██║  ██╗███████╗██║ ╚████║███████╗███████╗${N}"
echo -e "${G}   ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚══════╝╚══════╝${N}"
echo -e "${W}                 ULTRA MEGA SUPER INSTALLER v3${N}"
echo -e "${C}═══════════════════════════════════════════════════════════════════${N}"
echo

hack_load() {
    local msg="$1"
    echo -ne "\033[0;36m   ▸ \033[0m${msg} "
    for i in {1..3}; do
        echo -ne "\033[0;35m.\033[0m"; sleep 0.2
        echo -ne "\b \b"; sleep 0.1
    done
    echo -e "\033[0;32mOK\033[0m"
}

typewriter() {
    local text="$1" delay="${2:-0.01}"
    for ((i=0; i<${#text}; i++)); do
        echo -ne "${text:$i:1}"
        sleep "$delay"
    done
    echo
}

step() {
    local num="$1" total="$2" title="$3"
    echo
    echo -e "${B}╭──────────────────────────────────────────────────────────────╮${N}"
    echo -e "${B}│${N} ${W}PASO ${num}/${total}${N} · ${M}${title}${N}"
    echo -e "${B}╰──────────────────────────────────────────────────────────────╯${N}"
}

ok() { echo -e "${G}   ✓${N} $*"; }
fail() { echo -e "${R}   ✗${N} $*"; }
info() { echo -e "${C}   ▸${N} $*"; }

# ── Detección de arquitectura ───────────────────────────────
hack_load "Detectando arquitectura"
QEMU=""
case "$ARCH" in
    x86_64|amd64) ok "x86_64 nativo" ;;
    aarch64|arm64)
        info "ARM64 detectado. Instalando QEMU..."
        apt-get update -qq
        apt-get install -y -qq qemu-user-static binfmt-support 2>&1 | tail -2
        systemctl restart binfmt-support 2>/dev/null || true
        if [[ -f /proc/sys/fs/binfmt_misc/qemu-x86_64 ]]; then
            ok "QEMU amd64 listo"
            QEMU="qemu-x86_64-static"
        else
            fail "QEMU no pudo registrar amd64"; exit 1
        fi
        ;;
    *) fail "Arquitectura no soportada: $ARCH"; exit 1 ;;
esac

# ── Barra de progreso ───────────────────────────────────────
progress_bar() {
    local current=$1 total=$2
    local width=40
    local filled=$(( current * width / total ))
    local empty=$(( width - filled ))
    local bar=""
    for ((i=0; i<filled; i++)); do bar+="█"; done
    for ((i=0; i<empty; i++)); do bar+="░"; done
    echo -ne "\r${C}[${bar}]${N} ${W}$(( current * 100 / total ))%${N}"
}

# ── Pasos ───────────────────────────────────────────────────
TOTAL=13
CURRENT=0

step 1 $TOTAL "BACKUP DE SEGURIDAD"
hack_load "Creando respaldo"
if [[ -d /etc/movivip ]]; then
    TS="$(date +%Y%m%d-%H%M%S)"
    tar -czf "/root/backup-movivip-$TS.tar.gz" /etc/movivip 2>/dev/null || true
    ok "Backup: /root/backup-movivip-$TS.tar.gz"
    if [[ "${MV_FORCE:-0}" != "1" ]] && [[ -t 0 ]]; then
        echo -e "${Y}   ¿Sobrescribir instalación existente? (s/N): ${N}\c"
        read -r RESP
        [[ "${RESP,,}" == "s" ]] || { echo "Cancelado."; exit 0; }
    fi
else
    info "Sin instalación previa."
fi

step 2 $TOTAL "LIMPIEZA PROFUNDA"
hack_load "Eliminando restos"
chattr -R -i /etc/movivip 2>/dev/null || true
chattr -i /usr/local/bin/movivip-* 2>/dev/null || true
rm -rf /etc/movivip 2>/dev/null || true
rm -f /usr/local/bin/badvpn-udpgw /usr/local/bin/bhttp-server /usr/local/bin/btun-server \
      /usr/local/bin/xhttp-server /usr/local/bin/hcr /usr/local/bin/xray \
      /usr/local/bin/hysteria1 /usr/local/bin/zivpn /usr/local/bin/movivip-* \
      /usr/local/bin/menu 2>/dev/null || true
rm -f /etc/systemd/system/movivip-* /etc/systemd/system/badvpn-* \
      /etc/systemd/system/dropbear_custom.service /etc/systemd/system/hcr.service \
      /etc/systemd/system/ssh-ws-internal.service /etc/systemd/system/udp-custom.service \
      /etc/systemd/system/bhttp.service /etc/systemd/system/btun.service \
      /etc/systemd/system/xhttp.service 2>/dev/null || true
rm -f /etc/cron.d/movivip-* 2>/dev/null || true
systemctl daemon-reload 2>/dev/null || true
ok "Limpieza completada."

step 3 $TOTAL "INSTALANDO DEPENDENCIAS"
hack_load "Instalando paquetes base"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq haproxy stunnel4 dropbear fail2ban curl openssl python3 certbot 2>&1 | tail -2
ok "Dependencias instaladas."

step 4 $TOTAL "COPIA DEL PANEL"
hack_load "Copiando panel"
cp -a "$HERE/etc-movivip" /etc/movivip
chmod -R 700 /etc/movivip
chmod 755 /etc/movivip/menu.sh /etc/movivip/install.sh 2>/dev/null || true
ok "Panel copiado."

step 5 $TOTAL "BINARIOS Y WRAPPERS"
mkdir -p /usr/local/bin
cp -a "$HERE/usr-local-bin/." /usr/local/bin/ 2>/dev/null || true
chmod +x /usr/local/bin/movivip-* /usr/local/bin/menu 2>/dev/null || true
if [[ -n "$QEMU" ]]; then
    for bin in movivip-lic movivip-guard; do
        if [[ -f "/usr/local/bin/$bin" ]]; then
            mv "/usr/local/bin/$bin" "/usr/local/bin/$bin.amd64"
            cat > "/usr/local/bin/$bin" <<WRAP
#!/bin/bash
exec $QEMU /usr/local/bin/$bin.amd64 "\$@"
WRAP
            chmod +x "/usr/local/bin/$bin"
        fi
    done
    ok "Wrappers QEMU creados."
fi
ok "Binarios instalados."

step 6 $TOTAL "SERVICIOS SYSTEMD"
if [[ -d "$HERE/systemd" ]]; then
    cp -a "$HERE/systemd/." /etc/systemd/system/ 2>/dev/null || true
    systemctl daemon-reload
fi
ok "Servicios instalados."

step 7 $TOTAL "CONFIGURANDO DOMINIO"
IP_PUBLICA="$(hostname -I | awk '{print $1}')"
echo -e "${C}   Dominio para el panel (Enter para IP: $IP_PUBLICA)${N}"
if [[ -n "${MV_DOMINIO:-}" ]]; then
    DOMINIO="$MV_DOMINIO"
    echo -e "   ${W}Dominio:${N} $DOMINIO"
else
    read -r -p "   Dominio: " DOMINIO
    [[ -z "$DOMINIO" ]] && DOMINIO="$IP_PUBLICA"
fi
sed -i "s|^SERVER_DOMAIN=.*|SERVER_DOMAIN=\"$DOMINIO\"|" /etc/movivip/config.conf 2>/dev/null || echo "SERVER_DOMAIN=\"$DOMINIO\"" >> /etc/movivip/config.conf
sed -i "s|^SERVER_IP=.*|SERVER_IP=\"$IP_PUBLICA\"|" /etc/movivip/config.conf 2>/dev/null || echo "SERVER_IP=\"$IP_PUBLICA\"" >> /etc/movivip/config.conf
ok "Dominio: $DOMINIO"

step 8 $TOTAL "ABRIENDO PUERTOS"
PORTS="22 80 443 8080 8443 7200 7300 8883 36600 36712 54321 8012 90 109 143 1194 8388 1080 3128 5667"
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
    for p in $PORTS; do
        ufw allow "$p"/tcp >/dev/null 2>&1 || true
        ufw allow "$p"/udp >/dev/null 2>&1 || true
    done
    ufw reload >/dev/null 2>&1 || true
    ok "UFW: puertos abiertos."
fi
for p in $PORTS; do
    iptables -C INPUT -p tcp --dport "$p" -j ACCEPT 2>/dev/null || iptables -I INPUT -p tcp --dport "$p" -j ACCEPT 2>/dev/null || true
    iptables -C INPUT -p udp --dport "$p" -j ACCEPT 2>/dev/null || iptables -I INPUT -p udp --dport "$p" -j ACCEPT 2>/dev/null || true
done
if command -v netfilter-persistent >/dev/null 2>&1; then
    netfilter-persistent save >/dev/null 2>&1 || true
elif command -v iptables-save >/dev/null 2>&1; then
    mkdir -p /etc/iptables
    iptables-save > /etc/iptables/rules.v4 2>/dev/null || true
fi
ok "iptables: puertos abiertos y persistidos."

step 9 $TOTAL "HAPROXY"
if [[ -f "$HERE/haproxy-fixed.cfg" ]]; then
    mkdir -p /etc/haproxy
    sed "s|akamai.jackdev.online|$DOMINIO|g; s|172.235.151.253|$IP_PUBLICA|g" "$HERE/haproxy-fixed.cfg" > /etc/haproxy/haproxy.cfg
    /usr/sbin/haproxy -c -f /etc/haproxy/haproxy.cfg 2>/dev/null && ok "HAProxy config válida."
fi

step 10 $TOTAL "ACME WEBROOT"
mkdir -p /var/www/acme/.well-known/acme-challenge
pkill -f "http.server 8090" >/dev/null 2>&1 || true
sleep 1
cd /var/www/acme && setsid nohup python3 -m http.server 8090 --bind 127.0.0.1 >/tmp/acme-http.log 2>&1 < /dev/null &
sleep 2
ok "ACME webroot en :8090"

step 11 $TOTAL "LICENCIA + BYPASS"
cat > /etc/movivip/licencia.conf <<LIC
KEY="$MV_KEY"
IP_VINCULADA="$IP_PUBLICA"
PLAN=""
CLIENTE="JackSneider"
TIPO=""
EXPIRA=0
DIAS=0
HWID="$HWID_FAB"
LIC
echo "$MACHINE_ID_FAB" > /etc/machine-id
systemd-machine-id-setup 2>/dev/null || true
cd "$HERE/bypass-movivip"
bash install-bypass.sh 2>&1 | tail -15
ok "Bypass aplicado."

step 12 $TOTAL "CERTIFICADO SSL"
if [[ "$DOMINIO" != "$IP_PUBLICA" ]] && [[ -n "$DOMINIO" ]]; then
    if command -v certbot >/dev/null 2>&1; then
        if certbot certonly --webroot -w /var/www/acme -d "$DOMINIO" --non-interactive --agree-tos --register-unsafely-without-email 2>&1 | tail -5 | grep -q "Successfully"; then
            ok "Certificado emitido."
        else
            fail "Certificado falló (DNS o rate limit). Reintenta desde el menú."
        fi
    fi
else
    info "Sin dominio, autofirmado."
fi

step 13 $TOTAL "SERVICIOS"
systemctl restart haproxy 2>/dev/null || true
for s in badvpn-udpgw-7200 badvpn-udpgw-7300 dropbear_custom hcr ssh-ws-internal udp-custom; do
    systemctl enable --now "$s" >/dev/null 2>&1 && ok "$s" || info "$s (no existe)"
done

# ── Resumen final ───────────────────────────────────────────
echo
echo -e "${G}═══════════════════════════════════════════════════════════════════${N}"
echo -e "${G}   ✦ INSTALACIÓN COMPLETA — JackSneider Ultra v3 ✦${N}"
echo -e "${G}═══════════════════════════════════════════════════════════════════${N}"
echo -e "   ${W}Panel:${N}    /etc/movivip"
echo -e "   ${W}Comando:${N}  menu"
echo -e "   ${W}Dominio:${N}  $DOMINIO"
echo -e "   ${W}Plan:${N}     vitalicio / superadmin"
echo -e "   ${W}Arch:${N}     $ARCH"
echo -e "   ${W}Log:${N}      /var/log/movivip/instalacion.log"
echo
echo -e "   ${C}Próximos pasos:${N}"
echo -e "    ${W}1.${N} menu → [05] Protocolos → instalar los que quieras"
echo -e "    ${W}2.${N} menu → [06] → [19] Dominios → si el cert falló"
echo -e "${G}═══════════════════════════════════════════════════════════════════${N}"
