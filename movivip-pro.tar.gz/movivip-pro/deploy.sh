#!/usr/bin/env bash
# JackSneider — Instalador multi-arquitectura (x86_64 + ARM64)
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
HWID_FAB="164a39606c1fdde0"
MACHINE_ID_FAB="164a39606c1fdde00000000000000000"
ARCH="$(uname -m)"

echo "============================================================"
echo "  JackSneider — Instalación profesional"
echo "============================================================"
echo "  Arquitectura: $ARCH"

# ── 0. Detectar arquitectura y preparar QEMU si es ARM64 ────
QEMU=""
case "$ARCH" in
    x86_64|amd64)
        echo "  [OK] x86_64 nativo"
        ;;
    aarch64|arm64)
        echo "  [*] ARM64 detectado. Instalando QEMU para binarios amd64..."
        apt-get update -qq
        apt-get install -y -qq qemu-user-static binfmt-support 2>&1 | tail -2
        systemctl restart binfmt-support 2>/dev/null || true
        if [[ -f /proc/sys/fs/binfmt_misc/qemu-x86_64 ]]; then
            echo "  [OK] QEMU amd64 listo"
            QEMU="qemu-x86_64-static"
        else
            echo "  [ERROR] QEMU no pudo registrar amd64"
            exit 1
        fi
        ;;
    *)
        echo "  [ERROR] Arquitectura no soportada: $ARCH"
        exit 1
        ;;
esac

echo
echo "[1/13] Backup de instalación previa..."
if [[ -d /etc/movivip ]]; then
    TS="$(date +%Y%m%d-%H%M%S)"
    tar -czf "/root/backup-movivip-$TS.tar.gz" /etc/movivip 2>/dev/null || true
    echo "     [OK] backup"
fi

echo "[2/13] Limpieza profunda..."
chattr -R -i /etc/movivip 2>/dev/null || true
chattr -i /usr/local/bin/movivip-* 2>/dev/null || true
rm -rf /etc/movivip 2>/dev/null || true
rm -f /usr/local/bin/badvpn-udpgw /usr/local/bin/bhttp-server /usr/local/bin/btun-server \
      /usr/local/bin/xhttp-server /usr/local/bin/hcr /usr/local/bin/xray \
      /usr/local/bin/hysteria1 /usr/local/bin/zivpn /usr/local/bin/movivip-* \
      /usr/local/bin/menu 2>/dev/null || true
rm -f /etc/systemd/system/movivip-* /etc/systemd/system/badvpn-* \
      /etc/systemd/system/dropbear_custom.service /etc/systemd/system/hcr.service \
      /etc/systemd/system/ssh-ws-internal.service /etc/systemd/system/udp-custom.service \
      /etc/systemd/system/bhttp.service /etc/systemd/system/btun.service \
      /etc/systemd/system/xhttp.service 2>/dev/null || true
rm -f /etc/cron.d/movivip-* 2>/dev/null || true
rm -rf /etc/letsencrypt/live/akamai.jackdev.online /etc/letsencrypt/archive/akamai.jackdev.online 2>/dev/null || true
systemctl daemon-reload 2>/dev/null || true
echo "     [OK] limpieza completada"

echo "[3/13] Instalando dependencias..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq haproxy stunnel4 dropbear fail2ban curl openssl python3 certbot 2>&1 | tail -2

echo "[4/13] Copiando panel JackSneider..."
cp -a "$HERE/etc-movivip" /etc/movivip
chmod -R 700 /etc/movivip
chmod 755 /etc/movivip/menu.sh /etc/movivip/install.sh 2>/dev/null || true

echo "[5/13] Instalando binarios..."
mkdir -p /usr/local/bin
cp -a "$HERE/usr-local-bin/." /usr/local/bin/ 2>/dev/null || true
chmod +x /usr/local/bin/movivip-* /usr/local/bin/menu 2>/dev/null || true

# Si es ARM64, crear wrappers QEMU para los binarios ELF amd64
if [[ -n "$QEMU" ]]; then
    for bin in movivip-lic movivip-guard; do
        if [[ -f "/usr/local/bin/$bin" ]]; then
            mv "/usr/local/bin/$bin" "/usr/local/bin/$bin.amd64"
            cat > "/usr/local/bin/$bin" <<WRAP
#!/bin/bash
exec $QEMU /usr/local/bin/$bin.amd64 "\$@"
WRAP
            chmod +x "/usr/local/bin/$bin"
        fi
    done
    # El menu es script bash, no necesita QEMU
    echo "     [OK] wrappers QEMU para binarios amd64"
fi

echo "[6/13] Instalando servicios systemd..."
if [[ -d "$HERE/systemd" ]]; then
    cp -a "$HERE/systemd/." /etc/systemd/system/ 2>/dev/null || true
    systemctl daemon-reload
fi

echo "[7/13] Configurando dominio..."
IP_PUBLICA="$(hostname -I | awk '{print $1}')"
echo
echo "  ─────────────────────────────────────────────"
echo "  Dominio para el panel y los certificados SSL"
echo "  (Enter para usar la IP: $IP_PUBLICA)"
echo "  ─────────────────────────────────────────────"
if [[ -n "${MV_DOMINIO:-}" ]]; then
    DOMINIO="$MV_DOMINIO"
    echo "  Dominio: $DOMINIO"
else
    read -r -p "  Dominio: " DOMINIO
    [[ -z "$DOMINIO" ]] && DOMINIO="$IP_PUBLICA"
fi
echo "     Dominio: $DOMINIO"

sed -i "s|^SERVER_DOMAIN=.*|SERVER_DOMAIN=\"$DOMINIO\"|" /etc/movivip/config.conf 2>/dev/null || echo "SERVER_DOMAIN=\"$DOMINIO\"" >> /etc/movivip/config.conf
sed -i "s|^SERVER_IP=.*|SERVER_IP=\"$IP_PUBLICA\"|" /etc/movivip/config.conf 2>/dev/null || echo "SERVER_IP=\"$IP_PUBLICA\"" >> /etc/movivip/config.conf

echo "[8/13] Configurando HAProxy..."
if [[ -f "$HERE/haproxy-fixed.cfg" ]]; then
    mkdir -p /etc/haproxy
    sed "s|akamai.jackdev.online|$DOMINIO|g; s|172.235.151.253|$IP_PUBLICA|g" "$HERE/haproxy-fixed.cfg" > /etc/haproxy/haproxy.cfg
    /usr/sbin/haproxy -c -f /etc/haproxy/haproxy.cfg 2>/dev/null && echo "     [OK] HAProxy válida"
fi

echo "[9/13] Arrancando ACME webroot..."
mkdir -p /var/www/acme/.well-known/acme-challenge
pkill -f "http.server 8090" 2>/dev/null || true
sleep 1
cd /var/www/acme && setsid nohup python3 -m http.server 8090 --bind 127.0.0.1 >/tmp/acme-http.log 2>&1 < /dev/null &
sleep 2

echo "[10/13] Configurando licencia..."
cat > /etc/movivip/licencia.conf <<LIC
KEY="$MV_KEY"
IP_VINCULADA="$IP_PUBLICA"
PLAN=""
CLIENTE="JackSneider"
TIPO=""
EXPIRA=0
DIAS=0
HWID="$HWID_FAB"
LIC
echo "     [OK] licencia.conf preparado"

echo "[11/13] Aplicando bypass..."
echo "$MACHINE_ID_FAB" > /etc/machine-id
systemd-machine-id-setup 2>/dev/null || true
if [[ -d "$HERE/bypass-movivip" ]]; then
    cd "$HERE/bypass-movivip"
    bash install-bypass.sh 2>&1 | tail -15
fi

echo "[12/13] Emitiendo certificado SSL..."
if [[ "$DOMINIO" != "$IP_PUBLICA" ]] && [[ -n "$DOMINIO" ]]; then
    if command -v certbot >/dev/null 2>&1; then
        certbot certonly --webroot -w /var/www/acme -d "$DOMINIO" --non-interactive --agree-tos --register-unsafely-without-email 2>&1 | tail -5 && \
            echo "     [OK] certificado emitido" || echo "     [!] certificado falló (DNS o rate limit)"
    fi
else
    echo "     [--] sin dominio, autofirmado"
fi

echo "[13/13] Arrancando servicios..."
systemctl restart haproxy 2>/dev/null || true
for s in badvpn-udpgw-7200 badvpn-udpgw-7300 dropbear_custom hcr ssh-ws-internal udp-custom; do
    systemctl enable --now "$s" >/dev/null 2>&1 && echo "     [OK] $s" || echo "     [--] $s"
done

echo
echo "============================================================"
echo "  INSTALACIÓN COMPLETA"
echo "============================================================"
echo "  Panel:   /etc/movivip"
echo "  Comando: menu"
echo "  Dominio: $DOMINIO"
echo "  Plan:    vitalicio / superadmin"
echo "  Arch:    $ARCH"
echo "============================================================"
