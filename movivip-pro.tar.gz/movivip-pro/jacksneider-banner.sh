#!/bin/bash
if [[ $- == *i* ]]; then
    clear
    
    # Colores (Estilo Cyberpunk suave)
    C="\033[38;5;51m"  # Cyan brillante
    M="\033[38;5;201m" # Magenta neón
    G="\033[38;5;46m"  # Verde Matrix
    Y="\033[38;5;226m" # Amarillo
    W="\033[38;5;255m" # Blanco
    R="\033[0m"

    # Datos
    IP_PUB=$(curl -4 -s --max-time 2 ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
    CONEXIONES=$( (who | awk '{print $1}' && ps aux | grep -E "dropbear|sshd:" | grep -v grep | awk '{print $1}') | sort -u | wc -l)
    UPTIME=$(uptime -p | sed 's/up //' | cut -c1-15)
    RAM=$(free -m | awk '/Mem:/ {printf "%d%%", $3/$2 * 100}')
    DISCO=$(df -h / | awk 'NR==2 {print $5}')
    CPU=$(top -bn1 | grep "Cpu(s)" | sed "s/.*, *\([0-9.]*\)%* id.*/\1/" | awk '{print 100 - $1"%"}')

    # Logo DIOS ES AMOR
    echo -e "${C}"
    echo "          ██████╗ ██╗ ██████╗ ███████╗"
    echo "          ██╔══██╗██║██╔═══██╗██╔════╝"
    echo "          ██║  ██║██║██║   ██║███████╗"
    echo "          ██║  ██║██║██║   ██║╚════██║"
    echo "          ██████╔╝██║╚██████╔╝███████║"
    echo "          ╚═════╝ ╚═╝ ╚═════╝ ╚══════╝"
    echo -e "${M}                 E S   A M O R${R}"
    echo ""

    # Caja de información mejorada (usando printf para alinear perfecto)
    echo -e "${M}  ╔══════════════════════════════════════════╗${R}"
    echo -e "${M}  ║${G}          ⚡ ESTADO DEL SERVIDOR ⚡         ${M}║${R}"
    echo -e "${M}  ╠══════════════════════════════════════════╣${R}"
    
    printf "${M}  ║${R}  ${Y}📍 IP Pública:${R}  ${C}%-20s${R} ${M}║${R}\n" "$IP_PUB"
    printf "${M}  ║${R}  ${Y}👥 Conectados:${R}  ${C}%-20s${R} ${M}║${R}\n" "$CONEXIONES"
    printf "${M}  ║${R}  ${Y}⏱  Uptime:${R}     ${C}%-20s${R} ${M}║${R}\n" "$UPTIME"
    printf "${M}  ║${R}  ${Y}🧠 RAM:${R}         ${C}%-20s${R} ${M}║${R}\n" "$RAM"
    printf "${M}  ║${R}  ${Y}💾 Disco:${R}       ${C}%-20s${R} ${M}║${R}\n" "$DISCO"
    printf "${M}  ║${R}  ${Y}⚙️  CPU:${R}         ${C}%-20s${R} ${M}║${R}\n" "$CPU"

    echo -e "${M}  ╠══════════════════════════════════════════╣${R}"
    echo -e "${M}  ║${R}  ${C}📢 ${W}t.me/+I-VOBBPsGSZjOGE5${R}         ${M}║${R}"
    echo -e "${M}  ║${R}  ${C}📱 ${W}WhatsApp: 3181882682${R}              ${M}║${R}"
    echo -e "${M}  ╚══════════════════════════════════════════╝${R}"
    
    echo ""
    echo -e "${G}       ✝  \"Jehová es mi pastor; nada me faltará.\"${R}"
    echo -e "${R}"
fi
