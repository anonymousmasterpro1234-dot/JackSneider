#!/usr/bin/env bash

secure_movivip_permissions() {
    [[ -d /etc/movivip ]] || return 1
    find /etc/movivip -type d -exec chmod 0755 {} + || return 1
    find /etc/movivip -type f -exec chmod go-w {} + || return 1
    for _secret_file in config.conf licencia.conf cf.conf xui-credentials; do
        if [[ -f "/etc/movivip/$_secret_file" ]]; then
            chmod 0600 "/etc/movivip/$_secret_file" || return 1
        fi
    done
}

# ============================================================================
# JackSneider — Instalador v10 Full (orquestador modular)
#
# Estructura:
#   0. Licencia           → clave + validación ANTES de copiar nada
#   1. Preflight          → validaciones antes de tocar nada
#   2. Sistema base       → paquetes, SSL, stunnel, firewall
#   3. Config servidor    → dominio (solo hace falta para el certificado SSL/TLS)
#   4. Protocolos         → selección e instalación
#   5. Cierre             → permisos, monitoreo, resumen
#
# El unico DNS que toca este instalador es PREGUNTAR el dominio: sin el no
# hay certificado TLS y el panel no arranca por HTTPS. Crear registros,
# subdominios o distribuciones no es cosa del instalador; eso vive en las
# herramientas del panel, que el administrador abre cuando quiere.
#
# Clave de licencia: argumento, $MOVIVIP_LICENSE_KEY, o se pregunta.
# Sin clave válida el instalador aborta y no deja archivos en el servidor.
# Se valida DOS veces: al principio y otra vez antes del cierre.
# ============================================================================
set -uo pipefail

# VINCULO NUCLEO UI.SH (NEBULA)
BASE_UI=""
[ -f "${BASE_UI}/lib/ui.sh" ] && . "${BASE_UI}/lib/ui.sh" 2>/dev/null || true

# ============================================================================
# CAPA DE PRESENTACIÓN (ui.sh + mvui) — cargar DESDE EL ORIGEN antes de copiar
# ============================================================================
INSTALL_LOG="/var/log/movivip-install.log"
INSTALL_STEP=0
INSTALL_TOTAL=5
MVUI_ERRORES=0
MVUI_AVISOS=0

_MVUI_DIR=""
for _c in "${BASE:-}/lib" "$(dirname "${BASH_SOURCE[0]}")/lib" /etc/movivip/lib; do
    [[ -n "$_c" && -f "$_c/mvui.sh" ]] && _MVUI_DIR="$_c" && break
done
# Antes era:  [[ -n "$_MVUI_DIR" ]] && . "$_MVUI_DIR/mvui.sh" || true
#
# Con ese "|| true", si mvui.sh no venia en el payload la instalacion seguia
# adelante sin una sola funcion de interfaz. Cada mv_fase, mv_error y mv_detalle
# de aqui en adelante era un "command not found" y el instalador continuaba a
# ciegas, devolviendo un codigo de salida que no significaba nada. Sin UI no se
# puede instalar bien ni saber que ha pasado: es una dependencia dura.
#
# Se usa printf y no mv_error porque justo cuando esto falla, mv_error puede no
# existir. Un fallo de arranque tiene que poder imprimirse sin la libreria que
# ha fallado.
if [[ -z "$_MVUI_DIR" ]]; then
    printf '\n[FATAL] No se encontro lib/mvui.sh en ninguna ruta.\n' >&2
    printf '        Rutas probadas:\n' >&2
    for _c in "${BASE:-}/lib" "$(dirname "${BASH_SOURCE[0]}")/lib" /etc/movivip/lib; do
        printf '          - %s\n' "$_c" >&2
    done
    printf '        El payload esta incompleto o corrupto. Nada se instalo.\n' >&2
    exit 1
fi
# lib/ui.sh es el design system compartido ("JACKSNEIDER-VIP"): banner,
# secciones y paleta que ya usan menu.sh y las herramientas. Sin el, el
# instalador saldria con una estetica propia y el cliente veria dos productos
# distintos dentro de la misma instalacion. Es dependencia dura, igual que
# mvui.sh, y se carga ANTES: mvui.sh adopta su paleta al inicializar.
#
# Se usa printf y no mv_error por el mismo motivo de arriba: en este punto
# mv_error puede no existir aun.
if [[ ! -f "$_MVUI_DIR/ui.sh" ]]; then
    printf '\n[FATAL] No se encontro lib/ui.sh en %s\n' "$_MVUI_DIR" >&2
    printf '        El payload esta incompleto o corrupto. Nada se instalo.\n' >&2
    exit 1
fi
if ! . "$_MVUI_DIR/ui.sh"; then
    printf '\n[FATAL] No se pudo cargar %s\n' "$_MVUI_DIR/ui.sh" >&2
    printf '        Suele ser sintaxis rota en ui.sh.\n' >&2
    printf '        Nada se instalo.\n' >&2
    exit 1
fi
if ! . "$_MVUI_DIR/mvui.sh"; then
    printf '\n[FATAL] No se pudo cargar %s\n' "$_MVUI_DIR/mvui.sh" >&2
    printf '        Suele ser sintaxis rota en mvui.sh.\n' >&2
    printf '        Nada se instalo.\n' >&2
    exit 1
fi
MVUI_LOG="$INSTALL_LOG"

log_error() {
    local linea="$1" desc="$2" cmd="$3" err="$4"
    printf '[%s] FALLO en linea %s: %s | cmd: %s | salida: %s\n' \
        "$(date '+%Y-%m-%d %H:%M:%S')" "$linea" "$desc" "$cmd" "${err:0:400}" \
        >>"$INSTALL_LOG" 2>/dev/null
}

run_cmd() {
    local desc="$1" linea="$2"; shift 2
    mv_correr "$desc" "" "$*"
    local rc=$?
    if (( rc != 0 )); then
        MVUI_ERRORES=$((MVUI_ERRORES + 1))
        log_error "$linea" "$desc" "$*" "$(tail -5 "$INSTALL_LOG" 2>/dev/null | tr '\n' ' ')"
    fi
    return 0
}

step() { INSTALL_STEP=$((INSTALL_STEP + 1)); mv_fase "$1"; }
_anim_bar() { :; }
show_progress_bar() { local d="${3:-}"; mv_ok "$d"; }

# ============================================================================
# GATE DE LICENCIA — se ejecuta ANTES de copiar nada a /etc/movivip
# ============================================================================
# Por que aqui y no despues de copiar:
#   * `movivip-lic` es el unico que decide firma del proveedor, HWID y
#     revocacion. Sin el no hay decision de licencia que tomar.
#   * Si se copia primero, una instalacion abandonada deja los 262
#     archivos del producto en el disco del cliente sin que se haya
#     comprado licencia nunca.
#   * La comprobacion previa usa `--test`, que NO escribe licencia.conf
#     ni avisa al bot: si la clave es invalida, no queda ni un byte en
#     /etc/movivip. Fail-closed de verdad.
#   * La activacion real (--key) va DESPUES de copiar, para que
#     licencia.conf quede escrito junto al resto del payload.
#
# La clave entra por esta via, en orden de prioridad:
#   1. $MOVIVIP_LICENSE_KEY   (headless)
#   2. $1                     (lo que pasa install-auto.sh)
#   3. prompt interactivo     (setup-amd64.sh sin argumentos)
MV_LIC_BIN_LOCAL=""
MV_LICENSE_KEY=""
_MV_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Busca el validador. En instalacion nueva todavia no esta en
# /usr/local/bin, asi que la primera fuente es el payload extraido.
#
# Que un fichero sea ejecutable no dice nada de que sea el validador. Antes
# esta funcion se conformidad con "[ -x ]", con lo que MV_LIC_BIN=/bin/true
# hacia que el gate devolviera 0 y la instalacion siguiera sin licencia: no
# hacia falta saber la clave, solo conocer una ruta.
#
# Ahora un candidato tiene que pasar las cuatro comprobaciones:
#   1. existe y es ejecutable
#   2. es un ELF (descarta scripts de shell y ficheros de texto)
#   3. no es escribible por grupo ni por otros (descarta /tmp y similares)
#   4. lo posee root (estos scripts corren como root)
#
# La busqueda por PATH tambien se quito: PATH lo controla quien invoca, y un
# "movivip-lic" en un directorio anterior ya era un sustituto gratis.
#
# MV_LIC_BIN sigue existiendo para desarrollo, pero ya no manda por si solo:
# hay que poner ademas MV_LIC_BIN_TRUST=1. Sin ese segundo permiso, un
# MV_LIC_BINjected en el entorno se ignora y gana una ruta conocida.
_mv_validador_confiable() {
    local c="$1"
    [ -n "$c" ] && [ -f "$c" ] && [ -x "$c" ] || return 1

    # Via de escape para el arnes de pruebas, que mete un script de shell
    # donde va el validador. Sin esto ninguna prueba podria ejercitar los
    # flujos de instalacion. Exige permiso explicito y aparte: en
    # produccion esto no se activa nunca.
    [ "${MV_LIC_BIN_TRUST:-0}" = "1" ] && return 0

    # 2. cabecera ELF
    [ "$(head -c 4 "$c" 2>/dev/null | od -An -tx1 | tr -d ' \n')" = "7f454c46" ] || return 1

    # 3. permisos: nadie mas que root puede escribirlo
    local perms
    perms="$(stat -c '%a' "$c" 2>/dev/null)" || return 1
    [ $(( 0$perms & 0022 )) -eq 0 ] || return 1

    # 4. propiedad root
    [ "$(stat -c '%u' "$c" 2>/dev/null)" = "0" ] || return 1
    return 0
}

_mv_resolver_validador() {
    local c

    # Override de desarrollo: exige permiso explicito aparte.
    c="${MV_LIC_BIN:-}"
    if [ -n "$c" ] && [ "${MV_LIC_BIN_TRUST:-0}" = "1" ]; then
        _mv_validador_confiable "$c" && { printf '%s' "$c"; return 0; }
        # mv_aviso todavia no existe aqui: las librerias se sourcean mas
        # abajo, asi que el aviso va directo a stderr.
        printf 'aviso: MV_LIC_BIN no es un validador confiable; se ignora.\n' >&2
    fi

    for c in "$_MV_SRC/bin/movivip-lic" \
             /usr/local/bin/movivip-lic /etc/movivip/bin/movivip-lic; do
        if _mv_validador_confiable "$c"; then printf '%s' "$c"; return 0; fi
    done
    return 1
}

# Ya hay licencia activa en este servidor? (instalacion/update)
_mv_lic_ya_valida() {
    local b
    b="$(_mv_resolver_validador)" || return 1
    "$b" --gate >/dev/null 2>&1
}

# Prompt con reintentos: una key mal tecleada no debe obligar a
# re-descargar 22 MB, pero tampoco se queda en bucle infinito.
#
# La clave se deja en la global MV_KEY_INPUT en vez de imprimirla: si esta
# funcion escribiera en stdout y su resultado se capturara con $(...), los
# avisos que imprime se pegarian a la clave y el validador recibiria basura.
MV_KEY_INPUT=""
_mv_pedir_clave() {
    local r intentos=0
    while (( intentos < 3 )); do
        if ! read -r -p "  Clave de licencia: " r; then
            mv_error "Entrada cerrada (Ctrl-D). No se instalo nada."
            return 1
        fi
        r="${r//[[:space:]]/}"
        if [ -n "$r" ]; then MV_KEY_INPUT="$r"; return 0; fi
        mv_aviso "La clave no puede quedar vacia."
        intentos=$((intentos+1))
    done
    return 1
}

gate_licencia() {
    MV_LIC_GATE_PASADA=$((${MV_LIC_GATE_PASADA:-0} + 1))
    mv_fase "Validacion de licencia (${MV_LIC_GATE_PASADA}. pasada)"

    # Reinstalacion/update: si ya hay una licencia activa, se sigue.
    # No se pide la clave de nuevo al cliente que ya la tiene.
    # Ojo: en la 2. pasada, con clave validada EN ESTA sesion, NO se
    # accepta el atajo del fichero local: el refuerzo existiria para nada.
    # Con la clave en memoria se fuerza la revalidacion online mas abajo.
    if [ "${MV_LIC_GATE_PASADA:-1}" -lt 2 ] || [ -z "${MV_LICENSE_KEY:-}" ]; then
        if _mv_lic_ya_valida; then
            mv_ok "Licencia activa detectada en este servidor"
            return 0
        fi
    fi

    if ! MV_LIC_BIN_LOCAL="$(_mv_resolver_validador)"; then
        mv_error "El paquete no incluye el validador de licencia (movivip-lic)."
        mv_error "Sin el no hay forma de comprobar la licencia: no se instala nada."
        return 1
    fi

    local KEY=""
    if [ -n "${MOVIVIP_LICENSE_KEY:-}" ]; then
        mv_detalle "Clave tomada de MOVIVIP_LICENSE_KEY"
        KEY="$MOVIVIP_LICENSE_KEY"
    elif [ -n "${MV_LICENSE_KEY:-}" ]; then
        # Segunda pasada del gate: la clave ya se valido en ESTA sesion.
        # No se vuelve a pedir, pero si se revalida contra el servidor,
        # que es justo el objetivo del refuerzo.
        mv_detalle "Revalidando la licencia tomada en esta sesion"
        KEY="$MV_LICENSE_KEY"
    elif [ "$#" -gt 0 ] && [ -n "${1:-}" ] && [ "${1#-}" = "$1" ]; then
        KEY="$1"
    elif [ -t 0 ]; then
        mv_p ""
        mv_detalle "Este producto requiere una clave de licencia valida."
        mv_p "  Telegram : JackSneider"
        mv_p "  WhatsApp : 3181882682"
        mv_p "  Web      : https://"
        mv_p ""
        _mv_pedir_clave || {
            mv_error "No se ingreso ninguna clave. No se instala nada."
            return 1
        }
        KEY="$MV_KEY_INPUT"
    else
        mv_error "Este producto requiere una clave de licencia."
        mv_error "Sin terminal no se puede preguntar: pasa la clave como"
        mv_error "argumento o define MOVIVIP_LICENSE_KEY. No se instala nada."
        return 1
    fi

    mv_detalle "Comprobando firma, HWID y revocacion..."
    local out rc detalle
    out="$("$MV_LIC_BIN_LOCAL" --test --json "$KEY" 2>/dev/null)"
    rc=$?
    if [ "$rc" -eq 0 ]; then
        MV_LICENSE_KEY="$KEY"
        mv_ok "Licencia valida (${KEY:0:6}****)"
        return 0
    fi

    # 2. pasada y fallo de RED (rc=2): no se aborta. La primera
    # validacion, al principio del instalador, si fue online y salio
    # bien; cortar aqui por un corte de internet dejaria el sistema a
    # medias justo antes del cierre. Solo se aborta si el servidor
    # contesto y dijo que la clave NO vale (rc=1: invalida o revocada),
    # que es exactamente lo que el refuerzo busca detectar.
    if [ "$rc" -eq 2 ] && [ "${MV_LIC_GATE_PASADA:-1}" -ge 2 ]; then
        mv_aviso "Segunda validacion sin respuesta del servidor de licencias."
        mv_aviso "Se continua con la primera validacion (online) del inicio."
        return 0
    fi

    detalle="$(printf '%s' "$out" \
        | sed -n 's/.*"detalle":"\([^"]*\)".*/\1/p')"
    if [ "$rc" -eq 2 ]; then
        mv_error "No se pudo contactar con el servidor de licencias."
        mv_aviso "Revisa la conexion a internet. No se instalo nada."
    else
        # Reinstalacion: si la clave es correcta pero HWID/IP cambiaron
        if printf '%s' "$detalle" | grep -qi "huella de maquina distinta\|machine fingerprint\|hwid"; then
            mv_error "Clave ${KEY:0:6}**** no valida: ${detalle}"
            mv_aviso "La clave esta atada a otro servidor (HWID/IP distinto)."
            mv_aviso "Si formateaste/recreaste la VPS, contacta a soporte para re-vincular la licencia."
            mv_aviso "Telegram: JackSneider  |  WhatsApp: 3181882682"
        else
            mv_error "Clave ${KEY:0:6}**** no valida${detalle:+: $detalle}"
            mv_aviso "No se instalo nada."
        fi
    fi
    mv_p "  Telegram : JackSneider   WhatsApp : 3181882682"
    return 1
}

# Escribe licencia.conf y avisa al bot. Solo si en ESTA ejecucion se
# valido una clave nueva: si ya habia licencia activa, no se toca nada.
activar_licencia() {
    [ -n "$MV_LICENSE_KEY" ] || return 0
    local b="$BASE/bin/movivip-lic"
    [ -x "$b" ] || b="$MV_LIC_BIN_LOCAL"
    [ -x "$b" ] || return 0
    mv_detalle "Registrando la licencia en el servidor..."
    if "$b" --key "$MV_LICENSE_KEY" >/dev/null 2>&1; then
        mv_ok "Licencia registrada"
    else
        mv_aviso "No se pudo escribir licencia.conf; se reintentara en el primer uso"
    fi
    return 0
}

# ============================================================================
# COPIA DEL PAYLOAD A /etc/movivip/
# ============================================================================
copiar_payload() {
    local src
    src=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
    if [[ "$src" != "/etc/movivip" && "$src" != "/etc/movivip/"* ]]; then
        mv_detalle "Copiando payload a /etc/movivip/ ..."
        mkdir -p /etc/movivip
        cp -a "$src"/. /etc/movivip/ || return 1
        secure_movivip_permissions || return 1
        cd /etc/movivip
    fi
}

# ============================================================================
# LIBRERÍAS BASE (tras copiar)
# ============================================================================
BASE="/etc/movivip"
CONFIG="$BASE/config.conf"

pkg_update() { apt-get update -y; }
pkg_install() { DEBIAN_FRONTEND=noninteractive apt-get install -y "$@"; }
pkg_clean() { apt-get clean; rm -rf /var/lib/apt/lists/*; }

# Las librerias de licencia NO se cargan aqui. Este bloque vivia antes
# del gate y era un bugs con dos caras:
#   * en instalacion nueva /etc/movivip no existe, asi que no cargaba nada
#   * en reinstalacion, licguard.sh hacia `exit 1` si la licencia no era
#     valida, matando install.sh ANTES de que el gate tuviera oportunidad
#     de pedir una clave nueva al cliente
# Se cargan dentro de main(), despues de validar y copiar.
#
# licguard.sh ya no esta en ninguna parte. Los 107 scripts del panel usaban
# sourcearlo desde su propio arbol para decidir si podian correr, lo que
# dejaba el gate en manos de un fichero de texto que el usuario del servidor
# puede editar. Ahora cada script invoca /usr/local/bin/movivip-guard --gate,
# que el stub instala fuera del arbol editable, y este instalador ya no tiene
# ninguna puerta que cruzar: la licencia se valida en el stub, en el binario,
# antes de descifrar el payload y antes de escribir un byte aqui.

# ============================================================================
# ORQUESTADOR PRINCIPAL
# ============================================================================
main() {
    # Cabecera de marca. Es lo primero que ve el cliente: el banner NEBULA
    # de lib/ui.sh, la misma identidad que el menu del panel. En salida sin
    # terminal mv_banner cae a texto plano, sin un solo escape.
    mv_banner "Instalador JackSneider" "v10 Full"

    # 0. Licencia. Fail-closed y antes de tocar /etc/movivip: si la clave
    #    no es valida, el servidor queda exactamente como estaba.
    gate_licencia "$@" || exit 1

    # 1. Copiar payload a /etc/movivip/
    copiar_payload || {
        mv_error "No se pudo copiar y proteger el payload en /etc/movivip"
        exit 1
    }

    # 2. Registrar la licencia recien validada (escribe licencia.conf)
    activar_licencia

    # Cargar resto de librerías (ya en /etc/movivip/lib/)
    #
    # Esto era:  [[ -f ... ]] && . "$BASE/lib/$lib" 2>/dev/null || true
    #
    # Ese "2>/dev/null || true" se comia los errores de carga. Por eso
    # mv_warn estuvo sin definir durante horas y el preflight se quejaba de un
    # comando inexistente sin que nadie entendiera de donde salia: la
    # libreria estaba rota, el error salia por stderr, y la redireccion lo
    # converto en un "--" silencioso. Fallos invisibles, que son los caros.
    #
    # Ahora si falta una libreria, o si al cargarla el shell devuelve error
    # (tipicamente sintaxis rota), la instalacion para aqui y lo dice.
    # scripts del panel al guard compilado: ya no lo sourceaba nadie y su
    # presenciaInviteaba a pensar que era la puerta, cuando lo unico que
    # defendia era un fichero de texto editable por el administrador.
    for lib in ui.sh mvui.sh nav.sh anim.sh fixcrlf.sh delivery.sh duracion.sh firebase-plan.sh licgate.sh ofuscar.sh arch.sh; do

        if [[ ! -f "$BASE/lib/$lib" ]]; then
            mv_error "Falta la libreria $lib en $BASE/lib/"
            mv_detalle "El payload esta incompleto. Vuelve a ejecutar la instalacion."
            exit 1
        fi
        if ! . "$BASE/lib/$lib"; then
            mv_error "No se pudo cargar la libreria $lib"
            mv_detalle "Suele ser sintaxis rota. Revisa $BASE/lib/$lib"
            exit 1
        fi
    done


    # 3. Preflight
    . "${BASE:-/etc/movivip}/lib/paso-preflight.sh"
    paso_preflight || exit 1

# Primero se cargan TODAS las librerías de paso, y luego se ejecutan. Antes
    # estaba intercalado (cargar un paso, ejecutarlo, cargar el siguiente), que
    # funciona, pero deja el ejecutor en medio de la lista de librerias y es
    # facil meter un paso nuevo sin cargarlo.
    . "${BASE:-/etc/movivip}/lib/paso-sistema.sh"
    . "${BASE:-/etc/movivip}/lib/paso-dominio.sh"
    . "${BASE:-/etc/movivip}/lib/paso-protocolos.sh"
    . "${BASE:-/etc/movivip}/lib/paso-cierre.sh"

    # lib/ofuscar.sh se carga la ultima: cierre_ofuscar (definida arriba) la
    # usa al ejecutarse. Sin ella la instalacion no podria garantizar que el
    # payload quede ofuscado, asi que un fallo aqui es payload incompleto.
    # ---- A partir de aqui se registra que pasos se han hecho de verdad -----
    #
    # install.sh llamaba a sus pasos sueltos y no guardaba si habian ocurrido.
    # Con eso, un paso podia no ejecutarse (por no existir, por un typo, por un
    # fallo de carga) y el instalador seguia hasta el final con un cartel de
    # exito. Ya ha pasado con paso_protocolos: una letra de diferencia, ningun
    # protocolo instalado, y "JackSneider instalado correctamente" en
    # pantalla.
    #
    # mv_paso envuelve cada llamada y apunta el resultado. Al final,
    # mv_pasos_completos decide si se puede decir que se instalo.
    mv_paso "Sistema base"             paso_sistema
    mv_paso "Configuración del servidor" paso_config_servidor
    # El nombre real es paso_protocolos, con doble "o". install.sh pedia
    # paso_protocols, con una sola: "command not found", ningun protocolo
    # instalado, y despues el instalador anunciaba exito. Un typo de una letra
    # que cargo el producto entero de forma invisible.
    mv_paso "Protocolos"               paso_protocolos

    # Segunda validacion de licencia (refuerzo). La primera fue antes de
    # copiar un solo byte; esta es justo antes de firmar el cierre. Entre
    # las dos pasan los pasos largos, con lo que una clave revocada,
    # caducada o viciada por el validador NO llega a dejar el sistema
    # instalado y con los puertos abiertos: si aqui cae, se aborta.
    # Con la licencia ya activa en esta sesion, gate la reconoce al
    # instante (_mv_lic_ya_valida) y no vuelve a pedir nada.
    gate_licencia "$@" || exit 1

    # Cierre y resumen. Devuelve != 0 si falta algun paso, y ese codigo tiene
    # que llegar hasta el proceso: es la unica forma de que un script que
    # llama al instalador sepa que fallo.
    paso_cierre || exit 1

    # Ultimo acto de la instalacion: el instalador se retira de la VPS y
    # reinicia. Cuando el servidor vuelve, en disco ya no queda install.sh.
    rm -f -- "$0"
    mv_ok "Instalación finalizada — reiniciando..."
    reboot
    return 0
}

# ----------------------------------------------------------------------------
# Seguimiento de pasos: lo que permite decir la verdad al final
# ----------------------------------------------------------------------------
declare -a MV_PASOS_OK=()
declare -a MV_PASOS_KO=()
declare -a MV_PASOS_ESPERADOS=(
    "Sistema base"
    "Configuración del servidor"
    "Protocolos"
)
MV_PASOS_FALTANTES=()

# mv_paso "Nombre" funcion...
mv_paso() {
    local nombre="$1"; shift
    mv_detalle "Ejecutando: $nombre"
    "$@"
    local rc=$?
    if (( rc == 0 )); then
        MV_PASOS_OK+=("$nombre")
        _mvui_log "  paso OK: $nombre"
    else
        MV_PASOS_KO+=("$nombre (codigo $rc)")
        _mvui_log "  paso FALLO: $nombre (codigo $rc)"
    fi
    return $rc
}

# mv_pasos_completos: true solo si todo lo esperado esta en la lista de OK.
mv_pasos_completos() {
    MV_PASOS_FALTANTES=()
    local esperado
    for esperado in "${MV_PASOS_ESPERADOS[@]}"; do
        local visto=0 ok
        for ok in ${MV_PASOS_OK[@]+"${MV_PASOS_OK[@]}"}; do
            [[ "$ok" == "$esperado" ]] && { visto=1; break; }
        done
        (( visto )) || MV_PASOS_FALTANTES+=("$esperado")
    done

    if (( ${#MV_PASOS_KO[@]} > 0 )); then
        MV_PASOS_FALTANTES+=("${MV_PASOS_KO[@]}")
    fi

    (( ${#MV_PASOS_FALTANTES[@]} == 0 ))
}

# ============================================================================
# PASO 2: CONFIGURACIÓN DEL SERVIDOR (extraído del monolito original)
# ============================================================================
paso_config_servidor() {
    mv_fase "Configuración del servidor"

    # La IP se resuelve FUERA de run_cmd, y no es cosmetico.
    # run_cmd -> mv_correr hace: salida=$(eval "$cmd" 2>&1)
    # y $(...) es una subshell. SERVER_IP asignado dentro de ella se pierde al
    # salir, asi que la comprobacion siguiente lo encontraba SIEMPRE vacio y
    # toda instalacion moria aqui con "No se pudo obtener IP publica". No era un
    # fallo de red ni del servidor: era imposible que funcionara. Esta es la
    # unica linea del payload que sufria este patron, pero conviene no
    # repetirlo: asignar a traves de run_cmd no propaga nada al shell padre.
    mv_spin_iniciar "Obteniendo IP pública"
    SERVER_IP=""
    for _fuente in \
        "https://api.ipify.org" \
        "https://ifconfig.me/ip" \
        "http://checkip.amazonaws.com" \
        "https://icanhazip.com"; do
        [[ -n "$SERVER_IP" ]] && break
        SERVER_IP="$(curl -fsS --max-time 10 "$_fuente" 2>/dev/null || true)"
        SERVER_IP="${SERVER_IP//[$'\r\n' ]/}"
    done

    # Ultimo recurso: primera IP del host que no sea loopback. En un VPS con
    # IP propia es la correcta; detras de NAT dara una privada, que es mejor
    # que no tener nada pero conviene decirlo en voz alta.
    if [[ -z "$SERVER_IP" ]]; then
        SERVER_IP="$(hostname -I 2>/dev/null | tr ' ' '\n' | grep -v '^127\.' | grep -v '^$' | head -1)"
        if [[ -n "$SERVER_IP" ]]; then
            mv_aviso "No se pudo contactar con un servicio de IP publica."
            mv_aviso "Se usara la IP local del servidor ($SERVER_IP)."
            mv_aviso "Si el panel quedara fuera de alcance, revisa el NAT."
        fi
    fi

    # Validar forma. Sin esto, un proxy o un captive portal que devuelva HTML
    # se guardaria como "IP" y reventaria mas downstream, en un sitio peor.
    if [[ -n "$SERVER_IP" && ! "$SERVER_IP" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]]; then
        mv_aviso "El servicio de IP devolvio algo que no es una IPv4; se descarta."
        SERVER_IP=""
    fi

    if [[ -z "$SERVER_IP" ]]; then
        mv_error "No se pudo obtener la IP publica de este servidor"
        mv_detalle "Comprobado a mano con: curl -4 -fsS https://api.ipify.org"
        mv_detalle "Si tampoco responde, el servidor no tiene salida a internet."
        exit 1
    fi

    mv_spin_terminar ok
    mv_detalle "IP detectada: $SERVER_IP"

    # Dominio. Antes el prompt vivia aqui mismo, y solo se preguntaba en
    # modo interactivo: en headless se aceptaba SERVER_DOMAIN tal cual, sin
    # validar ni normalizar. Un "https://Panel.MiDominio.com/" colado a mano
    # pasaba el chequeo y reventaba mas tarde, al emitir el certificado.
    # paso-dominio.sh normaliza, valida y repregunta. No pregunta por el
    # proveedor DNS: el dominio es el mismo sea cual sea quien lo tenga.
    mv_configurar_dominio || exit 1
    export SERVER_DOMAIN

    # Aqui NO se toca ningun proveedor DNS. Antes se guardaban CF_EMAIL y
    # CF_KEY en $BASE/cf.conf si venian por entorno; ese cf.conf era la
    # puerta con la que slowdns.sh y cloudflare.sh creaban registros solos,
    # un instalador que ademas de instalar empezaba a tocar la zona DNS de
    # un dominio ajeno. El dominio solo se pregunta para el certificado
    # SSL/TLS; crear o cambiar registros es labor del administrador desde
    # las herramientas del panel.

    # Directorio base
    mkdir -p "$BASE"/{protocolos,usuarios,sistema,logs}

    # Secreto HWID
    HWID_SECRET=$(openssl rand -hex 32 2>/dev/null || od -An -N32 -tx1 /dev/urandom 2>/dev/null | tr -d ' \n')
    if ! [[ "$HWID_SECRET" =~ ^[[:xdigit:]]{64}$ ]]; then
        mv_error "No se pudo generar un secreto HWID criptográficamente seguro"
        exit 1
    fi

    # Persistir config básica
    cat > "$CONFIG" <<EOF
SERVER_IP="$SERVER_IP"
SERVER_DOMAIN="$SERVER_DOMAIN"
HWID_SECRET="$HWID_SECRET"
INSTALL_DATE="$(date '+%Y-%m-%d %H:%M:%S')"
VERSION="v10 Full"
EOF
    chmod 600 "$CONFIG"
    secure_movivip_permissions || {
        mv_error "No se pudieron asegurar los permisos de /etc/movivip"
        exit 1
    }
    mv_ok "Configuración del servidor guardada"
}

# ============================================================================
# ENTRY POINT
# ============================================================================
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi