# MoviVIPNetwork - Paquetes de distribución por arquitectura

Generar los archivos con Go:

```sh
go run ./cmd/movivip build-dist
```

Para empaquetar una sola arquitectura o elegir otro directorio de salida:

```sh
go run ./cmd/movivip build-dist --arch amd64 --out ./dist
```

`build_dist_all_arch.sh` se conserva durante la migración como referencia de
compatibilidad; no se ha retirado del flujo existente.

El empaquetador acepta amd64, 386, armv5/6/7, armhf, arm64, riscv64,
loong64, s390x, mips/mipsle/mips64/mips64le y ppc64/ppc64le.

Los paquetes incluyen el árbol de scripts; el empaquetador no compila,
convierte ni valida los binarios de los protocolos para cada arquitectura.
La disponibilidad de cada protocolo depende de que su binario o su release
de terceros publique una compilación compatible con la arquitectura objetivo.
La normalizacion de CRLF se hace sobre el staging del paquete, nunca sobre los
archivos fuente; `.ltm`, `.git` y el directorio de salida se excluyen del bundle.

## Instaladores Go firmados por arquitectura

Este flujo es distinto de `build-dist`: crea los ejecutables autocontenidos
`setup-linux-*` y los archivos `.meta` correspondientes. La salida contiene
solo los ejecutables y metadatos: no incluye envoltorios `.sh`,
`install-auto.sh`, `VERSION` ni `SHA256SUMS`.
Compila el validador de licencia, el guard y el stub para cada arquitectura,
normaliza y valida una copia temporal del árbol, y no modifica las fuentes.
Cada arquitectura conserva `payload-<arch>.meta` (descriptor firmado) y
`setup-linux-<arch>.meta` (SHA-256 del ejecutable).

Desde la raíz de `MOVIVIP PRODUCION`:

```powershell
go run ./cmd/release -module . -in . `
  -out ..\movivip-release-8.2.20 `
  -signkey C:\secure\movivip-ed25519.b64
```

El comando selecciona las 15 arquitecturas Linux admitidas por defecto; se
puede limitar la lista con `-targets amd64,arm64`. `-out` debe ser un
directorio nuevo y quedar fuera del árbol que se empaqueta. La clave debe ser
un archivo Base64 con la clave privada Ed25519 de 64 bytes; mantenla fuera del
repositorio y no la incluyas en el payload. El empaquetador excluye del payload
el código de construcción (`cmd`, `internal`, `licence`), pruebas y artefactos
locales; conserva los scripts y activos de ejecución.
Esta clave firma el payload distribuido y es distinta de las licencias, que se
validan en línea con el firmador de la VPS; ese servicio no proporciona la
clave privada de firma del release.

El repositorio no incluye una clave de firma de producción. Sin el archivo
privado correcto, el comando debe fallar y no se debe publicar el artefacto.
No se deben sustituir las claves de producción por una clave de prueba.

Matriz de binarios confirmados por los instaladores:

| Protocolo | Arquitecturas |
|---|---|
| Xray | Las arquitecturas indicadas arriba, mediante el instalador oficial |
| Sing-box 1.14.4 (TUIC, AnyTLS, Naive) | amd64, 386, armv5/6/7, arm64, mips/mipsle/mips64/mips64le, loong64, riscv64, s390x, ppc64le |
| Hysteria v1.3.5 | amd64, 386, armv5, armv7, arm64, mipsle, s390x |
| DTunnel v3.2.0 | amd64, 386, armv7, arm64 |
| ZiVPN 1.4.9 | amd64, armv7, arm64 |
| SlowDNS (dnstt) | amd64 |

`arm` se usa solo para hosts armv7 en los instaladores sin asset específico;
sing-box también publica un asset verificado para armv6. SlowDNS se limita a amd64 mientras no haya un origen
confiable verificado para sus otros binarios. Los instaladores rechazan las
arquitecturas sin un asset confirmado en lugar de descargar un ejecutable
incompatible.

Sing-box descarga un asset oficial con SHA-256 fijado por arquitectura. Usa el
certificado Certbot existente para `SERVER_DOMAIN`, sin cambiar los listeners
de HAProxy ni interrumpir el puerto 80. Sus puertos predeterminados son TUIC
UDP/36713, AnyTLS TCP/36714 y Naive TCP/36715; se pueden cambiar desde su
gestor o desde el administrador de puertos.

## HAProxy SSL: buffering y enrutamiento

La instalación comprueba que el ejecutable HAProxy exista y propaga los
errores de actualización, instalación, validación y arranque; un archivo
`haproxy.cfg` existente por sí solo no cuenta como instalación. En Ubuntu
compatible intenta actualizar a HAProxy 3.x y verifica el soporte QUIC antes
de continuar. La apertura local de TCP 80/443/8080/8443 usa firewalld, UFW o
iptables; las reglas iptables se insertan antes de reglas posteriores y se
persisten cuando hay un servicio de persistencia disponible. Esto no configura
el firewall externo del proveedor VPS.

HAProxy usa un buffer global de inspeccion de 1 MiB, compartido por sus
frontends; no se configura por ACL ni por protocolo. El cuerpo HTTP y los
tuneles se transmiten al backend, no se acumulan completos en ese buffer. El
buffer mayor puede aumentar la memoria potencial usada por conexiones
concurrentes.
Las rutas actuales se eligen por protocolo, ALPN y path; el frontend HTTP/2
limita a 10 segundos la recepcion de cabeceras incompletas, sin acortar el
tiempo de las sesiones gRPC.

BHTTP en modo HAProxy conserva el backend HTTP/2 local `127.0.0.1:2003`
separado de XHTTP (`2001/2002`). BTUN BHTTP v2 inicia con una trama binaria
cuyo primer byte es `00`; HAProxy identifica ese marcador y enruta el flujo TCP
antes de evaluar otras reglas de inspeccion que esperan mas datos, sin esperar
el resto de la trama inicial, desde los puertos publicos 80/443/8080/8443 al
primer listener h2c plano configurado (por defecto 8880).
La ruta HTTP/1 `/bhttp` sigue disponible para clientes que sí permiten
configurar un payload; BTUN no requiere payload. El resto de HTTP, TLS,
WebSocket y las rutas existentes conserva su enrutamiento. En modo standalone
se conserva `GET /`.

## BadVPN

La instalacion y reparacion muestran progreso compacto; la salida detallada de
la descarga y compilacion solo se presenta si falla una tarea. El menu permite
reparar BadVPN incluso cuando figura apagado, y la opcion `--repair` (o
`--reparar`) ejecuta la misma reparacion que `--install`.

## Optimizador y mantenimiento

La auto-instalacion del optimizador selecciona BBR por defecto cuando el
kernel lo ofrece y aplica buffers TCP acotados por la RAM disponible y el
numero de conexiones establecidas. El limite por socket va de 2 a 16 MiB; con
poca RAM disponible o mayor concurrencia se reduce para evitar que el
autoajuste TCP permita un consumo potencial desproporcionado. El MTU actual se
conserva salvo que el usuario lo cambie manualmente. El menu de perfiles permite
elegir BBR + FQ, BBR + FQ_CoDel, CUBIC + FQ o CUBIC + FQ_CoDel. BBR y CUBIC son
controles TCP alternativos; nunca se activan simultaneamente. El perfil actual
se muestra en el menu principal, en el estado y en el selector. La opcion de
restaurar perfil vuelve al control TCP y a la cola guardados antes del primer
cambio; el perfil seleccionado se conserva al arrancar. El control TCP elegido
persiste en un archivo sysctl independiente.

El mantenimiento programado se ejecuta como maximo cada seis horas. Reporta
RAM disponible (no solo RAM ocupada por cache), swap, carga, CPU asignada en
cgroups y procesos con mayor CPU; limita el journal a 200 MiB. No ejecuta
`drop_caches`, `swapoff`, `autoremove`, borrados genericos de `/tmp`, ni senales
o reinicios de procesos. `--ram` es un diagnostico: Linux administra la cache
de archivos y recuperarla a la fuerza puede empeorar el rendimiento. Una carga
de CPU alta requiere identificar y corregir el proceso o dimensionar la VPS;
ningun limpiador puede reducirla con seguridad sin afectar trabajo activo. Al
actualizar desde una version anterior, aplicar una vez la optimizacion de red
para que el nuevo limite de buffers TCP quede activo.

ZiVPN guarda su firewall en `/etc/iptables/rules.v4` y cuenta con un servicio
de arranque que vuelve a aplicar el DNAT y el puerto UDP despues de restaurar
las reglas de red. El menu incluye una opcion para reparar la conexion y el
comando `zipvpn.sh --repair` hace la misma reconciliacion sin abrir el menu.
BBR/CUBIC solo afectan conexiones TCP: no reducen por si solos el ping del
trafico UDP de juegos, que depende principalmente de la ruta y la congestión
del proveedor.

## Respaldo de scripts de facturacion

Antes de una instalacion nueva, `facturas.sh` guarda una copia persistente de
los scripts existentes bajo el directorio de datos de facturacion. Al
desinstalar restaura ese estado exacto y elimina los scripts que no existian
antes. Las instalaciones antiguas sin ese respaldo conservan el fallback a
`pristine/`, con una advertencia de que esas copias pueden estar desactualizadas.

## Instaladores con verificacion de integridad

- SlowDNS solo instala el binario amd64 cuyo SHA-256 esta fijado en
  `protocolos/slowdns.sh`; las descargas HTTPS tambien deben coincidir con ese
  hash.
- La instalacion y actualizacion remotas de 3X-UI estan suspendidas hasta
  integrar un instalador y binarios verificables. Para una instalacion
  existente, el menu permite regenerar la contrasena y guardar las credenciales
  en `/etc/movivip/xui-credentials` con permisos de root.
- Las opciones de CheckUser que descargaban scripts remotos estan bloqueadas
  hasta disponer de fuentes fijadas a una version y verificadas.
