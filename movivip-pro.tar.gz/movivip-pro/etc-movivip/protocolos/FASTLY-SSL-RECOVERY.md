# Fastly origin TLS recovery

The VPS origin certificate is issued for `freenetzone.movivipoppax.uk`, not
for Fastly's shared `*.global.prod.fastly.net` hostname. Fastly's backend must
use the origin domain for TLS SNI and certificate validation.

The shared hostname `freenet.pro.global.prod.fastly.net` is a CNAME target,
not the public hostname to add as the VPS certificate domain or use in client
profiles. The Fastly diagnostic accepts a full URL or hostname, tests HTTP and
HTTPS separately, and allows this technical hostname even when no custom
domain has been saved. A `404` at `/` is expected for the protocol origin.
HTTPS certificate mismatch on the shared hostname is not repaired by issuing a
certificate on the VPS; add the user's own domain to the Fastly service, point
its CNAME to the shared hostname, and use that custom domain as the backend
Host/SNI. For an HTTPS backend, the VPS certificate must cover that same
custom domain.

The diagnostic also compares the custom hostname's resolved IPv4 addresses with
the VPS origin. If they match, it reports that traffic is going directly to the
VPS and that the observed HTTP response is not a Fastly edge test. Add the custom
hostname to the Fastly service and point its DNS CNAME to the shared Fastly
hostname before using the response to judge CDN health.

Automatic recovery is deliberately limited to a stopped HAProxy service, after
validating its configuration. The diagnostic starts it once and repeats the
origin and edge checks. It does not restart or reload an already-running
HAProxy on a 5xx: an active 503 can come from an unhealthy application/backend
or from Fastly, and reloading the proxy cannot safely resolve either without
identifying the failing component. A live 503 is reported with the origin and
edge status so the operator can repair the correct backend or Fastly service.

The domain manager supports repeated add/remove operations for extra hostnames,
renews and checks the public certificate after each change, and rolls back a
domain-list edit if certificate issuance or validation fails. A successful
certificate deployment is kept even if the separate HTTPS health probe returns
something other than the expected `404`; the health issue is reported without
reverting the domain list, so the active certificate SANs and configured names
stay aligned. It shows whether the self-signed or public certificate is active
and flags missing/expired coverage. A single Let's Encrypt certificate can
contain at most 100 names; entries beyond that limit are rejected for renewal
instead of being reported as certified.

The diagnostic does not reload an already-running HAProxy in response to a
5xx: reloading unchanged configuration does not repair a failing backend and
can interrupt active connections. It may start HAProxy only when the service
is stopped and its configuration validates first. Sing-box uses its own
TUIC/AnyTLS/Naive ports and does not rewrite HAProxy routes or origin
certificates.

The explicit `ssl.sh --issue-cert <domain>` and domain-change flows require a
valid public certificate. If HTTP-01 validation fails, they report the failure
without substituting a self-signed certificate. The Fastly-managed hostname is
not part of the origin certificate SAN; Fastly controls its edge TLS.

If a clean SSL installation hits a temporary Let's Encrypt rate limit, it
finishes starting HAProxy and the SSL tunnel with the local certificate and
reports that public TLS is still pending. Fastly HTTPS origin validation will
not work until the limit expires and `ssl.sh --issue-cert <domain>` succeeds.
This keeps the service installed without falsely marking the certificate as
publicly trusted.

The SSL installer keeps HAProxy listening on port 80 during HTTP-01 renewal.
Only `/.well-known/acme-challenge/` is routed to the temporary local webroot
service.

The SSH/WebSocket adapter returns `404 Not Found` immediately for a normal
request to `/`. It does this before opening an SSH tunnel. WebSocket upgrade
requests continue through the existing tunnel and HAProxy protocol routes.
The verified paths `/vmess-v2ray`, `/vless-v2ray`, and `/trojan-v2ray` return
`101 Switching Protocols` on ports 80 and 443.

The SSL repair action validates the HAProxy certificate and configuration,
restores missing WebSocket service files, reapplies the protocol routes,
restarts configured local backends when their ports are down, checks required
listeners, and repairs the public certificate through Certbot when needed.
On a clean reinstall, HAProxy must be brought up and the public certificate
issued before stunnel is configured, because stunnel consumes that certificate.
Xray gRPC setup must not create V2Ray routes before the V2Ray Core is installed;
the V2Ray installer adds and validates its own HTTP/2 backends transactionally.
The repair check skips the on-demand ACME webroot listener outside certificate
issuance; the remaining HAProxy backends and public certificate are still checked.
Before replacing the VPS installation, a root-only recovery archive is stored
on the server at `/root/movivip-recovery-20261030/vps-state.tar.gz`. Its SHA-256
is `749747cda0136cdd3a47a3d8ba410100f98789b8f31999aef3113a5b27e96048`.
The existing Let's Encrypt certificate covers only
`freenetzone.movivipoppax.uk` and expires on 2027-01-28 UTC.

The separate desktop recovery folder contains the installer, protocol script,
tests, and this note. It intentionally excludes TLS private keys and user
credentials.
