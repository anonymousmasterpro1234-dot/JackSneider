#!/usr/bin/env python3
"""Install and remove BHTTP routing in the shared HAProxy frontends."""

from __future__ import annotations

import os
import re
import stat
import sys
import tempfile
from pathlib import Path


ROUTE_MARKERS = (
    "# BEGIN MOVIVIP BHTTP ROUTES",
    "# END MOVIVIP BHTTP ROUTES",
)
DEFINITION_MARKERS = (
    "# BEGIN MOVIVIP BHTTP DEFINITIONS",
    "# END MOVIVIP BHTTP DEFINITIONS",
)


def section(content: str, kind: str, name: str) -> re.Match[str]:
    match = re.search(
        rf"(?ms)^{kind} {re.escape(name)}[ \t]*\n.*?"
        r"(?=^(?:global|defaults|frontend|backend|listen)\b|\Z)",
        content,
    )
    if not match:
        raise ValueError(f"{kind} {name} not found")
    return match


def replace_section(content: str, match: re.Match[str], updated: str) -> str:
    return content[: match.start()] + updated + content[match.end() :]


def remove_section(content: str, kind: str, name: str) -> str:
    match = re.search(
        rf"(?ms)^{kind} {re.escape(name)}[ \t]*\n.*?"
        r"(?=^(?:global|defaults|frontend|backend|listen)\b|\Z)",
        content,
    )
    return content if not match else content[: match.start()] + content[match.end() :]


def remove_managed_blocks(content: str) -> str:
    for begin, end in (ROUTE_MARKERS, DEFINITION_MARKERS):
        content = re.sub(
            rf"(?ms)^# {re.escape(begin[2:])}\n.*?^# {re.escape(end[2:])}\n?",
            "",
            content,
        )
    content = re.sub(
        r"(?m)^[ \t]*(?:acl acl_(?:bhttp_host|sni_bhttp|bhttp_payload|bhttp_binary|bhttp_binary_payload|bhttp_websocket|bhttp_h2c)\b.*"
        r"|tcp-request content accept if acl_bhttp_(?:payload|binary|binary_payload|h2c)\b.*"
        r"|use_backend bhttp_(?:tcp|h2c_recir|tls|plain|h2)_backend\b.*)\n?",
        "",
        content,
    )
    content = remove_section(content, "frontend", "bhttp_direct_frontend")
    for name in (
        "bhttp_tls_backend",
        "bhttp_plain_backend",
        "bhttp_tcp_backend",
        "bhttp_h2_backend",
        "bhttp_h2c_recir_backend",
        "xhttp_h2c_backend",
        "bhttp_h2c_frontend",
    ):
        content = remove_section(content, "backend", name)
        content = remove_section(content, "frontend", name)
    return content


def insert_routes(content: str, frontend_name: str) -> str:
    match = section(content, "frontend", frontend_name)
    frontend = match.group(0)
    block = """# BEGIN MOVIVIP BHTTP ROUTES
    acl acl_bhttp_payload payload(0,10) -m beg -i "GET /bhttp"
    acl acl_bhttp_path_space payload(10,1) -m str " "
    acl acl_bhttp_path_query payload(10,1) -m str "?"
    acl acl_bhttp_websocket payload(0,512) -m sub -i "Upgrade: websocket"
    acl acl_bhttp_binary payload(0,1) -m bin 00
    acl acl_bhttp_h2c payload(0,3) -m bin 505249
    tcp-request content accept if acl_bhttp_binary
    tcp-request content accept if acl_bhttp_payload acl_bhttp_path_space
    tcp-request content accept if acl_bhttp_payload acl_bhttp_path_query
    tcp-request content accept if acl_bhttp_h2c
    use_backend bhttp_tcp_backend if acl_bhttp_binary
    use_backend bhttp_tcp_backend if acl_bhttp_payload acl_bhttp_path_space !acl_bhttp_websocket
    use_backend bhttp_tcp_backend if acl_bhttp_payload acl_bhttp_path_query !acl_bhttp_websocket
    use_backend bhttp_h2c_recir_backend if acl_bhttp_h2c
# END MOVIVIP BHTTP ROUTES
"""
    anchor = re.search(r"(?m)^[ \t]*tcp-request content\b", frontend)
    if not anchor:
        anchor = re.search(r"(?m)^[ \t]*(?:use_backend|default_backend)\b", frontend)
    if not anchor:
        raise ValueError(f"routing anchor not found in frontend {frontend_name}")
    frontend = frontend[: anchor.start()] + block + frontend[anchor.start() :]
    return replace_section(content, match, frontend)


def install(
    cfg: Path,
    tcp_port: str,
    xhttp_enabled: bool,
    h2_port: str | None = None,
) -> None:
    if not tcp_port.isdecimal() or not 1 <= int(tcp_port) <= 65535:
        raise ValueError(f"invalid BHTTP TCP backend port: {tcp_port}")
    h2_port = tcp_port if h2_port is None else h2_port
    if not h2_port.isdecimal() or not 1 <= int(h2_port) <= 65535:
        raise ValueError(f"invalid BHTTP h2 backend port: {h2_port}")
    if xhttp_enabled and h2_port in ("2001", "2002"):
        raise ValueError("BHTTP h2 backend port conflicts with XHTTP ports 2001/2002")
    content = cfg.read_text()
    content = remove_managed_blocks(content)
    content = insert_routes(content, "multiport_frontend")
    content = insert_routes(content, "ssl_frontend")

    match = section(content, "frontend", "h2_frontend")
    frontend = match.group(0)
    anchor = re.search(r"(?m)^[ \t]*default_backend h2_not_found_backend[ \t]*$", frontend)
    if not anchor:
        raise ValueError("h2_not_found_backend fallback not found in h2_frontend")
    h2_route = """# BEGIN MOVIVIP BHTTP ROUTES
    acl p_bhttp path -i /bhttp
    use_backend bhttp_h2_backend if p_bhttp

# END MOVIVIP BHTTP ROUTES
"""
    frontend = frontend[: anchor.start()] + h2_route + frontend[anchor.start() :]
    content = replace_section(content, match, frontend)

    fallback = "xhttp_h2c_backend" if xhttp_enabled else "h2_not_found_backend"
    definitions = f"""# BEGIN MOVIVIP BHTTP DEFINITIONS
frontend bhttp_h2c_frontend
    mode http
    bind abns@bhttp-h2c-front accept-proxy proto h2
    timeout http-request 10s
    acl p_bhttp path -i /bhttp
    use_backend bhttp_h2_backend if p_bhttp
    default_backend {fallback}

backend bhttp_tcp_backend
    mode tcp
    server bhttp_tcp_local 127.0.0.1:{tcp_port} check

backend bhttp_h2_backend
    mode http
    server bhttp_h2_local 127.0.0.1:{h2_port} proto h2 check

backend bhttp_h2c_recir_backend
    mode tcp
    server bhttp_h2c_recir abns@bhttp-h2c-front send-proxy-v2 check
"""
    if xhttp_enabled:
        definitions += """\nbackend xhttp_h2c_backend
    mode http
    server xhttp_h2c_local 127.0.0.1:2002 proto h2 check
"""
    definitions += "# END MOVIVIP BHTTP DEFINITIONS\n"
    content = content.rstrip() + "\n\n" + definitions
    write_atomic(cfg, content)


def remove(cfg: Path) -> None:
    content = remove_managed_blocks(cfg.read_text())
    write_atomic(cfg, content.rstrip() + "\n")


def write_atomic(path: Path, content: str) -> None:
    directory = path.parent
    fd, temporary = tempfile.mkstemp(prefix=".haproxy-bhttp-", dir=directory)
    try:
        with os.fdopen(fd, "w") as stream:
            stream.write(content)
        os.chmod(temporary, stat.S_IMODE(path.stat().st_mode))
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def main(argv: list[str]) -> int:
    if len(argv) < 3 or argv[1] not in ("install", "remove"):
        print(
            "Usage: bhttp_haproxy.py install <haproxy.cfg> <tcp-port>"
            " [xhttp-on [h2-port]]"
            " | remove <haproxy.cfg>",
            file=sys.stderr,
        )
        return 2
    cfg = Path(argv[2])
    if argv[1] == "remove":
        if len(argv) != 3:
            print("remove requires only the HAProxy config path", file=sys.stderr)
            return 2
        remove(cfg)
        return 0
    if len(argv) not in (5, 6):
        print("install requires a TCP backend port, XHTTP state, and optional h2 port", file=sys.stderr)
        return 2
    install(cfg, argv[3], argv[4] == "ON", argv[5] if len(argv) == 6 else None)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
