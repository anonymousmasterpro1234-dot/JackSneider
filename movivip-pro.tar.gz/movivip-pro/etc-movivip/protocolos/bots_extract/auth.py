# MoviVIP Personal Bot — autenticación (login = contraseña root de la VPS)
# ==========================================================================
# El bot NO guarda la contraseña. En cada login lee el hash del usuario ROOT
# desde /etc/shadow y comprueba  crypt(clave_ingresada, hash) == hash.
# Resultado: si el dueño cambia `passwd root` en la VPS, el bot acepta la
# nueva contraseña al instante (verificación dinámica, sin sincronización).
#
# Hash esperado en Ubuntu 20.04: SHA-512 ($6$...). El módulo estándar `crypt`
# (glibc) lo soporta. Si el hash tiene otro esquema no soportado, se rechaza
# de forma segura (fail-closed: nunca concede acceso ante duda).
import crypt
import logging
import time

import config

log = logging.getLogger("movivip.auth")

# estado del rate-limit de intentos (en memoria del proceso)
_intentos = {}   # uid -> [n_fallos, bloqueado_hasta_ts]


def _hash_usuario():
    """Devuelve el hash de config.AUTH_USER en /etc/shadow, o None."""
    try:
        with open(config.AUTH_SHADOW, encoding="utf-8", errors="replace") as f:
            for linea in f:
                campos = linea.rstrip("\n").split(":")
                if len(campos) > 1 and campos[0] == config.AUTH_USER:
                    return campos[1]
    except Exception as e:
        log.warning("no se pudo leer %s: %s", config.AUTH_SHADOW, e)
    return None


def verificar_password(pw):
    """True si `pw` es la contraseña actual del usuario root de la VPS."""
    if not pw:
        return False
    h = _hash_usuario()
    if h and h.startswith("$"):
        try:
            return crypt.crypt(pw, h) == h
        except Exception as e:
            log.warning("crypt fallo: %s", e)
    # RESPALDO (producto): si /etc/shadow no es utilizable (cuenta bloqueada
    # '!', sin hash, o el proceso no puede leerlo) y el instalador dejó una
    # VPS_PASSWORD real, se acepta esa como contraseña de acceso.
    ref = getattr(config, "AUTH_PASSWORD_FALLBACK", "")
    if ref:
        try:
            import hmac
            return hmac.compare_digest(str(pw), str(ref))
        except Exception:
            return pw == ref
    # cuentas bloqueadas (*, !, !!) o sin hash -> nunca autorizar (fail-closed)
    return False


def puede_intentar(uid):
    """(permitido, segundos_restantes). Rate-limit de intentos fallidos."""
    est = _intentos.get(uid)
    if not est:
        return True, 0
    n, hasta = est
    if time.time() < hasta:
        return False, int(hasta - time.time())
    # bloqueo expirado -> resetear
    _intentos.pop(uid, None)
    return True, 0


def registrar_fallo(uid):
    """Suma un fallo; si supera el máximo, aplica bloqueo temporal."""
    n, _ = _intentos.get(uid, [0, 0])
    n += 1
    if n >= config.AUTH_MAX_INTENTOS:
        _intentos[uid] = [0, time.time() + config.AUTH_BLOQUEO_SEG]
    else:
        _intentos[uid] = [n, 0]


def registrar_exito(uid):
    _intentos.pop(uid, None)
