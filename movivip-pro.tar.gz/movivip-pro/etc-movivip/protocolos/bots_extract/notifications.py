"""Opt-in Telegram notifications and administrator-controlled templates."""

import asyncio
import logging

from telegram import Bot
from telegram.error import TelegramError

import config
import db

log = logging.getLogger("movivip.notifications")

_NOTIFICATION_BOT = None

_EVENTS = {
    "created": ("Cuenta creada", "template_created"),
    "renewed": ("Cuenta renovada", "template_renewed"),
    "expired": ("Cuenta vencida", "template_expired"),
}
_DEFAULT_TEMPLATES = {
    "created": "🎉 {marca}: cuenta creada\nProtocolo: {protocolo}\nVence: {fecha}",
    "renewed": "🔄 {marca}: cuenta renovada\nProtocolo: {protocolo}\nVence: {fecha}",
    "expired": "⏳ {marca}: cuenta vencida\nProtocolo: {protocolo}\nFecha: {fecha}",
    "welcome": "👋 Bienvenido a {marca}. Aquí recibirás las notificaciones que hayas aceptado.",
    "announcement": "📣 {marca}\n\nEscribe aquí tu anuncio.",
    "maintenance": "🛠 {marca}\n\nEscribe aquí el aviso de mantenimiento.",
}


def setting(key, default=""):
    defaults = {
        "notification_brand": config.BRAND,
        "notification_support": config.LINK_REDIREC,
        "notification_web": config.SOCIAL_LINKS.get("web", ""),
        "notification_whatsapp": config.SOCIAL_LINKS.get("whatsapp_personal", ""),
        "notification_channel": str(
            config.NOTIF_CHANNEL_ID or
            ("" if config._plh(config.MAIN_CHANNEL) else config.MAIN_CHANNEL)),
        "notification_group": str(
            config.NOTIF_GROUP_ID or
            ("" if config._plh(config.SUPPORT_GROUP) else config.SUPPORT_GROUP)),
        "broadcast_events": "0",
        "broadcast_enabled": "1",
        "event_created": "1",
        "event_renewed": "1",
        "event_expired": "1",
        "welcome_text": _DEFAULT_TEMPLATES["welcome"],
        "template_announcement": _DEFAULT_TEMPLATES["announcement"],
        "template_maintenance": _DEFAULT_TEMPLATES["maintenance"],
    }
    for event, (_, template_key) in _EVENTS.items():
        defaults[template_key] = _DEFAULT_TEMPLATES[event]
    return db.get_setting(key, defaults.get(key, default))


def render(template, values):
    try:
        return template.format_map(values)
    except (KeyError, ValueError) as exc:
        raise ValueError(f"template contains an invalid placeholder: {exc}") from exc


def event_text(event, account):
    if event not in _EVENTS:
        raise ValueError("unsupported notification event")
    _, template_key = _EVENTS[event]
    return render(setting(template_key), {
        "marca": setting("notification_brand", config.BRAND),
        "protocolo": account.get("protocolo") or "—",
        "fecha": account.get("fecha") or "—",
    })


async def initialize():
    global _NOTIFICATION_BOT
    if not config.NOTIF_TOKEN:
        raise RuntimeError("notification bot token is not configured")
    _NOTIFICATION_BOT = Bot(token=config.NOTIF_TOKEN)
    await _NOTIFICATION_BOT.initialize()


async def shutdown():
    global _NOTIFICATION_BOT
    if _NOTIFICATION_BOT is not None:
        await _NOTIFICATION_BOT.shutdown()
        _NOTIFICATION_BOT = None


async def _send_to(chat_id, text):
    if _NOTIFICATION_BOT is None:
        log.error("notification bot is not initialized; no message was sent")
        return False
    try:
        await _NOTIFICATION_BOT.send_message(chat_id=chat_id, text=text)
        return True
    except TelegramError as exc:
        log.warning("notification delivery failed for chat %s: %s", chat_id, exc)
        return False


async def notify_event(event, account):
    """Broadcast generic-safe account event templates only when enabled."""
    if event not in _EVENTS:
        raise ValueError("unsupported notification event")
    if setting(f"event_{event}", "1") != "1":
        return
    text = event_text(event, account)
    if setting("broadcast_events", "0") == "1":
        await broadcast(text)


def welcome_text():
    return render(setting("welcome_text"), {
        "marca": setting("notification_brand", config.BRAND),
        "soporte": setting("notification_support", ""),
        "web": setting("notification_web", ""),
        "whatsapp": setting("notification_whatsapp", ""),
    })


async def broadcast(text):
    if setting("broadcast_enabled", "1") != "1":
        return 0, 0
    recipients = set(db.subscribers())
    for target in (setting("notification_channel"), setting("notification_group")):
        if target:
            recipients.add(target)
    if not recipients:
        return 0, 0

    sent = 0
    failed = 0
    for recipient in recipients:
        if await _send_to(recipient, text):
            sent += 1
        else:
            failed += 1
        await asyncio.sleep(0.04)
    return sent, failed


def render_announcement(kind):
    if kind not in ("announcement", "maintenance"):
        raise ValueError("unsupported broadcast template")
    return render(setting(f"template_{kind}"), {
        "marca": setting("notification_brand", config.BRAND),
        "soporte": setting("notification_support", ""),
        "web": setting("notification_web", ""),
        "whatsapp": setting("notification_whatsapp", ""),
    })
