"""Customer-facing opt-in bot for MoviVIP notifications."""

import asyncio
import logging
import os
import sys

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

import config
import db
import license_policy
import notifications
from aiout import to_thread

log = logging.getLogger("movivip.notif_bot")
_LICENSE_VALID = False


async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not user or not update.effective_chat:
        return
    if not _LICENSE_VALID:
        await update.effective_chat.send_message(
            "El servicio de notificaciones está temporalmente suspendido.")
        return
    if update.effective_chat.type != "private":
        await update.effective_chat.send_message(
            "Abre este bot en un chat privado y envía /start para suscribirte.")
        return
    db.subscribe(user.id, user.username or "")
    await update.effective_chat.send_message(notifications.welcome_text())


async def stop(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not user or not update.effective_chat:
        return
    if update.effective_chat.type != "private":
        await update.effective_chat.send_message(
            "Envía /stop en el chat privado con este bot.")
        return
    db.unsubscribe(user.id)
    await update.effective_chat.send_message(
        "Listo: no recibirás más avisos. Puedes volver a suscribirte con /start.")


async def post_init(app: Application):
    global _LICENSE_VALID
    allowed, reason = await to_thread(license_policy.check_bot_license)
    if not allowed:
        _LICENSE_VALID = False
        raise RuntimeError(f"notification bot suspended by license gate: {reason}")
    db.init_db()
    _LICENSE_VALID = True
    v5_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "v5")
    if v5_path not in sys.path:
        sys.path.insert(0, v5_path)
    from handlers_v5 import register_v5

    register_v5(app)
    app.bot_data["license_watch"] = asyncio.get_running_loop().create_task(
        license_watch(app))


async def license_watch(app: Application):
    global _LICENSE_VALID
    while True:
        await asyncio.sleep(60)
        allowed, reason = await to_thread(license_policy.check_bot_license)
        _LICENSE_VALID = allowed
        if not allowed:
            log.error("notification bot suspended by license gate: %s", reason)


async def post_shutdown(app: Application):
    global _LICENSE_VALID
    _LICENSE_VALID = False
    task = app.bot_data.get("license_watch")
    if task and not task.done():
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


def run():
    if not config.NOTIF_TOKEN:
        raise RuntimeError("notification bot token is not configured")
    app = (Application.builder().token(config.NOTIF_TOKEN)
           .post_init(post_init).post_shutdown(post_shutdown).build())
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("stop", stop))
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run()
