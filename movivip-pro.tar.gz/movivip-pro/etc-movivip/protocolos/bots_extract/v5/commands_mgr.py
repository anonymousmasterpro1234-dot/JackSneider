# -*- coding: utf-8 -*-
"""
commands_mgr.py — white-label v5
CRUD + render de comandos arbitrarios (tabla `commands` + `command_items`).
El panel puede crear/editar/borrar CUALQUIER comando, su plantilla (con emojis
premium) y su foto -> re-editable en cualquier momento.
"""
from __future__ import annotations
from context import get_db, BRAND_NAME, SUPPORT_TAG
from premium_emoji import e, SEP_FIRE, SEP_SPARK

# Plantilla por defecto para un comando nuevo (usa tokens de secciones).
DEFAULT_PLANTILLA = (
    "🔑 <b>" + BRAND_NAME.upper() + "</b> 🔑\n"
    "{SEP_FIRE}\n"
    "☄️ <b>TÍTULO DEL COMANDO</b>\n"
    "{SEP_FIRE}\n"
    "{items}\n"
    "{SEP_FIRE}\n"
    "🎯 <b>" + SUPPORT_TAG + "</b>"
)

SECTION_LABEL = {
    "vendedores": "💎 PROVEEDORES",
    "ubicaciones": "🌎 UBICACIONES",
    "beneficios": "🎁 BENEFICIOS",
    "libre": "📌",
    "items": "",
}

RESERVED_COMMANDS = {
    "start", "help", "panel", "admin", "vip", "desbanear", "db", "stats",
    "members", "reports", "welcomes", "preview", "welcome_preview", "official",
    "hc", "subirhc", "listhc", "delhc", "hcentregas", "hcliberar",
    "cancelar_hc", "cancelar_bienv", "cancelar_promo", "adblock_list",
    "adblock_unban", "adblock_ban", "adblock_help",
}


# ── Lectura ─────────────────────────────────────────────────────────────────
def list_commands(conn=None):
    own = conn is None
    conn = conn or get_db()
    try:
        return conn.execute("SELECT * FROM commands ORDER BY id").fetchall()
    finally:
        if own:
            conn.close()


def get_command(slug=None, cid=None, conn=None):
    own = conn is None
    conn = conn or get_db()
    try:
        if cid is not None:
            return conn.execute("SELECT * FROM commands WHERE id=?", (cid,)).fetchone()
        return conn.execute("SELECT * FROM commands WHERE slug=?", (slug,)).fetchone()
    finally:
        if own:
            conn.close()


def get_items(command_id, conn=None, visible_only=False):
    own = conn is None
    conn = conn or get_db()
    try:
        q = "SELECT * FROM command_items WHERE command_id=?"
        if visible_only:
            q += " AND visible=1"
        q += " ORDER BY seccion, pos, id"
        return conn.execute(q, (command_id,)).fetchall()
    finally:
        if own:
            conn.close()


def available_commands(conn=None) -> list:
    """Comandos públicos que los usuarios pueden ejecutar."""
    own = conn is None
    conn = conn or get_db()
    try:
        rows = conn.execute(
            "SELECT slug, titulo FROM commands WHERE enabled=1 ORDER BY id"
        ).fetchall()
        commands = [("/start", "Iniciar suscripción"), ("/stop", "Cancelar suscripción")]
        for row in rows:
            slug = str(row["slug"] or "").lower()
            if slug in RESERVED_COMMANDS or not slug:
                continue
            commands.append((f"/{slug}", row["titulo"] or ""))
        # /vip es un comando público propio aunque no exista como comando editable.
        if not any(command == "/vip" for command, _ in commands):
            commands.append(("/vip", "Proveedores y ubicaciones"))
        return commands
    finally:
        if own:
            conn.close()


# ── Render ──────────────────────────────────────────────────────────────────
def render_command(slug_or_id, conn=None) -> str:
    own = conn is None
    conn = conn or get_db()
    try:
        row = get_command(slug=slug_or_id, cid=(slug_or_id if isinstance(slug_or_id, int) else None), conn=conn)
        if not row:
            return ""
        tpl = row["plantilla"] or ""
        # construir bloques por sección
        items = get_items(row["id"], conn=conn, visible_only=True)
        sec = {}
        for it in items:
            sec.setdefault(it["seccion"], []).append(it)
        blocks = []
        for s in ("vendedores", "ubicaciones", "beneficios"):
            if sec.get(s):
                label = SECTION_LABEL.get(s)
                if label:
                    blocks.append(f"{label}")
                for it in sec[s]:
                    pre = e(it["emoji_key"]) + " " if it["emoji_key"] else "• "
                    blocks.append(f"{pre}{it['texto']}")
                blocks.append("")
        for it in sec.get("libre", []):
            pre = e(it["emoji_key"]) + " " if it["emoji_key"] else ""
            blocks.append(f"{pre}{it['texto']}")
        items_txt = "\n".join(blocks).strip()

        out = (tpl.replace("{SEP_FIRE}", SEP_FIRE)
                  .replace("{SEP_SPARK}", SEP_SPARK)
                  .replace("{items}", items_txt)
                  .replace("{titulo}", row["titulo"] or ""))
        return out
    finally:
        if own:
            conn.close()


def media_of(slug_or_id, conn=None):
    own = conn is None
    conn = conn or get_db()
    try:
        row = get_command(slug=slug_or_id, cid=(slug_or_id if isinstance(slug_or_id, int) else None), conn=conn)
        if not row:
            return (None, None)
        return (row["media_file_id"], row["media_type"])
    finally:
        if own:
            conn.close()


# ── Escritura ───────────────────────────────────────────────────────────────
def create_command(slug: str, titulo: str = "", plantilla: str = None, conn=None) -> int:
    own = conn is None
    conn = conn or get_db()
    try:
        cur = conn.execute(
            "INSERT INTO commands (slug, titulo, plantilla, enabled) VALUES (?,?,?,1)",
            (slug.strip().lstrip("/").lower(), titulo or slug, plantilla or DEFAULT_PLANTILLA))
        conn.commit()
        return cur.lastrowid
    finally:
        if own:
            conn.close()


def update_field(cid: int, field: str, value, conn=None):
    allowed = {"titulo", "plantilla", "media_file_id", "media_type", "enabled"}
    if field not in allowed:
        raise ValueError(field)
    own = conn is None
    conn = conn or get_db()
    try:
        conn.execute(f"UPDATE commands SET {field}=?, updated_at=datetime('now') WHERE id=?", (value, cid))
        conn.commit()
    finally:
        if own:
            conn.close()


def delete_command(cid: int, conn=None):
    own = conn is None
    conn = conn or get_db()
    try:
        conn.execute("DELETE FROM command_items WHERE command_id=?", (cid,))
        conn.execute("DELETE FROM commands WHERE id=?", (cid,))
        conn.commit()
    finally:
        if own:
            conn.close()


def toggle_command(cid: int, conn=None) -> int:
    own = conn is None
    conn = conn or get_db()
    try:
        conn.execute("UPDATE commands SET enabled = 1 - enabled WHERE id=?", (cid,))
        conn.commit()
        r = conn.execute("SELECT enabled FROM commands WHERE id=?", (cid,)).fetchone()
        return int(r["enabled"]) if r else 0
    finally:
        if own:
            conn.close()


# ── Items ───────────────────────────────────────────────────────────────────
def add_item(command_id: int, texto: str, seccion: str = "libre", emoji_key: str = None, conn=None) -> int:
    own = conn is None
    conn = conn or get_db()
    try:
        row = conn.execute("SELECT COALESCE(MAX(pos),-1)+1 AS p FROM command_items WHERE command_id=? AND seccion=?",
                           (command_id, seccion)).fetchone()
        pos = row["p"] if row else 0
        cur = conn.execute(
            "INSERT INTO command_items (command_id, seccion, pos, emoji_key, texto, visible) VALUES (?,?,?,?,?,1)",
            (command_id, seccion, pos, emoji_key, texto))
        conn.commit()
        return cur.lastrowid
    finally:
        if own:
            conn.close()


def update_item(item_id: int, field: str, value, conn=None):
    if field not in {"texto", "emoji_key", "seccion", "pos", "visible"}:
        raise ValueError(field)
    own = conn is None
    conn = conn or get_db()
    try:
        conn.execute(f"UPDATE command_items SET {field}=?, updated_at=datetime('now') WHERE id=?", (value, item_id))
        conn.commit()
    finally:
        if own:
            conn.close()


def delete_item(item_id: int, conn=None):
    own = conn is None
    conn = conn or get_db()
    try:
        conn.execute("DELETE FROM command_items WHERE id=?", (item_id,))
        conn.commit()
    finally:
        if own:
            conn.close()


# ── Seed de un comando nuevo por defecto ────────────────────────────────────
def seed_default_commands(conn=None):
    """Si no existe el comando /vip, lo crea con la plantilla propia."""
    own = conn is None
    conn = conn or get_db()
    try:
        exists = conn.execute("SELECT 1 FROM commands WHERE slug='vip'").fetchone()
        if exists:
            return
        from templates import render_vip
        create_command("vip", "Proveedores autorizados / ubicaciones", render_vip(), conn=conn)
    finally:
        if own:
            conn.close()
