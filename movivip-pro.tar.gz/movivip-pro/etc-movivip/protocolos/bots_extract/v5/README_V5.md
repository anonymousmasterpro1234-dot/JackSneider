# v5 — MoviVIP Guardian · Integración y Deploy

Módulos integrados en el bot de notificaciones. Comparten la configuración y
la base de datos configuradas por el instalador.

```
v5/
├── context.py         config + BD + is_admin + exención por admins del chat
├── premium_emoji.py   (ya existía) 23 emojis premium
├── link_guard.py      (ya existía) detección de links/credenciales
├── abuse_engine.py    (ya existía) escalado de castigo
├── core/db.py         (ya existía) esquema + migración no destructiva
├── templates.py       plantillas (bienvenida, /vip) + seed  ← +YouTube/TikTok/Web/SSH
├── welcome.py         render + envío de bienvenida unificada desde la BD
├── commands_mgr.py    CRUD + render de comandos arbitrarios
├── abuse.py           anti-link real (borra, castiga, escala, historial)
├── panel.py           panel admin (Bienvenida · Comandos · Anti-abuso)
└── handlers_v5.py     register_v5(app)  ← ÚNICO punto de entrada
```

`notif_bot.py` carga `handlers_v5.register_v5` tras validar la licencia e
inicializar la base compartida. Los comandos, callbacks y moderación se
mantienen bloqueados cuando el gate de licencia queda inválido.

## 2) Instalación y deploy

```bash
# `bot.sh` descarga el manifiesto v5 junto con el resto del paquete.
# Para una actualización directa, copiar `v5/` y `bienvenida.jpg` al
# directorio del cliente antes de reiniciar su unidad `*-notif.service`.
```

## 3) Uso

- **/panel** (admins) → panel por botones: Bienvenida, Comandos, Anti-abuso.
- **/vip** (público) → plantilla de proveedores/ubicaciones/beneficios.
- **Bienvenida**: grupos/supergrupos y el canal oficial configurado.
- La plantilla de bienvenida acepta `{comandos}` para colocar la lista de comandos públicos activos.
  Si el texto guardado no contiene ese marcador, la lista se añade al final.
- **Anti-abuso**: borra links/credenciales de NO-admins y escala
  AVISO → MUTE 15m → MUTE 1h → BAN. Exentos: owner + admins del chat + canal/grupo.

## 4) Botones de bienvenida (seed)

📢 Canal · 👥 Grupo · 🔑 Bot Key · 🛒 Soporte · ▶️ YouTube · 🎵 TikTok ·
🌐 Web · 🖥️ SSH Bot · 🎁 FreeNetZone Canal · 👥 FreeNetZone Grupo · 🚇 TunnelCol
