# -*- coding: utf-8 -*-
"""
handlers_v5.py — white-label v5
Punto de entrada: register_v5(app).

Se importa como módulo PLANO (el directorio v5/ se añade a sys.path),
igual que hace el host con /opt/movivip-admin/notif.

    import sys, os
    sys.path.insert(0, "/opt/movivip-admin/notif/v5")
    from handlers_v5 import register_v5
    register_v5(app)
"""
from __future__ import annotations
import os

from telegram.ext import (
    ChatMemberHandler, CommandHandler, CallbackQueryHandler, MessageHandler, filters,
    ApplicationHandlerStop,
)

import context as ctx
import panel
import abuse
import seed
import welcome as W
from core.db import init_db

V5_TAG = "Guardian v5"


def _stop(fn):
    """Envuelve un handler: tras ejecutarlo corta el resto de handlers del update.
    Necesario porque el host registra CommandHandler/MessageHandler en el grupo 0
    (primer handler que casa en un grupo gana) y se comería /vip, /panel, etc."""
    async def _h(update, context):
        if not ctx.license_active():
            query = getattr(update, "callback_query", None)
            if query:
                await query.answer("El bot está suspendido por licencia.", show_alert=True)
            elif update.effective_message:
                await update.effective_message.reply_text(
                    "El bot está suspendido por licencia.")
            raise ApplicationHandlerStop
        await fn(update, context)
        raise ApplicationHandlerStop
    return _h


def _ensure_schema():
    """Crea/actualiza el esquema (no destructivo) en la BD compartida."""
    conn = ctx.get_db()
    try:
        init_db(conn)
    finally:
        conn.close()


def register_v5(app):
    """Registra comandos, anti-abuso, panel y callbacks. Devuelve True si OK."""
    _ensure_schema()

    # seed idempotente (bienvenida + botones + comando /vip)
    seed.apply_seed()

    # ── Comandos — grupo -2 + stop (ganan al host, que va en grupo 0) ───
    app.add_handler(CommandHandler("panel", _stop(panel.cmd_panel)), group=-2)
    app.add_handler(CommandHandler("admin", _stop(panel.cmd_panel)), group=-2)   # alias
    app.add_handler(CommandHandler("vip", _stop(panel.cmd_vip)), group=-2)       # PÚBLICO
    app.add_handler(CommandHandler("desbanear", _stop(panel.cmd_unban)), group=-2)

    # comandos públicos ya existentes en la BD (excepto reservados)
    try:
        panel.register_existing_commands(app, group=-2)
    except Exception as e:
        ctx.LOGGER.error("register_existing_commands: %s", e)

    # ── Anti-abuso (grupos) — corre ANTES que detect_mentions (grupo 0) ─
    app.add_handler(
        MessageHandler(filters.ChatType.GROUPS & (filters.TEXT | filters.CAPTION) & ~filters.COMMAND,
                       _stop(abuse.handle_group_link)),
        group=-1,
    )
    app.add_handler(
        MessageHandler(
            filters.ChatType.GROUPS & filters.StatusUpdate.NEW_CHAT_MEMBERS,
            _stop(_welcome_group_members),
        ),
        group=-1,
    )
    app.add_handler(ChatMemberHandler(_stop(_welcome_channel_member)), group=-1)

    # ── Callbacks del panel — grupo -1 + pattern (no choca con el catch-all) ─
    app.add_handler(CallbackQueryHandler(_stop(panel.vip_callback), pattern=r"^mv:vip$"), group=-1)
    app.add_handler(CallbackQueryHandler(_stop(panel.on_callback), pattern=r"^p5:"), group=-1)

    # ── Input del panel (texto/media en privado) — después del host ──────
    app.add_handler(
        MessageHandler(
            filters.ChatType.PRIVATE & (
                filters.TEXT | filters.PHOTO | filters.VIDEO |
                filters.ANIMATION | filters.Sticker.ALL | filters.Document.ALL),
            _stop(panel.handle_input)),
        group=1,
    )

    ctx.LOGGER.info("%s registrado (panel + anti-abuso + bienvenida + comandos)", V5_TAG)
    return True


async def _welcome_group_members(update, context):
    message = update.effective_message
    chat = update.effective_chat
    if not message or not chat:
        return
    for member in message.new_chat_members or []:
        if member.is_bot:
            continue
        try:
            await W.deliver(context.bot, chat.id, member.first_name, member.username, "group")
        except Exception:
            ctx.LOGGER.exception("failed to send group welcome for chat %s", chat.id)


async def _welcome_channel_member(update, context):
    change = update.chat_member
    if not change or change.chat.type != "channel":
        return
    if not _is_configured_channel(change.chat):
        return
    old_member = change.old_chat_member
    new_member = change.new_chat_member
    if old_member.status not in ("left", "kicked"):
        return
    if new_member.status not in ("member", "administrator", "restricted"):
        return
    if new_member.status == "restricted" and not getattr(new_member, "is_member", False):
        return
    user = new_member.user
    if user.is_bot:
        return
    try:
        await W.deliver(
            context.bot, change.chat.id, user.first_name, user.username, "channel")
    except Exception:
        ctx.LOGGER.exception("failed to send channel welcome for chat %s", change.chat.id)


def _is_configured_channel(chat):
    if ctx.CHANNEL_ID and str(chat.id) == str(ctx.CHANNEL_ID):
        return True
    link = (ctx.CHANNEL_LINK or "").strip().lower()
    if not link:
        return False
    username = link.rsplit("/", 1)[-1].lstrip("@")
    return bool(chat.username and chat.username.lower() == username)
