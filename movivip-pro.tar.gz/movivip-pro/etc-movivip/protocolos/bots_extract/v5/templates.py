# -*- coding: utf-8 -*-
"""
templates.py — white-label v5
Plantillas del cliente (todo se deriva de config/env) + datos semilla para DB.

- Bienvenida unificada (canal + grupo) con botones de socios.
- Comando /vip (NUEVA plantilla propia, 4 proveedores autorizados).
- seed(): dicts listos para INSERT (welcome_config, welcome_buttons, commands, command_items).
"""
from __future__ import annotations
from premium_emoji import e, sep, SEP_FIRE, strip_premium
from context import (BRAND_NAME, CHANNEL_LINK, GROUP_LINK, SSH_BOT, STORE_BOT,
                     SUPPORT_TAG, SUPPORT_URL, LINK_REDIREC, WEB_URL, KEY_BOT,
                     SOCIAL)

# ── Enlaces oficiales del CLIENTE (desde config/env; vacíos = se omiten) ─────
OWN_CHANNEL = CHANNEL_LINK
OWN_GROUP   = GROUP_LINK
SUPPORT     = SUPPORT_URL or (("https://t.me/" + SUPPORT_TAG.lstrip("@")) if SUPPORT_TAG else "")
WEB         = WEB_URL
YOUTUBE     = SOCIAL.get("youtube", "")
TIKTOK      = SOCIAL.get("tiktok", "")

SOCIOS = []

# Redes oficiales (aparecen como botones en la bienvenida) — solo las definidas
REDES = [d for d in (
    {"text": "▶️ YouTube", "url": YOUTUBE},
    {"text": "🎵 TikTok",  "url": TIKTOK},
) if d["url"]]

# ── Contenido /vip (EDITABLE desde el panel) ────────────────────────────────
VENDEDORES  = ["JackSneider", "@Clmadi", "@ArenaVpsVIP", "@Cninho"]
UBICACIONES = ["Colombia 🇨🇴", "Miami 🇺🇸", "Phoenix 🇺🇸",
               "Chicago 🇺🇸", "Virginia 🇺🇸", "Canadá 🇨🇦"]
BENEFICIOS  = ["Alta velocidad ⚡️", "Conexión estable 🔺",
               "Atención personalizada 👨‍💻", "Activación inmediata 🔛", "Soporte 24/7 🏪"]


def render_vip() -> str:
    """Plantilla /vip de JackSneider en HTML con emojis premium."""
    L = [
        f"{e('key')} <b>MOVIVIP NETWORK</b> {e('key')}",
        SEP_FIRE,
        f"{e('comet')} <b>SERVIDORES DISPONIBLES</b>",
        SEP_FIRE,
        "💎 <b>PROVEEDORES AUTORIZADOS</b>",
    ]
    L += [f"{e('check')} {v}" for v in VENDEDORES]
    L += [SEP_FIRE, "🌎 <b>UBICACIONES DE RED</b>"]
    L += [f"{e('check')} IP {u}" for u in UBICACIONES]
    L += [SEP_FIRE, f"{e('gift')} <b>BENEFICIOS VIP</b>"]
    L += [f"{e('check')} {b}" for b in BENEFICIOS]
    L += [
        SEP_FIRE,
        f"{e('warn')} <b>NO TE QUEDES SIN TU SERVICIO</b>",
        "🎯 Vive la experiencia <b>premium</b> de JackSneider.",
        SEP_FIRE,
        f"{e('arrow_r')} <b>{SUPPORT_TAG}</b> {e('arrow_l')}",
    ]
    return "\n".join(L)


def render_welcome(nombre: str, uid, fecha: str, target: str = "group") -> str:
    """Bienvenida UNIFICADA (misma para canal y grupo).

    Si target == "{target}" se deja el placeholder para que welcome.build_text()
    lo resuelva por destino (canal/grupo) al enviar.
    """
    if target == "{target}":
        donde = "{target}"
    else:
        donde = "📍 Canal" if target == "channel" else "💬 Grupo"
    L = [
        f"{e('comet')} <b>MOVIVIP NETWORK</b>",
        f"👋 ¡Bienvenido/a, <b>{nombre}</b>!",
        f"👤 <b>Telegram:</b> {uid}",
        donde,
        "📌 <b>Reglas de la comunidad</b>",
        f"{e('check')} Respeto y buen trato.",
        f"{e('check')} Sin spam ni publicidad no autorizada.",
        f"{e('check')} Cuida tus datos; no compartas contraseñas.",
        f"{e('check')} Usa los botones oficiales para canales y soporte.",
        f"{e('key')} Para ver proveedores, ubicaciones y beneficios, escribe <code>/vip</code>.",
        "{comandos}",
        "💙 Gracias por ser parte de nuestra comunidad.",
    ]
    return "\n".join(L)


def _rows_seed():
    """Filas de botones de bienvenida (omite los enlaces vacíos del cliente)."""
    def b(text, url, target="both"):
        return {"text": text, "url": url, "target": target} if url else None
    flat = [
        b("📢 Canal", OWN_CHANNEL), b("👥 Grupo", OWN_GROUP),
        b("🔑 Bot Key", KEY_BOT),   b("🛒 Soporte", SUPPORT),
        b("▶️ YouTube", YOUTUBE),   b("🎵 TikTok", TIKTOK),
        b("🌐 Web", WEB),           b("🖥️ SSH Bot", SSH_BOT),
    ]
    out, pos = [], 0
    for it in flat:
        if it:
            it["pos"] = pos; pos += 1; out.append(it)
    for s in SOCIOS:  # lista vacía por defecto (white-label)
        it = b(s.get("text", ""), s.get("url", ""))
        if it:
            it["pos"] = pos; pos += 1; out.append(it)
    return out


def seed() -> dict:
    """Datos semilla para la BD (el panel podrá editar/reordenar/ocultar todo)."""
    return {
        "welcome_config": {
            "media_file_id": None, "media_type": "photo",
            "texto": render_welcome("{nombre}", "{usuario}", "{fecha}", "{target}"),
            "channel_enabled": 1, "group_enabled": 1,
        },
        "welcome_buttons": _rows_seed(),
        "commands": [{
            "slug": "vip", "titulo": "Proveedores autorizados / ubicaciones",
            "plantilla": render_vip(), "media_file_id": None, "media_type": None, "enabled": 1,
        }],
        "command_items": (
            [{"seccion": "vendedores",  "pos": i, "texto": v, "emoji_key": "check"} for i, v in enumerate(VENDEDORES)] +
            [{"seccion": "ubicaciones", "pos": i, "texto": u, "emoji_key": "check"} for i, u in enumerate(UBICACIONES)] +
            [{"seccion": "beneficios",  "pos": i, "texto": b, "emoji_key": "check"} for i, b in enumerate(BENEFICIOS)]
        ),
    }


if __name__ == "__main__":
    print("=" * 46, "\n   /vip  (versión premium -> cliente nuevo)\n", "=" * 46)
    print(strip_premium(render_vip()))
    print("\n" + "=" * 46, "\n   BIENVENIDA (canal/grupo)\n", "=" * 46)
    print(strip_premium(render_welcome("Kevin", "7375551234", "12/10/2026", "group")))
    print("\n[botones]")
    for b in seed()["welcome_buttons"]:
        print(f"  {b['text']:28} -> {b['url']}  [{b['target']}]")
