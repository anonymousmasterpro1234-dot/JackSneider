# -*- coding: utf-8 -*-
"""v5 — Guardian (paquete de mejoras, white-label). Importar como carpeta en sys.path."""
from handlers_v5 import register_v5, V5_TAG  # noqa: F401

__all__ = ["register_v5", "V5_TAG"]
