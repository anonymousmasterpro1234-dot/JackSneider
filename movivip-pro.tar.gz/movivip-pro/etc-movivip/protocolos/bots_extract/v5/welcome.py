# -*- coding: utf-8 -*-
"""
welcome.py — white-label v5
Bienvenida UNIFICADA (canal + grupo): 1 solo mensaje (foto/video + caption + botones).
Todo se lee de la BD (welcome_config + welcome_buttons) -> editable desde el panel.
"""
from __future__ import annotations
import html
import os
import re
import datetime
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.error import BadRequest
from context import get_db, CHANNEL_ID, GROUP_ID, LOGGER, BRAND_NAME, CHANNEL_LINK
from commands_mgr import available_commands
from premium_emoji import strip_premium

CAPTION_LIMIT = 1024
HEAD_CAPTION = f"👋 ¡Bienvenido a <b>{BRAND_NAME}</b>!"


def _now_str() -> str:
    return datetime.datetime.now().strftime("%d/%m/%Y %H:%M")


def get_config(conn=None) -> dict:
    own = conn is None
    conn = conn or get_db()
    try:
        row = conn.execute("SELECT * FROM welcome_config WHERE id=1").fetchone()
        return dict(row) if row else {}
    finally:
        if own:
            conn.close()


def get_buttons(conn=None, target: str = "both") -> list:
    own = conn is None
    conn = conn or get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM welcome_buttons WHERE visible=1 AND (target='both' OR target=?) ORDER BY pos, id",
            (target,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        if own:
            conn.close()


def build_text(nombre: str, uid, target: str, conn=None) -> str:
    cfg = get_config(conn)
    base = cfg.get("texto") or (
        f"👋 Bienvenido <b>{{nombre}}</b> a <b>{html.escape(BRAND_NAME)}</b>\n"
        "{comandos}"
    )
    where = "📍 Canal" if target == "channel" else "💬 Grupo"
    user_name = str(uid or "").strip()
    if user_name and not user_name.isdecimal() and user_name not in ("-", "None"):
        user_name = "@" + user_name.lstrip("@")
    else:
        user_name = "Sin @usuario público"
    values = {
        "nombre": html.escape(str(nombre or "Nuevo")),
        "usuario": html.escape(user_name),
        "id": html.escape(str(uid if uid is not None else "-")),
        "fecha": _now_str(),
        "target": where,
    }
    commands = available_commands(conn)
    command_lines = ["📚 <b>Comandos disponibles</b>"]
    for command, title in commands:
        description = f" — {html.escape(str(title))}" if title else ""
        command_lines.append(f"• <code>{command}</code>{description}")
    commands_text = "\n".join(command_lines)
    values["comandos"] = commands_text
    out = re.sub(
        r"\{(nombre|usuario|id|fecha|target|comandos)\}",
        lambda match: values[match.group(1)],
        base,
    )
    if "{comandos}" not in base:
        out = f"{out.rstrip()}\n\n{commands_text}"
    # Compatibilidad con textos antiguos que quedaron con "💬 Grupo" fijo.
    if target == "channel":
        out = out.replace("· 💬 Grupo", "· 📍 Canal")
    return out


def build_keyboard(conn=None, target: str = "both") -> InlineKeyboardMarkup:
    btns = get_buttons(conn, target)
    rows, row = [], []
    for b in btns:
        label = b.get("text") or "•"
        url = b.get("url") or CHANNEL_LINK
        if not url:
            continue
        row.append(InlineKeyboardButton(label, url=url))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton(
        "🔎 Ver proveedores · /vip", callback_data="mv:vip")])
    return InlineKeyboardMarkup(rows) if rows else None


def _media_source(cfg: dict):
    """
    Devuelve (tipo, fuente). Prioridad:
      1) media_path  -> archivo LOCAL editable (fuera del paquete)
      2) media_file_id -> id de Telegram
    tipo: 'photo' | 'video' | None. fuente: str(file_id) | file object | None.
    """
    mtype = (cfg.get("media_type") or "photo").lower()
    if mtype not in ("photo", "video"):
        mtype = "photo"
    path = (cfg.get("media_path") or "").strip()
    if path and not os.path.isabs(path):
        path = os.path.join(os.path.dirname(os.path.dirname(__file__)), path)
    if path and os.path.isfile(path):
        return mtype, open(path, "rb")
    fid = (cfg.get("media_file_id") or "").strip()
    if fid:
        return mtype, fid
    fallback = os.path.join(os.path.dirname(os.path.dirname(__file__)), "bienvenida.jpg")
    if mtype == "photo" and os.path.isfile(fallback):
        return "photo", open(fallback, "rb")
    return None, None


def _visible_len(text: str) -> int:
    """Cuenta unidades UTF-16 visibles, sin etiquetas HTML ni custom emoji."""
    visible = re.sub(r"<[^>]*>", "", strip_premium(text or ""))
    return len(html.unescape(visible).encode("utf-16-le")) // 2


def _rewind(src) -> None:
    try:
        if hasattr(src, "seek"):
            src.seek(0)
    except Exception:
        pass


async def _send_with_emoji_fallback(send, **kwargs):
    """Reintenta con emojis normales si Telegram rechaza entidades premium."""
    try:
        return await send(**kwargs)
    except BadRequest as exc:
        detail = str(exc).lower()
        if not any(k in detail for k in ("entit", "emoji", "parse")):
            raise
        LOGGER.warning("Telegram rechazó las entidades de emoji premium; se reintentará con emojis normales")
        fallback_kwargs = dict(kwargs)
        for key in ("text", "caption"):
            if key in fallback_kwargs:
                fallback_kwargs[key] = strip_premium(fallback_kwargs[key])
        for key in ("photo", "video"):
            _rewind(fallback_kwargs.get(key))
        return await send(**fallback_kwargs)


async def deliver(bot, chat_id, first_name: str, username, target: str = "both", conn=None) -> bool:
    """
    Envía la bienvenida v5 a chat_id: 1 solo mensaje si el texto cabe como caption;
    si no (texto visible > 1024), foto con caption corto + mensaje con el texto y botones.

    Importante: el límite 1024 se mide sobre el texto visible, NO sobre el HTML
    con etiquetas <tg-emoji>. Antes se comparaba len(text) y por eso la foto y el
    texto se enviaban separados aunque el texto visible cupiera perfectamente.
    """
    own = conn is None
    conn = conn or get_db()
    try:
        cfg = get_config(conn)
        enabled_key = "channel_enabled" if target == "channel" else "group_enabled"
        if not int(cfg.get(enabled_key, 1)):
            LOGGER.info("welcome disabled for %s; skipping chat %s", target, chat_id)
            return False
        text = build_text(first_name or "Nuevo", username or "-", target, conn)
        kb = build_keyboard(conn, target)
        mtype, src = _media_source(cfg)
        fits = _visible_len(text) <= CAPTION_LIMIT
        try:
            if src is not None and mtype == "video":
                if fits:
                    await _send_with_emoji_fallback(
                        bot.send_video, chat_id=chat_id, video=src, caption=text,
                        parse_mode=ParseMode.HTML, reply_markup=kb)
                else:
                    await _send_with_emoji_fallback(
                        bot.send_video, chat_id=chat_id, video=src, caption=HEAD_CAPTION,
                        parse_mode=ParseMode.HTML)
                    await _send_with_emoji_fallback(
                        bot.send_message, chat_id=chat_id, text=text,
                        parse_mode=ParseMode.HTML, reply_markup=kb,
                        disable_web_page_preview=True)
                return True
            if src is not None:  # photo
                if fits:
                    await _send_with_emoji_fallback(
                        bot.send_photo, chat_id=chat_id, photo=src, caption=text,
                        parse_mode=ParseMode.HTML, reply_markup=kb)
                else:
                    await _send_with_emoji_fallback(
                        bot.send_photo, chat_id=chat_id, photo=src, caption=HEAD_CAPTION,
                        parse_mode=ParseMode.HTML)
                    await _send_with_emoji_fallback(
                        bot.send_message, chat_id=chat_id, text=text,
                        parse_mode=ParseMode.HTML, reply_markup=kb,
                        disable_web_page_preview=True)
                return True
            await _send_with_emoji_fallback(
                bot.send_message, chat_id=chat_id, text=text,
                parse_mode=ParseMode.HTML, reply_markup=kb,
                disable_web_page_preview=True)
            return True
        finally:
            try:
                if hasattr(src, "close"):
                    src.close()
            except Exception:
                pass
    finally:
        if own:
            conn.close()


async def send_welcome(bot, user, target: str):
    """Compat: envía la bienvenida (1 solo mensaje) al canal o grupo configurado."""
    chat_id = CHANNEL_ID if target == "channel" else GROUP_ID
    if not chat_id:
        LOGGER.warning("send_welcome: chat_id no configurado para %s", target)
        return
    return await deliver(
        bot, chat_id,
        getattr(user, "full_name", None) or getattr(user, "first_name", "Nuevo"),
        getattr(user, "id", "-"), target,
    )
