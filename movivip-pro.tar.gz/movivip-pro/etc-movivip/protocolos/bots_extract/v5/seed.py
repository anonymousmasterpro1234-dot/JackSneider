# -*- coding: utf-8 -*-
"""
seed.py — white-label v5
Aplica los datos semilla (bienvenida + botones + comando /vip) SOLO si están vacíos.
Idempotente: se puede llamar en cada arranque sin duplicar nada.
"""
from __future__ import annotations
from context import get_db, LOGGER
from templates import seed as tseed
import commands_mgr as C


def apply_seed(conn=None):
    own = conn is None
    conn = conn or get_db()
    try:
        conn.execute("INSERT OR IGNORE INTO welcome_config (id) VALUES (1)")
        conn.execute("INSERT OR IGNORE INTO abuse_settings (id) VALUES (1)")
        data = tseed()

        # 1) texto de bienvenida
        row = conn.execute("SELECT texto FROM welcome_config WHERE id=1").fetchone()
        if row is not None:
            current_text = row["texto"] or ""
            if not current_text.strip():
                updated_text = data["welcome_config"]["texto"]
            elif "{comandos}" not in current_text:
                updated_text = f"{current_text.rstrip()}\n\n{{comandos}}"
            else:
                updated_text = current_text
            if updated_text != current_text:
                conn.execute(
                    "UPDATE welcome_config SET texto=?, updated_at=datetime('now') WHERE id=1",
                    (updated_text,),
                )
                LOGGER.info("seed: texto de bienvenida actualizado")

        # 2) botones de bienvenida
        n = conn.execute("SELECT COUNT(*) AS c FROM welcome_buttons").fetchone()["c"]
        if n == 0:
            for b in data["welcome_buttons"]:
                conn.execute(
                    "INSERT INTO welcome_buttons (pos, text, url, target, visible) VALUES (?,?,?,?,1)",
                    (b["pos"], b["text"], b["url"], b["target"]))
            LOGGER.info("seed: %d botones de bienvenida insertados", len(data["welcome_buttons"]))

        conn.commit()

        # 3) comando /vip
        C.seed_default_commands(conn)
    finally:
        if own:
            conn.close()
