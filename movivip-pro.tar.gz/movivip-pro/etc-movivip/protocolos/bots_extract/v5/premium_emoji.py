# -*- coding: utf-8 -*-
"""
premium_emoji.py — white-label (v5)
Catálogo de emojis premium (Telegram custom_emoji / <tg-emoji>).

Fuente del mapeo: catálogo interno del pack (los IDs premium son del pack del cliente).
Escaneo: 23 IDs únicos -> 8 destellos + 8 fuegos + 7 singulares (check/gift/key/comet/warn/⮕/⬅).

Uso:
    from premium_emoji import e, sep, strip_premium
    texto = f"{e('check')} Bienvenido a <b>TuMarca</b> {e('fire')}"

Notas:
- El cliente que soporte emojis premium muestra la versión animada; el resto ve el fallback (emoji normal).
- Los mensajes que usen <tg-emoji> DEBEN enviarse con parse_mode="HTML".
- En titles/descripciones de botones NO se admiten <tg-emoji>; usar el fallback plano.
"""

# ── Sets decorativos (se usan repetidos como línea separadora) ───────────────
# 8 destellos (fallback ✨) — orden tal cual aparecen en la plantilla
SPARKLES = [
    ("5217577295392290530", "✨"),
    ("5217607248494212444", "✨"),
    ("5220018327170067514", "✨"),
    ("5217636024775095236", "✨"),
    ("5219955341474673762", "✨"),
    ("5220082025830036895", "✨"),
    ("5217930891459837203", "✨"),
    ("5220012971345852945", "✨"),
]

# 8 fuegos (fallback 🔥)
FIRES = [
    ("5370596264205366968", "🔥"),
    ("5372804697734260925", "🔥"),
    ("5372933134436297955", "🔥"),
    ("5372972326012857961", "🔥"),
    ("5370635893868606590", "🔥"),
    ("5370660697304741172", "🔥"),
    ("5372880070115341091", "🔥"),
    ("5370754155793102519", "🔥"),
]

# ── Singulares ───────────────────────────────────────────────────────────────
SINGLE = {
    "check":   ("5462919317832082236", "✅"),
    "gift":    ("5199749070830197566", "🎁"),
    "key":     ("6176966310920983412", "🔑"),
    "comet":   ("5999256348217315828", "☄️"),
    "warn":    ("5989870161048376071", "⚠️"),
    "arrow_r": ("5215613971352004352", "➡️"),
    "arrow_l": ("5215361191051798408", "⬅️"),
}


def _tag(emoji_id: str, fallback: str) -> str:
    return f'<tg-emoji emoji-id="{emoji_id}">{fallback}</tg-emoji>'


def e(name: str) -> str:
    """Devuelve el <tg-emoji> de un emoji singular por nombre.
    name: check|gift|key|comet|warn|arrow_r|arrow_l  (si no existe -> cadena vacía)."""
    pair = SINGLE.get(name)
    return _tag(*pair) if pair else ""


def fire() -> str:
    return _tag(*FIRES[0])


def sparkle() -> str:
    return _tag(*SPARKLES[0])


def sep(kind: str = "fire", n: int = 8, offset: int = 0) -> str:
    """Línea separadora de n emojis premium.
    kind: 'fire' | 'sparkle'. offset permite variar la animación inicial."""
    pool = FIRES if kind == "fire" else SPARKLES
    out = []
    for i in range(n):
        emoji_id, fb = pool[(i + offset) % len(pool)]
        out.append(_tag(emoji_id, fb))
    return "".join(out)


# Separadores listos para usar (estilo de la plantilla del bot-key)
SEP_FIRE = sep("fire", 8)
SEP_SPARK = sep("sparkle", 8)

# Mapa id -> fallback (útil para whitelist/validación/strip)
ID_TO_FALLBACK = {i: f for i, f in SPARKLES + FIRES}
for _k, (_i, _f) in SINGLE.items():
    ID_TO_FALLBACK[_i] = _f


def strip_premium(text: str) -> str:
    """Reemplaza <tg-emoji emoji-id="...">X</tg-emoji> por X (para logs, títulos, texto plano)."""
    import re
    return re.sub(r'<tg-emoji emoji-id="\d+">(.*?)</tg-emoji>', r"\1", text, flags=re.S)


def is_valid_id(emoji_id: str) -> bool:
    return str(emoji_id) in ID_TO_FALLBACK
