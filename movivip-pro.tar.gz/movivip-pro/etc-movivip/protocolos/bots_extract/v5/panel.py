# -*- coding: utf-8 -*-
"""
panel.py — white-label v5
Panel admin por botones (DM con el bot). Todo re-editable:
  🎨 Bienvenida (foto/video, texto, botones, destino canal/grupo, on/off)
  🛠️ Comandos   (crear/editar/borrar CUALQUIER comando, plantilla, foto)
  🛡️ Anti-abuso (media de castigo, texto de aviso, escalado, historial, on/off)
Usa una máquina de estados simple en context.user_data['v5'].
"""
from __future__ import annotations
import html
import json
import re
from urllib.parse import urlsplit

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import CommandHandler, ApplicationHandlerStop

from context import get_db, is_admin_simple, LOGGER, BRAND_NAME, GROUP_ID
import welcome as W
import commands_mgr as C
import abuse as A

# ════════════════════════════════════════════════════════════════════════════
# Helpers
# ════════════════════════════════════════════════════════════════════════════
def _cap(s, n=28):
    s = (s or "").strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def _set_state(context, await_, arg=None, extra=None):
    for key in ("bienv_edit", "promo_edit", "editando_boton_idx",
                "boton_nuevo_texto", "promo_texto", "promo_foto",
                "promo_boton_texto", "promo_boton_edit_texto"):
        context.user_data.pop(key, None)
    st = {"await": await_, "arg": arg}
    if extra:
        st.update(extra)
    context.user_data["v5"] = st


def _clear_state(context):
    context.user_data.pop("v5", None)


def _state(context):
    return context.user_data.get("v5")


def _media(msg):
    if msg.photo:
        return (msg.photo[-1].file_id, "photo")
    if msg.video:
        return (msg.video.file_id, "video")
    if msg.animation:
        return (msg.animation.file_id, "anim")
    if msg.sticker:
        return (msg.sticker.file_id, "sticker")
    if msg.document:
        mt = "video" if (msg.document.mime_type or "").startswith("video") else "photo"
        return (msg.document.file_id, mt)
    return (None, None)


def _is_https_url(value):
    try:
        parsed = urlsplit(value)
        return (
            parsed.scheme.lower() == "https"
            and bool(parsed.hostname)
            and not any(char.isspace() for char in value)
        )
    except ValueError:
        return False


async def _deny(query):
    await query.answer("🚫 Solo administradores.", show_alert=True)


# ════════════════════════════════════════════════════════════════════════════
# Vistas (menús)
# ════════════════════════════════════════════════════════════════════════════
def view_home():
    text = (f"🛡️ <b>PANEL {BRAND_NAME.upper()}</b> 🛡️\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "🎨 Bienvenida · 🛠️ Comandos · 🛡️ Anti-abuso\n"
            "Todo es editable y se aplica al instante.")
    kb = [
        [InlineKeyboardButton("🎨 Bienvenida", callback_data="p5:w:menu"),
         InlineKeyboardButton("🛠️ Comandos", callback_data="p5:c:list")],
        [InlineKeyboardButton("🛡️ Anti-abuso", callback_data="p5:a:menu"),
         InlineKeyboardButton("🔎 Vista previa bienvenida", callback_data="p5:w:prev:group")],
        [InlineKeyboardButton("✖️ Cerrar", callback_data="p5:close")],
    ]
    return text, InlineKeyboardMarkup(kb)


def view_welcome():
    conn = get_db()
    try:
        cfg = W.get_config(conn)
    finally:
        conn.close()
    chan = "✅" if int(cfg.get("channel_enabled", 1)) else "🚫"
    grp = "✅" if int(cfg.get("group_enabled", 1)) else "🚫"
    media = cfg.get("media_type") or "none"
    media_ok = bool(cfg.get("media_file_id") or cfg.get("media_path"))
    text = (f"🎨 <b>BIENVENIDA</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🖼️ Media: <b>{media}</b> {'(configurada)' if media_ok else '(sin foto/video)'}\n"
            f"📝 Texto: {'configurado' if cfg.get('texto') else 'vacío'}\n"
            f"🔘 Botones: se editan aparte\n"
            f"📢 Canal: {chan}   👥 Grupo: {grp}")
    kb = [
        [InlineKeyboardButton("🖼️ Cambiar foto/video", callback_data="p5:w:media"),
         InlineKeyboardButton("📝 Editar texto", callback_data="p5:w:text")],
        [InlineKeyboardButton("🔘 Botones", callback_data="p5:w:btns")],
        [InlineKeyboardButton(f"📢 Canal {chan}", callback_data="p5:w:tg:channel"),
         InlineKeyboardButton(f"👥 Grupo {grp}", callback_data="p5:w:tg:group")],
        [InlineKeyboardButton("🔎 Ver canal", callback_data="p5:w:prev:channel"),
         InlineKeyboardButton("🔎 Ver grupo", callback_data="p5:w:prev:group")],
        [InlineKeyboardButton("⬅️ Volver", callback_data="p5:home")],
    ]
    return text, InlineKeyboardMarkup(kb)


def view_buttons():
    conn = get_db()
    try:
        rows = conn.execute("SELECT * FROM welcome_buttons ORDER BY pos, id").fetchall()
    finally:
        conn.close()
    kb = []
    for b in rows:
        i = b["id"]
        vis = "👁️" if int(b["visible"]) else "🙈"
        kb.append([
            InlineKeyboardButton(f"✏️ {_cap(b['text'], 18)}", callback_data=f"p5:w:settext:{i}"),
            InlineKeyboardButton("🔗", callback_data=f"p5:w:seturl:{i}"),
            InlineKeyboardButton(vis, callback_data=f"p5:w:bt:{i}"),
            InlineKeyboardButton("⬆️", callback_data=f"p5:w:up:{i}"),
            InlineKeyboardButton("⬇️", callback_data=f"p5:w:dn:{i}"),
            InlineKeyboardButton("🗑️", callback_data=f"p5:w:del:{i}"),
        ])
    kb.append([InlineKeyboardButton("➕ Añadir botón", callback_data="p5:w:badd")])
    kb.append([InlineKeyboardButton("⬅️ Volver", callback_data="p5:w:menu")])
    text = ("🔘 <b>BOTONES DE BIENVENIDA</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "✏️ texto · 🔗 enlace · 👁️ visible · ⬆️⬇️ orden · 🗑️ borrar")
    return text, InlineKeyboardMarkup(kb)


def view_commands():
    conn = get_db()
    try:
        rows = C.list_commands(conn)
    finally:
        conn.close()
    kb = []
    for r in rows:
        on = "✅" if int(r["enabled"]) else "🚫"
        kb.append([InlineKeyboardButton(f"{on} /{r['slug']} · {_cap(r['titulo'], 22)}",
                                        callback_data=f"p5:c:open:{r['id']}")])
    kb.append([InlineKeyboardButton("➕ Nuevo comando", callback_data="p5:c:new")])
    kb.append([InlineKeyboardButton("⬅️ Volver", callback_data="p5:home")])
    return "🛠️ <b>COMANDOS</b>\n━━━━━━━━━━━━━━━━━━━━━━\nCrea/edita cualquier comando, su plantilla y su foto.", InlineKeyboardMarkup(kb)


def view_command(cid):
    conn = get_db()
    try:
        r = C.get_command(cid=cid, conn=conn)
    finally:
        conn.close()
    if not r:
        return "Comando no encontrado.", InlineKeyboardMarkup([[InlineKeyboardButton("⬅️", callback_data="p5:c:list")]])
    on = "✅ Activo" if int(r["enabled"]) else "🚫 Inactivo"
    text = (f"🛠️ <b>/{r['slug']}</b>\n━━━━━━━━━━━━━━━━━━━━━━\n"
            f"Título: {r['titulo'] or '—'}\nEstado: {on}\n"
            f"Foto: {'sí' if r['media_file_id'] else 'no'}")
    kb = [
        [InlineKeyboardButton("✏️ Título", callback_data=f"p5:c:title:{cid}"),
         InlineKeyboardButton("📝 Plantilla", callback_data=f"p5:c:tpl:{cid}")],
        [InlineKeyboardButton("🖼️ Foto", callback_data=f"p5:c:media:{cid}"),
         InlineKeyboardButton(on, callback_data=f"p5:c:tgl:{cid}")],
        [InlineKeyboardButton("🧩 Ítems", callback_data=f"p5:c:items:{cid}"),
         InlineKeyboardButton("🔎 Vista previa", callback_data=f"p5:c:prev:{cid}")],
        [InlineKeyboardButton("🗑️ Borrar", callback_data=f"p5:c:del:{cid}"),
         InlineKeyboardButton("⬅️ Volver", callback_data="p5:c:list")],
    ]
    return text, InlineKeyboardMarkup(kb)


def view_items(cid):
    conn = get_db()
    try:
        items = C.get_items(cid, conn=conn)
    finally:
        conn.close()
    kb = []
    for it in items:
        i = it["id"]
        vis = "👁️" if int(it["visible"]) else "🙈"
        kb.append([
            InlineKeyboardButton(f"✏️ [{it['seccion']}] {_cap(it['texto'], 18)}",
                                 callback_data=f"p5:c:itedit:{i}"),
            InlineKeyboardButton(vis, callback_data=f"p5:c:ittgl:{i}"),
            InlineKeyboardButton("🗑️", callback_data=f"p5:c:itdel:{i}"),
        ])
    kb.append([InlineKeyboardButton("➕ Añadir ítem", callback_data=f"p5:c:itadd:{cid}")])
    kb.append([InlineKeyboardButton("⬅️ Volver", callback_data=f"p5:c:open:{cid}")])
    return "🧩 <b>ÍTEMS</b> (se insertan donde la plantilla tenga <code>{items}</code>)\nSi tu plantilla ya trae el texto completo, no necesitas ítems.", InlineKeyboardMarkup(kb)


def view_abuse():
    conn = get_db()
    try:
        s = A.get_settings(conn)
        cases = [
            (row, A.resolve_chat_id(conn, row["user_id"]))
            for row in A.active_cases(conn, 8)
        ]
    finally:
        conn.close()
    on = "✅" if int(s.get("enabled", 1)) else "🚫"
    mt = s.get("punish_media_type") or "none"
    text = (f"🛡️ <b>ANTI-ABUSO</b>\n━━━━━━━━━━━━━━━━━━━━━━\n"
            f"Estado: {on}\nMedia de castigo: <b>{mt}</b> {'(subida)' if s.get('punish_media_file_id') else '(ninguna)'}\n"
            f"Aviso: {'configurado' if s.get('warn_text') else 'por defecto'}\n"
            f"Escalado: AVISO → MUTE 15m → MUTE 1h → BAN\n"
            f"Casos activos visibles: <b>{len(cases)}</b> (máx. 8)")
    kb = [
        [InlineKeyboardButton("🎬 Media de castigo", callback_data="p5:a:media"),
         InlineKeyboardButton("📝 Texto de aviso", callback_data="p5:a:warn")],
        [InlineKeyboardButton("📶 Escalado", callback_data="p5:a:esc"),
         InlineKeyboardButton("📜 Historial", callback_data="p5:a:hist")],
        [InlineKeyboardButton("🔓 Desbanear por ID", callback_data="p5:a:unban_input")],
    ]
    for row, chat_id in cases:
        if not chat_id:
            continue
        is_muted = row["status"] == "muted"
        status = "silenciado" if is_muted else "baneado"
        action = "🔊 Quitar silencio" if is_muted else "🔓 Desbanear"
        kb.append([InlineKeyboardButton(
            f"{action} · {status} · ID {row['user_id']}",
            callback_data=f"p5:a:unban:{row['user_id']}:{chat_id}")])
    kb.extend([
        [InlineKeyboardButton(f"{on} Anti-abuso", callback_data="p5:a:tgl")],
        [InlineKeyboardButton("⬅️ Volver", callback_data="p5:home")],
    ])
    return text, InlineKeyboardMarkup(kb)


# ════════════════════════════════════════════════════════════════════════════
# Comandos
# ════════════════════════════════════════════════════════════════════════════
async def cmd_panel(update, context):
    if update.effective_chat.type != "private":
        await update.effective_message.reply_text(
            "🔒 Abre el chat privado del bot para usar el panel de administración."
        )
        return
    if not is_admin_simple(update.effective_user.id):
        await update.effective_message.reply_text("🚫 Solo administradores.")
        return
    _clear_state(context)
    text, kb = view_home()
    await update.effective_message.reply_text(text, reply_markup=kb, parse_mode=ParseMode.HTML)


async def cmd_unban(update, context):
    """Desbanea un ID usando el chat actual o el grupo configurado."""
    user = update.effective_user
    msg = update.effective_message
    if not is_admin_simple(user.id):
        return await msg.reply_text("🚫 Solo administradores.")
    if not context.args or len(context.args) > 2:
        return await msg.reply_text("Uso: /desbanear ID_USUARIO [CHAT_ID]")
    try:
        user_id = int(context.args[0])
        chat_id = int(context.args[1]) if len(context.args) == 2 else None
        if user_id <= 0:
            raise ValueError
    except ValueError:
        return await msg.reply_text("⚠️ IDs inválidos. Uso: /desbanear ID_USUARIO [CHAT_ID]")

    if chat_id is None and update.effective_chat.type in ("group", "supergroup"):
        chat_id = update.effective_chat.id
    if chat_id is None:
        conn = get_db()
        try:
            chat_id = A.resolve_chat_id(conn, user_id)
        finally:
            conn.close()
    if chat_id is None:
        try:
            chat_id = int(GROUP_ID)
        except (TypeError, ValueError):
            chat_id = 0
    if not chat_id:
        return await msg.reply_text("⚠️ No encontré el grupo. Indica el CHAT_ID.")
    try:
        action = await A.unban_user(context.bot, user_id, chat_id, user.id)
    except Exception as exc:
        LOGGER.error("Falló desbanear %s en %s: %s", user_id, chat_id, exc, exc_info=True)
        return await msg.reply_text(f"❌ No se pudo desbanear a {user_id}: {exc}")
    verb = "silencio retirado" if action == "unmuted" else "desbaneado"
    await msg.reply_text(f"✅ Usuario {user_id}: {verb} en el chat {chat_id}.")


async def cmd_vip(update, context):
    """PÚBLICO: envía el comando /vip configurado."""
    await _send_public_command(
        update.effective_message, context, "vip", requester=update.effective_user)


async def vip_callback(update, context):
    """Ejecuta /vip al pulsar el botón de la bienvenida."""
    query = update.callback_query
    if not query or query.data != "mv:vip":
        return
    try:
        await _send_public_command(
            query.message, context, "vip", requester=query.from_user)
    except Exception as exc:
        LOGGER.error("vip callback failed: %s", exc, exc_info=True)
        await query.answer("No se pudo mostrar /vip. Inténtalo de nuevo.", show_alert=True)
        return
    await query.answer("Proveedores autorizados")


async def _send_public_command(msg, context, slug, requester=None):
    conn = get_db()
    try:
        r = C.get_command(slug=slug, conn=conn)
        if not r or not int(r["enabled"]):
            await msg.reply_text("Comando no disponible.")
            return
        text = C.render_command(r["id"], conn=conn)
        fid, mt = r["media_file_id"], (r["media_type"] or "photo")
    finally:
        conn.close()
    if requester is not None:
        label = (f"@{requester.username}" if requester.username
                 else requester.full_name or "miembro")
        mention = (
            f'<a href="tg://user?id={int(requester.id)}">'
            f'{html.escape(label)}</a>'
        )
        text = f"👤 Solicitado por {mention}\n\n{text}"
    visible = W._visible_len(text)
    if fid and mt == "photo":
        if visible <= W.CAPTION_LIMIT:
            await W._send_with_emoji_fallback(
                msg.reply_photo, photo=fid, caption=text, parse_mode=ParseMode.HTML)
        else:
            await W._send_with_emoji_fallback(
                msg.reply_photo, photo=fid, caption=W.HEAD_CAPTION, parse_mode=ParseMode.HTML)
            await W._send_with_emoji_fallback(
                msg.reply_text, text=text, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    elif fid and mt == "video":
        if visible <= W.CAPTION_LIMIT:
            await W._send_with_emoji_fallback(
                msg.reply_video, video=fid, caption=text, parse_mode=ParseMode.HTML)
        else:
            await W._send_with_emoji_fallback(
                msg.reply_video, video=fid, caption=W.HEAD_CAPTION, parse_mode=ParseMode.HTML)
            await W._send_with_emoji_fallback(
                msg.reply_text, text=text, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    else:
        await W._send_with_emoji_fallback(
            msg.reply_text, text=text, parse_mode=ParseMode.HTML, disable_web_page_preview=True)


def build_public_command_handler(slug, stop=False):
    async def _h(update, context):
        from context import license_active
        if not license_active():
            await update.effective_message.reply_text(
                "El bot está suspendido por licencia.")
            raise ApplicationHandlerStop
        await _send_public_command(update.effective_message, context, slug)
        if stop:
            raise ApplicationHandlerStop
    return CommandHandler(slug, _h)


def register_existing_commands(app, group=-2):
    conn = get_db()
    try:
        rows = C.list_commands(conn)
    finally:
        conn.close()
    for r in rows:
        if r["slug"] in C.RESERVED_COMMANDS:
            continue
        app.add_handler(build_public_command_handler(r["slug"], stop=True), group=group)
        LOGGER.info("comando público registrado: /%s (grupo %s)", r["slug"], group)


# ════════════════════════════════════════════════════════════════════════════
# Dispatcher de callbacks
# ════════════════════════════════════════════════════════════════════════════
async def on_callback(update, context):
    q = update.callback_query
    if not q or not (q.data or "").startswith("p5:"):
        return
    if not q.message or q.message.chat.type != "private":
        await q.answer(
            "🔒 El panel solo funciona en el chat privado del bot.",
            show_alert=True,
        )
        raise ApplicationHandlerStop
    if not is_admin_simple(q.from_user.id):
        await _deny(q)
        raise ApplicationHandlerStop
    await q.answer()
    try:
        await _route(q, context, q.data[3:])
    except Exception as e:
        LOGGER.error("panel callback %s: %s", q.data, e, exc_info=True)
        _clear_state(context)
        try:
            await q.edit_message_text("⚠️ No se pudo completar la acción. No se guardaron cambios; vuelve a intentarlo.")
        except Exception:
            pass
    raise ApplicationHandlerStop


async def _edit(q, text, kb):
    try:
        await q.edit_message_text(text, reply_markup=kb, parse_mode=ParseMode.HTML,
                                  disable_web_page_preview=True)
    except Exception:
        await q.message.reply_text(text, reply_markup=kb, parse_mode=ParseMode.HTML,
                                   disable_web_page_preview=True)


async def _route(q, context, d):
    # Cualquier navegación cancela el formulario anterior. Las acciones de
    # edición activan su nuevo estado después de llegar a su propio bloque.
    _clear_state(context)
    p = d.split(":")
    head = p[0]

    # ── home ────────────────────────────────────────────────────────────
    if d == "home":
        t, k = view_home(); return await _edit(q, t, k)
    if d == "close":
        _clear_state(context)
        return await q.edit_message_text("✖️ Panel cerrado. Usa /panel cuando quieras.")

    # ── BIENVENIDA ──────────────────────────────────────────────────────
    if head == "w":
        sub = p[1] if len(p) > 1 else "menu"
        if sub == "menu":
            t, k = view_welcome(); return await _edit(q, t, k)
        if sub == "media":
            _set_state(context, "w_media")
            return await _edit(q, "🖼️ Envía la <b>foto o video</b> de bienvenida (o /cancelar).",
                               InlineKeyboardMarkup([[InlineKeyboardButton("⬅️", callback_data="p5:w:menu")]]))
        if sub == "text":
            _set_state(context, "w_text")
            return await _edit(q, "📝 Envía el <b>texto</b> de bienvenida (HTML + emojis).\n"
                                  "Variables: <code>{nombre}</code> <code>{usuario}</code> <code>{id}</code> <code>{fecha}</code> <code>{target}</code> <code>{comandos}</code>\n"
                                  "La lista de comandos públicos activos se inserta en <code>{comandos}</code>. "
                                  "Si no incluyes la variable, se añade al final automáticamente.",
                               InlineKeyboardMarkup([[InlineKeyboardButton("⬅️", callback_data="p5:w:menu")]]))
        if sub == "btns":
            t, k = view_buttons(); return await _edit(q, t, k)
        if sub == "tg":  # toggle destino
            tgt = "channel_enabled" if p[2] == "channel" else "group_enabled"
            conn = get_db()
            try:
                conn.execute(f"UPDATE welcome_config SET {tgt}=1-{tgt} WHERE id=1"); conn.commit()
            finally:
                conn.close()
            t, k = view_welcome(); return await _edit(q, t, k)
        if sub == "prev":  # vista previa (mensaje nuevo)
            target = p[2] if len(p) > 2 else "group"
            conn = get_db()
            try:
                cfg = W.get_config(conn)
                text = W.build_text("Kevin", "@kevin", target, conn)
                kb = W.build_keyboard(conn, target)
                mtype, source = W._media_source(cfg)
            finally:
                conn.close()
            visible = W._visible_len(text)
            try:
                if source is not None and visible <= 1024:
                    if mtype == "video":
                        await W._send_with_emoji_fallback(
                            q.message.reply_video, video=source, caption=text,
                            parse_mode=ParseMode.HTML, reply_markup=kb)
                    else:
                        await W._send_with_emoji_fallback(
                            q.message.reply_photo, photo=source, caption=text,
                            parse_mode=ParseMode.HTML, reply_markup=kb)
                elif source is not None:
                    # Texto demasiado largo para caption: media + texto separado.
                    if mtype == "video":
                        await W._send_with_emoji_fallback(q.message.reply_video, video=source)
                    else:
                        await W._send_with_emoji_fallback(q.message.reply_photo, photo=source)
                    await W._send_with_emoji_fallback(
                        q.message.reply_text, text=text, parse_mode=ParseMode.HTML,
                        reply_markup=kb, disable_web_page_preview=True)
                else:
                    await W._send_with_emoji_fallback(
                        q.message.reply_text, text=text, parse_mode=ParseMode.HTML,
                        reply_markup=kb, disable_web_page_preview=True)
            finally:
                if source is not None and hasattr(source, "close"):
                    try:
                        source.close()
                    except Exception:
                        pass
            return
        if sub == "badd":
            _set_state(context, "w_btn_text")
            return await _edit(q, "➕ Escribe el <b>texto</b> del nuevo botón (con emoji).",
                               InlineKeyboardMarkup([[InlineKeyboardButton("⬅️", callback_data="p5:w:btns")]]))
        if sub in ("settext", "seturl"):
            i = int(p[2])
            _set_state(context, "w_btn_edit_text" if sub == "settext" else "w_btn_edit_url", i)
            what = "texto" if sub == "settext" else "enlace (URL https://...)"
            return await _edit(
                q, f"✏️ Escribe el nuevo <b>{what}</b>.",
                InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Cancelar", callback_data="p5:w:btns")]]))
        if sub == "bt":
            i = int(p[2]); conn = get_db()
            try:
                conn.execute("UPDATE welcome_buttons SET visible=1-visible WHERE id=?", (i,)); conn.commit()
            finally:
                conn.close()
            t, k = view_buttons(); return await _edit(q, t, k)
        if sub in ("up", "dn"):
            i = int(p[2]); _swap_button(i, -1 if sub == "up" else 1)
            t, k = view_buttons(); return await _edit(q, t, k)
        if sub == "del":
            i = int(p[2]); conn = get_db()
            try:
                conn.execute("DELETE FROM welcome_buttons WHERE id=?", (i,)); conn.commit()
            finally:
                conn.close()
            t, k = view_buttons(); return await _edit(q, t, k)

    # ── COMANDOS ────────────────────────────────────────────────────────
    if head == "c":
        sub = p[1] if len(p) > 1 else "list"
        if sub == "list":
            t, k = view_commands(); return await _edit(q, t, k)
        if sub == "new":
            _set_state(context, "c_new_slug")
            return await _edit(q, "➕ Escribe el <b>nombre del comando</b> SIN la barra (ej: <code>precios</code>).",
                               InlineKeyboardMarkup([[InlineKeyboardButton("⬅️", callback_data="p5:c:list")]]))
        cid = int(p[2]) if len(p) > 2 else None
        if sub == "open":
            t, k = view_command(cid); return await _edit(q, t, k)
        if sub == "title":
            _set_state(context, "c_title", cid)
            return await _edit(
                q, "✏️ Escribe el nuevo <b>título</b> del comando.",
                InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Cancelar", callback_data=f"p5:c:open:{cid}")]]))
        if sub == "tpl":
            _set_state(context, "c_tpl", cid)
            return await _edit(q, "📝 Envía la <b>plantilla</b> (HTML + emojis).\n"
                                  "Tokens: <code>{SEP_FIRE}</code> <code>{SEP_SPARK}</code> <code>{items}</code>",
                               InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Cancelar", callback_data=f"p5:c:open:{cid}")]]))
        if sub == "media":
            _set_state(context, "c_media", cid)
            return await _edit(
                q, "🖼️ Envía la <b>foto/video</b> del comando.",
                InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Cancelar", callback_data=f"p5:c:open:{cid}")]]))
        if sub == "tgl":
            C.toggle_command(cid); t, k = view_command(cid); return await _edit(q, t, k)
        if sub == "del":
            C.delete_command(cid)
            return await _edit(q, "🗑️ Comando borrado.", InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Comandos", callback_data="p5:c:list")]]))
        if sub == "items":
            t, k = view_items(cid); return await _edit(q, t, k)
        if sub == "itadd":
            _set_state(context, "c_add_text", cid)
            return await _edit(
                q, "➕ Escribe el <b>texto</b> del nuevo ítem.",
                InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Cancelar", callback_data=f"p5:c:items:{cid}")]]))
        if sub == "itedit":
            _set_state(context, "c_edit_text", cid)
            return await _edit(
                q, "✏️ Escribe el nuevo <b>texto</b> del ítem.",
                InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Cancelar", callback_data="p5:c:list")]]))
        if sub == "ittgl":
            conn = get_db()
            try:
                it = conn.execute("SELECT command_id FROM command_items WHERE id=?", (cid,)).fetchone()
                conn.execute("UPDATE command_items SET visible=1-visible WHERE id=?", (cid,)); conn.commit()
                parent = it["command_id"] if it else None
            finally:
                conn.close()
            if parent:
                t, k = view_items(parent); return await _edit(q, t, k)
            return
        if sub == "itdel":
            conn = get_db()
            try:
                it = conn.execute("SELECT command_id FROM command_items WHERE id=?", (cid,)).fetchone()
                parent = it["command_id"] if it else None
            finally:
                conn.close()
            C.delete_item(cid)
            if parent:
                t, k = view_items(parent); return await _edit(q, t, k)
            return
        if sub == "prev":
            conn = get_db()
            try:
                r = C.get_command(cid=cid, conn=conn)
                text = C.render_command(cid, conn=conn)
                fid, mt = r["media_file_id"], (r["media_type"] or "photo")
            finally:
                conn.close()
            if fid and mt == "photo":
                await q.message.reply_photo(fid, caption=text, parse_mode=ParseMode.HTML)
            elif fid and mt == "video":
                await q.message.reply_video(fid, caption=text, parse_mode=ParseMode.HTML)
            else:
                await q.message.reply_text(text, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
            return

    # ── ANTI-ABUSO ──────────────────────────────────────────────────────
    if head == "a":
        sub = p[1] if len(p) > 1 else "menu"
        if sub == "menu":
            t, k = view_abuse(); return await _edit(q, t, k)
        if sub == "media":
            _set_state(context, "a_media")
            return await _edit(
                q, "🎬 Envía el <b>GIF / sticker / foto</b> de castigo.",
                InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Cancelar", callback_data="p5:a:menu")]]))
        if sub == "unban_input":
            _set_state(context, "a_unban")
            return await _edit(
                q, "🔓 Envía el <b>ID de usuario</b> y, si hace falta, el <b>chat_id</b>.\n"
                "Formato: <code>123456789 -1001234567890</code>\n"
                "También puedes usar /desbanear ID [CHAT_ID].",
                InlineKeyboardMarkup([[InlineKeyboardButton(
                    "⬅️ Cancelar", callback_data="p5:a:menu")]]))
        if sub == "unban":
            user_id, chat_id = int(p[2]), int(p[3])
            action = await A.unban_user(context.bot, user_id, chat_id, q.from_user.id)
            verb = "silencio retirado" if action == "unmuted" else "desbaneado"
            await q.message.reply_text(f"✅ Usuario {user_id}: {verb} en el chat {chat_id}.")
            t, k = view_abuse()
            return await _edit(q, t, k)
        if sub == "warn":
            _set_state(context, "a_warn")
            return await _edit(
                q, "📝 Envía el <b>texto de aviso</b>.\nVariables: <code>{nombre}</code> <code>{strikes}</code>",
                InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Cancelar", callback_data="p5:a:menu")]]))
        if sub == "esc":
            conn = get_db()
            try:
                s = A.get_settings(conn)
            finally:
                conn.close()
            _set_state(context, "a_esc")
            pretty = json.dumps(json.loads(s.get("escalation_json") or "[]") if s.get("escalation_json") else
                                [{"strikes": 1, "action": "warn", "minutes": 0},
                                 {"strikes": 2, "action": "mute", "minutes": 15},
                                 {"strikes": 3, "action": "mute", "minutes": 60},
                                 {"strikes": 4, "action": "ban", "minutes": 0}], indent=1, ensure_ascii=False)
            return await _edit(
                q, f"📶 Escalado actual:\n<pre>{pretty}</pre>\n\nEnvía el JSON nuevo para cambiarlo.",
                InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Cancelar", callback_data="p5:a:menu")]]))
        if sub == "tgl":
            conn = get_db()
            try:
                conn.execute("UPDATE abuse_settings SET enabled=1-enabled WHERE id=1"); conn.commit()
            finally:
                conn.close()
            t, k = view_abuse(); return await _edit(q, t, k)
        if sub == "hist":
            conn = get_db()
            try:
                rows = A.history(conn, 15)
            finally:
                conn.close()
            lines = [f"🛡️ <b>HISTORIAL</b> (últimos 15)"]
            if not rows:
                lines.append("Sin eventos.")
            for r in rows:
                lines.append(f"• {r['ts']} · {r['username'] or r['user_id']} · {r['action']} · {_cap(r['matched'], 30)}")
            return await _edit(q, "\n".join(lines), InlineKeyboardMarkup([[InlineKeyboardButton("⬅️", callback_data="p5:a:menu")]]))


def _swap_button(i, direction):
    """Reordena: mueve el botón `i` una posición arriba/abajo y renumera pos."""
    conn = get_db()
    try:
        rows = conn.execute("SELECT id FROM welcome_buttons ORDER BY pos, id").fetchall()
        ids = [r["id"] for r in rows]
        if i not in ids:
            return
        idx = ids.index(i)
        j = idx + direction
        if j < 0 or j >= len(ids):
            return
        ids[idx], ids[j] = ids[j], ids[idx]
        for order, bid in enumerate(ids):
            conn.execute("UPDATE welcome_buttons SET pos=? WHERE id=?", (order, bid))
        conn.commit()
    finally:
        conn.close()


# ════════════════════════════════════════════════════════════════════════════
# Máquina de estados (input de texto/media del panel)
# ════════════════════════════════════════════════════════════════════════════
async def handle_input(update, context):
    st = _state(context)
    if not st or not st.get("await"):
        return
    msg = update.effective_message
    uid = update.effective_user.id
    if not is_admin_simple(uid):
        _clear_state(context)
        return await msg.reply_text("🚫 Ya no tienes permiso para editar este panel.")
    kind = st["await"]
    arg = st.get("arg")
    text = msg.text or ""

    # cancelar
    if text.strip().lower() in ("/cancelar", "/cancel", "cancelar"):
        _clear_state(context)
        await msg.reply_text("✔️ Cancelado. /panel")
        return

    text_kinds = {
        "w_text", "w_btn_text", "w_btn_url", "w_btn_edit_text", "w_btn_edit_url",
        "c_new_slug", "c_title", "c_tpl", "c_add_text", "c_edit_text",
        "a_warn", "a_esc",
    }
    if kind in text_kinds and not text.strip():
        return await msg.reply_text("⚠️ Envía texto válido. No se guardaron cambios.")

    if kind == "a_unban":
        parts = text.split()
        if len(parts) not in (1, 2):
            return await msg.reply_text("⚠️ Formato: ID_USUARIO [CHAT_ID].")
        try:
            user_id = int(parts[0])
            chat_id = int(parts[1]) if len(parts) == 2 else None
            if user_id <= 0:
                raise ValueError
        except ValueError:
            return await msg.reply_text("⚠️ Los IDs deben ser números válidos.")
        if chat_id is None:
            conn = get_db()
            try:
                chat_id = A.resolve_chat_id(conn, user_id)
            finally:
                conn.close()
        if chat_id is None:
            try:
                chat_id = int(GROUP_ID)
            except (TypeError, ValueError):
                chat_id = 0
        if not chat_id:
            return await msg.reply_text("⚠️ No encontré el grupo. Envía también el CHAT_ID.")
        try:
            action = await A.unban_user(context.bot, user_id, chat_id, uid)
        except Exception as exc:
            LOGGER.error("Falló desbanear %s en %s: %s", user_id, chat_id, exc, exc_info=True)
            return await msg.reply_text(f"❌ No se pudo desbanear a {user_id}: {exc}")
        _clear_state(context)
        verb = "silencio retirado" if action == "unmuted" else "desbaneado"
        return await msg.reply_text(f"✅ Usuario {user_id}: {verb} en el chat {chat_id}.")

    conn = get_db()
    try:
        # ── Bienvenida ──────────────────────────────────────────────
        if kind == "w_media":
            fid, mt = _media(msg)
            if not fid or mt not in ("photo", "video"):
                return await msg.reply_text("⚠️ Envía una foto o video.")
            conn.execute("UPDATE welcome_config SET media_file_id=?, media_path=NULL, media_type=?, updated_at=datetime('now') WHERE id=1",
                         (fid, mt)); conn.commit()
            _clear_state(context)
            return await msg.reply_text(f"✅ Media de bienvenida guardada ({mt}).")
        if kind == "w_text":
            conn.execute("UPDATE welcome_config SET texto=?, updated_at=datetime('now') WHERE id=1",
                         (msg.text_html or text,)); conn.commit()
            _clear_state(context)
            return await msg.reply_text("✅ Texto de bienvenida guardado.")
        if kind == "w_btn_text":
            _set_state(context, "w_btn_url", None, {"tmp_text": text.strip()})
            return await msg.reply_text(
                "🔗 Ahora envía la <b>URL</b> (https://...).", parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Cancelar", callback_data="p5:w:btns")]]))
        if kind == "w_btn_url":
            url = text.strip()
            if not _is_https_url(url):
                return await msg.reply_text("⚠️ Enlace inválido. Envía una URL completa que empiece por https://.")
            tmp = st.get("tmp_text") or "•"
            conn.execute("INSERT INTO welcome_buttons (pos, text, url, target, visible) VALUES "
                         "((SELECT COALESCE(MAX(pos),-1)+1 FROM welcome_buttons), ?, ?, 'both', 1)",
                         (tmp, url)); conn.commit()
            _clear_state(context)
            return await msg.reply_text("✅ Botón añadido. /panel → Bienvenida → Botones")
        if kind == "w_btn_edit_text":
            conn.execute("UPDATE welcome_buttons SET text=? WHERE id=?", (text.strip(), arg)); conn.commit()
            _clear_state(context); return await msg.reply_text("✅ Texto del botón actualizado.")
        if kind == "w_btn_edit_url":
            url = text.strip()
            if not _is_https_url(url):
                return await msg.reply_text("⚠️ Enlace inválido. Envía una URL completa que empiece por https://.")
            conn.execute("UPDATE welcome_buttons SET url=? WHERE id=?", (url, arg)); conn.commit()
            _clear_state(context); return await msg.reply_text("✅ Enlace del botón actualizado.")

        # ── Comandos ────────────────────────────────────────────────
        if kind == "c_new_slug":
            slug = text.strip().lower()
            if slug.startswith("/"):
                slug = slug[1:]
            if not re.fullmatch(r"[a-z][a-z0-9_]{0,31}", slug):
                return await msg.reply_text(
                    "⚠️ Nombre inválido. Usa letras, números y guion bajo; empieza con letra y máximo 32 caracteres.")
            reserved = {
                "start", "help", "panel", "admin", "vip", "desbanear", "db", "stats", "members",
                "reports", "welcomes", "preview", "welcome_preview", "official", "hc",
                "subirhc", "listhc", "delhc", "hcentregas", "hcliberar", "cancelar_hc",
                "cancelar_bienv", "cancelar_promo", "adblock_list", "adblock_unban",
                "adblock_ban", "adblock_help",
            }
            if slug in reserved:
                return await msg.reply_text("⚠️ Ese nombre está reservado por una función del bot.")
            existing = C.get_command(slug=slug, conn=conn)
            if existing:
                return await msg.reply_text("⚠️ Ya existe ese comando.")
            new_id = C.create_command(slug, slug, conn=conn)
            _clear_state(context)
            # registrar handler en caliente
            try:
                context.application.add_handler(build_public_command_handler(slug, stop=True), group=-2)
            except Exception as e:
                LOGGER.warning("no pude registrar /%s: %s", slug, e)
            t, k = view_command(new_id)
            return await msg.reply_text(f"✅ Comando /{slug} creado.\n\n" + t, reply_markup=k, parse_mode=ParseMode.HTML)
        if kind == "c_title":
            C.update_field(arg, "titulo", text.strip(), conn=conn)
            _clear_state(context); return await msg.reply_text("✅ Título actualizado.")
        if kind == "c_tpl":
            template = msg.text_html or text
            if not template.strip():
                return await msg.reply_text("⚠️ La plantilla no puede quedar vacía.")
            C.update_field(arg, "plantilla", template, conn=conn)
            _clear_state(context); return await msg.reply_text("✅ Plantilla actualizada.")
        if kind == "c_media":
            fid, mt = _media(msg)
            if not fid or mt not in ("photo", "video"):
                return await msg.reply_text("⚠️ Envía una foto o video.")
            C.update_field(arg, "media_file_id", fid, conn=conn)
            C.update_field(arg, "media_type", mt, conn=conn)
            _clear_state(context); return await msg.reply_text("✅ Foto del comando guardada.")
        if kind == "c_add_text":
            C.add_item(arg, text.strip(), "libre", conn=conn)
            _clear_state(context); return await msg.reply_text("✅ Ítem añadido.")
        if kind == "c_edit_text":
            C.update_item(arg, "texto", text.strip(), conn=conn)
            _clear_state(context); return await msg.reply_text("✅ Ítem actualizado.")

        # ── Anti-abuso ──────────────────────────────────────────────
        if kind == "a_media":
            fid, mt = _media(msg)
            if not fid:
                return await msg.reply_text("⚠️ Envía GIF/sticker/foto.")
            conn.execute("UPDATE abuse_settings SET punish_media_file_id=?, punish_media_type=?, updated_at=datetime('now') WHERE id=1",
                         (fid, mt)); conn.commit()
            _clear_state(context); return await msg.reply_text(f"✅ Media de castigo guardada ({mt}).")
        if kind == "a_warn":
            conn.execute("UPDATE abuse_settings SET warn_text=?, updated_at=datetime('now') WHERE id=1",
                         (msg.text_html or text,)); conn.commit()
            _clear_state(context); return await msg.reply_text("✅ Texto de aviso guardado.")
        if kind == "a_esc":
            try:
                steps = json.loads(text)
            except ValueError:
                return await msg.reply_text("⚠️ JSON inválido. Inténtalo de nuevo.")
            if not isinstance(steps, list) or not steps:
                return await msg.reply_text("⚠️ Envía una lista JSON de escalones, no se guardaron cambios.")
            try:
                normalized = []
                for step in steps:
                    if not isinstance(step, dict):
                        raise ValueError
                    strikes = int(step["strikes"])
                    action = str(step["action"]).lower()
                    minutes = int(step.get("minutes", 0) or 0)
                    if strikes <= 0 or action not in ("warn", "mute", "ban", "kick") or minutes < -1:
                        raise ValueError
                    normalized.append({"strikes": strikes, "action": action, "minutes": minutes})
                normalized.sort(key=lambda step: step["strikes"])
                if len({step["strikes"] for step in normalized}) != len(normalized):
                    raise ValueError
            except (KeyError, TypeError, ValueError):
                return await msg.reply_text(
                    "⚠️ Cada escalón debe tener strikes > 0, action warn/mute/ban/kick y minutes ≥ -1.")
            data = json.dumps(normalized, ensure_ascii=False)
            conn.execute("UPDATE abuse_settings SET escalation_json=?, updated_at=datetime('now') WHERE id=1",
                         (data,)); conn.commit()
            _clear_state(context); return await msg.reply_text("✅ Escalado actualizado.")
    finally:
        conn.close()
