# -*- coding: utf-8 -*-
"""
abuse_engine.py — white-label v5
Lógica pura de escalado de castigo (sin dependencia de Telegram -> testeable).

Escalada confirmada por el owner:
    1) AVISO  ->  2) MUTE 15m  ->  3) MUTE 1h  ->  4) BAN
Configurable desde DB (tabla abuse_settings.escalation_json).
"""
from __future__ import annotations
from dataclasses import dataclass
import json
from typing import List, Optional

# strikes -> acción. `minutes` sólo aplica a mute; 0/-1 = permanente.
ESCALATION_DEFAULT: List[dict] = [
    {"strikes": 1, "action": "warn", "minutes": 0},
    {"strikes": 2, "action": "mute", "minutes": 15},
    {"strikes": 3, "action": "mute", "minutes": 60},
    {"strikes": 4, "action": "ban",  "minutes": 0},
]

ACTION_LABEL = {
    "warn": "AVISO",
    "mute": "SILENCIADO",
    "ban":  "BANEADO",
    "kick": "EXPULSADO",
}


@dataclass(frozen=True)
class Action:
    kind: str          # warn | mute | ban | kick
    minutes: int = 0
    strikes: int = 0

    @property
    def label(self) -> str:
        if self.kind == "mute" and self.minutes:
            return f"{ACTION_LABEL['mute']} {self.minutes} min"
        return ACTION_LABEL.get(self.kind, self.kind.upper())


class AbuseEngine:
    """Traduce (strikes acumulados) -> Action. Sin estado: el estado vive en DB."""

    def __init__(self, escalation: Optional[List[dict]] = None):
        try:
            esc = json.loads(escalation) if isinstance(escalation, str) else escalation
        except (ValueError, TypeError):
            esc = None
        self.escalation = self._normalize(esc or ESCALATION_DEFAULT)

    @staticmethod
    def _normalize(esc: List[dict]) -> List[dict]:
        clean = []
        for step in esc:
            if not isinstance(step, dict):
                continue
            try:
                s = int(step.get("strikes", 0))
                a = str(step.get("action", "warn")).lower()
                m = int(step.get("minutes", 0) or 0)
            except (ValueError, TypeError):
                continue
            if s <= 0 or a not in ("warn", "mute", "ban", "kick"):
                continue
            clean.append({"strikes": s, "action": a, "minutes": m})
        clean.sort(key=lambda x: x["strikes"])
        return clean or ESCALATION_DEFAULT

    def decide(self, strikes: int) -> Action:
        """Devuelve la acción para el total de strikes (>=1)."""
        strikes = max(1, int(strikes))
        chosen = self.escalation[0]
        for step in self.escalation:
            if strikes >= step["strikes"]:
                chosen = step
            else:
                break
        return Action(chosen["action"], chosen["minutes"], strikes)

    def next_step(self, strikes: int) -> Optional[dict]:
        """Siguiente escalón (o None si ya está al tope)."""
        for step in self.escalation:
            if step["strikes"] > strikes:
                return step
        return None

    @property
    def max_strikes_before_ban(self) -> int:
        for step in self.escalation:
            if step["action"] == "ban":
                return step["strikes"]
        return len(self.escalation) + 1


# ── Autotest ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    eng = AbuseEngine()
    print("escalación:", eng.escalation)
    for s in range(1, 6):
        a = eng.decide(s)
        nxt = eng.next_step(s)
        print(f"strikes={s} -> {a.kind.upper():5} ({a.label})  | siguiente: {nxt}")
    print("ban a los", eng.max_strikes_before_ban, "strikes")
