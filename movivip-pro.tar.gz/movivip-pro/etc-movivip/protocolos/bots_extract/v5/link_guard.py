# -*- coding: utf-8 -*-
"""
link_guard.py — white-label v5
Motor de detección de enlaces/credenciales para el anti-abuso.

Política (confirmada por el owner):
  - SOLO se bloquea a NO-admins.
  - Exentos SIEMPRE: owner + admins (tabla `admins`) + el propio canal/grupo.
  - El guard devuelve los "hits"; el castigo lo aplica abuse_engine.py.

Uso:
    from link_guard import scan, should_block, DEFAULT_PATTERNS
    hits = scan("mira mi ssh root:x@1.2.3.4:22 y vmess://AAAA")
    if should_block(is_exempt=False, text=..., allowlist=[r"t\\.me/MiCanalOficial"]):
        ...
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Iterable, List, Optional

# ── Patrones por defecto (editables desde DB: link_blocklist / link_allowlist) ──
#   Cada tipo -> regex. Orden no importa; scan() los aplica todos.
DEFAULT_PATTERNS = {
    # URLs web
    "url":        r"(?:https?://|ftp://|www\.)[^\s]+",
    # Telegram
    "telegram":   r"(?:t\.me|telegram\.me|telegram\.dog|tg://)[A-Za-z0-9_/?=+.:\-]*",
    # WhatsApp
    "whatsapp":   r"(?:wa\.me|api\.whatsapp\.com|chat\.whatsapp\.com|whatsapp\.com)/[^\s]*",
    # Configs VPN / proxies
    "vpn_config": r"\b(?:vmess|vless|trojan|ss|ssr|socks|socks5|hysteria2?|hy2|tuic|wireguard|wg)://[^\s]+",
    # Comando ssh
    "ssh_cmd":    r"\bssh\s+(?:-[\w]+\s+)*[\w.\-]+@[\w.\-]+",
    # credenciales usuario:clave@ip:puerto
    "creds":      r"\b[A-Za-z0-9_.\-]{2,32}:[^\s@:/]{3,64}@(?:\d{1,3}\.){3}\d{1,3}(?::\d{2,5})?\b",
    # IP:puerto
    "ip_port":    r"\b(?:\d{1,3}\.){3}\d{1,3}:\d{2,5}\b",
    # dominio:puerto
    "domain_port": r"\b[a-z0-9\-]+(?:\.[a-z0-9\-]+)+:\d{2,5}\b",
    # UUID (típico de v2ray/xray)
    "uuid":       r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b",
    # base64 largo (payload vmess)
    "b64_payload": r"\b(?:[A-Za-z0-9+/]{40,}={0,2})\b",
    # llamada a comprar/filtrar por privado con @usuario
    "at_username": r"(?<![\w/])@[A-Za-z][A-Za-z0-9_]{4,31}\b",
}

# Tipos "duros" (configs/credenciales). Si aparece uno -> castigo en modo estricto.
HARD_KINDS = {"vpn_config", "creds", "ssh_cmd", "ip_port", "domain_port", "uuid", "b64_payload"}


@dataclass(frozen=True)
class Hit:
    kind: str
    value: str
    start: int
    end: int

    def __str__(self) -> str:
        return f"{self.kind}:{self.value}"


def _compile(patterns: dict) -> dict:
    out = {}
    for kind, rx in patterns.items():
        try:
            out[kind] = re.compile(rx, re.IGNORECASE | re.MULTILINE)
        except re.error:
            # patrón inválido desde DB -> se ignora (no romper el bot)
            continue
    return out


_COMPILED = _compile(DEFAULT_PATTERNS)


def scan(text: str, patterns: Optional[dict] = None) -> List[Hit]:
    """Devuelve lista de Hit (ordenados por posición, sin solapes triviales)."""
    if not text:
        return []
    compiled = _compile(patterns) if patterns else _COMPILED
    hits: List[Hit] = []
    for kind, rx in compiled.items():
        for m in rx.finditer(text):
            val = m.group(0)
            # descartar falsos positivos obvios
            if kind == "b64_payload" and _looks_like_text(val):
                continue
            hits.append(Hit(kind, val, m.start(), m.end()))
    hits.sort(key=lambda h: (h.start, h.end))
    return hits


def _looks_like_text(s: str) -> bool:
    """Heurística: base64 con muchas vocales suele ser texto normal, no config."""
    vowels = sum(c.lower() in "aeiou" for c in s)
    return vowels / max(len(s), 1) > 0.45


def _matches_any(value: str, regexes: Iterable[str]) -> bool:
    for rx in regexes or []:
        try:
            if re.search(rx, value, re.IGNORECASE):
                return True
        except re.error:
            continue
    return False


def should_block(
    is_exempt: bool,
    text: str,
    allowlist: Optional[Iterable[str]] = None,
    blocklist: Optional[Iterable[str]] = None,
    strict: bool = True,
) -> List[Hit]:
    """
    Devuelve los hits que ameritan castigo.
      - is_exempt=True (owner/admin/canal) -> []  (nunca se bloquea)
      - blocklist: si un hit casa, se bloquea aunque esté en allowlist
      - allowlist: hits que casan se ignoran (ej. mis propios t.me)
      - strict=True: exige tipo "duro" (configs/credenciales) OR cualquier hit
                     si no hay duros; strict=False: cualquier URL/hit cuenta.
    """
    if is_exempt:
        return []
    hits = scan(text)
    if not hits:
        return []

    result: List[Hit] = []
    for h in hits:
        if _matches_any(h.value, blocklist):
            result.append(h)
            continue
        if _matches_any(h.value, allowlist):
            continue
        if strict and h.kind == "at_username":
            # en estricto, un simple @usuario no castiga por sí solo
            continue
        result.append(h)
    return result


# ── Autotest ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    samples = {
        "v2ray":   "Toma mi config vless://abc-def@1.2.3.4:443?type=ws#x",
        "ssh":     "ssh root:MiClave123@203.0.113.9:22 listo",
        "telegram":"unete a t.me/MiCanalOficial",
        "wa":      "escribeme a https://wa.me/573117008185",
        "uuid":    "id 550e8400-e29b-41d4-a716-446655440000 server",
        "ip":      "conectate a 203.0.113.9:8012",
        "limpio":  "hola buenas, gracias por el servicio ✅",
        "user":    "saludos @Clmadi",
    }
    for name, txt in samples.items():
        hits = scan(txt)
        print(f"[{name:9}] -> {[str(h) for h in hits]}")

    print("\n-- política --")
    print("admin manda vless:", should_block(True, samples["v2ray"]))       # -> []
    print("miembro manda vless:", [str(h) for h in should_block(False, samples["v2ray"])])
    print("allowlist t.me propio:", should_block(False, samples["telegram"],
          allowlist=[r"t\.me/MiCanalOficial"]))                            # -> []
