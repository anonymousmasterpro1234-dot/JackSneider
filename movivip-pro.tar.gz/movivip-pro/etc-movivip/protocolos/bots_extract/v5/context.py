# -*- coding: utf-8 -*-
"""
context.py — white-label v5
Resuelve configuración/DB/admin desde el host (notif_bot) o desde entorno.
Todas las piezas v5 (panel, abuse, welcome, commands) usan esto -> 1 sola fuente.
"""
from __future__ import annotations
import os
import sys
import logging
import sqlite3

LOGGER = logging.getLogger("movivip.v5")
if not LOGGER.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s [v5] %(levelname)s %(message)s"))
    LOGGER.addHandler(_h)
    LOGGER.setLevel(logging.INFO)


def _load_env_file(path: str = "/etc/movivip/.env") -> None:
    """Si las vars MOVIVIP_* no están en el entorno, las lee del .env."""
    try:
        if not os.path.isfile(path):
            return
        with open(path, encoding="utf-8", errors="replace") as fh:
            for ln in fh:
                ln = ln.strip()
                if not ln or ln.startswith("#") or "=" not in ln:
                    continue
                k, v = ln.split("=", 1)
                k, v = k.strip(), v.strip().strip('"').strip("'")
                if k and k not in os.environ:
                    os.environ[k] = v
    except Exception:
        pass


_load_env_file()


def _host():
    """Módulo host (notif_bot) si está en ejecución."""
    for name in ("__main__", "notif_bot"):
        m = sys.modules.get(name)
        if m is not None and (hasattr(m, "TOKEN") or hasattr(m, "_LICENSE_VALID")):
            return m
    return None


_H = _host()


def _get(attr: str, env: str = None, default=None):
    if _H is not None and hasattr(_H, attr):
        return getattr(_H, attr)
    if env:
        return os.environ.get(env, default)
    return default


def _cfg():
    """config.py del cliente si está cargado en el intérprete (host/ruta)."""
    return sys.modules.get("config")


def _cfg_attr(name, default=""):
    c = _cfg()
    try:
        v = getattr(c, name, None) if c is not None else None
    except Exception:
        v = None
    return v if v not in (None, "") else default


def _cfg_social(key, default=""):
    c = _cfg()
    try:
        return (getattr(c, "SOCIAL_LINKS", None) or {}).get(key) or default
    except Exception:
        return default


def _brand(*vals):
    """Primer valor real (no vacío ni placeholder 'PONER_...')."""
    for v in vals:
        v = (v or "").strip()
        if v and not v.upper().startswith("PONER_"):
            return v
    return ""


def _env_int(env: str, default: int = 0) -> int:
    try:
        return int(os.environ.get(env, "") or default)
    except (ValueError, TypeError):
        return default


# ── Config ──────────────────────────────────────────────────────────────────
CHANNEL_ID = (_get("CHANNEL_ID", "MOVIVIP_NOTIF_CHANNEL_ID", None)
              or _cfg_attr("NOTIF_CHANNEL_ID", 0) or 0)
GROUP_ID = (_get("GROUP_ID", "MOVIVIP_NOTIF_GROUP_ID", None)
            or _cfg_attr("NOTIF_GROUP_ID", 0) or 0)

# ── Marca y enlaces del CLIENTE (env -> host notif_bot -> config.py -> neutro) ──
BRAND_NAME   = _brand(os.environ.get("MOVIVIP_BRAND_NAME", ""),
                      _get("BRAND_NAME", None, ""), _cfg_attr("BRAND_NAME")) or "JackSneider"
CHANNEL_LINK = _brand(os.environ.get("MOVIVIP_CHANNEL_LINK", ""),
                      _get("CHANNEL_LINK", None, ""),
                      _cfg_social("telegram_ch"), _cfg_attr("BRAND_CHANNEL"),
                      _cfg_attr("MAIN_CHANNEL"))
GROUP_LINK   = _brand(os.environ.get("MOVIVIP_GROUP_LINK", ""),
                      _get("GROUP_LINK", None, ""),
                      _cfg_social("telegram_group"), _cfg_attr("BRAND_GROUP"),
                      _cfg_attr("SUPPORT_GROUP"))
SSH_BOT      = _brand(os.environ.get("MOVIVIP_SSH_BOT", ""),
                      _get("SSH_BOT", None, ""),
                      _cfg_attr("BRAND_BOT"), _cfg_attr("SSH_BOT"))
STORE_BOT    = _brand(os.environ.get("MOVIVIP_STORE_BOT", ""),
                      _get("STORE_BOT", None, ""),
                      _cfg_attr("BRAND_STORE"), _cfg_attr("STORE_BOT"))
LINK_REDIREC = _brand(os.environ.get("MOVIVIP_LINK_REDIREC", ""),
                      _get("LINK_REDIREC", None, ""), _cfg_attr("LINK_REDIREC"))
_SUPPORT_RAW = _brand(os.environ.get("MOVIVIP_SUPPORT_BOT", ""),
                      _get("SUPPORT_BOT", None, ""), _cfg_attr("BRAND_SUPPORT"))
SUPPORT_BOT  = _SUPPORT_RAW or "soporte"
SUPPORT_TAG  = "@" + SUPPORT_BOT.lstrip("@")
SUPPORT_URL  = LINK_REDIREC or (f"https://t.me/{_SUPPORT_RAW.lstrip('@')}" if _SUPPORT_RAW else "")
WEB_URL      = _brand(os.environ.get("MOVIVIP_WEB_URL", ""),
                      _get("WEB_URL", None, ""), _cfg_social("web"))
KEY_BOT      = _brand(os.environ.get("MOVIVIP_KEY_BOT", ""),
                      _get("KEY_BOT", None, ""), _cfg_attr("BRAND_KEY"))
DB_PATH = (_get("DB_PATH", "MOVIVIP_DB_PATH", None)
           or os.environ.get("NOTIF_DB") or _cfg_attr("DB_PATH", "/root/movivip.db"))

# Mapa de enlaces sociales del cliente (para templates/botones).
SOCIAL = {
    "web": WEB_URL,
    "tiktok": _brand(os.environ.get("MOVIVIP_TIKTOK", ""), _cfg_social("tiktok")),
    "youtube": _brand(os.environ.get("MOVIVIP_YOUTUBE", ""), _cfg_social("youtube")),
    "telegram_ch": CHANNEL_LINK,
    "telegram_group": GROUP_LINK,
    "whatsapp_ch": _brand(os.environ.get("MOVIVIP_WHATSAPP_CH", ""), _cfg_social("whatsapp_ch")),
    "whatsapp_community": _brand(os.environ.get("MOVIVIP_WHATSAPP_COMMUNITY", ""), _cfg_social("whatsapp_community")),
    "whatsapp_personal": _brand(os.environ.get("MOVIVIP_WHATSAPP_PERSONAL", ""), _cfg_social("whatsapp_personal")),
}

_admin_ids = _get("ADMIN_IDS", None, None)
if not _admin_ids:
    _admin_ids = _cfg_attr("ADMIN_IDS", None)
if not _admin_ids:
    _admin_ids = [int(x) for x in (os.environ.get("ADMIN_IDS", "") or "").replace(" ", "").split(",") if x.isdigit()]
ADMIN_IDS = [int(value) for value in (_admin_ids or []) if str(value).isdigit() and int(value) > 0]
ADMIN_USERNAMES = []


def get_db() -> sqlite3.Connection:
    """Conexión DB: reutiliza la del host si existe; si no, abre la ruta configurada."""
    host = _H
    if host is not None and hasattr(host, "get_db"):
        try:
            return host.get_db()
        except Exception:
            LOGGER.debug("host.get_db() falló, abro directo", exc_info=True)
    conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=30000")
    except sqlite3.Error:
        pass
    return conn


def is_admin_simple(user_id: int) -> bool:
    """Admin por ID, respetando la desactivación de la tabla admins."""
    if not user_id:
        return False
    configured_admin = user_id in ADMIN_IDS
    conn = None
    try:
        conn = get_db()
        columns = {
            row[1] for row in conn.execute("PRAGMA table_info(admins)").fetchall()
        }
        if "tg_id" not in columns:
            return configured_admin
        active_column = ", is_active" if "is_active" in columns else ""
        row = conn.execute(
            f"SELECT 1{active_column} FROM admins WHERE tg_id=?", (user_id,)
        ).fetchone()
        if row:
            return bool(row["is_active"]) if "is_active" in columns else True
        return configured_admin
    except sqlite3.Error:
        LOGGER.exception("No se pudo comprobar el permiso de administrador")
        return configured_admin
    finally:
        if conn is not None:
            conn.close()


def license_active() -> bool:
    """Guardian actions are available only while the host's cached gate is valid."""
    return bool(_H is not None and getattr(_H, "_LICENSE_VALID", False))


async def is_exempt(bot, chat_id: int, user, message=None) -> bool:
    """
    True si el autor NUNCA debe ser bloqueado:
      owner/admin de config + admins reales del chat (getChatAdministrators, con caché).
    El propio canal/grupo (mensajes sin from_user o SenderChat) también exonera.
    """
    # mensajes de canal / anonymous admin -> no hay usuario real
    if message is not None:
        sc = getattr(message, "sender_chat", None)
        if sc is not None:
            return True
    if user is None:
        return True
    if is_admin_simple(user.id):
        return True
    return await is_chat_admin_cached(bot, chat_id, user.id)


# ── Caché de administradores del chat ───────────────────────────────────────
_ADMIN_CACHE: dict = {}          # chat_id -> (expira_ts, {ids})
_ADMIN_TTL = 300                 # 5 min


async def is_chat_admin_cached(bot, chat_id: int, user_id: int) -> bool:
    import time
    now = time.time()
    cached = _ADMIN_CACHE.get(chat_id)
    if cached and cached[0] > now:
        return user_id in cached[1]
    try:
        admins = await bot.get_chat_administrators(chat_id)
        ids = {m.user.id for m in admins if getattr(m, "user", None)}
        _ADMIN_CACHE[chat_id] = (now + _ADMIN_TTL, ids)
        return user_id in ids
    except Exception:
        LOGGER.debug("get_chat_administrators falló para %s", chat_id, exc_info=True)
        # ante fallo, no exonerar (pero tampoco romper)
        return False


def invalidate_admin_cache(chat_id: int = None):
    if chat_id is None:
        _ADMIN_CACHE.clear()
    else:
        _ADMIN_CACHE.pop(chat_id, None)
