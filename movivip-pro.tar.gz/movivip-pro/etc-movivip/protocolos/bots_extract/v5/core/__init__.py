# -*- coding: utf-8 -*-
"""core — utilidades base del bot v5 (db, logging)."""
