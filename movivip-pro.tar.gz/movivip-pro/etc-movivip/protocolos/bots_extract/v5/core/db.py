# -*- coding: utf-8 -*-
"""
core/db.py — white-label v5
Capa SQLite única: WAL + busy_timeout + esquema + migraciones NO destructivas.

Uso:
    from core.db import open_db, init_db
    conn = open_db()            # por defecto NOTIF_DB o ./notif.db
    init_db(conn)               # crea tablas y aplica migraciones
"""
from __future__ import annotations
import os
import sqlite3
from typing import Optional

DEFAULT_DB = os.environ.get("NOTIF_DB", "movivip.db")

SCHEMA = """
-- ── ADMIN / RBAC ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS admins (
    tg_id      INTEGER PRIMARY KEY,
    role       TEXT NOT NULL DEFAULT 'admin',   -- owner | admin | mod
    is_active  INTEGER NOT NULL DEFAULT 1,
    brand      TEXT,
    perms_json TEXT,
    added_by   INTEGER,
    added_at   TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_log (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    tg_id   INTEGER,
    action  TEXT,
    details TEXT,
    ts      TEXT DEFAULT (datetime('now'))
);

-- ── BIENVENIDA UNIFICADA (canal + grupo) ───────────────────────────────────
CREATE TABLE IF NOT EXISTS welcome_config (
    id              INTEGER PRIMARY KEY CHECK (id = 1),
    media_file_id   TEXT,
    media_path      TEXT,                         -- ruta LOCAL editable (fuera del paquete)
    media_type      TEXT DEFAULT 'photo',        -- photo | video | none
    texto           TEXT,
    channel_enabled INTEGER DEFAULT 1,
    group_enabled   INTEGER DEFAULT 1,
    updated_at      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS welcome_buttons (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    pos             INTEGER DEFAULT 0,
    text            TEXT NOT NULL,
    emoji_key       TEXT,                         -- premium_emoji.SINGLE key (o NULL)
    premium_emoji_id TEXT,
    url             TEXT,
    kind            TEXT DEFAULT 'url',           -- url | callback
    target          TEXT DEFAULT 'both',          -- both | channel | group
    visible         INTEGER DEFAULT 1,
    updated_at      TEXT DEFAULT (datetime('now'))
);

-- ── ANTI-ABUSO ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS abuse_settings (
    id                  INTEGER PRIMARY KEY CHECK (id = 1),
    enabled             INTEGER DEFAULT 1,
    punish_media_file_id TEXT,
    punish_media_type   TEXT,                     -- anim | sticker | emoji | none
    warn_text           TEXT,
    escalation_json     TEXT,
    strict               INTEGER DEFAULT 1,
    updated_at          TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS abuse_strikes (
    user_id     INTEGER PRIMARY KEY,
    strikes     INTEGER DEFAULT 0,
    status      TEXT DEFAULT 'ok',                -- ok | muted | banned
    chat_id     INTEGER,
    muted_until TEXT,
    first_at    TEXT,
    last_at     TEXT,
    reason      TEXT,
    unbanned_by INTEGER
);

CREATE TABLE IF NOT EXISTS abuse_events (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id   INTEGER,
    username  TEXT,
    chat_id   INTEGER,
    msg_id    INTEGER,
    matched   TEXT,
    action    TEXT,
    ts        TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS link_allowlist (id INTEGER PRIMARY KEY AUTOINCREMENT, pattern TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS link_blocklist (id INTEGER PRIMARY KEY AUTOINCREMENT, pattern TEXT NOT NULL);

-- ── COMANDOS / PLANTILLAS (panel "Comandos") ───────────────────────────────
CREATE TABLE IF NOT EXISTS commands (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    slug          TEXT UNIQUE NOT NULL,           -- vip | precios | soporte ...
    titulo        TEXT,
    plantilla     TEXT,                            -- texto con {SEP_FIRE} / {SEP_SPARK}
    media_file_id TEXT,
    media_type    TEXT,
    enabled       INTEGER DEFAULT 1,
    updated_at    TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS command_items (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    command_id INTEGER NOT NULL,
    seccion    TEXT NOT NULL,                     -- vendedores | ubicaciones | beneficios | libre
    pos        INTEGER DEFAULT 0,
    emoji_key  TEXT,
    texto      TEXT,
    visible    INTEGER DEFAULT 1,
    updated_at TEXT DEFAULT (datetime('now'))
);

-- ── PROMOS (se conserva) ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS promos (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    texto      TEXT,
    media_file_id TEXT,
    botones    TEXT,
    enabled    INTEGER DEFAULT 1,
    updated_at TEXT DEFAULT (datetime('now'))
);
"""


def open_db(path: Optional[str] = None) -> sqlite3.Connection:
    conn = sqlite3.connect(path or DEFAULT_DB, check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("PRAGMA journal_mode=WAL")
    cur.execute("PRAGMA busy_timeout=30000")
    cur.execute("PRAGMA foreign_keys=ON")
    cur.execute("PRAGMA synchronous=NORMAL")
    conn.commit()
    return conn


def _table_exists(conn, name: str) -> bool:
    r = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone()
    return r is not None


def _ensure_column(conn, table: str, col: str, decl: str) -> None:
    """ALTER TABLE ... ADD COLUMN si falta (migración NO destructiva)."""
    if not _table_exists(conn, table):
        return
    cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if col not in cols:
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {decl}")
        except sqlite3.Error:
            pass


def init_db(conn: sqlite3.Connection) -> sqlite3.Connection:
    """Crea el esquema y aplica migraciones NO destructivas."""
    conn.executescript(SCHEMA)

    # migración: adblock_strikes -> abuse_strikes (compatibilidad bot-key)
    if _table_exists(conn, "adblock_strikes") and not conn.execute(
        "SELECT 1 FROM abuse_strikes LIMIT 1"
    ).fetchone():
        try:
            conn.execute("""INSERT OR IGNORE INTO abuse_strikes
                (user_id, strikes, first_at, last_at, reason)
                SELECT user_id, strikes, first_at,
                       COALESCE(last_at, datetime('now')), 'migrado/adblock'
                FROM adblock_strikes""")
        except sqlite3.Error:
            pass

    # seed: fila única de configs
    conn.execute("INSERT OR IGNORE INTO welcome_config (id) VALUES (1)")
    conn.execute("INSERT OR IGNORE INTO abuse_settings (id) VALUES (1)")

    # migraciones aditivas (DBs antiguas)
    _ensure_column(conn, "admins", "is_active", "INTEGER NOT NULL DEFAULT 1")
    _ensure_column(conn, "welcome_config", "media_file_id", "TEXT")
    _ensure_column(conn, "welcome_config", "media_path", "TEXT")
    _ensure_column(conn, "welcome_config", "media_type", "TEXT DEFAULT 'photo'")
    _ensure_column(conn, "welcome_config", "channel_enabled", "INTEGER DEFAULT 1")
    _ensure_column(conn, "welcome_config", "group_enabled", "INTEGER DEFAULT 1")
    _ensure_column(conn, "welcome_config", "updated_at", "TEXT")
    _ensure_column(conn, "welcome_buttons", "emoji_key", "TEXT")
    _ensure_column(conn, "welcome_buttons", "premium_emoji_id", "TEXT")
    _ensure_column(conn, "welcome_buttons", "url", "TEXT")
    _ensure_column(conn, "welcome_buttons", "kind", "TEXT DEFAULT 'url'")
    _ensure_column(conn, "welcome_buttons", "target", "TEXT DEFAULT 'both'")
    _ensure_column(conn, "welcome_buttons", "visible", "INTEGER DEFAULT 1")
    _ensure_column(conn, "welcome_buttons", "updated_at", "TEXT")
    _ensure_column(conn, "abuse_strikes", "chat_id", "INTEGER")

    conn.commit()
    return conn


def get_row(conn, table: str, where: str = "1=1", params: tuple = ()):
    return conn.execute(f"SELECT * FROM {table} WHERE {where} LIMIT 1", params).fetchone()


# ── Autotest ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import tempfile
    p = os.path.join(tempfile.gettempdir(), "v5_test.db")
    if os.path.exists(p):
        os.remove(p)
    c = init_db(open_db(p))
    names = [r[0] for r in c.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()]
    print("tablas:", names)
    print("journal:", c.execute("PRAGMA journal_mode").fetchone()[0])
    print("welcome_config:", dict(c.execute("SELECT * FROM welcome_config").fetchone()))
