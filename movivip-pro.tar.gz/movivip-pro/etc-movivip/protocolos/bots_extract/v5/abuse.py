# -*- coding: utf-8 -*-
"""
abuse.py — white-label v5
Anti-abuso REAL (anti-links/credenciales) con escalado AVISO→MUTE15→MUTE60→BAN.
- Bloquea SOLO a NO-admins (owner/config + admins del chat + canal/grupo exentos).
- Borra el mensaje ofensor, aplica castigo, guarda strikes + evento, avisa.
- Media de castigo la sube el owner desde el panel (GIF/sticker/emoji).
"""
from __future__ import annotations
import datetime
import html
import json

from telegram import ChatPermissions
from telegram.constants import ParseMode
from telegram.ext import ApplicationHandlerStop

from context import (LOGGER, get_db, is_exempt, CHANNEL_LINK, GROUP_LINK,
                     SUPPORT_URL, SSH_BOT, STORE_BOT, LINK_REDIREC, WEB_URL, SOCIAL)
from link_guard import should_block
from abuse_engine import AbuseEngine, ACTION_LABEL


# ── Carga de config ─────────────────────────────────────────────────────────
def get_settings(conn=None) -> dict:
    own = conn is None
    conn = conn or get_db()
    try:
        row = conn.execute("SELECT * FROM abuse_settings WHERE id=1").fetchone()
        return dict(row) if row else {}
    finally:
        if own:
            conn.close()


def _engine(conn=None) -> AbuseEngine:
    return AbuseEngine(get_settings(conn).get("escalation_json"))


def _allow_from_links():
    """Patrones de las URLs/usernames oficiales del CLIENTE (omite los vacíos)."""
    import re
    vals = [CHANNEL_LINK, GROUP_LINK, SUPPORT_URL, LINK_REDIREC, WEB_URL,
            SSH_BOT, STORE_BOT,
            SOCIAL.get("youtube", ""), SOCIAL.get("tiktok", ""),
            SOCIAL.get("whatsapp_ch", ""), SOCIAL.get("whatsapp_community", ""),
            SOCIAL.get("whatsapp_personal", ""),
            "https://t.me/+I-VOBBPsGSZjOGE5", "https://t.me/+I-VOBBPsGSZjOGE5",
            "https://t.me/movivip_key_bot", "https://t.me/MOVIVIPNETWORK_SSH_BOT",
            "https://t.me/+I-VOBBPsGSZjOGE5", "https://t.me/+I-VOBBPsGSZjOGE5",
            "https://t.me/+I-VOBBPsGSZjOGE5s", "https://t.me/TunnelCol",
            "https://",
            "https://youtube.com/JackSneiderNetwork",
            "https://tiktok.com/@movi.vip.network"]
    out, seen = [], set()
    for u in vals:
        u = (u or "").strip()
        if not u:
            continue
        s = ("t.me/" + u.lstrip("@")) if u.startswith("@") else re.sub(r"^https?://", "", u)
        s = s.rstrip("/")
        if not s:
            continue
        p = re.escape(s)
        if p not in seen:
            seen.add(p); out.append(p)
    return out


def _allow_block(conn):
    try:
        allow = [r[0] for r in conn.execute("SELECT pattern FROM link_allowlist").fetchall()]
        block = [r[0] for r in conn.execute("SELECT pattern FROM link_blocklist").fetchall()]
    except Exception:
        allow, block = [], []
    # allowlist por defecto: los enlaces oficiales del PROPIO cliente
    allow += _allow_from_links()
    return allow, block


# ── Strikes ─────────────────────────────────────────────────────────────────
def get_strikes(conn, user_id: int) -> int:
    row = conn.execute("SELECT strikes FROM abuse_strikes WHERE user_id=?", (user_id,)).fetchone()
    return int(row["strikes"]) if row else 0


def bump_strikes(conn, user_id: int, reason: str = "", chat_id: int = None) -> int:
    now = datetime.datetime.utcnow().isoformat(timespec="seconds")
    row = conn.execute("SELECT strikes FROM abuse_strikes WHERE user_id=?", (user_id,)).fetchone()
    if row:
        n = int(row["strikes"]) + 1
        conn.execute(
            "UPDATE abuse_strikes SET strikes=?, last_at=?, reason=?, chat_id=? WHERE user_id=?",
            (n, now, reason, chat_id, user_id))
    else:
        n = 1
        conn.execute(
            "INSERT INTO abuse_strikes (user_id, strikes, first_at, last_at, reason, chat_id) "
            "VALUES (?,?,?,?,?,?)", (user_id, n, now, now, reason, chat_id))
    conn.commit()
    return n


def log_event(conn, user_id, username, chat_id, msg_id, matched, action):
    conn.execute("INSERT INTO abuse_events (user_id, username, chat_id, msg_id, matched, action) VALUES (?,?,?,?,?,?)",
                 (user_id, username, chat_id, msg_id, matched, action))
    conn.commit()


def reset_user(conn, user_id: int):
    conn.execute("UPDATE abuse_strikes SET strikes=0, status='ok', muted_until=NULL WHERE user_id=?", (user_id,))
    conn.commit()


def set_status(conn, user_id: int, chat_id: int, status: str, muted_until=None):
    if status not in ("ok", "muted", "banned"):
        raise ValueError("Estado de moderación inválido.")
    conn.execute(
        "UPDATE abuse_strikes SET status=?, chat_id=?, muted_until=? WHERE user_id=?",
        (status, chat_id, muted_until, user_id))
    conn.commit()


def active_cases(conn, limit: int = 10):
    return conn.execute(
        "SELECT user_id, strikes, status, chat_id, muted_until, last_at, reason "
        "FROM abuse_strikes WHERE status='banned' OR "
        "(status='muted' AND (muted_until IS NULL OR julianday(muted_until)>julianday('now'))) "
        "ORDER BY CASE status WHEN 'banned' THEN 0 ELSE 1 END, last_at DESC LIMIT ?",
        (limit,)).fetchall()


def resolve_chat_id(conn, user_id: int, chat_id=None):
    if chat_id is not None:
        return int(chat_id)
    row = conn.execute(
        "SELECT chat_id FROM abuse_strikes WHERE user_id=? AND chat_id IS NOT NULL",
        (user_id,)).fetchone()
    if row:
        return int(row["chat_id"])
    row = conn.execute(
        "SELECT chat_id FROM abuse_events WHERE user_id=? AND chat_id IS NOT NULL "
        "ORDER BY id DESC LIMIT 1", (user_id,)).fetchone()
    return int(row["chat_id"]) if row else None


async def unban_user(bot, user_id: int, chat_id: int, admin_id: int = None):
    if not chat_id:
        raise ValueError("No se encontró el grupo; indica su chat_id.")
    conn = get_db()
    try:
        case = conn.execute(
            "SELECT status FROM abuse_strikes WHERE user_id=?", (user_id,)
        ).fetchone()
        action = "admin_unmute" if case and case["status"] == "muted" else "admin_unban"
    finally:
        conn.close()

    if action == "admin_unmute":
        chat = await bot.get_chat(chat_id=int(chat_id))
        permissions = chat.permissions or ChatPermissions(
            can_send_messages=True,
            can_send_audios=True,
            can_send_documents=True,
            can_send_photos=True,
            can_send_videos=True,
            can_send_video_notes=True,
            can_send_voice_notes=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True,
            can_change_info=False,
            can_invite_users=False,
            can_pin_messages=False,
        )
        await bot.restrict_chat_member(
            chat_id=int(chat_id), user_id=int(user_id), permissions=permissions)
    else:
        await bot.unban_chat_member(
            chat_id=int(chat_id), user_id=int(user_id), only_if_banned=True)

    conn = get_db()
    try:
        row = conn.execute("SELECT username FROM abuse_events WHERE user_id=? "
                           "ORDER BY id DESC LIMIT 1", (user_id,)).fetchone()
        username = row["username"] if row else None
        conn.execute(
            "UPDATE abuse_strikes SET status='ok', muted_until=NULL, chat_id=?, unbanned_by=? "
            "WHERE user_id=?", (chat_id, admin_id, user_id))
        conn.execute(
            "INSERT INTO abuse_events (user_id, username, chat_id, matched, action) "
            "VALUES (?,?,?,?,?)",
            (user_id, username, chat_id, f"admin_id:{admin_id or 0}", action))
        conn.commit()
    finally:
        conn.close()
    return "unmuted" if action == "admin_unmute" else "unbanned"


def history(conn, limit: int = 20):
    return conn.execute("SELECT * FROM abuse_events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()


# ── Media de castigo ────────────────────────────────────────────────────────
async def send_punish_media(bot, chat_id, reply_to=None):
    cfg = get_settings()
    fid = cfg.get("punish_media_file_id")
    mt = (cfg.get("punish_media_type") or "none").lower()
    if not fid or mt in ("none", ""):
        return
    try:
        if mt == "anim":
            await bot.send_animation(chat_id, fid, reply_to_message_id=reply_to)
        elif mt == "sticker":
            await bot.send_sticker(chat_id, fid, reply_to_message_id=reply_to)
        elif mt == "photo":
            await bot.send_photo(chat_id, fid, reply_to_message_id=reply_to)
        elif mt == "video":
            await bot.send_video(chat_id, fid, reply_to_message_id=reply_to)
    except Exception as e:
        LOGGER.error("No se pudo enviar la media de castigo (%s): %s", mt, e, exc_info=True)


def _mute_perms():
    # restringir todo lo posible (silenciar)
    return ChatPermissions(
        can_send_messages=False,
        can_send_audios=False, can_send_documents=False, can_send_photos=False,
        can_send_videos=False, can_send_video_notes=False, can_send_voice_notes=False,
        can_send_polls=False, can_send_other_messages=False,
        can_add_web_page_previews=False, can_change_info=False, can_invite_users=False,
        can_pin_messages=False,
    )


async def _mute(bot, chat_id, user_id, minutes: int):
    until = None
    if minutes and minutes > 0:
        until = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=minutes)
    await bot.restrict_chat_member(chat_id, user_id, permissions=_mute_perms(), until_date=until)


# ── Handler principal ───────────────────────────────────────────────────────
async def handle_group_link(update, context):
    msg = update.effective_message
    chat = update.effective_chat
    user = update.effective_user
    if not msg or not chat or chat.type not in ("group", "supergroup"):
        return
    text = msg.text or msg.caption or ""
    if not text:
        return

    conn = get_db()
    try:
        st = get_settings(conn)
        if not int(st.get("enabled", 1)):
            return
        # exención (owner/admin del chat/canal)
        if await is_exempt(context.bot, chat.id, user, msg):
            return
        allow, block = _allow_block(conn)
        hits = should_block(False, text, allowlist=allow, blocklist=block,
                            strict=bool(int(st.get("strict", 1))))
        if not hits:
            return

        # 1) borrar mensaje ofensor
        try:
            await msg.delete()
        except Exception as e:
            LOGGER.debug("no pude borrar msg: %s", e)

        # 2) strike + escalado
        matched = ", ".join(f"{h.kind}:{h.value[:40]}" for h in hits[:4])
        n = bump_strikes(conn, user.id, matched, chat.id)
        action = _engine(conn).decide(n)

        username = f"@{user.username}" if user.username else (user.full_name or str(user.id))
        safe_username = html.escape(username)
        applied = False
        try:
            if action.kind == "warn":
                warn = st.get("warn_text") or (
                    f"⚠️ <b>{html.escape(user.full_name or username)}</b>, "
                    "no se permiten enlaces/credenciales.\n"
                    f"Aviso <b>{n}</b>. Si reincides serás silenciado y luego baneado.")
                warn = warn.replace("{nombre}", html.escape(user.full_name or "")).replace(
                    "{strikes}", str(n))
                notice = await context.bot.send_message(
                    chat.id, warn, parse_mode=ParseMode.HTML)
                applied = True
            elif action.kind == "mute":
                await _mute(context.bot, chat.id, user.id, action.minutes)
                applied = True
            elif action.kind == "ban":
                await context.bot.ban_chat_member(chat.id, user.id)
                applied = True
            elif action.kind == "kick":
                await context.bot.ban_chat_member(chat.id, user.id)
                applied = True
                await context.bot.unban_chat_member(
                    chat_id=chat.id, user_id=user.id, only_if_banned=True)
        except Exception as e:
            LOGGER.error("Falló aplicar castigo %s a %s en %s: %s",
                         action.kind, user.id, chat.id, e, exc_info=True)
            if not applied:
                action = type(action)(kind="failed", minutes=0)
            elif action.kind == "kick":
                action = type(action)(kind="ban", minutes=0, strikes=n)

        if applied:
            status = "banned" if action.kind == "ban" else "muted" if action.kind == "mute" else "ok"
            until = None
            if action.kind == "mute" and action.minutes > 0:
                until = (datetime.datetime.now(datetime.timezone.utc)
                         + datetime.timedelta(minutes=action.minutes)).isoformat()
            try:
                set_status(conn, user.id, chat.id, status, until)
            except Exception:
                LOGGER.error("No se pudo persistir estado de moderación uid=%s",
                             user.id, exc_info=True)
            await send_punish_media(context.bot, chat.id)
            if action.kind == "warn":
                await _autodel(context, chat.id, notice.message_id, 15)
            elif action.kind == "mute":
                try:
                    await context.bot.send_message(
                        chat.id, f"🔇 <b>{safe_username}</b> silenciado "
                        f"{action.minutes} min (aviso {n}).",
                        parse_mode=ParseMode.HTML)
                except Exception:
                    LOGGER.error("No se pudo publicar el aviso de silencio uid=%s",
                                 user.id, exc_info=True)
            elif action.kind == "ban":
                try:
                    await context.bot.send_message(
                        chat.id, f"⛔ <b>{safe_username}</b> baneado por reincidencia ({n}).",
                        parse_mode=ParseMode.HTML)
                except Exception:
                    LOGGER.error("No se pudo publicar el aviso de ban uid=%s",
                                 user.id, exc_info=True)
            elif action.kind == "kick":
                try:
                    await context.bot.send_message(
                        chat.id, f"👢 <b>{safe_username}</b> expulsado por reincidencia ({n}).",
                        parse_mode=ParseMode.HTML)
                except Exception:
                    LOGGER.error("No se pudo publicar el aviso de expulsión uid=%s",
                                 user.id, exc_info=True)
        else:
            try:
                await context.bot.send_message(
                    chat.id,
                    f"⚠️ No se pudo aplicar la acción de moderación a "
                    f"<code>{user.id}</code>. Revisa los permisos del bot.",
                    parse_mode=ParseMode.HTML)
            except Exception:
                LOGGER.error("No se pudo avisar del fallo de moderación uid=%s",
                             user.id, exc_info=True)

        log_event(conn, user.id, username, chat.id, msg.message_id, matched, action.kind)
        LOGGER.info("ABUSE uid=%s strikes=%s -> %s (%s)", user.id, n, action.kind, matched)
    finally:
        conn.close()

    # detener propagación: no dejar que otros handlers procesen el mensaje bloqueado
    raise ApplicationHandlerStop


async def _autodel(context, chat_id, msg_id, secs):
    """Borra un mensaje pasado N segundos (si hay JobQueue)."""
    jq = getattr(context, "job_queue", None)
    if not jq:
        return

    async def _del(ctx):
        try:
            await ctx.bot.delete_message(chat_id, msg_id)
        except Exception:
            pass

    try:
        jq.run_once(_del, secs)
    except Exception:
        pass
