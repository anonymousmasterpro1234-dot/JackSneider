# MoviVIP Admin Bot — bot de Telegram (ADMIN / produccion, white-label)
# =======================================================================
# Nace del bot PERSONAL de MoviVIP, adaptado a producción multi-cliente:
#   * LOGIN OBLIGATORIO con la CONTRASEÑA ROOT de la VPS, validada dinámicamente
#     contra /etc/shadow.
#   * Sin anuncios, sin miniapp, sin referidos: crear/renovar al instante.
#   * Config white-label (config.py) + ADAPTATIVO: el menú solo muestra los
#     protocolos realmente instalados en la VPS.
#   * Corre DENTRO del VPS: usa account.sh local (sin SSH/paramiko).
import asyncio

from aiout import to_thread  # asyncio.to_thread no existe en Py3.8 (.190)
import html
import json
import logging
import re
import string
import time
from urllib.parse import urlsplit

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.error import BadRequest, TelegramError
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler,
                          ContextTypes, MessageHandler, filters)

import auth
import config
import db
import license_policy
import notifications
import protocolos
import sshprod
import vpsinfo

log = logging.getLogger("movivip.bot")
_BOT_LICENSE_VALID = False

# vmess/vless/trojan = 3 protocolos con su MISMO motor (xray_add) y link propio
GRUPO_V2RAY = ("vmess", "vless", "trojan", "v2ray")
_PROTO_ALT = "|".join(protocolos.todos())
PROTO_PATTERN = rf"^proto:({_PROTO_ALT}|v2ray|ssh|zipvpn)$"
FAM_PATTERN = r"^fam:(ssh|http|v2ray|indep)$"
AUTO_PATTERN = rf"^auto:({_PROTO_ALT}|v2ray|ssh|zipvpn)$"
MAN_PATTERN = rf"^man:({_PROTO_ALT}|v2ray|ssh|zipvpn)$"

# creación MANUAL: usuario válido = minúsculas, 3-16 chars, empieza por letra
_USER_RE = re.compile(r"^[a-z][a-z0-9_]{2,15}$")
_RESERVADOS = {
    "root", "admin", "administrador", "ubuntu", "daemon", "bin", "sys", "sync",
    "games", "man", "lp", "mail", "news", "uucp", "proxy", "www-data", "backup",
    "list", "irc", "gnats", "nobody", "sshd", "dropbear", "systemd", "operator",
    "ftp", "telnet", "test", "guest", "user", "mysql", "postgres", "movivip",
    "xray", "hysteria", "slowdns", "zivpn", "nproc", "messagebus", "pollinate",
    "systemd-network", "systemd-resolve",
}
_FLUJO_SEG = 300  # 5 min para completar la creación manual antes de expirar

TEXTO_LOGIN = (
    "🔐 <b>ACCESO PRIVADO</b>\n"
    "━━━━━━━━━━━━━━━━━━━\n"
    f"Bot de administración de <b>{config.BRAND}</b>.\n\n"
    "Escribe la <b>contraseña root de esta VPS</b> para entrar.\n"
    "🛡 Tu mensaje se borra automáticamente al validarlo."
)


def nombre_proto(p):
    return protocolos.nombre(p) or (p if p else "?")


# ───────────────────────── auth helpers ─────────────────────────
def _authed(uid):
    """True si el usuario está logueado y la sesión no ha caducado."""
    if not _BOT_LICENSE_VALID or not config.OWNER_ID or uid != config.OWNER_ID:
        return False
    u = db.get_usuario(uid)
    if not u:
        return False
    try:
        ts = int(u["auth_ts"] or 0)
    except (KeyError, TypeError):
        return False
    return 0 <= (int(time.time()) - ts) <= config.AUTH_SESION_SEG


async def _guard_cb(q):
    """Guard para callbacks: sin sesión -> avisa y corta."""
    if not _BOT_LICENSE_VALID:
        await q.answer("⛔ Bot suspendido: licencia no elegible o no verificable.",
                       show_alert=True)
        return False
    if _authed(q.from_user.id):
        return True
    await q.answer("🔒 Sesión expirada. Envía /start para entrar.", show_alert=True)
    return False


# ───────────────────────── utilidades ─────────────────────────
def _fecha(ts):
    try:
        return time.strftime("%d/%m/%Y", time.localtime(ts))
    except Exception:
        return "?"


def _restante_h(ts):
    seg = max(0, ts - int(time.time()))
    d, r = divmod(seg, 86400)
    h = r // 3600
    if d:
        return f"{d}d {h}h"
    if h:
        return f"{h}h"
    return f"{max(1, r // 60)}m"


def esc(x):
    return html.escape(str(x or ""))


def _password_aleatorio():
    import secrets
    abc = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789"
    return "Mv" + "".join(secrets.choice(abc) for _ in range(10))


def _sufijo():
    import secrets
    import string
    return "".join(secrets.choice(string.ascii_lowercase + string.digits)
                   for _ in range(6))


def menu_keyboard(uid):
    cuentas = db.cuentas_de(uid)
    viva = sum(1 for c in cuentas if c["viva"])
    expirada = any(c["estado"] == "expirada" for c in cuentas)
    sin_limite = config.MAX_CUENTAS_POR_USUARIO <= 0
    filas = []
    f1 = []
    if sin_limite or viva < config.MAX_CUENTAS_POR_USUARIO:
        f1.append(InlineKeyboardButton("🛰 Crear Cuenta", callback_data="crear"))
    f1.append(InlineKeyboardButton("👤 Mi Cuenta", callback_data="micta"))
    filas.append(f1)
    f2 = []
    if expirada:
        f2.append(InlineKeyboardButton("🔄 Renovar", callback_data="renovar_menu"))
    if cuentas:
        f2.append(InlineKeyboardButton("🗑️ Eliminar", callback_data="del_menu"))
    if f2:
        filas.append(f2)
    filas.append([
        InlineKeyboardButton("📊 Info VPS", callback_data="vpsinfo"),
        InlineKeyboardButton("🟢 En línea", callback_data="online"),
    ])
    filas.append([
        InlineKeyboardButton("🌐 Protocolos", callback_data="ayuda_proto"),
        InlineKeyboardButton("❓ Ayuda", callback_data="ayuda"),
    ])
    if config.OWNER_ID and uid == config.OWNER_ID:
        filas.append([InlineKeyboardButton(
            "📣 Configurar notificaciones", callback_data="notif_home")])
    filas.append([InlineKeyboardButton("🔒 Salir", callback_data="logout")])
    return InlineKeyboardMarkup(filas)


def tarjeta_menu(uid, ahora=None):
    ahora = ahora or int(time.time())
    cuentas = db.cuentas_de(uid, ahora)
    viva = [c for c in cuentas if c["viva"]]
    lineas = []
    for c in cuentas:
        if c["viva"]:
            lineas.append(f"  ✅ {nombre_proto(c['protocolo'])} · vence "
                          f"{_fecha(c['expira_ts'])} (⏳{_restante_h(c['expira_ts'])})")
        elif c["estado"] == "expirada":
            lineas.append(f"  ⏳ {nombre_proto(c['protocolo'])} · vencida → renovar")
    cuerpo = "\n".join(lineas) if lineas else "  (sin cuentas aún)"
    slots = ("∞ ilimitadas" if config.MAX_CUENTAS_POR_USUARIO <= 0
             else f"{len(viva)}/{config.MAX_CUENTAS_POR_USUARIO}")
    return (
        "╔══════════════════════╗\n"
        f"║   🛡️  {config.BRAND}  🛡️\n"
        "╚══════════════════════╝\n"
        f"Cuentas activas: {slots}\n"
        f"Tu cuenta dura {config.DIAS_CUENTA} días · {config.MAX_CONEXIONES} conexión\n"
        "Crear y renovar son inmediatos\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"{cuerpo}"
    )


def _link_v2ray(protocolo, uuid, usuario):
    """Link de importación (mismo uuid para vmess/vless/trojan). Puerto 443,
    HAProxy enruta por path, host con SAN en el certificado."""
    if not uuid or protocolo not in GRUPO_V2RAY:
        return ""
    import base64
    from urllib.parse import quote
    proto = "vmess" if protocolo == "v2ray" else protocolo
    host = config.SERVIDOR["host"]
    puerto = str(config.SERVIDOR.get("xray_port", 443))
    tag = f"MOVIVIP-{usuario or 'user'}-{proto}"
    if proto == "vmess":
        payload = {
            "v": "2", "ps": tag, "add": host, "port": puerto, "id": uuid,
            "aid": "0", "scy": "auto", "net": "ws", "type": "none",
            "host": host, "path": "/vmess", "tls": "tls", "sni": host,
        }
        crudo = json.dumps(payload, separators=(",", ":")).encode()
        return "vmess://" + base64.b64encode(crudo).decode()
    if proto == "vless":
        return (f"vless://{uuid}@{host}:{puerto}"
                "?encryption=none&security=tls&type=ws"
                "&path=%2Fvless&host={0}&sni={0}".format(host)
                + "#" + quote(tag, safe=""))
    return (f"trojan://{uuid}@{host}:{puerto}"
            "?security=tls&type=ws"
            "&path=%2Ftrojan-ws&host={0}&sni={0}".format(host)
            + "#" + quote(tag, safe=""))


def tarjeta_entrega(protocolo, usuario, password, uuid, expira_ts,
                    renovada=False, cfg=None):
    titulo = "🔄 CUENTA RENOVADA" if renovada else "✅ ¡CUENTA ACTIVADA!"
    filas = [f"📡 Protocolo: <b>{nombre_proto(protocolo)}</b>"]
    if usuario:
        filas.append(f"👤 Usuario: <code>{esc(usuario)}</code>")
    if password:
        filas.append(f"🔑 Contraseña: <code>{esc(password)}</code>")
    if protocolo in GRUPO_V2RAY and uuid:
        filas.append(f"🆔 UUID: <code>{esc(uuid)}</code>")
    filas.extend(protocolos.datos_tarjeta(protocolo, cfg))
    link = _link_v2ray(protocolo, uuid, usuario)
    if link:
        filas.append("🔗 Link para tu app:\n"
                     f"<code>{esc(link)}</code>")
    filas.append(f"📅 Vence: {_fecha(expira_ts)} "
                 f"(⏳{_restante_h(expira_ts)} restantes)")
    filas.append(f"📶 Conexiones simultáneas: {config.MAX_CONEXIONES}")
    return (
        f"{titulo}\n"
        "━━━━━━━━━━━━━━━━━━━\n" + "\n".join(filas) +
        "\n━━━━━━━━━━━━━━━━━━━\n"
        "⚠️ No compartas tus credenciales (1 conexión por cuenta)."
    )


async def _editar(msg, texto, markup=None):
    """Edita el mensaje (texto). Fallback: reenvío si la edición falla."""
    try:
        await msg.edit_text(texto, reply_markup=markup, parse_mode="HTML")
        return
    except BadRequest as e:
        if "not modified" in str(e).lower():
            return
        log.info("edit_text → reenvío: %s", e)
    except Exception as e:
        log.info("edit_text → reenvío: %s", e)
    try:
        await msg.get_bot().send_message(msg.chat_id, texto, parse_mode="HTML",
                                         reply_markup=markup)
    except Exception as e:
        log.warning("reenvío final: %s", e)


async def _enviar(ctx, chat_id, texto, kb=None):
    return await ctx.bot.send_message(chat_id, texto, parse_mode="HTML",
                                      reply_markup=kb)


async def _enviar_menu(ctx, chat_id, prefijo=""):
    texto = tarjeta_menu(chat_id)
    if prefijo:
        texto = f"{prefijo}\n\n{texto}"
    await _enviar(ctx, chat_id, texto, menu_keyboard(chat_id))


async def _pedir_login(ctx, chat_id):
    ctx.user_data["esperando_pw"] = True
    await _enviar(ctx, chat_id, TEXTO_LOGIN)


_NOTIF_FIELDS = {
    "brand": ("notification_brand", "nombre de marca", 60),
    "channel": ("notification_channel", "ID o @usuario del canal", 80),
    "group": ("notification_group", "ID o @usuario del grupo", 80),
    "support": ("notification_support", "enlace de soporte", 300),
    "web": ("notification_web", "enlace web", 300),
    "whatsapp": ("notification_whatsapp", "enlace de WhatsApp", 300),
}
_TEMPLATE_KEYS = {
    "created": "template_created",
    "renewed": "template_renewed",
    "expired": "template_expired",
    "welcome": "welcome_text",
    "announcement": "template_announcement",
    "maintenance": "template_maintenance",
}
_TEMPLATE_FIELDS = {
    "created": {"marca", "protocolo", "fecha"},
    "renewed": {"marca", "protocolo", "fecha"},
    "expired": {"marca", "protocolo", "fecha"},
    "welcome": {"marca", "soporte", "web", "whatsapp"},
    "announcement": {"marca", "soporte", "web", "whatsapp"},
    "maintenance": {"marca", "soporte", "web", "whatsapp"},
}
_NOTIF_TOGGLES = {
    "event_created": "Avisar al crear cuentas",
    "event_renewed": "Avisar al renovar cuentas",
    "event_expired": "Avisar al vencer cuentas",
    "broadcast_events": "Enviar eventos a suscriptores/canales",
    "broadcast_enabled": "Permitir anuncios masivos",
}


def _notif_home_keyboard():
    filas = [
        [InlineKeyboardButton("Marca", callback_data="notif_edit:brand"),
         InlineKeyboardButton("Canales y grupos", callback_data="notif_targets")],
        [InlineKeyboardButton("Enlaces de soporte", callback_data="notif_links")],
        [InlineKeyboardButton("Eventos de cuenta", callback_data="notif_events")],
        [InlineKeyboardButton("Plantillas y vista previa", callback_data="notif_templates")],
        [InlineKeyboardButton("Enviar anuncio", callback_data="notif_template:announcement"),
         InlineKeyboardButton("Mantenimiento", callback_data="notif_template:maintenance")],
        [InlineKeyboardButton("⬅️ Menú principal", callback_data="menu")],
    ]
    return InlineKeyboardMarkup(filas)


def _notif_targets_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Canal", callback_data="notif_edit:channel"),
         InlineKeyboardButton("Grupo", callback_data="notif_edit:group")],
        [InlineKeyboardButton("⬅️ Notificaciones", callback_data="notif_home")],
    ])


def _notif_links_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Soporte", callback_data="notif_edit:support"),
         InlineKeyboardButton("Sitio web", callback_data="notif_edit:web")],
        [InlineKeyboardButton("WhatsApp", callback_data="notif_edit:whatsapp")],
        [InlineKeyboardButton("⬅️ Notificaciones", callback_data="notif_home")],
    ])


def _notif_events_keyboard():
    filas = []
    for key, label in _NOTIF_TOGGLES.items():
        mark = "✅" if notifications.setting(key) == "1" else "⛔"
        filas.append([InlineKeyboardButton(f"{mark} {label}", callback_data=f"notif_toggle:{key}")])
    filas.append([InlineKeyboardButton("⬅️ Notificaciones", callback_data="notif_home")])
    return InlineKeyboardMarkup(filas)


def _notif_templates_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Cuenta creada", callback_data="notif_template:created"),
         InlineKeyboardButton("Cuenta renovada", callback_data="notif_template:renewed")],
        [InlineKeyboardButton("Cuenta vencida", callback_data="notif_template:expired"),
         InlineKeyboardButton("Bienvenida", callback_data="notif_template:welcome")],
        [InlineKeyboardButton("Anuncio", callback_data="notif_template:announcement"),
         InlineKeyboardButton("Mantenimiento", callback_data="notif_template:maintenance")],
        [InlineKeyboardButton("⬅️ Notificaciones", callback_data="notif_home")],
    ])


def _notif_template_keyboard(kind):
    rows = [[InlineKeyboardButton("Editar texto", callback_data=f"notif_template_edit:{kind}"),
             InlineKeyboardButton("Vista previa", callback_data=f"notif_preview:{kind}")]]
    if kind in ("announcement", "maintenance"):
        rows.append([InlineKeyboardButton(
            "Preparar envío", callback_data=f"notif_send:{kind}")])
    rows.append([InlineKeyboardButton("⬅️ Plantillas", callback_data="notif_templates")])
    return InlineKeyboardMarkup(rows)


def _notif_template_preview(kind):
    if kind in ("created", "renewed", "expired"):
        text = notifications.event_text(kind, {
            "protocolo": "SSH",
            "fecha": "30/12/2030",
        })
    elif kind == "welcome":
        text = notifications.welcome_text()
    else:
        text = notifications.render_announcement(kind)
    return text


async def cb_notif_home(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    await q.answer()
    await _editar(q.message, "📣 <b>Notificaciones</b>\n"
                  "Configura marca, canales, enlaces, eventos y plantillas.\n"
                  "Los envíos masivos solo llegan a usuarios que iniciaron el bot "
                  "de notificaciones con /start.",
                  _notif_home_keyboard())


async def cb_notif_page(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    await q.answer()
    pages = {
        "notif_targets": ("📡 <b>Canales y grupos</b>\n"
                          "Añade el bot de notificaciones como administrador del canal "
                          "o al grupo. Vacío desactiva el destino.",
                          _notif_targets_keyboard()),
        "notif_links": ("🔗 <b>Enlaces de soporte</b>\n"
                        "Usa enlaces http/https; deja vacío para quitarlos.",
                        _notif_links_keyboard()),
        "notif_events": ("🔔 <b>Eventos</b>\nActiva solo los avisos que quieras enviar.",
                         _notif_events_keyboard()),
        "notif_templates": ("✍️ <b>Plantillas</b>\n"
                            "Puedes editar y previsualizar antes de guardar.",
                            _notif_templates_keyboard()),
    }
    texto, teclado = pages[q.data]
    await _editar(q.message, texto, teclado)


async def cb_notif_edit(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    field = q.data.split(":", 1)[1]
    if field not in _NOTIF_FIELDS:
        await q.answer("Campo no válido.", show_alert=True)
        return
    ctx.user_data["notif_edit"] = _NOTIF_FIELDS[field][0]
    await q.answer()
    await _editar(
        q.message,
        f"Escribe el {_NOTIF_FIELDS[field][1]} (máximo "
        f"{_NOTIF_FIELDS[field][2]} caracteres). Envía /cancelar para volver.",
        InlineKeyboardMarkup([[
            InlineKeyboardButton("Cancelar", callback_data="notif_cancel")
        ]]),
    )


async def cb_notif_template(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    kind = q.data.split(":", 1)[1]
    if kind not in _TEMPLATE_KEYS:
        await q.answer("Plantilla no válida.", show_alert=True)
        return
    await q.answer()
    try:
        preview = esc(_notif_template_preview(kind))
    except ValueError as exc:
        preview = f"Plantilla inválida: {esc(exc)}"
    await _editar(q.message, f"<b>Plantilla · {esc(kind)}</b>\n\n{preview}",
                  _notif_template_keyboard(kind))


async def cb_notif_template_edit(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    kind = q.data.split(":", 1)[1]
    if kind not in _TEMPLATE_KEYS:
        await q.answer("Plantilla no válida.", show_alert=True)
        return
    ctx.user_data["notif_edit"] = _TEMPLATE_KEYS[kind]
    await q.answer()
    vars_text = ", ".join("{" + name + "}" for name in sorted(_TEMPLATE_FIELDS[kind]))
    await _editar(
        q.message,
        f"Escribe el texto para <b>{esc(kind)}</b> (máx. 2500 caracteres).\n"
        f"Variables permitidas: <code>{esc(vars_text)}</code>.\n"
        "El texto se envía sin formato HTML. /cancelar vuelve atrás.",
        InlineKeyboardMarkup([[
            InlineKeyboardButton("Cancelar", callback_data="notif_cancel")
        ]]),
    )


async def cb_notif_toggle(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    key = q.data.split(":", 1)[1]
    if key not in _NOTIF_TOGGLES:
        await q.answer("Opción no válida.", show_alert=True)
        return
    new_value = "0" if notifications.setting(key) == "1" else "1"
    db.set_setting(key, new_value)
    await q.answer("Actualizado")
    await _editar(q.message, "🔔 <b>Eventos</b>\nActiva solo los avisos que quieras enviar.",
                  _notif_events_keyboard())


async def cb_notif_preview(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    kind = q.data.split(":", 1)[1]
    if kind not in _TEMPLATE_KEYS:
        await q.answer("Plantilla no válida.", show_alert=True)
        return
    await q.answer("Vista previa")
    try:
        preview = esc(_notif_template_preview(kind))
    except ValueError as exc:
        preview = f"Plantilla inválida: {esc(exc)}"
    await _editar(q.message, f"👁 <b>Vista previa</b>\n\n{preview}",
                  _notif_template_keyboard(kind))


async def cb_notif_send(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    kind = q.data.split(":", 1)[1]
    if kind not in ("announcement", "maintenance"):
        await q.answer("Envío no válido.", show_alert=True)
        return
    await q.answer()
    try:
        preview = esc(_notif_template_preview(kind))
    except ValueError as exc:
        await _editar(q.message, f"Plantilla inválida: {esc(exc)}",
                      _notif_template_keyboard(kind))
        return
    await _editar(
        q.message,
        f"Se enviará este mensaje a las personas suscritas "
        f"({len(db.subscribers())}) y a los destinos configurados:\n\n{preview}",
        InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ Confirmar envío",
                                  callback_data=f"notif_send_confirm:{kind}")],
            [InlineKeyboardButton("Cancelar", callback_data="notif_templates")],
        ]),
    )


async def cb_notif_send_confirm(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    kind = q.data.split(":", 1)[1]
    if kind not in ("announcement", "maintenance"):
        await q.answer("Envío no válido.", show_alert=True)
        return
    try:
        text = _notif_template_preview(kind)
    except ValueError as exc:
        await q.answer(f"Plantilla inválida: {exc}", show_alert=True)
        return
    await q.answer("Enviando…")
    sent, failed = await notifications.broadcast(text)
    if not sent and not failed:
        texto = "No hay suscriptores activos ni canales/grupos configurados."
    else:
        texto = f"📨 Envío terminado.\nEnviados: {sent} · Fallidos: {failed}"
    await _editar(q.message, texto, _notif_templates_keyboard())


async def cb_notif_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    ctx.user_data.pop("notif_edit", None)
    await q.answer("Edición cancelada")
    await _editar(q.message, "📣 <b>Notificaciones</b>",
                  _notif_home_keyboard())


async def _save_notif_input(update: Update, ctx: ContextTypes.DEFAULT_TYPE, uid):
    key = ctx.user_data.pop("notif_edit", None)
    value = (update.message.text or "").strip()
    field = next((name for name, item in _NOTIF_FIELDS.items() if item[0] == key), None)
    if field:
        limit = _NOTIF_FIELDS[field][2]
        if len(value) > limit:
            await _enviar(ctx, uid, f"⚠️ El valor supera {limit} caracteres. Inténtalo otra vez.")
            ctx.user_data["notif_edit"] = key
            return
        if field == "brand" and not value:
            await _enviar(ctx, uid, "⚠️ La marca no puede quedar vacía.")
            ctx.user_data["notif_edit"] = key
            return
        if field in ("support", "web", "whatsapp") and value:
            try:
                parsed = urlsplit(value)
            except ValueError:
                parsed = None
            if not parsed or parsed.scheme not in ("http", "https") or not parsed.netloc:
                await _enviar(ctx, uid, "⚠️ Usa un enlace completo http:// o https://.")
                ctx.user_data["notif_edit"] = key
                return
        if field in ("channel", "group") and value and not re.fullmatch(
                r"(?:-?\d{5,20}|@[A-Za-z0-9_]{5,32})", value):
            await _enviar(ctx, uid, "⚠️ Usa un ID numérico o @usuario válido.")
            ctx.user_data["notif_edit"] = key
            return
        db.set_setting(key, value)
        await _enviar(ctx, uid, "✅ Guardado.", _notif_home_keyboard())
        return

    kind = next((name for name, template_key in _TEMPLATE_KEYS.items()
                 if template_key == key), None)
    if not kind:
        await _enviar(ctx, uid, "⚠️ No se reconoce el campo.")
        return
    allowed = _TEMPLATE_FIELDS[kind]
    try:
        for _, name, _, _ in string.Formatter().parse(value):
            if name is not None and name not in allowed:
                raise ValueError(f"variable no permitida: {{{name}}}")
        if not value or len(value) > 2500:
            raise ValueError("el texto debe tener entre 1 y 2500 caracteres")
        db.set_setting(key, value)
    except ValueError as exc:
        await _enviar(ctx, uid, f"⚠️ No se guardó: {esc(exc)}")
        ctx.user_data["notif_edit"] = key
        return
    await _enviar(ctx, uid, "✅ Plantilla guardada. Puedes abrirla para previsualizar.",
                  _notif_home_keyboard())


# ───────────────────────── /start /login /logout ─────────────────────────
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    if not u:
        return
    ctx.user_data.pop("flujo", None)
    if not _BOT_LICENSE_VALID:
        await _enviar(ctx, u.id, "⛔ Bot suspendido: licencia no elegible o no verificable.")
        return
    if not config.OWNER_ID or u.id != config.OWNER_ID:
        await _enviar(ctx, u.id, "⛔ Este bot es privado.")
        return
    db.nuevo_usuario(u.id, u.username, u.first_name)
    if _authed(u.id):
        await _enviar_menu(ctx, u.id, f"🛰 <b>{config.BRAND} — Menú</b>")
    else:
        await _pedir_login(ctx, u.id)


async def cmd_login(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    if not u:
        return
    if not _BOT_LICENSE_VALID:
        await _enviar(ctx, u.id, "⛔ Bot suspendido: licencia no elegible o no verificable.")
        return
    if not config.OWNER_ID or u.id != config.OWNER_ID:
        await _enviar(ctx, u.id, "⛔ Este bot es privado.")
        return
    db.nuevo_usuario(u.id, u.username, u.first_name)
    if _authed(u.id):
        await _enviar_menu(ctx, u.id, "✅ Ya tienes sesión activa.")
        return
    await _pedir_login(ctx, u.id)


async def cmd_logout(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    if not u:
        return
    db.clear_auth(u.id)
    ctx.user_data["esperando_pw"] = False
    ctx.user_data.pop("flujo", None)
    await _enviar(ctx, u.id, "🔒 Sesión cerrada. Envía /start para volver a entrar.")


async def cmd_ayuda(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    if not u:
        return
    if not _BOT_LICENSE_VALID:
        await _enviar(ctx, u.id, "⛔ Bot suspendido: licencia no elegible o no verificable.")
        return
    if not config.OWNER_ID or u.id != config.OWNER_ID:
        await _enviar(ctx, u.id, "⛔ Este bot es privado.")
        return
    if not _authed(u.id):
        await _pedir_login(ctx, u.id)
        return
    await _enviar(ctx, u.id, texto_ayuda(), menu_keyboard(u.id))


async def cmd_menu_cb(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    await q.answer()
    ctx.user_data.pop("flujo", None)
    await _editar(q.message, tarjeta_menu(q.from_user.id), menu_keyboard(q.from_user.id))


async def cmd_notif_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    if not u or not await _authed(u.id):
        return
    ctx.user_data.pop("notif_edit", None)
    await _enviar(ctx, u.id, "Edición cancelada.", _notif_home_keyboard())


# ───────────────────────── mensaje de texto (login) ─────────────────────────
async def msg_texto(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    if not u:
        return
    if not config.OWNER_ID or u.id != config.OWNER_ID:
        await _enviar(ctx, u.id, "⛔ Este bot es privado.")
        return
    if not _BOT_LICENSE_VALID:
        await _enviar(ctx, u.id, "⛔ Bot suspendido: licencia no elegible o no verificable.")
        return
    if _authed(u.id):
        if ctx.user_data.get("notif_edit"):
            await _save_notif_input(update, ctx, u.id)
            return
        # logueado: si hay una creación MANUAL en curso la procesamos;
        # si no, ignoramos el texto suelto (todo va por botones)
        flujo = ctx.user_data.get("flujo")
        if flujo:
            await _procesar_flujo(update, ctx, flujo)
        return
    if not ctx.user_data.get("esperando_pw"):
        await _pedir_login(ctx, u.id)
        return
    permitido, restante = auth.puede_intentar(u.id)
    if not permitido:
        await _enviar(ctx, u.id, f"⛔ Demasiados intentos. Espera {restante}s y reintenta.")
        return
    pw = (update.message.text or "").strip()
    # privacidad: borra ya el mensaje que contiene la contraseña
    try:
        await update.message.delete()
    except Exception:
        pass
    if auth.verificar_password(pw):
        auth.registrar_exito(u.id)
        db.set_auth(u.id)
        ctx.user_data["esperando_pw"] = False
        await _enviar_menu(ctx, u.id, "✅ Acceso concedido. Bienvenido.")
    else:
        auth.registrar_fallo(u.id)
        await _enviar(ctx, u.id,
                      "❌ Contraseña incorrecta.\n"
                      "Escribe de nuevo la contraseña root, o envía /start.")


# ───────────────────────── creación MANUAL (máquina de estados) ─────────────────────────
async def _crear_texto(ctx, uid, proto, usuario, password):
    await _enviar(ctx, uid, f"⏳ <b>Creando {nombre_proto(proto)}…</b>")

    async def responder(texto):
        await _enviar(ctx, uid, texto, menu_keyboard(uid))

    await _crear_final(responder, uid, proto, usuario, password)


async def _procesar_flujo(update, ctx, flujo):
    """Recibe el texto de una creación MANUAL (usuario / contraseña)."""
    uid = update.effective_user.id
    texto = (update.message.text or "").strip()
    try:
        await update.message.delete()  # privacidad: borra el dato enviado
    except Exception:
        pass
    proto = flujo.get("proto")
    grupo = protocolos.grupo_de(proto)
    # expiración del flujo (5 min) o protocolo ya no válido
    if grupo is None or int(time.time()) - int(flujo.get("ts", 0)) > _FLUJO_SEG:
        ctx.user_data.pop("flujo", None)
        await _enviar(ctx, uid, "⌛ La creación manual expiró. Vuelve a intentarlo.",
                      menu_keyboard(uid))
        return

    if flujo.get("paso") == "usuario":
        usuario = texto.lower()
        if not _USER_RE.match(usuario):
            await _enviar(ctx, uid,
                          "❌ <b>Usuario no válido.</b>\n"
                          "Minúsculas, 3-16 caracteres, empieza por letra y solo "
                          "letras/números/guion bajo.\n\n" + _pedir_manual(proto, "usuario"),
                          _kb_cancelar())
            return
        if usuario in _RESERVADOS:
            await _enviar(ctx, uid,
                          "❌ Ese nombre está <b>reservado</b> por el sistema.\n\n"
                          + _pedir_manual(proto, "usuario"), _kb_cancelar())
            return
        flujo["usuario"] = usuario
        if grupo == "v2ray":  # v2ray solo usa usuario
            ctx.user_data.pop("flujo", None)
            await _crear_texto(ctx, uid, proto, usuario, "")
            return
        flujo["paso"] = "password"
        flujo["ts"] = int(time.time())
        await _enviar(ctx, uid, _pedir_manual(proto, "password"), _kb_cancelar())
        return

    # paso == "password"
    if texto.lower() == "auto":
        password = _password_aleatorio()
    else:
        password = texto
        if len(password) < 6 or " " in password:
            await _enviar(ctx, uid,
                          "❌ <b>Contraseña no válida</b> (mín. 6 caracteres, sin "
                          "espacios).\n\n" + _pedir_manual(proto, "password"),
                          _kb_cancelar())
            return
    usuario = "" if grupo == "zipvpn" else flujo.get("usuario", "")
    ctx.user_data.pop("flujo", None)
    await _crear_texto(ctx, uid, proto, usuario, password)


# ───────────────────────── creación (submenú por familia) ─────────────────────────
def teclado_familias():
    filas = []
    for clave, f in protocolos.familias_disponibles().items():
        n = len(f["protos"])
        filas.append([InlineKeyboardButton(
            f'{f["emoji"]} {f["titulo"]}  ({n})',
            callback_data=f"fam:{clave}")])
    filas.append([InlineKeyboardButton("⬅️ Menú", callback_data="menu")])
    return InlineKeyboardMarkup(filas)


def teclado_familia(fam):
    f = protocolos.familias_disponibles().get(fam)
    if not f:
        return teclado_familias()
    filas = []
    for p in f["protos"]:
        info = protocolos.PROTOCOS[p]
        filas.append([InlineKeyboardButton(
            f'{info["emoji"]} {info["nombre"]}',
            callback_data=f"proto:{p}")])
    filas.append([InlineKeyboardButton("⬅️ Familias", callback_data="crear")])
    filas.append([InlineKeyboardButton("⬅️ Menú", callback_data="menu")])
    return InlineKeyboardMarkup(filas)


async def cb_crear(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    await q.answer()
    sin_limite = config.MAX_CUENTAS_POR_USUARIO <= 0
    cola = (f"{config.DIAS_CUENTA} días · ilimitadas" if sin_limite
            else f"{config.DIAS_CUENTA} días · máx {config.MAX_CUENTAS_POR_USUARIO}")
    await _editar(q.message,
                  "🛰 <b>CREAR CUENTA</b>\n"
                  "━━━━━━━━━━━━━━━━━━━\n"
                  "Elige la familia de tu protocolo:\n"
                  + "\n".join(
                      f'{f["emoji"]} <b>{f["titulo"]}</b> — {f["desc"]}'
                      for f in protocolos.familias_disponibles().values())
                  + f"\n\n({cola}, creación inmediata)",
                  teclado_familias())


async def cb_familia(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    fam = q.data.split(":", 1)[1]
    f = protocolos.familias_disponibles().get(fam)
    await q.answer()
    if not f:
        await _editar(q.message, "Familia no válida. Usa /start.", teclado_familias())
        return
    await _editar(
        q.message,
        f'{f["emoji"]} <b>{f["titulo"].upper()}</b>\n'
        "━━━━━━━━━━━━━━━━━━━\n"
        f'{f["desc"]}\n'
        "Cada protocolo recibe <b>su propia tarjeta</b> de conexión.\n\n"
        f"(Creación inmediata · {config.DIAS_CUENTA} días)",
        teclado_familia(fam))


def _teclado_modo(proto):
    fam = protocolos.familia_de(proto) or "ssh"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🤖 Automático (al azar)", callback_data=f"auto:{proto}")],
        [InlineKeyboardButton("✍️ Manual (yo elijo)", callback_data=f"man:{proto}")],
        [InlineKeyboardButton("⬅️ Volver", callback_data=f"fam:{fam}")],
    ])


def _modo_card(proto):
    return (
        f'{protocolos.emoji(proto)} <b>{nombre_proto(proto)}</b>\n'
        "━━━━━━━━━━━━━━━━━━━\n"
        "¿Cómo quieres crear la cuenta?\n\n"
        "🤖 <b>Automático</b> — usuario y contraseña al azar\n"
        "✍️ <b>Manual</b> — tú eliges usuario y/o contraseña\n\n"
        f"⏳ Duración: {config.DIAS_CUENTA} días · creación inmediata"
    )


def _pedir_manual(proto, paso):
    e = protocolos.emoji(proto)
    nombre = nombre_proto(proto)
    if paso == "usuario":
        return (f"{e} <b>{nombre} — Manual</b>\n"
                "━━━━━━━━━━━━━━━━━━━\n"
                "✍️ Escribe el <b>nombre de usuario</b> que quieres.\n\n"
                "Reglas: minúsculas, 3-16 caracteres, empieza con letra\n"
                "(ej: <code>juan01</code> · <code>mvpedro</code>).\n"
                "📩 Envíalo como mensaje de texto.")
    return (f"{e} <b>{nombre} — Manual</b>\n"
            "━━━━━━━━━━━━━━━━━━━\n"
            "✍️ Escribe la <b>contraseña</b> que quieres (mín. 6 caracteres, sin espacios).\n\n"
            "O envía <code>auto</code> para que la genere yo.\n"
            "📩 Envíala como mensaje de texto.")


def _kb_cancelar():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("❌ Cancelar", callback_data="menu")],
    ])


async def _crear_final(responder, uid, proto, usuario, password):
    """Crea la cuenta (auto o manual) y pinta tarjeta o error vía `responder`."""
    try:
        cfg = await to_thread(protocolos.cargar_config)
        grupo = protocolos.grupo_de(proto)
        if grupo == "ssh":
            res = await to_thread(sshprod.crear_ssh, usuario, password)
        elif grupo == "v2ray":
            res = await to_thread(sshprod.crear_v2ray, usuario)
        elif grupo == "zipvpn":
            res = await to_thread(sshprod.crear_zipvpn, password)
        else:
            raise RuntimeError("protocolo desconocido")
        if not res.ok:
            raise RuntimeError(res.error or "fallo al crear la cuenta")
        db.registrar_cuenta(uid, proto, usuario, password, res.uuid, res.expira_ts)
        try:
            await notifications.notify_event("created", {
                "protocolo": nombre_proto(proto),
                "usuario": usuario,
                "fecha": _fecha(res.expira_ts),
            })
        except ValueError:
            log.exception("plantilla de notificación de alta inválida")
        await responder(tarjeta_entrega(proto, usuario, password, res.uuid,
                                        res.expira_ts, cfg=cfg))
    except Exception as e:
        log.exception("crear fallo uid=%s proto=%s", uid, proto)
        await responder("⚠️ <b>No se pudo crear la cuenta</b>\n"
                        f"Detalle: <code>{esc(str(e)[:150])}</code>")


async def cb_proto(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    if not await _guard_cb(q):
        return
    proto = q.data.split(":", 1)[1]
    if protocolos.grupo_de(proto) is None:
        await q.answer("Protocolo no válido", show_alert=True)
        return
    ok, _ = db.puede_crear(uid)
    if not ok:
        await q.answer(f"🚫 Ya tienes {config.MAX_CUENTAS_POR_USUARIO} cuentas "
                       "activas. Elimina una o espera a que venza.", show_alert=True)
        await _editar(q.message, tarjeta_menu(uid), menu_keyboard(uid))
        return
    await q.answer()
    ctx.user_data.pop("flujo", None)
    await _editar(q.message, _modo_card(proto), _teclado_modo(proto))


async def cb_auto(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    if not await _guard_cb(q):
        return
    proto = q.data.split(":", 1)[1]
    if protocolos.grupo_de(proto) is None:
        await q.answer("Protocolo no válido", show_alert=True)
        return
    ok, _ = db.puede_crear(uid)
    if not ok:
        await q.answer(f"🚫 Ya tienes {config.MAX_CUENTAS_POR_USUARIO} cuentas activas.",
                       show_alert=True)
        await _editar(q.message, tarjeta_menu(uid), menu_keyboard(uid))
        return
    ctx.user_data.pop("flujo", None)
    await q.answer("⏳ Creando tu cuenta…")
    await _editar(q.message, f"⏳ <b>Creando {nombre_proto(proto)}…</b>\n"
                             "Espera unos segundos.", None)
    grupo = protocolos.grupo_de(proto)
    if grupo == "zipvpn":
        usuario, password = "", _password_aleatorio()
    elif grupo == "v2ray":
        usuario, password = f"mv{str(uid)[-6:]}{_sufijo()}", ""
    else:
        usuario, password = f"mv{str(uid)[-6:]}{_sufijo()}", _password_aleatorio()

    async def responder(texto):
        await _editar(q.message, texto, menu_keyboard(uid))

    await _crear_final(responder, uid, proto, usuario, password)


async def cb_man(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    if not await _guard_cb(q):
        return
    proto = q.data.split(":", 1)[1]
    grupo = protocolos.grupo_de(proto)
    if grupo is None:
        await q.answer("Protocolo no válido", show_alert=True)
        return
    ok, _ = db.puede_crear(uid)
    if not ok:
        await q.answer(f"🚫 Ya tienes {config.MAX_CUENTAS_POR_USUARIO} cuentas activas.",
                       show_alert=True)
        await _editar(q.message, tarjeta_menu(uid), menu_keyboard(uid))
        return
    await q.answer()
    paso = "password" if grupo == "zipvpn" else "usuario"
    ctx.user_data["flujo"] = {"proto": proto, "paso": paso, "ts": int(time.time())}
    await _editar(q.message, _pedir_manual(proto, paso), _kb_cancelar())


# ───────────────────────── mi cuenta / renovar / eliminar ─────────────────────────
async def cb_micta(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    uid = q.from_user.id
    await q.answer()
    cuentas = db.cuentas_de(uid)
    if not cuentas:
        await _editar(q.message, "Aún no tienes cuentas.\n\n" + tarjeta_menu(uid),
                      menu_keyboard(uid))
        return
    filas = []
    for c in cuentas:
        if c["viva"]:
            filas.append(f"✅ #{c['id']} {nombre_proto(c['protocolo'])} · "
                         f"vence {_fecha(c['expira_ts'])} (⏳{_restante_h(c['expira_ts'])})")
        elif c["estado"] == "expirada":
            filas.append(f"⏳ #{c['id']} {nombre_proto(c['protocolo'])} · vencida → renovar")
        else:
            filas.append(f"💤 #{c['id']} {nombre_proto(c['protocolo'])} · {c['estado']}")
    viva = sum(1 for c in cuentas if c["viva"])
    botones = []
    for c in cuentas:
        if c["estado"] == "expirada":
            botones.append(InlineKeyboardButton(
                f"🔄 Renovar #{c['id']}", callback_data=f"renovar:{c['id']}"))
    for c in cuentas:
        if c["viva"]:
            botones.append(InlineKeyboardButton(
                f"🗑️ Eliminar #{c['id']}", callback_data=f"del:{c['id']}"))
    filas_b = [botones[i:i + 2] for i in range(0, len(botones), 2)]
    sin_limite = config.MAX_CUENTAS_POR_USUARIO <= 0
    if sin_limite or viva < config.MAX_CUENTAS_POR_USUARIO:
        filas_b.append([InlineKeyboardButton("🛰 Crear otra cuenta", callback_data="crear")])
    filas_b.append([InlineKeyboardButton("⬅️ Menú", callback_data="menu")])
    slots = "∞" if sin_limite else f"{viva}/{config.MAX_CUENTAS_POR_USUARIO}"
    await _editar(
        q.message,
        "👤 <b>MI CUENTA</b>\n━━━━━━━━━━━━━━━━━━━\n"
        f"Slots usados: {slots}\n" + "\n".join(filas),
        InlineKeyboardMarkup(filas_b))


async def cb_renovar_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    uid = q.from_user.id
    expiradas = [c for c in db.cuentas_de(uid) if c["estado"] == "expirada"]
    if not expiradas:
        await q.answer("No tienes cuentas vencidas.", show_alert=True)
        return
    if len(expiradas) == 1:
        await _renovar(q, uid, expiradas[0])
        return
    botones = [[InlineKeyboardButton(
        f"🔄 {nombre_proto(c['protocolo'])} "
        f"({c['usuario'] or (c['password'][:6] + '…')})",
        callback_data=f"renovar:{c['id']}")] for c in expiradas]
    botones.append([InlineKeyboardButton("⬅️ Menú", callback_data="menu")])
    await q.answer()
    await _editar(q.message, "¿Qué cuenta quieres renovar?", InlineKeyboardMarkup(botones))


async def cb_renovar(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    uid = q.from_user.id
    cid = int(q.data.split(":", 1)[1])
    cu = db.get_cuenta(cid)
    if not cu or cu["tg_id"] != uid:
        await q.answer("Cuenta no encontrada", show_alert=True)
        return
    await _renovar(q, uid, cu)


async def _renovar(q, uid, cu):
    await q.answer("⏳ Renovando…")
    await _editar(q.message,
                  f"⏳ <b>Renovando {nombre_proto(cu['protocolo'])}…</b>", None)
    try:
        cfg = await to_thread(protocolos.cargar_config)
        res = await to_thread(sshprod.renovar, cu["protocolo"],
                                      cu["usuario"], cu["password"])
        if not res.ok:
            raise RuntimeError(res.error or "fallo al renovar")
        db.renombrar_expiracion(cu["id"], res.expira_ts)
        if res.uuid and res.uuid != cu["uuid"]:
            db.actualizar_uuid(cu["id"], res.uuid)
        try:
            await notifications.notify_event("renewed", {
                "protocolo": nombre_proto(cu["protocolo"]),
                "usuario": cu["usuario"],
                "fecha": _fecha(res.expira_ts),
            })
        except ValueError:
            log.exception("plantilla de notificación de renovación inválida")
        await _editar(
            q.message,
            tarjeta_entrega(cu["protocolo"], cu["usuario"], cu["password"],
                            res.uuid or cu["uuid"], res.expira_ts,
                            renovada=True, cfg=cfg),
            menu_keyboard(uid))
    except Exception as e:
        log.exception("renovar fallo uid=%s", uid)
        await _editar(q.message,
                      f"⚠️ No se pudo renovar: <code>{esc(str(e)[:150])}</code>",
                      menu_keyboard(uid))


async def cb_del_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    uid = q.from_user.id
    cuentas = [c for c in db.cuentas_de(uid) if c["estado"] != "borrada"]
    if not cuentas:
        await q.answer("No tienes cuentas.", show_alert=True)
        return
    botones = []
    for c in cuentas:
        estado = "✅" if c["viva"] else "⏳"
        ident = c["usuario"] or (c["password"][:6] + "…")
        botones.append([InlineKeyboardButton(
            f"{estado} #{c['id']} {nombre_proto(c['protocolo'])} · {ident}",
            callback_data=f"del:{c['id']}")])
    botones.append([InlineKeyboardButton("⬅️ Menú", callback_data="menu")])
    await q.answer()
    await _editar(q.message, "¿Qué cuenta quieres eliminar?",
                  InlineKeyboardMarkup(botones))


async def cb_del(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    uid = q.from_user.id
    cid = int(q.data.split(":", 1)[1])
    cu = db.get_cuenta(cid)
    if not cu or cu["tg_id"] != uid:
        await q.answer("Cuenta no encontrada", show_alert=True)
        return
    await q.answer()
    ident = cu["usuario"] or (cu["password"][:6] + "…")
    await _editar(
        q.message,
        f"⚠️ <b>¿Eliminar esta cuenta?</b>\n━━━━━━━━━━━━━━━━━━━\n"
        f"#{cid} · {nombre_proto(cu['protocolo'])} · <code>{esc(ident)}</code>\n\n"
        "Se borrará del servidor YA.",
        InlineKeyboardMarkup([
            [InlineKeyboardButton("🗑️ Sí, eliminar", callback_data=f"delyes:{cid}")],
            [InlineKeyboardButton("❌ No", callback_data="micta")],
        ]))


async def cb_delyes(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    uid = q.from_user.id
    cid = int(q.data.split(":", 1)[1])
    cu = db.get_cuenta(cid)
    if not cu or cu["tg_id"] != uid:
        await q.answer("Cuenta no encontrada", show_alert=True)
        return
    await q.answer("Eliminando…")
    try:
        eliminado = await to_thread(sshprod.eliminar, cu["protocolo"],
                                            cu["usuario"], cu["password"])
    except Exception as e:
        log.warning("eliminar VPS: %s", e)
        eliminado = False
    if not eliminado:
        await q.answer("⚠️ No se pudo borrar en el servidor. Reintenta.", show_alert=True)
        return
    db.eliminar_cuenta(cid)
    await _editar(q.message,
                  f"🗑️ Cuenta #{cid} eliminada.\n\n" + tarjeta_menu(uid),
                  menu_keyboard(uid))


async def cb_logout(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    uid = q.from_user.id
    db.clear_auth(uid)
    ctx.user_data["esperando_pw"] = False
    await q.answer("Sesión cerrada")
    await _editar(q.message,
                  "🔒 Sesión cerrada. Envía /start y escribe la contraseña para entrar.",
                  None)


# ───────────────────────── ayuda ─────────────────────────
def texto_ayuda():
    n_proto = len(protocolos.disponibles())
    n_fam = len(protocolos.familias_disponibles())
    return (
        "❓ <b>CÓMO FUNCIONA</b>\n"
        "━━━━━━━━━━━━━━━━━━━\n"
        "1️⃣ <b>Crear Cuenta</b> → elige familia y protocolo.\n"
        "   La cuenta se crea <b>al instante</b>.\n"
        f"2️⃣ Recibes tu tarjeta ({config.DIAS_CUENTA} días · "
        f"{config.MAX_CONEXIONES} conexión).\n"
        "━━━━━━━━━━━━━━━━━━━\n"
        "🔄 <b>Renovar</b>: recrea la cuenta vencida (mismos datos).\n"
        "🗑 <b>Eliminar</b>: la borra del servidor.\n"
        "🔒 <b>Salir</b>: cierra la sesión (pide contraseña otra vez).\n"
        "━━━━━━━━━━━━━━━━━━━\n"
        "🔐 El acceso usa la <b>contraseña root de la VPS</b>: si la cambias "
        "en el servidor, el bot acepta la nueva automáticamente.\n"
        f"🌐 <b>{n_proto} protocolos</b> en {n_fam} familias: solo los "
        "instalados en esta VPS (SSH, V2Ray, Hysteria, Shadowsocks, ZIPVPN…)."
    )


async def cb_ayuda(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    await q.answer()
    await _editar(q.message, texto_ayuda(), menu_keyboard(q.from_user.id))


async def cb_ayuda_proto(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    await q.answer()
    lineas = []
    familias = protocolos.familias_disponibles()
    for clave, f in familias.items():
        protos = " · ".join(protocolos.PROTOCOS[p]["nombre"] for p in f["protos"])
        lineas.append(f'{f["emoji"]} <b>{f["titulo"]}</b> ({len(f["protos"])})\n'
                      f"    {protos}")
    await _editar(q.message,
                  f"🌐 <b>PROTOCOLOS ({len(protocolos.disponibles())} en "
                  f"{len(familias)} familias)</b>\n"
                  "━━━━━━━━━━━━━━━━━━━\n" + "\n\n".join(lineas) +
                  "\n━━━━━━━━━━━━━━━━━━━\n"
                  "Cada protocolo recibe <b>su propia tarjeta</b> con sus "
                  "puertos/keys/links.\n"
                  "🛡 V2Ray → link de importación · 📦 ZIPVPN → password simple · "
                  "🔐 familia SSH → IP + puertos + credenciales.",
                  teclado_familias())


# ───────────────────────── INFO VPS / EN LÍNEA ─────────────────────────
def _linea_servicio(s):
    if s["tcp"] and s["udp"]:
        puertos = ", ".join(s["tcp"]) + " · udp " + ", ".join(s["udp"])
    elif s["udp"]:
        puertos = "udp " + ", ".join(s["udp"])
    else:
        puertos = ", ".join(s["tcp"]) or "—"
    icono = "🟢" if s["activo"] else "🔴"
    return f'{icono} {s["nombre"]} — <code>{puertos}</code>'


async def _texto_vpsinfo():
    datos = await to_thread(vpsinfo.resumen)
    idn = datos["ident"]
    servs = datos["servicios"]
    activos = sum(1 for s in servs if s["activo"])
    caidos = len(servs) - activos
    lineas = [
        "📊 <b>INFO DE LA VPS</b>",
        "━━━━━━━━━━━━━━━━━━━",
        f'🖥 <b>{esc(idn["hostname"])}</b> · {esc(idn["os"])}',
        f'🧬 Kernel {esc(idn["kernel"])} · ⏱ {esc(idn["uptime"])}',
        f'📈 Carga: {esc(idn["carga"])} · 💾 RAM {idn["mem_pct"]}%',
        f'💾 Disco: {esc(idn["disco"])}',
        f'📡 IP: <code>{esc(idn["ip"])}</code>',
    ]
    if idn["dominios"]:
        lineas.append("🌐 <b>Dominios:</b>")
        lineas.extend(f"   • <code>{esc(d)}</code>" for d in idn["dominios"])
    lineas.append("")
    lineas.append(f"⚙️ <b>PROTOCOLOS Y PUERTOS</b> ({activos} activos"
                  + (f" · {caidos} caídos" if caidos else "") + ")")
    lineas.extend(_linea_servicio(s) for s in servs)
    texto = "\n".join(lineas)
    return texto[:4000] if len(texto) > 4000 else texto


def _kb_refrescar(dato):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 Actualizar", callback_data=dato)],
        [InlineKeyboardButton("⬅️ Menú", callback_data="menu")],
    ])


async def cb_vpsinfo(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    await q.answer("⏳ Leyendo el servidor…")
    texto = await _texto_vpsinfo()
    await _editar(q.message, texto, _kb_refrescar("vpsinfo"))


async def cb_online(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not await _guard_cb(q):
        return
    await q.answer("⏳ Consultando…")
    datos = await to_thread(vpsinfo.usuarios_en_linea)
    sesiones = datos["sesiones"]
    conex = datos["conexiones"]
    lineas = ["🟢 <b>USUARIOS EN LÍNEA</b>", "━━━━━━━━━━━━━━━━━━━"]
    if sesiones:
        lineas.append(f"🖥 <b>Sesiones SSH ({len(sesiones)}):</b>")
        lineas.extend(f"   • <code>{esc(s)}</code>" for s in sesiones[:15])
    else:
        lineas.append("🖥 Sin sesiones SSH abiertas.")
    lineas.append("")
    if conex:
        lineas.append(f"🔌 <b>Conexiones activas ({len(conex)} IP):</b>")
        for ip, svcs in list(conex.items())[:25]:
            lineas.append(f"   • <code>{esc(ip)}</code> → "
                          f"{', '.join(esc(x) for x in svcs)}")
    else:
        lineas.append("💤 Sin conexiones de clientes ahora mismo.")
    lineas.append("")
    lineas.append(f'🕒 {time.strftime("%d/%m %H:%M:%S")}')
    texto = "\n".join(lineas)
    await _editar(q.message, texto[:4000] if len(texto) > 4000 else texto,
                  _kb_refrescar("online"))


# ───────────────────────── arranque ─────────────────────────
async def _post_init(app: Application):
    global _BOT_LICENSE_VALID
    allowed, reason = await to_thread(license_policy.check_bot_license)
    if not allowed:
        _BOT_LICENSE_VALID = False
        raise RuntimeError(f"admin bot suspended by license gate: {reason}")
    if not config.OWNER_ID:
        raise RuntimeError("Telegram admin ID is not configured; refusing open access")
    if not config.NOTIF_TOKEN:
        raise RuntimeError("notification bot token is not configured")
    db.init_db()
    await notifications.initialize()
    _BOT_LICENSE_VALID = True
    db._APP = app
    # arrancar el vigilante de expiración DENTRO del loop ya en ejecución
    # (get_running_loop evita el PTBUserWarning de Application.create_task)
    try:
        from sweeper import loop as sweep_loop
        app.bot_data["sweeper"] = asyncio.get_running_loop().create_task(
            sweep_loop(app))
    except Exception:
        log.exception("no se pudo arrancar el sweeper")
    app.bot_data["license_watch"] = asyncio.get_running_loop().create_task(
        _license_watch(app))


async def _license_watch(app: Application):
    global _BOT_LICENSE_VALID
    while True:
        await asyncio.sleep(60)
        allowed, reason = await to_thread(license_policy.check_bot_license)
        _BOT_LICENSE_VALID = allowed
        if not allowed:
            log.error("licencia de bots revocada/no elegible: %s", reason)


async def _post_shutdown(app: Application):
    global _BOT_LICENSE_VALID
    _BOT_LICENSE_VALID = False
    for key in ("sweeper", "license_watch"):
        tarea = app.bot_data.get(key)
        if tarea and not tarea.done():
            tarea.cancel()
            try:
                await tarea
            except asyncio.CancelledError:
                pass
            except Exception:
                log.exception("error al detener la tarea %s", key)
    await notifications.shutdown()


def run():
    if not config.BOT_TOKEN:
        raise RuntimeError("admin bot token is not configured")
    if not config.NOTIF_TOKEN:
        raise RuntimeError("notification bot token is not configured")
    app = (
        Application.builder()
        .token(config.BOT_TOKEN)
        .post_init(_post_init)
        .post_shutdown(_post_shutdown)
        .build()
    )
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("login", cmd_login))
    app.add_handler(CommandHandler("logout", cmd_logout))
    app.add_handler(CommandHandler(["help", "menu", "ayuda"], cmd_ayuda))
    app.add_handler(CommandHandler("cancelar", cmd_notif_cancel))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, msg_texto))

    cbs = {
        "menu": cmd_menu_cb,
        "crear": cb_crear,
        "micta": cb_micta,
        "renovar_menu": cb_renovar_menu,
        "del_menu": cb_del_menu,
        "ayuda": cb_ayuda,
        "ayuda_proto": cb_ayuda_proto,
        "vpsinfo": cb_vpsinfo,
        "online": cb_online,
        "logout": cb_logout,
        "notif_home": cb_notif_home,
    }
    for dato, fn in cbs.items():
        app.add_handler(CallbackQueryHandler(fn, pattern=f"^{dato}$"))
    for pat, fn in [
        ("^notif_(?:targets|links|events|templates)$", cb_notif_page),
        ("^notif_edit:(?:brand|channel|group|support|web|whatsapp)$", cb_notif_edit),
        ("^notif_template:(?:created|renewed|expired|welcome|announcement|maintenance)$",
         cb_notif_template),
        ("^notif_template_edit:(?:created|renewed|expired|welcome|announcement|maintenance)$",
         cb_notif_template_edit),
        ("^notif_preview:(?:created|renewed|expired|welcome|announcement|maintenance)$",
         cb_notif_preview),
        ("^notif_toggle:(?:event_created|event_renewed|event_expired|broadcast_events|broadcast_enabled)$",
         cb_notif_toggle),
        ("^notif_send:(?:announcement|maintenance)$", cb_notif_send),
        ("^notif_send_confirm:(?:announcement|maintenance)$", cb_notif_send_confirm),
        ("^notif_cancel$", cb_notif_cancel),
        (FAM_PATTERN, cb_familia),
        (PROTO_PATTERN, cb_proto),
        (AUTO_PATTERN, cb_auto),
        (MAN_PATTERN, cb_man),
        ("^renovar:\\d+$", cb_renovar),
        ("^del:\\d+$", cb_del),
        ("^delyes:\\d+$", cb_delyes),
    ]:
        app.add_handler(CallbackQueryHandler(fn, pattern=pat))

    async def on_error(update, ctx):
        log.exception("error handler: %s", ctx.error)
    app.add_error_handler(on_error)

    log.info("Bot arrancando (@%s)", config.BOT_USERNAME)
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)


if __name__ == "__main__":
    run()
