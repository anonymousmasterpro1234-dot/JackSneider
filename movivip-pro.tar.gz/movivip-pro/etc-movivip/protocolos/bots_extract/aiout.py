# Compat: asyncio.to_thread() NO existe en Python 3.8 (la VPS .190 usa 3.8.10;
# se añadió en 3.9). Este helper hace lo mismo con run_in_executor, así el
# bot corre igual en 3.8, 3.9, 3.10...
# Uso:  res = await to_thread(funcion_bloqueante, arg1, arg2)
import asyncio
import functools


async def to_thread(func, *args, **kwargs):
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, functools.partial(func, *args, **kwargs))
