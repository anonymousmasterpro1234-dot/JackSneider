# MoviVIP Personal Bot — Info de la VPS (servicios, puertos, dominios, en línea)
# =============================================================================
# Este módulo corre DENTRO de la VPS (el bot vive en .190), así que consulta
# systemd + ss + /proc directamente. NUNCA lanza: cualquier fallo degrada a ""
# y la tarjeta muestra lo que se pudo leer.
#
# Mapa protocolo -> unidades systemd + puertos, VERIFICADO empíricamente en
# la VPS 82.39.109.190 el 2026-10-17 (ss -tlnp/ulnp con PID + systemctl):
#   sshd:22 · dropbear 90/143/109 · badvpn 7200/7300 · udp-custom 36712/udp
#   slowdns 5300/udp · stunnel4 444/445/844 · xhttp 8080 (haproxy) ·
#   bhttp 2003 interno (HAProxy /bhttp) · btun 7900 tcp+udp · payload 8082-8085/8090/8799
#   hcr 8883→443 · xray 10002-10015 (TLS vía haproxy 443/8443) ·
#   hysteria 36600/udp · shadowsocks(ss-server) 8388 tcp+udp · socks5 1080
#   zivpn UDP 5667 (ZIPVPN, sin unit systemd: proceso 'zivpn')
import os
import re
import subprocess

import config

_PAYLOAD_UNITS = ["payload-pdirect", "payload-pdirect2", "payload-pget",
                  "payload-popen", "payload-ppriv", "payload-ppub"]

# (nombre visible, unidades systemd, puertos TCP públicos, puertos UDP)
_SERVICIOS = [
    ("🔐 SSH / SSL",      ["ssh"],                                    ["22"], []),
    ("🚪 Dropbear",       ["dropbear_custom"],                        ["90", "143", "109"], []),
    ("⚡ BadVPN",         ["badvpn-udpgw-7200", "badvpn-udpgw-7300"], ["7200", "7300"], []),
    ("🌊 UDP Custom",     ["udp-custom"],                             [], ["36712"]),
    ("🐌 SlowDNS",        ["slowdns"],                                [], ["5300"]),
    ("🔒 Stunnel TLS",    ["stunnel4"],                               ["444", "445", "844"], []),
    ("🛸 SSH-XHTTP",      ["xhttp"],                                  ["8080"], []),
    ("📡 BHTTP v2",       ["bhttp"],                                  [], []),
    ("🧵 BTUN",           ["btun"],                                   ["7900"], ["7900"]),
    ("🐋 Payload",        _PAYLOAD_UNITS,
                                                                      ["8082", "8083", "8084", "8085", "8090", "8799"], []),
    ("🕸️ HCR Relay",      ["hcr"],                                    ["8883"], []),
    ("🛡️ V2Ray (xray)",   ["xray"],                                   ["443", "8443"], []),
    ("🌀 Hysteria",       ["hysteria1-server"],                       [], ["36600"]),
    ("🐋 Shadowsocks",    ["shadowsocks-libev-server@8388"],          ["8388"], ["8388"]),
    ("🕸️ SOCKS5",         ["sockd"],                                  ["1080"], []),
    ("📦 ZIPVPN",         ["zivpn"],                                  [], ["5667"]),
    ("🌉 HAProxy (TLS)",  ["haproxy"],                                ["443", "8443"], []),
]

# puertos VPN → etiqueta corta (para "usuarios en línea")
_PUERTO_SERVICIO = {
    22: "SSH", 90: "Dropbear", 143: "Dropbear", 109: "Dropbear",
    80: "HTTP", 443: "TLS", 8080: "HTTP/2", 8443: "TLS",
    444: "Stunnel", 445: "Stunnel", 844: "Stunnel",
    7200: "BadVPN", 7300: "BadVPN",
    1080: "SOCKS5", 8388: "Shadowsocks", 7900: "BTUN", 8883: "HCR",
}


def _run(cmd, timeout=8):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           encoding="utf-8", errors="replace")
        return p.stdout or ""
    except Exception:
        return ""


def _leer(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception:
        return ""


def _puertos(flag):
    """Puertos en escucha de `ss <flag> -H`. Devuelve set[int]."""
    out = set()
    for linea in _run(["ss", flag, "-H"]).splitlines():
        partes = linea.split()
        if len(partes) < 4:
            continue
        m = re.search(r":(\d+)$", partes[3])
        if m:
            out.add(int(m.group(1)))
    return out


def _units_activas():
    """Nombres de units activas, con y sin sufijo `.service` (para poder
    comparar contra nombres pelados tipo 'bhttp' o 'badvpn-udpgw-7200')."""
    out = _run(["systemctl", "list-units", "--type=service", "--state=active",
                "--no-legend", "--plain"])
    res = set()
    for ln in out.splitlines():
        ln = ln.strip()
        if not ln:
            continue
        nombre = ln.split()[0]
        res.add(nombre)
        if nombre.endswith(".service"):
            res.add(nombre[:-len(".service")])
    return res


# ───────────────────────── API pública de detección ─────────────────────────
# La usan protocolos.py (menú adaptativo) y admin_bot.py (Info VPS).
def units_activas():
    """Set de units activas (nombre con y sin .service), en minúsculas."""
    return {u.lower() for u in _units_activas()}


def puertos_tcp():
    """Set[int] de puertos TCP en escucha (ss -tlnH)."""
    return _puertos("-tlnH")


def puertos_udp():
    """Set[int] de puertos UDP en escucha (ss -ulnH)."""
    return _puertos("-ulnH")


def proceso_corriendo(nombre):
    """True si hay un proceso con ese nombre exacto (para servicios sin unit,
    p. ej. zivpn)."""
    return bool(_run(["pgrep", "-x", nombre]).strip())


def existe(path):
    """True si existe el fichero/carpeta (config de xray, hysteria...)."""
    try:
        return os.path.exists(path)
    except Exception:
        return False


def esta_activo(units, tcp_ports=None, udp_ports=None, proc=None,
                tcp_set=None, udp_set=None, units_set=None):
    """¿Está vivo un servicio? Por systemd O por puerto en escucha O por
    proceso. Acepta los sets ya calculados para no repetir ss/systemctl."""
    if units_set is None:
        units_set = units_activas()
    if tcp_ports and tcp_set is None:
        tcp_set = puertos_tcp()
    if udp_ports and udp_set is None:
        udp_set = puertos_udp()
    if units and (set(str(u).lower() for u in units) & units_set):
        return True
    if tcp_ports and tcp_set and any(int(p) in tcp_set for p in tcp_ports):
        return True
    if udp_ports and udp_set and any(int(p) in udp_set for p in udp_ports):
        return True
    if proc and proceso_corriendo(proc):
        return True
    return False


def _dominios():
    """Dominios declarados en config.conf (server/slowdns/cloudfront)."""
    d = []
    for ln in _leer("/etc/movivip/config.conf").splitlines():
        ln = ln.strip()
        if ln.startswith("#") or "=" not in ln:
            continue
        k, _, v = ln.partition("=")
        k, v = k.strip(), v.strip().strip('"')
        if not v or any(x in k.upper() for x in ("KEY", "PASS", "TOKEN", "SECRET")):
            continue
        if "domain" in k.lower() and v not in d:
            d.append(v)
    return d


def identidad():
    osrel = _leer("/etc/os-release")
    pretty = ""
    for ln in osrel.splitlines():
        if ln.startswith("PRETTY_NAME="):
            pretty = ln.split("=", 1)[1].strip().strip('"')
    # memoria
    mem = {}
    for ln in _leer("/proc/meminfo").splitlines():
        k, _, v = ln.partition(":")
        mem[k.strip()] = int(v.split()[0]) if v.split() else 0
    total = mem.get("MemTotal", 0)
    disp = mem.get("MemAvailable", mem.get("MemFree", 0))
    mem_pct = int(round(100 * (total - disp) / total)) if total else 0
    # disco /
    disco = ""
    df = _run(["df", "-h", "/"]).splitlines()
    if len(df) >= 2:
        cols = df[1].split()
        if len(cols) >= 5:
            disco = f"{cols[2]}/{cols[1]} ({cols[4]})"
    try:
        carga = " ".join(_leer("/proc/loadavg").split()[:3])
    except Exception:
        carga = ""
    return {
        "hostname": _run(["hostname"]).strip() or "?",
        "os": pretty or "?",
        "kernel": _run(["uname", "-r"]).strip() or "?",
        "uptime": _run(["uptime", "-p"]).strip().replace("up ", "") or "?",
        "carga": carga or "—",
        "ip": config.SERVIDOR.get("ip", "?"),
        "dominios": _dominios(),
        "mem_pct": mem_pct,
        "mem_disp": f"{disp // 1024}MB libres",
        "disco": disco or "—",
    }


def servicios():
    """Estado real de cada protocolo (por systemd Y por puerto en escucha)."""
    tcp = _puertos("-tlnH")
    udp = _puertos("-ulnH")
    activas = _units_activas()
    filas = []
    for nombre, units, tports, uports in _SERVICIOS:
        por_puerto = (all(int(p) in tcp for p in tports) and
                      all(int(p) in udp for p in uports)) and bool(tports or uports)
        por_unit = bool(set(units) & activas)
        filas.append({
            "nombre": nombre,
            "tcp": tports,
            "udp": uports,
            "activo": bool(por_puerto or por_unit),
        })
    return filas


def resumen():
    return {"ident": identidad(), "servicios": servicios()}


def usuarios_en_linea():
    """Sesiones reales (who) + conexiones establecidas a puertos VPN por IP."""
    sesiones = [ln.strip() for ln in _run(["who"]).splitlines() if ln.strip()]
    por_ip = {}
    for linea in _run(["ss", "-tnH"]).splitlines():
        partes = linea.split()
        if len(partes) < 5 or partes[0] != "ESTAB":
            continue
        m = re.search(r":(\d+)$", partes[3])
        if not m:
            continue
        svc = _PUERTO_SERVICIO.get(int(m.group(1)))
        if not svc:
            continue
        ip = partes[4].rsplit(":", 1)[0].strip("[]")
        if (ip.startswith("127.") or ip in ("::1",)
                or ip.startswith("149.154.") or ip.startswith("91.108.")):
            continue  # loopback + servidores de Telegram
        por_ip.setdefault(ip, set()).add(svc)
    return {
        "sesiones": sesiones,
        "conexiones": {ip: sorted(v) for ip, v in sorted(por_ip.items())},
    }
