# MoviVIP Bot SSH v2 — catálogo de protocolos (familias + tarjetas)
# ====================================================================
# 17 protocolos en 4 familias. REGLAS DEL DISEÑO (aprobadas por el jefe):
#   * CADA protocolo tiene SU tarjeta de entrega con datos específicos.
#   * Todos los de familia "ssh" comparten la MISMA cuenta SSH (user/pass)
#     → el límite de 2 cuentas vivas sigue intacto (igual que el bot oficial
#     MoviVIP: cuenta + plantilla variada, verificado en bots_extract).
#   * Los datos de tarjeta se leen de config.conf del VPS EN RUNTIME
#     (get_config con cache TTL) → si el jefe cambia un puerto, la tarjeta
#     se actualiza sola. Fallbacks constantes documentados para lo que
#     config.conf NO expone (badvpn, udp custom, slowdns-udp, hcr, socks5).
#   * protocolos.py NO importa sshprod (evita import circular: sshprod
#     importa protocolos para las ramas de crear/eliminar/renovar).
import subprocess
import threading
import time

import config
import vpsinfo

# ────────────────────────── familias (submenú) ──────────────────────────
FAMILIAS = {
    "ssh": {
        "emoji": "🔐",
        "titulo": "SSH & Directos",
        "protos": ("ssh", "dropbear", "badvpn", "udpcustom", "slowdns"),
        "desc": "Cuenta SSH con sus puertos/directos",
    },
    "http": {
        "emoji": "🌐",
        "titulo": "Túneles HTTP/S",
        "protos": ("xhttp", "bhttp", "btun", "payload", "hcr"),
        "desc": "SSH sobre HTTP/2, TCP/UDP y relays",
    },
    "v2ray": {
        "emoji": "🛡",
        "titulo": "V2Ray (link de importación)",
        "protos": ("vmess", "vless", "trojan"),
        "desc": "V2rayNG · NekoBox · Nekoray",
    },
    "indep": {
        "emoji": "⚡",
        "titulo": "Independientes",
        "protos": ("hysteria", "shadowsocks", "socks5", "zipvpn"),
        "desc": "Servicios con credencial propia",
    },
}

# ────────────────────────── catálogo 17 protocolos ──────────────────────────
# grupo: "ssh"    → crea/borra/renueva cuenta SSH (add_ssh/delete_ssh)
#        "v2ray"  → motor xray_add (mismo uuid, link según protocolo)
#        "zipvpn" → motor zipvpn_add (password simple)
PROTOCOS = {
    "ssh":         {"nombre": "SSH/SSL",       "emoji": "🔐", "familia": "ssh",   "grupo": "ssh",    "app": "HTTP Injector · HTTP Custom"},
    "dropbear":    {"nombre": "Dropbear",      "emoji": "🚪", "familia": "ssh",   "grupo": "ssh",    "app": "KiteVPN · HTTP Custom"},
    "badvpn":      {"nombre": "BadVPN",        "emoji": "⚡", "familia": "ssh",   "grupo": "ssh",    "app": "Apps UDP (udpgw)"},
    "udpcustom":   {"nombre": "UDP Custom",    "emoji": "🌊", "familia": "ssh",   "grupo": "ssh",    "app": "KiteVPN UDP · UDP Custom"},
    "slowdns":     {"nombre": "SlowDNS",       "emoji": "🐌", "familia": "ssh",   "grupo": "ssh",    "app": "HTTP Injector (DNS tunnel)"},
    "xhttp":       {"nombre": "SSH-XHTTP",     "emoji": "🛸", "familia": "http",  "grupo": "ssh",    "app": "HTTP Injector · SSH over TLS"},
    "bhttp":       {"nombre": "BHTTP v2",      "emoji": "📡", "familia": "http",  "grupo": "ssh",    "app": "SSH-HTTP/2 bootstrap"},
    "btun":        {"nombre": "BTUN",          "emoji": "🧵", "familia": "http",  "grupo": "ssh",    "app": "VPN over TCP/UDP"},
    "payload":     {"nombre": "Payload",       "emoji": "🐋", "familia": "http",  "grupo": "ssh",    "app": "HTTP Custom (payload SSH)"},
    "hcr":         {"nombre": "HCR Relay",     "emoji": "🕸️", "familia": "http",  "grupo": "ssh",    "app": "SSH sobre relay TLS"},
    "vmess":       {"nombre": "VMess",         "emoji": "⚡", "familia": "v2ray", "grupo": "v2ray",  "app": "V2rayNG · NekoBox"},
    "vless":       {"nombre": "VLESS",         "emoji": "🔒", "familia": "v2ray", "grupo": "v2ray",  "app": "V2rayNG · NekoBox"},
    "trojan":      {"nombre": "Trojan",        "emoji": "🛡", "familia": "v2ray", "grupo": "v2ray",  "app": "V2rayNG · NekoBox"},
    "hysteria":    {"nombre": "Hysteria",      "emoji": "🌀", "familia": "indep", "grupo": "ssh",    "app": "Hysteria · Clash"},
    "shadowsocks": {"nombre": "Shadowsocks",   "emoji": "🐋", "familia": "indep", "grupo": "ssh",    "app": "Shadowsocks · V2rayNG"},
    "socks5":      {"nombre": "SOCKS5",        "emoji": "🕸️", "familia": "indep", "grupo": "ssh",    "app": "Proxy SOCKS5 nativo"},
    "zipvpn":      {"nombre": "ZIPVPN",        "emoji": "📦", "familia": "indep", "grupo": "zipvpn", "app": "Apps con password simple"},
}
# alias legacy (cuentas antiguas registradas como "v2ray")
ALIAS = {"v2ray": "vmess"}

# constantes de respaldo (lo que config.conf NO expone — verificado en la
# VPS 2026-10-17: systemd + ss -tlnp + haproxy.cfg)
DEFAULTS = {
    "BADVPN_PORTS": "7200, 7300",       # badvpn-udpgw-7200/7300.service
    "UDPCUSTOM_PORT": "36712",          # /usr/bin/config.json listen :36712
    "SLOWDNS_UDP_PORT": "5300",         # slowdns-server :5300 (udp)
    "SOCKS5_PORT": "1080",              # dante (sockd) :1080
    "HCR_SNI": "hcr",                   # haproxy: acl ssl_sni -i hcr → 443
    "SSLTLS_PORTS": config.SERVIDOR.get("ssl_ports", "22, 80, 443, 8080, 8443"),
    "BHTTP_PLAIN_PORT": config.SERVIDOR.get("bhttp_public_port", "8880"),
}

_TTL_SEG = 300
_cache = {"ts": 0.0, "cfg": None}
_cache_lock = threading.Lock()


def _parse_kv(texto):
    """Claves KEY=VALUE / KEY="valor" (comillas shell, comentarios #)."""
    out = {}
    for linea in texto.splitlines():
        linea = linea.strip()
        if not linea or linea.startswith("#"):
            continue
        k, sep, v = linea.partition("=")
        if not sep:
            continue
        k = k.strip()
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        if k:
            out[k] = v
    return out


def cargar_config(force=False):
    """Config real del VPS con cache TTL 300s. Nunca lanza: si falla devuelve
    la cache vieja o {} (las tarjetas usan DEFAULTS).

    Fusiona DOS fuentes (verificado 2026-10-17 en la VPS):
      1. /etc/movivip/config.conf — 44 claves (HYSTERIA/SS/XHTTP/BHTTP/BTUN/...)
      2. account.sh get_config    — solo 16 claves (DROPBEAR/SLOWDNS/ZIPVPN...)
    get_config manda sobre config.conf para las claves que sí emite."""
    with _cache_lock:
        if (not force and _cache["cfg"] is not None
                and time.time() - _cache["ts"] < _TTL_SEG):
            return _cache["cfg"]
    cfg = {}
    # 1) config.conf (fuente completa, persistida)
    try:
        with open(config.MOVIVIP_CONFIG_CONF, encoding="utf-8",
                  errors="replace") as f:
            cfg.update(_parse_kv(f.read()))
    except Exception:
        pass  # Windows/tests/sin permisos → sigue con get_config
    # 2) get_config (vista runtime del script, pisa lo anterior si difiere)
    try:
        p = subprocess.run(
            ["bash", config.ACCOUNT_SH, "get_config"],
            # 10s: la carga es caliente (tras crear cuenta) — un timeout de 90s
            # dejaría al usuario esperando si la red se cae (defecto crítico
            # de usabilidad detectado en auto-crítica 2026-10-17)
            capture_output=True, text=True, timeout=min(config.VPS_TIMEOUT_SEG, 10),
            encoding="utf-8", errors="replace",
        )
        cfg.update(_parse_kv(p.stdout or ""))
    except Exception:
        pass  # offline/tests → cfg parcial; los defaults cubren
    if cfg:
        with _cache_lock:
            _cache["cfg"] = cfg
            _cache["ts"] = time.time()
        return cfg
    with _cache_lock:
        return _cache["cfg"] or {}


def _hysteria_conf():
    """Lee la config REAL de hysteria (auth/obfs/puerto). {} si no existe."""
    try:
        import json
        path = getattr(config, "HYSTERIA_CONFIG", "/etc/hysteria/config.json")
        with open(path, encoding="utf-8", errors="replace") as f:
            d = json.load(f)
        listen = str(d.get("listen", ":36600"))
        puerto = listen.rsplit(":", 1)[-1] or "36600"
        auth = d.get("auth", {}) or {}
        pwd = ""
        if isinstance(auth, dict):
            cfg_auth = auth.get("config", {}) or {}
            pwd = cfg_auth.get("password", "") or auth.get("password", "")
        return {
            "listen_port": puerto,
            "password": pwd or "—",
            "obfs": (d.get("obfs", "—") or "—"),
            "alpn": (d.get("alpn", "h3") or "h3"),
        }
    except Exception:
        return {}


def _g(cfg, key, defecto="—"):
    v = cfg.get(key, "")
    return v if v else defecto


def nombre(proto):
    """Nombre visible tolerante: nunca pinta 'None'."""
    base = ALIAS.get(proto, proto)
    info = PROTOCOS.get(base)
    return info["nombre"] if info else (proto or "?")


def mapa_nombres():
    """{clave_cruda: nombre_bonito} para la miniapp (una sola fuente de
    verdad con PROTOCOS; incluye el alias legacy 'v2ray')."""
    m = {p: info["nombre"] for p, info in PROTOCOS.items()}
    m.update({alias: info["nombre"] for alias, base in ALIAS.items()
              if (info := PROTOCOS.get(base))})
    return m


def emoji(proto):
    info = PROTOCOS.get(ALIAS.get(proto, proto))
    return info["emoji"] if info else "📡"


def familia_de(proto):
    info = PROTOCOS.get(ALIAS.get(proto, proto))
    return info["familia"] if info else None


def grupo_de(proto):
    """'ssh' | 'v2ray' | 'zipvpn' — decide el motor de cuenta. Desconocido → None."""
    info = PROTOCOS.get(ALIAS.get(proto, proto))
    return info["grupo"] if info else None


def todos():
    """Las 17 claves oficiales (sin alias)."""
    return tuple(PROTOCOS.keys())


# ────────────────────────── líneas de tarjeta por protocolo ──────────────────────────
def datos_tarjeta(proto, cfg=None):
    """
    Filas HTML de datos ESPECÍFICOS del protocolo (sin user/pass/vence:
    eso ya lo añade bot.tarjeta_entrega). cfg = get_config() cacheado.
    """
    base = ALIAS.get(proto, proto)
    if cfg is None:
        cfg = cargar_config()
    ip = config.SERVIDOR["ip"]
    host = config.SERVIDOR["host"]
    L = []
    if base == "ssh":
        L.append(f"📡 IP: <code>{ip}</code>")
        L.append(f"🔐 SSH/SSL (directo): {DEFAULTS['SSLTLS_PORTS']}")
        L.append(f"🚪 Dropbear: {_g(cfg, 'DROPBEAR_PORT', config.SERVIDOR['ssh_ports'])}")
        L.append(f"🌐 Dominio: <code>{host}</code>")
    elif base == "dropbear":
        L.append(f"📡 IP: <code>{ip}</code>")
        L.append(f"🔌 Puertos Dropbear: {_g(cfg, 'DROPBEAR_PORT', config.SERVIDOR['ssh_ports'])}")
        L.append(f"🌐 Dominio: <code>{host}</code>")
    elif base == "badvpn":
        L.append(f"📡 IP: <code>{ip}</code>")
        L.append(f"🔌 Puertos UDP (udpgw): {DEFAULTS['BADVPN_PORTS']}")
        L.append("📶 Usa junto a tu usuario/contraseña SSH")
    elif base == "udpcustom":
        L.append(f"📡 IP: <code>{ip}</code>")
        L.append(f"🔌 Puerto UDP Custom: {DEFAULTS['UDPCUSTOM_PORT']}")
        L.append("📶 Conecta con tu usuario/contraseña SSH")
    elif base == "slowdns":
        L.append(f"🧭 Nameserver: <code>{_g(cfg, 'SLOWDNS_NS', config.SERVIDOR['slowdns'])}</code>")
        L.append(f"🔑 SlowDNS Key: <code>{_g(cfg, 'SLOWDNS_KEY', '—')}</code>")
        L.append(f"🔌 Puerto UDP: {_g(cfg, 'SLOWDNS_UDP_PORT', DEFAULTS['SLOWDNS_UDP_PORT'])}")
    elif base == "xhttp":
        L.append(f"🌐 Puerto TLS: {_g(cfg, 'XHTTP_PORT', '443')}")
        L.append(f"⚡ Puerto HTTP/2: {_g(cfg, 'XHTTP_PORT2', '8080')}")
        L.append(f"🖥 Servidor: <code>{host}</code>")
    elif base == "bhttp":
        if _g(cfg, "SSL") == "ON":
            L.append("📡 BHTTP v2: 80/443/8080/8443 · BTUN automático / HTTP /bhttp")
            L.append("🔒 TLS: certificado del dominio servido por HAProxy")
        else:
            L.append(f"📡 BHTTP v2 (directo): {DEFAULTS['BHTTP_PLAIN_PORT']}")
        L.append(f"🖥 Servidor: <code>{host}</code>")
    elif base == "btun":
        L.append(f"📡 Puerto BTUN: {_g(cfg, 'BTUN_PORT', '7900')}")
        L.append(f"🖥 Servidor: <code>{host}</code>")
        L.append("📶 VPN over TCP/UDP con tu usuario/contraseña SSH")
    elif base == "payload":
        L.append(f"🔌 Puertos Payload: {_g(cfg, 'PAYLOAD_PORT', '8082')}, "
                 f"{_g(cfg, 'PAYLOAD_PORT2', '8083')}, "
                 f"{_g(cfg, 'PAYLOAD_PORT3', '8084')}, "
                 f"{_g(cfg, 'PAYLOAD_PORT4', '8090')}")
        L.append(f"🖥 Servidor: <code>{host}</code>")
        L.append("📶 Payload SSH-2.0 con tu usuario/contraseña SSH")
    elif base == "hcr":
        L.append(f"🔒 SNI/Host: <code>{DEFAULTS['HCR_SNI']}</code>")
        L.append("🔌 Puerto: 443 (relay TLS del servidor)")
        L.append("📶 SSH sobre relay con tu usuario/contraseña SSH")
    elif base == "hysteria":
        h = _hysteria_conf()
        L.append(f"📡 UDP: {h.get('listen_port', '36600')} · Servidor: <code>{host}</code>")
        L.append(f"🔑 Auth: <code>{h.get('password', '—')}</code>")
        L.append(f"🛡 Obfs: <code>{h.get('obfs', '—')}</code>")
        L.append(f"🧬 ALPN: <code>{h.get('alpn', 'h3')}</code>")
        L.append("📱 App: Hysteria / Clash (protocolo hysteria)")
    elif base == "shadowsocks":
        # link SIP002 estándar: ss://base64(método:pass@host:port)#tag
        import base64
        from urllib.parse import quote
        metodo = _g(cfg, "SS_METHOD", "aes-256-gcm")
        pass_ = _g(cfg, "SS_PASSWORD", "—")
        puerto = _g(cfg, "SS_PORT", "8388")
        cred = base64.b64encode(f"{metodo}:{pass_}@{host}:{puerto}".encode()).decode()
        L.append(f"🔗 Link:\n<code>ss://{cred}#MOVIVIP-ss</code>")
        L.append(f"⚙️ {metodo} · puerto {puerto} (método y pass del servidor)")
    elif base == "socks5":
        L.append(f"🔌 Proxy: <code>{host}:{DEFAULTS['SOCKS5_PORT']}</code>")
        L.append("📶 Conecta con tu usuario/contraseña SSH")
    elif base == "zipvpn":
        L.append(f"🔌 Puerto: {_g(cfg, 'ZIPVPN_PORT', config.SERVIDOR['zipvpn_port'])}")
        L.append("🔑 Usa la contraseña de la tarjeta (password simple)")
    # vmess/vless/trojan: el link lo genera bot._link_v2ray (no aquí)
    return L


# ══════════════════════ AUTODETECCIÓN (adaptativo por VPS) ══════════════════════
# El MISMO paquete de bot se instala en VPS de clientes DISTINTOS, cada uno con
# un subconjunto de protocolos distinto. En vez de mostrar las 4 familias fijas,
# el menú se construye con lo que REALMENTE está instalado en ESTA VPS.
#
# Señales (verificadas 2026-10-17 en .190): unit systemd activa, puerto en
# escucha (ss) o proceso vivo. Tolerante a fallos: si no se detecta NADA
# (systemd/ss no disponibles), se muestran TODOS (fail-open) para no dejar el
# bot vacío.
#
# (unidades systemd, puertos TCP, puertos UDP, proceso)  ← cualquiera decide
_DETECCION = {
    "ssh":         (["ssh", "sshd"],                    [22],                    [], None),
    "dropbear":    (["dropbear_custom", "dropbear"],    [90, 143, 109],           [], None),
    "badvpn":      (["badvpn-udpgw-7200", "badvpn-udpgw-7300"], [7200, 7300],    [], None),
    "udpcustom":   (["udp-custom"],                     [],                       [36712], None),
    "slowdns":     (["slowdns"],                        [],                       [5300], None),
    "xhttp":       (["xhttp"],                          [8080],                   [], None),
    "bhttp":       (["bhttp"],                          [config.SERVIDOR.get("bhttp_plain_port", "2003")], [], None),
    "btun":        (["btun"],                           [7900],                   [7900], None),
    "payload":     (["payload-pdirect", "payload-pdirect2", "payload-pget",
                     "payload-popen", "payload-ppriv", "payload-ppub"],
                                                        [8082, 8083, 8084, 8090], [], None),
    "hcr":         (["hcr"],                            [8883],                   [], None),
    "vmess":       (["xray"],                           [],                       [], None),
    "vless":       (["xray"],                           [],                       [], None),
    "trojan":      (["xray"],                           [],                       [], None),
    "hysteria":    (["hysteria1-server"],               [],                       [36600], None),
    "shadowsocks": (["shadowsocks-libev-server"],       [8388],                   [], None),
    "socks5":      (["sockd"],                          [1080],                   [], None),
    "zipvpn":      ([],                                 [],                       [5667], "zivpn"),
}

_det = {"ts": 0.0, "val": None}
_det_lock = threading.Lock()


def _v2ray_instalado(units_set, tcp_set):
    """xray sirve vmess+vless+trojan a la vez → se detecta por unit, por el
    rango de puertos 10002-10015 o por la existencia de su config."""
    if "xray" in units_set:
        return True
    if any(10002 <= p <= 10015 for p in tcp_set):
        return True
    try:
        return vpsinfo.existe(getattr(config, "XRAY_CONFIG", ""))
    except Exception:
        return False


def instalados(force=False):
    """Set de claves de protocolo detectadas como instaladas en ESTA VPS.
    Con AUTODETECTAR=False devuelve las 17 (modo fijo)."""
    if not getattr(config, "AUTODETECTAR", True):
        return set(PROTOCOS)
    with _det_lock:
        if (not force and _det["val"] is not None
                and time.time() - _det["ts"] < _TTL_SEG * 2):
            return _det["val"]
    try:
        us = vpsinfo.units_activas()
        ts = vpsinfo.puertos_tcp()
        ud = vpsinfo.puertos_udp()
    except Exception:
        return set(PROTOCOS)  # fail-open
    res = set()
    for p, (units, tps, ups, proc) in _DETECCION.items():
        if p in ("vmess", "vless", "trojan"):
            if _v2ray_instalado(us, ts):
                res.add(p)
            continue
        if vpsinfo.esta_activo(units, tps, ups, proc, ts, ud, us):
            res.add(p)
    if not res:
        res = set(PROTOCOS)  # fail-open: no se pudo detectar nada
    with _det_lock:
        _det["val"] = res
        _det["ts"] = time.time()
    return res


def disponibles():
    """Las claves oficiales que SÍ están instaladas (orden de PROTOCOS)."""
    inv = instalados()
    return tuple(p for p in PROTOCOS if p in inv)


def familias_disponibles():
    """Como FAMILIAS pero solo con protocolos instalados y sin familias vacías."""
    inv = instalados()
    out = {}
    for clave, f in FAMILIAS.items():
        protos = tuple(p for p in f["protos"] if p in inv)
        if protos:
            g = dict(f)
            g["protos"] = protos
            out[clave] = g
    return out
