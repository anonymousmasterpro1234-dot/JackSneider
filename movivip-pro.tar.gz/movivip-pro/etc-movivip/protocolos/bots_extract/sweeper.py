# MoviVIP Personal Bot — vigilante de expiración
# ================================================
# Cada SWEEP_INTERVAL_SEG: marca vencidas, avisa al dueño (sin anuncios) y
# purga en la VPS las cuentas ya avisadas. Corre dentro del event loop de PTB.
import asyncio
import logging
import time

import config
import db
import notifications
import sshprod
from aiout import to_thread

log = logging.getLogger("movivip.sweeper")


def _texto_alerta(c):
    try:
        venc = time.strftime("%d/%m/%Y", time.localtime(c["expira_ts"]))
    except Exception:
        venc = "?"
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    ident = c["usuario"] or (c["password"][:6] + "…")
    return (
        f"⏳ <b>Tu cuenta #{c['id']} venció</b> ({venc})\n"
        f"📡 {c['protocolo']} · <code>{ident}</code>\n\n"
        "Ábrela desde el menú para renovarla cuando quieras."
    )


async def _sweep(app):
    now = int(time.time())
    db.marcar_expiradas(now)
    # 1) avisar a las recién vencidas
    for c in db.cuentas_para_alertar():
        try:
            await app.bot.send_message(c["tg_id"], _texto_alerta(c),
                                       parse_mode="HTML")
        except Exception as e:
            log.info("alerta uid=%s: %s", c["tg_id"], e)
        try:
            await notifications.notify_event("expired", {
                "protocolo": c["protocolo"],
                "usuario": c["usuario"],
                "fecha": time.strftime("%d/%m/%Y", time.localtime(c["expira_ts"])),
            })
        except ValueError:
            log.exception("plantilla de notificación de vencimiento inválida")
        db.marcar_alerta(c["id"])
    # 2) purgar en la VPS (silencioso)
    for c in db.cuentas_para_purgar():
        try:
            ok = await to_thread(sshprod.purgar, c["protocolo"],
                                 c["usuario"], c["password"])
        except Exception as e:
            log.info("purga #%s: %s", c["id"], e)
            ok = False
        if ok:
            db.marcar_purga(c["id"])
        else:
            log.info("purga pendiente #%s", c["id"])


async def loop(app):
    """Bucle perpetuo. Primer barrido a los 5s, luego cada SWEEP_INTERVAL_SEG."""
    await asyncio.sleep(5)
    while True:
        try:
            await _sweep(app)
        except asyncio.CancelledError:
            return
        except Exception:
            log.exception("sweep error")
        try:
            await asyncio.sleep(config.SWEEP_INTERVAL_SEG)
        except asyncio.CancelledError:
            return
