# MoviVIP Bot SSH v2 — ejecución de cuentas en la VPS (account.sh empaquetado)
# ===========================================================================
# Lock GLOBAL (threading.Lock): account.sh toca /etc/passwd + configs de Xray;
# ejecuciones concurrentes pueden corromperse → TODA mutación va serializada.
# Además el bot llama esto con aiout.to_thread (bug #6: nunca bloquear el loop).
import json
import logging
import os
import re
import shutil
import subprocess
import threading
import time

import config
import protocolos  # importa solo config (sin circular): define familias/grupos

log = logging.getLogger("movivip.sshprod")

_VPS_LOCK = threading.Lock()

# vmess/vless/trojan comparten el MISMO motor de cuentas (xray_add/xray_remove):
# una cuenta xray crea el usuario en los 6 inbounds; el protocolo elegido solo
# decide qué link se entrega. "v2ray" queda como alias de cuentas antiguas.
V2RAY_PROTOS = ("vmess", "vless", "trojan", "v2ray")
# Los 12 protocolos "ssh" (ssh, dropbear, badvpn, udpcustom, slowdns, xhttp,
# bhttp, btun, payload, hcr, hysteria, shadowsocks, socks5) comparten la MISMA
# cuenta SSH → se crean/borran/renuevan con add_ssh/delete_ssh (diseño aprobado
# 2026-10-17: cada protocolo con su tarjeta, límite de 2 intacto).
SSH_PROTOS = tuple(p for p in protocolos.todos()
                   if protocolos.grupo_de(p) == "ssh")

# firmas verificadas empíricamente el 2026-10-16 contra la VPS 82.39.109.42:
#   add_ssh <user> <pass> <days> <max_devices> <consumo> -> OK:xray_added:user:uuid
#                                                          OK:user:pass:AAAA-MM-DD:1:0
#   xray_add <user> <days>                                -> OK:xray_added:... | EXISTS:user
#   zipvpn_add <pass> <days> <gb>                         -> OK:zipvpn_added:pass
#   delete_ssh <user>                                     -> OK:deleted:user
#   xray_remove <user>                                    -> OK:xray_removed:...
#   zipvpn_remove <pass>                                  -> OK:zipvpn_removed:...


def _run(args, timeout=None):
    """Ejecuta account.sh serializado. Devuelve (rc, stdout). Lanza en errores raros."""
    with _VPS_LOCK:
        p = subprocess.run(
            ["bash", config.ACCOUNT_SH] + list(args),
            capture_output=True, text=True, timeout=timeout or config.VPS_TIMEOUT_SEG,
            encoding="utf-8", errors="replace",
        )
    return p.returncode, (p.stdout or "") + ("" if not p.stderr else "")


def _parse_fecha(s):
    """'2026-10-19' -> timestamp UTC medianoche (aprox local) ; devuelve None si falla."""
    try:
        from datetime import datetime, timedelta
        dt = datetime.strptime(s.strip(), "%Y-%m-%d")
        # account.sh calcula hoy+días; damos 1 día extra de gracia al mediodía
        return int((dt + timedelta(days=1, hours=-12)).timestamp())
    except Exception:
        return None


def _expira_en_dias(dias):
    return int(time.time()) + dias * 86400


class Resultado:
    def __init__(self, ok, expira_ts=0, uuid="", aviso="", error=""):
        self.ok = ok
        self.expira_ts = expira_ts
        self.uuid = uuid
        self.aviso = aviso
        self.error = error


def _fix_trojan_passwords():
    """
    account.sh (packed) escribe {"id": uuid} en los clients de trojan-in,
    pero el inbound Trojan de Xray autentica con "password":
    sin este fix los links trojan fallan en el TLS handshake (E2E rc=35,
    verificado 2026-10-17 contra la VPS real). Idempotente y tolerante:
    el alta de la cuenta NUNCA falla por esto (solo trojan quedaría igual).
    Valida con `xray run -test` ANTES de reemplazar la config viva: una
    config mala nunca deja xray caído para todos los usuarios.
    Devuelve True si modificó la config.
    """
    cfg = config.XRAY_CONFIG
    if not cfg or not os.path.exists(cfg):
        return False  # tests Windows / Xray instalado en otra ruta
    # IMPORTANTE: xray detecta el formato POR EXTENSIÓN — el tmp debe ser .json
    # ("Failed to get format of ...config.json.tmp" lo rechazaba, rc=23)
    tmp = cfg + ".tmp.json"
    try:
        with open(cfg, encoding="utf-8") as f:
            datos = json.load(f)  # jq ya validó que es JSON estricto
        cambiado = False
        for ib in datos.get("inbounds", []):
            # trojan-in (ws) Y trojan-grpc-in: ambos autentican con password
            if not str(ib.get("tag", "")).startswith("trojan"):
                continue
            for c in ib.get("settings", {}).get("clients", []):
                if "password" not in c and "id" in c:
                    c["password"] = c["id"]
                    cambiado = True
        if not cambiado:
            return False
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(datos, f, ensure_ascii=False, indent=2)
        # ¿hay un xray real que validar? (tests Windows no: se omite el test)
        if shutil.which("xray"):
            prueba = subprocess.run(["xray", "run", "-test", "-c", tmp],
                                    capture_output=True, timeout=30)
            if prueba.returncode != 0:
                log.warning("xray rechazó la config parcheada, NO se aplica: %s",
                            (prueba.stderr or b"")[:300])
                os.remove(tmp)
                return False
        os.replace(tmp, cfg)  # escritura atómica
        try:
            subprocess.run(["systemctl", "restart", "xray"],
                           capture_output=True, timeout=30)
        except Exception as e:
            # sin systemctl (tests) — el cambio ya quedó en disco
            log.warning("restart xray omitido: %s", e)
        return True
    except Exception as e:
        # config con comentarios/JSON inválido: no tocar, degradar en silencio
        log.warning("fix trojan password omitido: %s", e)
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False


def crear_ssh(usuario, password, dias=None):
    """Cuenta SSH completa (add_ssh crea SSH + Xray vmess/vless/trojan de una)."""
    dias = dias or config.DIAS_CUENTA
    try:
        rc, out = _run(["add_ssh", usuario, password, str(dias),
                        str(config.MAX_CONEXIONES), str(config.LIMITE_GB)])
    except Exception as e:
        return Resultado(False, error=f"excepción: {e}")
    if "OK:" not in out:
        return Resultado(False, error=out.strip()[:200] or f"rc={rc}")
    _fix_trojan_passwords()
    uuid = ""
    expira_ts = 0
    aviso = ""
    for linea in out.splitlines():
        p = linea.strip().split(":")
        if linea.startswith("OK:xray_added:") and len(p) >= 4:
            uuid = p[3]
        elif len(p) >= 5 and p[1] == usuario and p[2] == password:
            expira_ts = _parse_fecha(p[3]) or _expira_en_dias(dias)
    if "EXISTS" in out or "duplicado" in out.lower():
        aviso = "existente"
    if not expira_ts:
        expira_ts = _expira_en_dias(dias)
    return Resultado(True, expira_ts, uuid, aviso)


def crear_v2ray(usuario, dias=None):
    """Cuenta Xray (vmess/vless/trojan) — una sola creación, link según protocolo."""
    dias = dias or config.DIAS_CUENTA
    try:
        rc, out = _run(["xray_add", usuario, str(dias)])
    except Exception as e:
        return Resultado(False, error=f"excepción: {e}")
    # también en EXISTS: una cuenta creada antes del fix quedó sin password
    if "EXISTS" in out:
        _fix_trojan_passwords()
        return Resultado(True, _expira_en_dias(dias), aviso="existente")
    if "OK:xray_added" in out:
        _fix_trojan_passwords()
        p = out.strip().splitlines()[-1].split(":")
        uuid = p[3] if len(p) >= 4 else ""
        return Resultado(True, _expira_en_dias(dias), uuid)
    return Resultado(False, error=out.strip()[:200] or f"rc={rc}")


def crear_zipvpn(password, dias=None):
    dias = dias or config.DIAS_CUENTA
    try:
        rc, out = _run(["zipvpn_add", password, str(dias), str(config.LIMITE_GB)])
    except Exception as e:
        return Resultado(False, error=f"excepción: {e}")
    if "OK:zipvpn_added" in out:
        return Resultado(True, _expira_en_dias(dias))
    if "EXISTS" in out or "ya existe" in out.lower():
        return Resultado(True, _expira_en_dias(dias), aviso="existente")
    return Resultado(False, error=out.strip()[:200] or f"rc={rc}")


def eliminar(protocolo, usuario="", password=""):
    """Borra la cuenta en VPS. Idempotente: si ya no existe, OK igualmente.
    La rama la decide el GRUPO del protocolo (familias de protocolos.py)."""
    try:
        grupo = protocolos.grupo_de(protocolo)
        if grupo == "ssh":  # ssh + los 12 transportes (cuenta compartida)
            rc, out = _run(["delete_ssh", usuario])
            return "OK:deleted" in out or "not found" in out.lower() or "no existe" in out.lower()
        if grupo == "v2ray":  # vmess/vless/trojan/v2ray -> misma cuenta xray
            rc, out = _run(["xray_remove", usuario])
            return "OK:xray_removed" in out or "not found" in out.lower()
        if grupo == "zipvpn":
            rc, out = _run(["zipvpn_remove", password])
            return "OK:zipvpn_removed" in out or "not found" in out.lower()
    except Exception:
        return False
    return False


def renovar(protocolo, usuario="", password="", dias=None):
    """
    Renovación de la MISMA cuenta (mismo user/pass).
    En la práctica la VPS ya purgó la cuenta vencida (cron cada min) → recrear.
    Si aún existe → borrar+crear para que la fecha quede exacta.
    """
    dias = dias or config.DIAS_CUENTA
    grupo = protocolos.grupo_de(protocolo)
    if grupo == "ssh":
        eliminar(protocolo, usuario, password)
        return crear_ssh(usuario, password, dias)
    if grupo == "v2ray":
        eliminar(protocolo, usuario, password)
        return crear_v2ray(usuario, dias)
    if grupo == "zipvpn":
        eliminar("zipvpn", usuario, password)
        return crear_zipvpn(password, dias)
    return Resultado(False, error="protocolo desconocido")


def purgar(protocolo, usuario="", password=""):
    """Borra basura expirada de la VPS (silencioso, tolerante a fallos)."""
    try:
        return eliminar(protocolo, usuario, password)
    except Exception:
        return False
