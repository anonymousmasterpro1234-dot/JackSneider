# MoviVIP Personal Bot — capa de datos (SQLite WAL)
# ==================================================
# Versión PERSONAL: sin anuncios/ciclos/referidos. Solo usuarios + cuentas.
# Mantiene WAL + busy_timeout + BEGIN IMMEDIATE para escrituras atómicas.
import os
import sqlite3
import time

import config

_SCHEMA = """
CREATE TABLE IF NOT EXISTS usuarios (
    tg_id INTEGER PRIMARY KEY,
    username TEXT,
    first TEXT,
    auth_ts INTEGER DEFAULT 0,             -- último login OK (epoch)
    creado_en INTEGER
);
CREATE TABLE IF NOT EXISTS cuentas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tg_id INTEGER NOT NULL,
    protocolo TEXT NOT NULL,
    usuario TEXT DEFAULT '',
    password TEXT DEFAULT '',
    uuid TEXT DEFAULT '',
    expira_ts INTEGER NOT NULL,
    estado TEXT DEFAULT 'viva',            -- viva | expirada | borrada
    alerta_enviada INTEGER DEFAULT 0,
    purgada INTEGER DEFAULT 0,
    creado_en INTEGER
);
CREATE TABLE IF NOT EXISTS bot_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notification_subscribers (
    tg_id INTEGER PRIMARY KEY,
    username TEXT NOT NULL DEFAULT '',
    active INTEGER NOT NULL DEFAULT 1,
    subscribed_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cuentas_tg ON cuentas(tg_id, estado);
CREATE INDEX IF NOT EXISTS idx_cuentas_expira ON cuentas(estado, expira_ts);
"""


def _conn():
    c = sqlite3.connect(config.DB_PATH, timeout=15, isolation_level=None)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA busy_timeout=10000")
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init_db():
    os.makedirs(os.path.dirname(config.DB_PATH), exist_ok=True)
    c = _conn()
    try:
        c.execute("PRAGMA journal_mode=WAL")
        c.executescript(_SCHEMA)
        # migraciones idempotentes sobre DBs previas
        for col, ddl in (
            ("auth_ts", "ALTER TABLE usuarios ADD COLUMN auth_ts INTEGER DEFAULT 0"),
            ("purgada", "ALTER TABLE cuentas ADD COLUMN purgada INTEGER DEFAULT 0"),
        ):
            try:
                c.execute(ddl)
            except sqlite3.OperationalError:
                pass
    finally:
        c.close()


def _tx(c):
    c.execute("BEGIN IMMEDIATE")


# ───────────────────────── usuarios / auth ─────────────────────────
def nuevo_usuario(tg_id, username, first):
    c = _conn()
    try:
        _tx(c)
        row = c.execute("SELECT tg_id FROM usuarios WHERE tg_id=?", (tg_id,)).fetchone()
        if not row:
            c.execute("INSERT INTO usuarios(tg_id,username,first,creado_en) VALUES(?,?,?,?)",
                      (tg_id, username or "", first or "", int(time.time())))
        elif username or first:
            c.execute("UPDATE usuarios SET "
                      "username=COALESCE(NULLIF(?,''),username), "
                      "first=COALESCE(NULLIF(?,''),first) WHERE tg_id=?",
                      (username, first, tg_id))
        c.execute("COMMIT")
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()


def get_usuario(tg_id):
    c = _conn()
    try:
        return c.execute("SELECT * FROM usuarios WHERE tg_id=?", (tg_id,)).fetchone()
    finally:
        c.close()


def set_auth(tg_id, now=None):
    now = now or int(time.time())
    c = _conn()
    try:
        _tx(c)
        c.execute("UPDATE usuarios SET auth_ts=? WHERE tg_id=?", (now, tg_id))
        c.execute("COMMIT")
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()


def clear_auth(tg_id):
    c = _conn()
    try:
        _tx(c)
        c.execute("UPDATE usuarios SET auth_ts=0 WHERE tg_id=?", (tg_id,))
        c.execute("COMMIT")
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()


def get_setting(key, default=""):
    c = _conn()
    try:
        row = c.execute(
            "SELECT setting_value FROM bot_settings WHERE setting_key=?", (key,)
        ).fetchone()
        return row["setting_value"] if row else default
    finally:
        c.close()


def set_setting(key, value):
    c = _conn()
    try:
        _tx(c)
        c.execute(
            "INSERT INTO bot_settings(setting_key,setting_value) VALUES(?,?) "
            "ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value",
            (key, str(value)),
        )
        c.execute("COMMIT")
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()


def subscribe(tg_id, username=""):
    c = _conn()
    try:
        _tx(c)
        c.execute(
            "INSERT INTO notification_subscribers(tg_id,username,active,subscribed_at) "
            "VALUES(?,?,1,?) ON CONFLICT(tg_id) DO UPDATE SET "
            "username=excluded.username,active=1,subscribed_at=excluded.subscribed_at",
            (tg_id, username or "", int(time.time())),
        )
        c.execute("COMMIT")
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()


def unsubscribe(tg_id):
    c = _conn()
    try:
        _tx(c)
        c.execute("UPDATE notification_subscribers SET active=0 WHERE tg_id=?", (tg_id,))
        c.execute("COMMIT")
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()


def subscribers():
    c = _conn()
    try:
        return [row["tg_id"] for row in c.execute(
            "SELECT tg_id FROM notification_subscribers WHERE active=1"
        ).fetchall()]
    finally:
        c.close()


# ───────────────────────── cuentas ─────────────────────────
def cuentas_vivas(tg_id, now=None):
    now = now or int(time.time())
    c = _conn()
    try:
        return c.execute(
            "SELECT COUNT(*) FROM cuentas WHERE tg_id=? AND estado='viva' AND expira_ts>?",
            (tg_id, now)).fetchone()[0]
    finally:
        c.close()


def cuentas_de(tg_id, now=None):
    now = now or int(time.time())
    c = _conn()
    try:
        rows = c.execute(
            "SELECT * FROM cuentas WHERE tg_id=? AND estado!='borrada' "
            "ORDER BY CASE estado WHEN 'viva' THEN 0 ELSE 1 END, expira_ts DESC",
            (tg_id,)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["viva"] = (r["estado"] == "viva" and r["expira_ts"] > now)
            d["restante_seg"] = max(0, r["expira_ts"] - now)
            out.append(d)
        return out
    finally:
        c.close()


def get_cuenta(cid):
    c = _conn()
    try:
        return c.execute("SELECT * FROM cuentas WHERE id=?", (cid,)).fetchone()
    finally:
        c.close()


def puede_crear(tg_id, now=None):
    """(True, '') si hay slot libre. 0 en config = sin límite."""
    if config.MAX_CUENTAS_POR_USUARIO <= 0:
        return True, ""
    if cuentas_vivas(tg_id, now) >= config.MAX_CUENTAS_POR_USUARIO:
        return False, "limite"
    return True, ""


def registrar_cuenta(tg_id, protocolo, usuario, password, uuid, expira_ts):
    c = _conn()
    try:
        _tx(c)
        cur = c.execute(
            "INSERT INTO cuentas(tg_id,protocolo,usuario,password,uuid,expira_ts,estado,creado_en)"
            " VALUES(?,?,?,?,?,?,'viva',?)",
            (tg_id, protocolo, usuario, password, uuid, expira_ts, int(time.time())))
        cid = cur.lastrowid
        c.execute("COMMIT")
        return cid
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()


def renombrar_expiracion(cid, expira_ts):
    c = _conn()
    try:
        _tx(c)
        c.execute("UPDATE cuentas SET expira_ts=?, estado='viva', alerta_enviada=0, "
                  "purgada=0 WHERE id=?", (expira_ts, cid))
        c.execute("COMMIT")
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()


def actualizar_uuid(cid, uuid):
    if not uuid:
        return
    c = _conn()
    try:
        _tx(c)
        c.execute("UPDATE cuentas SET uuid=? WHERE id=?", (uuid, cid))
        c.execute("COMMIT")
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()


def marcar_expiradas(now=None):
    now = now or int(time.time())
    c = _conn()
    try:
        _tx(c)
        rows = c.execute("SELECT id FROM cuentas WHERE estado='viva' AND expira_ts<=?",
                         (now,)).fetchall()
        ids = [r["id"] for r in rows]
        if ids:
            c.execute("UPDATE cuentas SET estado='expirada' WHERE id IN (%s)"
                      % ",".join("?" * len(ids)), ids)
        c.execute("COMMIT")
        return ids
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()


def cuentas_para_alertar():
    c = _conn()
    try:
        return c.execute("SELECT * FROM cuentas WHERE estado='expirada' AND alerta_enviada=0"
                         ).fetchall()
    finally:
        c.close()


def marcar_alerta(cid):
    c = _conn()
    try:
        _tx(c)
        c.execute("UPDATE cuentas SET alerta_enviada=1 WHERE id=?", (cid,))
        c.execute("COMMIT")
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()


def cuentas_para_purgar():
    c = _conn()
    try:
        return c.execute(
            "SELECT * FROM cuentas WHERE estado='expirada' AND alerta_enviada=1"
            " AND purgada=0").fetchall()
    finally:
        c.close()


def marcar_purga(cid):
    c = _conn()
    try:
        _tx(c)
        c.execute("UPDATE cuentas SET purgada=1 WHERE id=?", (cid,))
        c.execute("COMMIT")
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()


def eliminar_cuenta(cid):
    c = _conn()
    try:
        _tx(c)
        c.execute("UPDATE cuentas SET estado='borrada' WHERE id=?", (cid,))
        c.execute("COMMIT")
    except Exception:
        c.execute("ROLLBACK")
        raise
    finally:
        c.close()
