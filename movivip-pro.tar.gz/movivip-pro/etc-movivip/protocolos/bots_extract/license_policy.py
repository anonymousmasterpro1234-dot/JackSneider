"""Fail-closed license policy shared by both Telegram bot processes."""

import os
import shutil
import subprocess


_BINARIES = (
    "/usr/local/bin/movivip-lic",
    "/etc/movivip/bin/movivip-lic",
    "/etc/movivip/movivip-lic",
)
_ALLOWED_PLANS = {
    "premium", "premiumplus", "premium_plus",
    "vitalicio", "vitalicia", "lifetime", "admin", "super", "superadmin",
    "super_admin", "administrador", "superadministrador",
}
_ALLOWED_TYPES = {
    "admin", "super", "superadmin", "super_admin", "administrador",
    "superadministrador",
}


def _fields(output):
    fields = {}
    for line in output.splitlines():
        key, separator, value = line.partition("=")
        if not separator or not key.startswith("LIC_"):
            continue
        fields[key] = value.strip().strip('"')
    return fields


def _norm(value):
    return "".join(str(value or "").lower().split()).replace("-", "_")


def eligible(plan, license_type):
    return _norm(plan) in _ALLOWED_PLANS or _norm(license_type) in _ALLOWED_TYPES


def check_bot_license(binary=None, runner=subprocess.run):
    """Return (allowed, reason); local license files are never trusted."""
    candidate = binary or os.environ.get("MV_LIC_BIN")
    if not candidate or not os.path.isfile(candidate) or not os.access(candidate, os.X_OK):
        candidate = next((path for path in _BINARIES if os.path.isfile(path)
                          and os.access(path, os.X_OK)), None)
    if not candidate:
        candidate = shutil.which("movivip-lic")
    if not candidate:
        return False, "movivip-lic is not installed"

    try:
        result = runner([candidate, "--gate"], capture_output=True, text=True,
                        timeout=15, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        return False, f"license verification failed: {exc}"

    fields = _fields(result.stdout or "")
    if result.returncode != 0 or fields.get("LIC_OK", "").lower() != "true":
        return False, fields.get("LIC_DETALLE") or "license is inactive or expired"

    plan = fields.get("LIC_PLAN", "")
    license_type = fields.get("LIC_TIPO", "")
    if eligible(plan, license_type):
        return True, ""
    if plan or license_type:
        return False, "the active license plan does not include Telegram bots"
    return False, "license plan metadata is unavailable"
