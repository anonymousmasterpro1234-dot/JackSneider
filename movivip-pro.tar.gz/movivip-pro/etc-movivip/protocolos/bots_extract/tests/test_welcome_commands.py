import os
import sys
import unittest

PACKAGE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
V5_DIR = os.path.join(PACKAGE_DIR, "v5")
if PACKAGE_DIR not in sys.path:
    sys.path.insert(0, PACKAGE_DIR)
if V5_DIR not in sys.path:
    sys.path.insert(0, V5_DIR)

from core.db import init_db, open_db
from seed import apply_seed
from welcome import build_text


class WelcomeCommandsTests(unittest.TestCase):
    def setUp(self):
        self.conn = init_db(open_db(":memory:"))
        self.conn.execute(
            "INSERT INTO commands (slug, titulo, enabled) VALUES (?, ?, 1)",
            ("precios", "Precios y planes"),
        )
        self.conn.execute(
            "INSERT INTO commands (slug, titulo, enabled) VALUES (?, ?, 0)",
            ("oculto", "No debe aparecer"),
        )
        self.conn.commit()

    def tearDown(self):
        self.conn.close()

    def test_commands_variable_renders_active_public_commands(self):
        self.conn.execute(
            "UPDATE welcome_config SET texto=? WHERE id=1",
            ("Hola {nombre}\n{comandos}\n{target}",),
        )
        self.conn.commit()

        text = build_text("Ana", "ana", "group", self.conn)

        self.assertIn("Hola Ana", text)
        self.assertIn("<code>/start</code>", text)
        self.assertIn("<code>/stop</code>", text)
        self.assertIn("<code>/vip</code>", text)
        self.assertIn("<code>/precios</code> — Precios y planes", text)
        self.assertNotIn("/oculto", text)
        self.assertNotIn("{comandos}", text)

    def test_commands_are_appended_to_existing_templates_without_marker(self):
        self.conn.execute(
            "UPDATE welcome_config SET texto=? WHERE id=1",
            ("Bienvenido {nombre}",),
        )
        self.conn.commit()

        text = build_text("Ana", "ana", "group", self.conn)

        self.assertIn("Bienvenido Ana", text)
        self.assertIn("Comandos disponibles", text)
        self.assertIn("<code>/precios</code>", text)

    def test_seed_adds_marker_without_overwriting_custom_welcome(self):
        self.conn.execute(
            "UPDATE welcome_config SET texto=? WHERE id=1",
            ("Plantilla personalizada para {nombre}.",),
        )
        self.conn.commit()

        apply_seed(self.conn)

        saved = self.conn.execute(
            "SELECT texto FROM welcome_config WHERE id=1"
        ).fetchone()["texto"]
        self.assertEqual(
            saved, "Plantilla personalizada para {nombre}.\n\n{comandos}")


if __name__ == "__main__":
    unittest.main()
