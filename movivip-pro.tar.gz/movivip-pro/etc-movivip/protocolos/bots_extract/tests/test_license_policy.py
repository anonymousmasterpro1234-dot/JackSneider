import sys
import unittest
from types import SimpleNamespace

import license_policy


class LicensePolicyTests(unittest.TestCase):
    def test_allowed_plans_and_admin_types(self):
        for plan in (
            "Premium", "Vitalicio", "Vitalicia", "Premium Plus",
            "Admin", "Super", "Super Admin",
        ):
            with self.subTest(plan=plan):
                self.assertTrue(license_policy.eligible(plan, "cliente"))
        for license_type in ("admin", "super", "superadmin", "super-admin"):
            with self.subTest(license_type=license_type):
                self.assertTrue(license_policy.eligible("bronce", license_type))

    def test_unqualified_plans_are_denied(self):
        for plan in ("bronce", "plata", "platino", "platinum", "standard", "mayorista", ""):
            with self.subTest(plan=plan):
                self.assertFalse(license_policy.eligible(plan, "cliente"))

    def test_check_requires_valid_license_and_eligible_metadata(self):
        results = [
            SimpleNamespace(returncode=0, stdout=(
                'LIC_OK=true\nLIC_PLAN="Premium"\nLIC_TIPO="cliente"\n')),
        ]

        def runner(*args, **kwargs):
            return results.pop(0)

        allowed, reason = license_policy.check_bot_license(
            binary=sys.executable, runner=runner)
        self.assertTrue(allowed)
        self.assertEqual(reason, "")

    def test_check_rejects_an_active_but_ineligible_plan(self):
        results = [
            SimpleNamespace(returncode=0, stdout=(
                'LIC_OK=true\nLIC_PLAN="Bronce"\nLIC_TIPO="cliente"\n')),
        ]

        def runner(*args, **kwargs):
            return results.pop(0)

        allowed, reason = license_policy.check_bot_license(
            binary=sys.executable, runner=runner)
        self.assertFalse(allowed)
        self.assertIn("does not include", reason)

    def test_check_uses_gate_once_without_export(self):
        calls = []

        def runner(args, **kwargs):
            calls.append(args)
            return SimpleNamespace(returncode=0, stdout=(
                'LIC_OK=true\nLIC_PLAN="Vitalicia"\nLIC_TIPO="cliente"\n'))

        allowed, reason = license_policy.check_bot_license(binary=sys.executable, runner=runner)
        self.assertTrue(allowed)
        self.assertEqual(reason, "")
        self.assertEqual(calls, [[sys.executable, "--gate"]])


if __name__ == "__main__":
    unittest.main()
