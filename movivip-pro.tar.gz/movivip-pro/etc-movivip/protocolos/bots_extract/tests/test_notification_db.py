import os
import tempfile
import unittest

import config
import db


class NotificationDatabaseTests(unittest.TestCase):
    def setUp(self):
        self._original_db_path = config.DB_PATH
        self._temporary_directory = tempfile.TemporaryDirectory()
        config.DB_PATH = os.path.join(self._temporary_directory.name, "bot.db")
        db.init_db()

    def tearDown(self):
        config.DB_PATH = self._original_db_path
        self._temporary_directory.cleanup()

    def test_notification_settings_are_persistent(self):
        db.set_setting("notification_brand", "Test Brand")
        self.assertEqual(db.get_setting("notification_brand"), "Test Brand")
        self.assertEqual(db.get_setting("missing", "fallback"), "fallback")

    def test_subscribers_can_opt_in_and_out(self):
        db.subscribe(1234, "test_user")
        self.assertIn(1234, db.subscribers())

        db.unsubscribe(1234)
        self.assertNotIn(1234, db.subscribers())

        db.subscribe(1234, "renews")
        self.assertIn(1234, db.subscribers())


if __name__ == "__main__":
    unittest.main()
