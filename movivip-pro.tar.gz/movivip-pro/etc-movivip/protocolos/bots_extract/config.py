"""
Configuration — plantilla del CLIENTE (white-label)
===================================================
Bot admin MoviVIP (fork del bot PERSONAL, adaptado a producción multi-cliente).

DISEÑO (dos capas):
  1) CONTRATO DEL INSTALADOR  →  datos públicos que `bot.sh` rellena con `sed`
     (ADMIN_IDS, DOMINIO, MARCA, ...). Las credenciales se leen de un archivo
     local protegido y nunca se incrustan en este módulo.
  2) ADAPTADOR INTERNO        →  nombres que usa el bot (BOT_TOKEN, SERVIDOR,
     ACCOUNT_SH, AUTH_*, ...) derivados de la capa 1. El resto de módulos
     (admin_bot, protocolos, sshprod, vpsinfo, db, auth, sweeper) leen SOLO
     esta segunda capa.

El bot corre DENTRO del VPS del cliente (misma máquina que account.sh), así que
crea/borra cuentas llamando a /etc/movivip/usuarios/account.sh en LOCAL
(sin SSH/paramiko). Login = contraseña root de la VPS, validada contra
/etc/shadow.
"""

import json
import os
import stat
import sqlite3

# Secrets are provisioned by bot.sh in a root-only file, never in this module.
_SECRETS_FILE = os.environ.get(
    "MOVIVIP_BOT_SECRETS", os.path.join(os.path.dirname(__file__), ".secrets.json"))
try:
    with open(_SECRETS_FILE, "r", encoding="utf-8") as _secrets_stream:
        _secrets = json.load(_secrets_stream)
    if os.name == "posix" and stat.S_IMODE(os.stat(_SECRETS_FILE).st_mode) & 0o077:
        raise PermissionError("bot secrets file must not be accessible to group or others")
    if not isinstance(_secrets, dict):
        raise ValueError("the bot secrets file must contain a JSON object")
    for _name, _value in _secrets.items():
        if isinstance(_name, str) and isinstance(_value, str):
            os.environ.setdefault(_name, _value)
except FileNotFoundError:
    pass
except (OSError, ValueError, json.JSONDecodeError) as _exc:
    raise RuntimeError(f"unable to load bot secrets from {_SECRETS_FILE}") from _exc

# =============================================================================
# 1) CONTRATO DEL INSTALADOR — NO renombrar estas claves
# =============================================================================
ADMIN_BOT_TOKEN = ""                        # leído desde el archivo local de secretos
ADMIN_IDS = [0]                             # ID de Telegram autorizado (no es secreto)
NOTIF_BOT_TOKEN = ""                        # leído desde el archivo local de secretos
NOTIF_CHANNEL_ID = 0
NOTIF_GROUP_ID = 0

# Monetag / MiniApp (el bot NO los usa; se conservan por compatibilidad del
# instalador y por si el cliente activa su propia miniapp).
MONETAG_ZONE_ID = "PONER_ZONE_ID_AQUI"
MONETAG_SDK_URL = "//libtl.com/sdk.js"
MONETAG_SDK_FUNC = "PONER_SDK_FUNC_AQUI"
MINIAPP_BASE_URL = "http://127.0.0.1:5000"

# VPS del cliente
VPS_HOST = "127.0.0.1"
VPS_PORT = 22
VPS_USER = "root"
VPS_PASSWORD = ""
SSH_HOST = "127.0.0.1"
VPS_SUBDOMAIN = "PONER_SUBDOMINIO_AQUI"

# Dominios
DOMAIN_MAIN = "PONER_DOMINIO_AQUI"
CLOUDFLARE_DOMAIN = DOMAIN_MAIN
CDN_PRIMARY = "PONER_CDN_PRIMARY_AQUI"
CDN_SECONDARY = "PONER_CDN_SECONDARY_AQUI"
CDN_ALT = "PONER_CDN_ALT_AQUI"
CDN_EXTRA = "PONER_CDN_EXTRA_AQUI"

# SlowDNS / VayDNS / DNSTT
SLOWDNS_NS = f"ns1.{DOMAIN_MAIN}"
SLOWDNS_KEY = "PONER_SLOWDNS_KEY_AQUI"
SLOWDNS_PUB = "PONER_SLOWDNS_PUB_AQUI"
SLOWDNS_PORT = 5300
VAYDNS_PORT = 5354
VAYDNS_DOMAIN = f"t.{DOMAIN_MAIN}"
VAYDNS_PUBKEY = "PONER_VAYDNS_PUBKEY_AQUI"
DNSTT_PORT = 5355
DNSTT_DOMAIN = f"d.{DOMAIN_MAIN}"
DNSTT_PUBKEY = "PONER_DNSTT_PUBKEY_AQUI"

# MiniApp / API (opcional)
MINIAPP_URL = f"https://{VPS_SUBDOMAIN}:8448"
API_URL = f"http://{VPS_HOST}:5000"
FIREBASE_SERVICE_ACCOUNT = None

# Firebase (mismas claves que el instalador rellena con sed)
FB_API_KEY = os.environ.get("FB_API_KEY", "")
FB_AUTH_EMAIL = os.environ.get("FB_AUTH_EMAIL", "")
FB_AUTH_PASS = os.environ.get("FB_AUTH_PASS", "")

# Enlace de atención del administrador (el bot NO cobra)
LINK_REDIREC = ""

# Telegram
MAIN_CHANNEL = "PONER_CANAL_AQUI"
SUPPORT_GROUP = "PONER_GRUPO_AQUI"

# Branding (white-label)
BRAND_NAME = "PONER_MARCA_AQUI"
MY_BRAND = "PONER_MARCA_KEY_AQUI"
BRAND_BOT = "PONER_BOT_MARCA_AQUI"
BRAND_PREMIUM = ""
BRAND_SUPPORT = ""
BRAND_CHANNEL = ""
BRAND_GROUP = ""
BRAND_STORE = ""
BRAND_MINIAPP = ""

# Base de datos (el instalador lee esta ruta literal para su tabla `admins`)
DB_PATH = "/root/movivip.db"

# Planes / límites del producto (compatibilidad con el generador)
MAX_DAYS_CREATE = 30
PLANS = {
    3: {"days": 3, "price": "Gratis", "max_devices": 1},
    7: {"days": 7, "price": "Gratis", "max_devices": 3},
    15: {"days": 15, "price": "Gratis", "max_devices": 5},
    30: {"days": 30, "price": "Gratis", "max_devices": 10},
}
MAX_DEVICES = 10
AD_COOLDOWN_SECONDS = 300

# Xray / V2Ray (el instalador rellena pubkey/shortid)
XRAY_VPS_IP = "127.0.0.1"
XRAY_VLESS_REALITY_PORT = 9443
XRAY_VMESS_WS_PORT = 8443
XRAY_VLESS_REALITY_PUBKEY = "PONER_PUBKEY_AQUI"
XRAY_VLESS_REALITY_SHORTID = "PONER_SHORTID_AQUI"
XRAY_VLESS_REALITY_SNI = "www.microsoft.com"
XRAY_VMESS_WS_PATH = "/vmess"
XRAY_CONFIG_PATH = "/usr/local/etc/xray/config.json"

# Rutas del sistema
BANNERS_DIR = "/etc/ssh/banners"
VPN_SHELL = "/usr/local/bin/vpn-shell.sh"

# Bienvenida / redes (los usa el bot de notificaciones del producto)
STORE_BOT = ""
SSH_BOT = ""
SOCIAL_LINKS = {
    'web': '', 'tiktok': '', 'youtube': '', 'telegram_ch': '',
    'telegram_group': '', 'whatsapp_ch': '', 'whatsapp_community': '',
    'whatsapp_personal': '',
}

# Operadores (exclusivo del vendedor; vacío en el repo público)
OPERATORS = {}
OPERATOR_PORTS = OPERATORS


def load_snis_from_db():
    """SNIs desde la tabla operator_snis (compartida entre bots). {} si no hay."""
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT operator, sni FROM operator_snis "
                    "WHERE is_active=1 ORDER BY operator, priority DESC")
        snis = {}
        for op, sni in cur.fetchall():
            snis.setdefault(op, {"snis": [], "default": None})
            snis[op]["snis"].append(sni)
            if snis[op]["default"] is None:
                snis[op]["default"] = sni
        conn.close()
        return snis
    except Exception:
        return {}


SNI_CONFIG = load_snis_from_db()


# =============================================================================
# 2) ADAPTADOR INTERNO — lo que lee el bot (derivado de la capa 1)
# =============================================================================
def _env(k, d=""):
    return os.environ.get(k, d)


def _plh(v):
    """True si `v` sigue siendo un placeholder 'PONER_...' vacío o sin rellenar."""
    return (not v) or ("PONER" in str(v).upper())


# --- Telegram ---
BOT_TOKEN = _env("MOVIVIP_BOT_TOKEN")
NOTIF_TOKEN = _env("MOVIVIP_NOTIF_BOT_TOKEN")
BRAND = BRAND_NAME if not _plh(BRAND_NAME) else "MoviVIP"
BOT_USERNAME = _env("MOVIVIP_BOT_USERNAME") or (
    BRAND_BOT if not _plh(BRAND_BOT) else BRAND)

# --- Acceso: solo el ID de Telegram configurado por el instalador ---
OWNER_ID = int(ADMIN_IDS[0]) if ADMIN_IDS and ADMIN_IDS and ADMIN_IDS[0] else 0

# --- Reglas del producto ---
DIAS_CUENTA = int(_env("MOVIVIP_DIAS", "30"))          # duración de la cuenta
MAX_CUENTAS_POR_USUARIO = int(_env("MOVIVIP_MAX_CUENTAS", "0"))  # 0 = sin límite
MAX_CONEXIONES = int(_env("MOVIVIP_MAX_CONEXIONES", "1"))        # por cuenta
LIMITE_GB = int(_env("MOVIVIP_LIMITE_GB", "0"))                  # 0 = sin límite

# --- Autenticación (login = contraseña root de ESTA VPS) ---
AUTH_USER = _env("MOVIVIP_AUTH_USER", "root")
AUTH_SHADOW = _env("MOVIVIP_SHADOW", "/etc/shadow")
AUTH_SESION_SEG = 12 * 3600
AUTH_MAX_INTENTOS = 5
AUTH_BLOQUEO_SEG = 300
# No se guarda una contraseña root de respaldo en el bot.
AUTH_PASSWORD_FALLBACK = ""

# --- Rutas del VPS (account.sh + config real) ---
ACCOUNT_SH = _env("MOVIVIP_ACCOUNT_SH", "/etc/movivip/usuarios/account.sh")
MOVIVIP_CONFIG_CONF = _env("MOVIVIP_CONFIG_CONF", "/etc/movivip/config.conf")
XRAY_CONFIG = _env("MOVIVIP_XRAY_CONFIG", XRAY_CONFIG_PATH)
HYSTERIA_CONFIG = _env("MOVIVIP_HYSTERIA_CONFIG", "/etc/hysteria/config.json")

# --- Autodetección de protocolos instalados (adaptativo por VPS) ---
# True  → el menú solo muestra los protocolos realmente instalados en la VPS.
# False → muestra las 4 familias completas (17 protocolos) siempre.
AUTODETECTAR = _env("MOVIVIP_AUTODETECTAR", "1").lower() not in ("0", "false", "no", "off")

# --- Datos de entrega (IP + dominio visibles en las tarjetas) ---
_ip = _env("MOVIVIP_IP")
if not _ip:
    _ip = VPS_HOST if not _plh(VPS_HOST) and VPS_HOST not in ("127.0.0.1",) else ""
_host = VPS_SUBDOMAIN if not _plh(VPS_SUBDOMAIN) else DOMAIN_MAIN
_slowdns = _env("MOVIVIP_SLOWDNS_NS") or (
    f"ns1.{DOMAIN_MAIN}" if not _plh(DOMAIN_MAIN) else "")
SERVIDOR = {
    "ip": _ip or VPS_HOST,
    "host": _host if not _plh(_host) else "localhost",
    "xray_port": _env("MOVIVIP_XRAY_PORT", "443"),
    "ssh_ports": _env("MOVIVIP_SSH_PORTS", "90, 143, 109"),
    "ssl_ports": _env("MOVIVIP_SSL_PORTS", "22, 80, 443, 8080, 8443"),
    "bhttp_plain_port": _env("MOVIVIP_BHTTP_LOCAL_PORT", "2003"),
    "bhttp_public_port": _env("MOVIVIP_BHTTP_PORT", "8880"),
    "zipvpn_port": _env("MOVIVIP_ZIPVPN_PORT", "5667"),
    "slowdns": _slowdns,
}

# --- Infra ---
SWEEP_INTERVAL_SEG = 60
VPS_TIMEOUT_SEG = 90
