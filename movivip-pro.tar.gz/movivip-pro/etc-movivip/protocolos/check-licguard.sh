#!/bin/bash
# MOVIVIP-PACKED-V2
_ecbfadecab() { local _m _l; _m=$(cat /etc/machine-id 2>/dev/null || hostname); _l=$(grep -E '^(LICENCIA|KEY)=' "/etc/movivip/licencia.conf" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '" \r\n'); printf '%s|%s|%s|movivip-pack-v2' "$_m" "$_l" "protocolos/check-licguard.sh" | sha256sum | awk '{print $1}'; }
case "$-" in *x*) exit 3;; esac
[[ -n "${BASH_XTRACEFD:-}${PS4:-}" && "${PS4:-}" != "+ "* ]] && exit 3
[[ -n "${LD_PRELOAD:-}${BASH_ENV:-}${ENV:-}" ]] && exit 3
_fcbeeaacbd='ob0agJyCWriniPRMGAKkJFQNHLFvrTP/4eeXorL/Ai8/v6F+m2jIgMUXskcsf34JXTzYKEg9scsiqP0dnzqjVJFYm5Rn8CFtPycF0GpVEdT3Qc9cTksZm3LclzsU7lWmPDUvqmxIyYgJu+vC35+WyUs5wdpWDfOTpS1+3MLAGbZ+W+U9R/Xikz+shFUpBF4V9Ui65ON+sZ30cQsO20pG+m2We+MnEjjIamj8pJ+NkMFXPMP2o2LDYXM6ocDKBqTtLtIXnKysOoDezH0LpsKLZU9MuZeh9Of9iCvvLBW60KxatGrPkJQelXqjgUwCjYeuHzs+DtqVXaXQT7GkR+cKnI0ox79yaveLcEGBEmvfyXj3mlhuGWpTH2pkfteXj/9VPCGAQwiH/F/WozuPMXFonJrHWX2GnLujpDEtlqjYjsjj0KtZB4nHghuubARY1jhP7cZzG7HKxdNPGf0jeL9vGC2RYetVFrK2C3Usc8uM3OLgEhbzEyQcHUTTcdXF5/H0egs9e9/oaVdBraYia4lnpK+U9uk1PoOwCoO/tVd3vSofbmVXBtzSi5W7kMtmxo2+BBBDJO+MYm+S/EBiS2yxlC8SS+hBaZTnwqIwgU/URhIe16vXwqwEOLclXD2NHcbnQcaULZnn2qEy0laAsSX/UfjqSnNAS5LKj2OtkYoq9npkbg9gzA0wBIUoswdSU3K4hXfr0Ua4Oz9ylvUUdQ5Hy+YDcbhpOnf2vtTQ0Cbw3tPpBKuuPp/0pBbc+yrIhPbH7Qy8Xp6Zw0dgZtzfwfo+evJm155uqldt8XF2LbCkXk6UQnt2/LHgnvo3IlbmVPrmENdohL5hd95turRDDCoIoQQJx2KlmOSv1MxJp94tmFfN3bjzHc7moCEBFNg5WVtw5iX7DTkLpdMIIpf2GG9nrRU9RiQimBL9GQone3yIMwUd784C8AYuVWWKtBlQebsy'
_ddeaccffbe="$(printf '%s' "$(_ecbfadecab)" | sha256sum | awk '{print $1}')"
_cabeaddcfb="$(printf '%s' "protocolos/check-licguard.sh" | sha256sum | awk '{print substr($1,1,32)}')"
if [[ "$(printf '%s' "$_fcbeeaacbd" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_ddeaccffbe" -iv "$_cabeaddcfb" 2>/dev/null | gunzip 2>/dev/null | sha256sum | awk '{print $1}')" != "09424d58a9e6828183128b96984da9f327e5b2435ab181bb11bb91c6adeb08b3" ]]; then exit 4; fi
eval "$(printf '%s' "$_fcbeeaacbd" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_ddeaccffbe" -iv "$_cabeaddcfb" 2>/dev/null | gunzip 2>/dev/null)"
