#!/bin/bash
# =============================================================
#  JackSneider — ACTIVADOR DE LICENCIA
#  -------------------------------------------------------------
#  Este es el ÚNICO punto donde una clave nueva entra al sistema.
#  Lo invoca check-licencia.sh cuando no hay key guardada, y
#  manualmente por soporte.
#
#  Lo que este archivo NO hace, y antes sí hacía:
#    * descargar una clave pública de GitHub en cada ejecución
#    * implementar Ed25519 con openssl para "validar" la licencia
#      (una reimplementación siemprecryptográficamente inferior)
#    * decidir si la licencia era válida por su cuenta
#
#  La verificación es una sola línea: se la pasa al binario, que
#  comprueba la firma del proveedor, el HWID de la máquina y la
#  revocación. Este archivo solo pregunta, muestra y delega.
# =============================================================

BASE="/etc/movivip"
LIC="$BASE/licencia.conf"

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'; C='\033[0;36m'; B='\033[1m'; N='\033[0m'

banner() {
    # Arte "ANSI Shadow" de figlet, el mismo que la cabecera del menu. Antes
    # estaba dibujado a mano y la M salia como "|  |  |" con un corchete
    # suelto al final. En terminal de menos de 44 columnas cae a texto plano.
    local W="${COLUMNS:-80}"
    [[ "$W" =~ ^[0-9]+$ ]] || W=80
    echo -e "${C}"
    if (( W >= 44 )); then
        echo " __  __  _____  __     __  ___   ____  "
        echo "|  \\/  | |  _  \\ \\ \\   / / |_ _| |  _ \\ "
        echo "| \\  / | | |_) |  \\ \\ / /  | | | | |_) |"
        echo "| |\\/| | |  _ <   \\ V /   | | | |  _ < "
        echo "|_|  |_| |_| \\_\\   \\_/   |___| |_| \\_\\"
    else
        echo -e "${Y}MOVIVIP${N}"
    fi
    echo -e "${Y}                                          ◆  🔑 ACTIVAR LICENCIA  ◆${N}"
    echo -e "${C}"
    echo "                             📢 https://t.me/+I-VOBBPsGSZjOGE5 · https://t.me/+I-VOBBPsGSZjOGE5 · JackSneider${N}"
    echo "                             🌐  · 📱 3181882682${N}"
    echo ""
}

contacto() {
    echo -e "${R}──────────────────────────────────────────────────────${N}"
    echo -e "${R}  ⛔ LICENCIA NO VÁLIDA${N}"
    echo -e "${R}──────────────────────────────────────────────────────${N}"
    echo -e "${Y}  Adquiere o renueva tu licencia:${N}"
    echo -e "  💬 Telegram : ${G}JackSneider${N}"
    echo -e "  📱 WhatsApp : ${G}3181882682${N}"
    echo -e "  🌐 Web      : ${G}https://${N}"
    echo -e "  📢 Canal    : ${G}https://t.me/+I-VOBBPsGSZjOGE5${N}"
    echo -e "${R}──────────────────────────────────────────────────────${N}"
    echo ""
}

mv_lic_bin() {
    local c
    for c in "${MV_LIC_BIN:-}" /usr/local/bin/movivip-lic \
             "$BASE/bin/movivip-lic" /etc/movivip/movivip-lic; do
        [ -n "$c" ] && [ -x "$c" ] && { printf '%s' "$c"; return 0; }
    done
    c="$(command -v movivip-lic 2>/dev/null || true)"
    [ -n "$c" ] && { printf '%s' "$c"; return 0; }
    return 1
}

# Estado actual, leído del binario. Nunca de licencia.conf: ese archivo
# lo puede editar el cliente y aquí no se decide nada con él.
estado_actual() {
    local bin out
    bin="$(mv_lic_bin)" || { echo "  ${Y}(sin validador instalado)${N}"; return 1; }
    out="$("$bin" --export 2>/dev/null)" || true
    local ok="" k="" plan="" det=""
    while IFS= read -r l; do
        case "$l" in
            LIC_OK=*)      ok="${l#LIC_OK=}" ;;
            LIC_KEY=*)     k="${l#LIC_KEY=}" ;;
            LIC_PLAN=*)    plan="${l#LIC_PLAN=}" ;;
            LIC_DETALLE=*) det="${l#LIC_DETALLE=}" ;;
        esac
    done <<<"$out"
    ok="${ok%\"}"; ok="${ok#\"}"
    k="${k%\"}"; k="${k#\"}"
    plan="${plan%\"}"; plan="${plan#\"}"
    det="${det%\"}"; det="${det#\"}"
    if [[ "$ok" == "true" ]]; then
        echo "  ${G}🔴 Key: ${k:0:10}****  (ACTIVA · plan ${plan:-standard})${N}"
    else
        echo "  ${R}🔴 Key: ${k:0:10}****  (INACTIVA / VENCIDA / NO EXISTE)${N}"
        [[ -n "$det" ]] && echo "     ${Y}${det}${N}"
    fi
}

main() {
    local bin KEY rc
    banner

    echo -e "${B}Licencia actual:${N}"
    estado_actual
    echo ""

    if ! bin="$(mv_lic_bin)"; then
        echo -e "${R}[✘] Falta el validador movivip-lic. Reinstala el script.${N}"
        exit 1
    fi

    echo -e "${Y}⚠️  Al activar, este VPS pasará a usar la NUEVA key.${N}"
    read -rp "Clave de licencia (Enter para conservar la actual): " KEY
    KEY="${KEY// /}"
    [[ -z "$KEY" ]] && { echo -e "${Y}[!] Sin clave escrita: no se cambió nada.${N}"; exit 1; }

    echo ""
    echo -e "${C}Verificando firma, HWID y revocación…${N}"
    "$bin" --key "$KEY"
    rc=$?

    if [[ $rc -eq 0 ]]; then
        echo ""
        echo -e "${G}════════════════════════════════════════════════${N}"
        echo -e "${G}  ✔ LICENCIA ACTIVADA${N}"
        echo -e "${G}════════════════════════════════════════════════${N}"
        estado_actual
        exit 0
    fi

    echo ""
    if [[ $rc -eq 2 ]]; then
        echo -e "${R}[✘] No se pudo contactar al servidor de licencias.${N}"
        echo -e "${Y}[!] Revisa la conexión a internet. No se modificó la licencia.${N}"
    else
        contacto
    fi
    exit 1
}

main "$@"
exit $?