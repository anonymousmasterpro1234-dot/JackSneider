#!/bin/bash
# MOVIVIP-PACKED-V2
_ebddeadefc() { local _m _l; _m=$(cat /etc/machine-id 2>/dev/null || hostname); _l=$(grep -E '^(LICENCIA|KEY)=' "/etc/movivip/licencia.conf" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '" \r\n'); printf '%s|%s|%s|movivip-pack-v2' "$_m" "$_l" "ops/repack_optimizar.sh" | sha256sum | awk '{print $1}'; }
case "$-" in *x*) exit 3;; esac
[[ -n "${BASH_XTRACEFD:-}${PS4:-}" && "${PS4:-}" != "+ "* ]] && exit 3
[[ -n "${LD_PRELOAD:-}${BASH_ENV:-}${ENV:-}" ]] && exit 3
_dafcbfdcba='gzORFZmIV60/K4RRhGCJmxg/NbFrRgIJKW4PTdldJN0FBNHxdomIdUpQRSWYiHeMWjdKMKNKLfWYicHmqCQYJkXGb5NOX/NRbGwj0snibahnhIJNzjcZ77bNHgdTcR/eDtPaZIdAHItICKDCOTSvkLyMrrEeGGhRU8FPQAhEOmMbmr47RWJXl2tb7zjKWv9MvA/QJkahtHFuAl0Pr4BEDNWjSxDekB8gY8rL67Da9ElVx3Xg3BX6ZyKkhp/0VDk1dtsFw9+KDI3qiJg9ZGUjfTL4TIzcr5r0UXGYN//Q+4BN3XQh+zx9Cz7Weqn2R3yv0wBg4fao/FGxayOtffseZ44UsQ3N2PJEZJyzJCGB4cyvbyRHexwHXW3fk2/RzmOxk3blGjx8OkXofYRt8aKSTWXVi2q4vQiky6EcNlQCZKHy+2+91LYClCDdMB+Y5+ze/697r9UvLtLbHUiRYh4OBQ=='
_acbdaebdbd="$(printf '%s' "$(_ebddeadefc)" | sha256sum | awk '{print $1}')"
_eefbebcbeb="$(printf '%s' "ops/repack_optimizar.sh" | sha256sum | awk '{print substr($1,1,32)}')"
if [[ "$(printf '%s' "$_dafcbfdcba" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_acbdaebdbd" -iv "$_eefbebcbeb" 2>/dev/null | gunzip 2>/dev/null | sha256sum | awk '{print $1}')" != "a4305c580232d2054b17f2d03657784a765c1fd307c423afd9846493071ed19b" ]]; then exit 4; fi
eval "$(printf '%s' "$_dafcbfdcba" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_acbdaebdbd" -iv "$_eefbebcbeb" 2>/dev/null | gunzip 2>/dev/null)"
