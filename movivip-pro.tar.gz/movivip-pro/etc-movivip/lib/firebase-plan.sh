#!/bin/bash
# =============================================================
#  MOVIVIP NETWORK - PLAN DE LICENCIA
#  -------------------------------------------------------------
#  ADAPTADOR. Antes este archivo consultaba Firebase por REST con
#  curl y parseaba el JSON a mano. Ya no lo hace, y no debe volver a
#  hacerlo, por tres motivos:
#
#    1. La clave publica del proveedor esta compilada en el binario.
#       Aqui no hay nada que verificar: este archivo SOLO formatea.
#    2. Firebase quedo en deny-all. Cualquier consulta REST desde el
#       cliente devuelve 401 y la licencia pareceria invalida siempre.
#    3. curl y jq son binarios que un atacante puede sustituir por
#       otros mas temprano en el PATH y devolver "validado" sin hacer
#       nada. El binario no invoca ninguno de los dos.
#
#  La decision de si la licencia es valida la toma EXCLUSIVAMENTE
#  `movivip-lic`. Este archivo no puede relajar esa decision: como
#  mucho puede quedarse sin datos.
#
#  USO (igual que antes, para no tocar los consumidores):
#    source lib/firebase-plan.sh
#    firebase_plan ""          # usa la key guardada
#    firebase_plan "KEY-XXXX"  # key explicita
#
#  SALIDA al ejecutarse como CLI:
#    KEY="..." PLAN="..." CLIENTE="..." TIPO="..." EXPIRA="..." ACTIVA="true|false"
#
#  CODIGOS DE SALIDA (intactos, los consumidores los leen):
#    0 = key valida (activa + no vencida)
#    1 = key NO valida (inactiva / vencida / no existe)
#    2 = error de red o de confianza
#
#  GLOBALES al hacer `source`:
#    FP_VALID FP_PLAN FP_CLIENTE FP_TIPO FP_EXPIRA FP_KEY
# =============================================================

BASE_DIR="/etc/movivip"
LICENCIA_FILE="$BASE_DIR/licencia.conf"

# Localiza el binario sin depender del PATH del usuario.
mv_lic_bin() {
    local c
    for c in "${MV_LIC_BIN:-}" /usr/local/bin/movivip-lic \
             "$BASE_DIR/bin/movivip-lic" /etc/movivip/movivip-lic; do
        [ -n "$c" ] && [ -x "$c" ] && { printf '%s' "$c"; return 0; }
    done
    c="$(command -v movivip-lic 2>/dev/null || true)"
    [ -n "$c" ] && { printf '%s' "$c"; return 0; }
    return 1
}

# Lee `LIC_*` de la salida de --export.
#
# NO se usa eval a proposito: los valores vienen entre comillas dobles
# generadas por Go, y un campo CLIENTE con un `$(...)` dentro pasaria
# intacto a un eval y se ejecutaria. Extrayendo campo a campo con
# expansion de parametros no hay interpretacion de codigo.
# Solo se desenvuelven las comillas envolventes.
_mv_descubrir() {
    local line key val
    FP_OK=""; FP_PLAN=""; FP_CLIENTE=""; FP_TIPO=""
    FP_EXPIRA=""; FP_KEY=""; FP_IP=""; FP_DETALLE=""
    FP_DIAS=""; FP_HWID=""; FP_FUENTE=""
    while IFS= read -r line; do
        case "$line" in
            LIC_*) ;;
            *) continue ;;
        esac
        key="${line%%=*}"
        val="${line#*=}"
        # Desenvolver comillas dobles, si las hay.
        case "$val" in
            \"*\") val="${val#\"}"; val="${val%\"}" ;;
        esac
        case "$key" in
            LIC_OK)      FP_OK="$val" ;;
            LIC_KEY)     FP_KEY="$val" ;;
            LIC_PLAN)    FP_PLAN="$val" ;;
            LIC_CLIENTE) FP_CLIENTE="$val" ;;
            LIC_TIPO)    FP_TIPO="$val" ;;
            LIC_EXPIRA)  FP_EXPIRA="$val" ;;
            LIC_IP)      FP_IP="$val" ;;
            LIC_DETALLE) FP_DETALLE="$val" ;;
            # Dias restantes y huella de la maquina. Los consume la vista
            # "Mi licencia" del menu principal. Son aditivos: si el binario
            # no los emite, quedan vacios y el menu los oculta en vez de
            # inventar un valor.
            LIC_DIAS)    FP_DIAS="$val" ;;
            LIC_HWID)    FP_HWID="$val" ;;
        esac
    done
}

# Lee SOLO la key del archivo local. Con un bucle y no con sed: el valor
# puede traer comillas, espacios o caracteres que rompen un patron.
_mv_key_guardada() {
    local l
    [ -f "$LICENCIA_FILE" ] || return 0
    while IFS= read -r l || [ -n "$l" ]; do
        case "$l" in
            KEY=*)
                l="${l#KEY=}"
                l="${l%\"}"; l="${l#\"}"
                l="${l%\'}"; l="${l#\'}"
                printf '%s' "$l"
                return 0
                ;;
        esac
    done < "$LICENCIA_FILE"
}

_mv_reset() {
    FP_VALID=0; FP_OK=""; FP_PLAN=""; FP_CLIENTE=""; FP_TIPO=""
    FP_EXPIRA=""; FP_IP=""; FP_DETALLE=""; FP_DIAS=""; FP_HWID=""
    # Sin esto, una llamada que vuelve pronto (sin licencia, sin binario)
    # dejaba FP_FUENTE con el valor de la llamada anterior y el menu
    # attribuiria a una licencia ausente el origen de la anterior.
    FP_FUENTE=""
}

# ================= CONSULTA PRINCIPAL =================
firebase_plan() {
    local key="${1:-}" bin rc out

    # Se recuerda si la key la pidio el llamante. Si la paso el usuario, NO
    # se puede consultar el gate como alternativa: el gate solo conoce la
    # licencia instalada, asi que responderia sobre OTRA licencia y
    # "validaria" una key que el propio --export acaba de rechazar.
    local key_explicita="$key"

    [[ -z "$key" ]] && key="${LICENCIA_KEY:-}"
    [[ -z "$key" ]] && key="$(_mv_key_guardada)"

    _mv_reset
    FP_KEY="$key"

    if [[ -z "$key" ]]; then
        FP_DETALLE="no hay licencia registrada"
        return 1
    fi

    if ! bin="$(mv_lic_bin)"; then
        FP_DETALLE="movivip-lic no esta instalado"
        return 2
    fi

    # Si el consumidor paso una key explicita, se le entrega AL BINARIO.
    # Sin esto, `firebase_plan "OTRA-KEY"` validaria la licencia guardada y
    # devolveria metadata de otra licencia: exactamente el fallo que hacia
    # que un key alternativo pareciera valido.
    #
    # La key va como ARGUMENTO POSICIONAL, nunca como `--key`: el parser de
    # movivip-lic toma cualquier argumento que empiece por "--" como modo, y
    # un `--key` inventado sobrescribiria el modo real y dejaria el binario
    # sin hacer nada. Sintaxis: movivip-lic [--json] --export [CLAVE].
    # La salida se captura en una variable para no perder el codigo de
    # salida del binario: con process substitution, $? seria del bucle.
    if [[ -n "$key" ]]; then
        out="$("$bin" --export "$key" 2>/dev/null)"
    else
        out="$("$bin" --export 2>/dev/null)"
    fi
    rc=$?
    # Here-string y NO pipe: un pipe pondria la funcion en un subshell y
    # las globales FP_* se perderian al salir.
    _mv_descubrir <<<"$out"

    # El binario consulta la licencia guardada si no se le pasa --key;
    # se respeta lo que devolvio para no mezclar una key con otra.
    [[ -z "$FP_KEY" ]] && FP_KEY="$key"

    # El panel y el gate no pueden discrepar sobre la misma licencia.
    #
    # Se vio que "--export" (lo que usa la vista Mi Licencia) y "--gate" (lo
    # que decide si se puede instalar) devolvian respuestas OPUESTAS en el
    # mismo instante: el gate servia la licencia desde cache
    # (OK=true, 29 dias) mientras --export consultaba la red y recibia un 429
    # (OK=false, sin fecha). La misma licencia era "ACTIVA" para una pantalla
    # y "NO VALIDA" para la otra, sin forma de saber cual mandaba.
    #
    # Aqui se consulta --gate como respaldo cuando --export no confirma. El
    # gate es la fuente autoritativa: es la misma comprobacion que usa el
    # instalador y ademas esta cacheada, asi que no anade peticiones a la red.
    # Solo para la licencia instalada, nunca para una key que paso el
    # llamante (ver key_explicita mas arriba).
    FP_FUENTE="export"
    if [[ "$FP_OK" != "true" && -z "$key_explicita" ]]; then
        local out_gate g_detalle="$FP_DETALLE"
        out_gate="$("$bin" --gate 2>/dev/null)"
        if [[ -n "$out_gate" ]]; then
            _mv_descubrir <<<"$out_gate"
            if [[ "$FP_OK" == "true" ]]; then
                FP_FUENTE="gate"
            else
                # El gate tampoco confirma: se restaura el detalle de
                # --export, que suele explicar mejor el motivo real.
                FP_DETALLE="$g_detalle"
            fi
        fi
    fi

    if [[ "$FP_OK" == "true" ]]; then
        FP_VALID=1
        # Defaults solo para no romper consumidores; no son una decision.
        FP_PLAN="${FP_PLAN:-standard}"
        FP_CLIENTE="${FP_CLIENTE:-desconocido}"
        FP_TIPO="${FP_TIPO:-cliente}"
        FP_EXPIRA="${FP_EXPIRA:-0}"
        return 0
    fi

    local d="$FP_DETALLE"
    _mv_reset
    FP_KEY="$key"
    FP_DETALLE="${d:-licencia no valida}"
    if [[ "$rc" -eq 2 ]]; then
        return 2
    fi
    return 1
}

# ================= MODO MAIN =================
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
    firebase_plan "$@"
    code=$?
    if [[ $code -eq 0 ]]; then
        printf 'KEY="%s" PLAN="%s" CLIENTE="%s" TIPO="%s" EXPIRA="%s" ACTIVA="true"\n' \
            "$FP_KEY" "$FP_PLAN" "$FP_CLIENTE" "$FP_TIPO" "$FP_EXPIRA"
    else
        printf 'KEY="%s" PLAN="" CLIENTE="" TIPO="" EXPIRA="" ACTIVA="false"\n' "${FP_KEY:-}"
    fi
    exit $code
fi