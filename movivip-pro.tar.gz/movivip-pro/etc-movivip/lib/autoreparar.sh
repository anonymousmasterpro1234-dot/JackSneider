#!/usr/bin/env bash
# ============================================================================
# AUTOREPARACIÓN AUTOMÁTICA DEL INSTALADOR
# Ejecuta verificaciones + reparaciones idempotentes al cierre de la instalación
# Cubre: servicios systemd, haproxy/SSL, SSH, banner HTML, binarios por arch (HCR)
# ============================================================================
BASE="/etc/movivip"
CONFIG="$BASE/config.conf"
[[ -f "$CONFIG" ]] && source "$CONFIG" || true

[[ -f "$BASE/lib/ui.sh" ]] && source "$BASE/lib/ui.sh"
[[ -f "$BASE/lib/mvui.sh" ]] && source "$BASE/lib/mvui.sh" 2>/dev/null || true
[[ -f "$BASE/languages/lang.sh" ]] && { source "$BASE/languages/lang.sh"; load_language "$(get_current_language)"; }
[[ -f "$BASE/languages/protocolos.sh" ]] && source "$BASE/languages/protocolos.sh" 2>/dev/null || true

_mv_ar_ok=0
_mv_ar_fix=0
_mv_ar_warn=0

_ar_inc_ok()   { (( _mv_ar_ok++ )); }
_ar_inc_fix()  { (( _mv_ar_fix++ )); }
_ar_inc_warn() { (( _mv_ar_warn++)); }

_ar_msg_ok()   { echo -e "  ${MV_GRN:-\e[1;92m}✔${MV_R:-\e[0m} $*"; _ar_inc_ok; }
_ar_msg_fix()  { echo -e "  ${MV_YLW:-\e[1;93m}↻${MV_R:-\e[0m} $* (corregido)"; _ar_inc_fix; }
_ar_msg_warn() { echo -e "  ${MV_DIM:-\e[1;90m}•${MV_R:-\e[0m} $*"; _ar_inc_warn; }
_ar_msg_fail() { echo -e "  ${MV_RED:-\e[1;91m}✖${MV_R:-\e[0m} $*"; }

_ar_fix_service() {
    local s="$1"; [[ -z "$s" ]] && return 0
    systemctl daemon-reload >/dev/null 2>&1 || true
    systemctl enable "$s" >/dev/null 2>&1 || true
    systemctl reset-failed "$s" >/dev/null 2>&1 || true
    if ! systemctl is-active --quiet "$s"; then
        systemctl restart "$s" >/dev/null 2>&1 || true
        sleep 0.5
    fi
    if systemctl is-active --quiet "$s"; then
        _ar_msg_fix "Servicio $s activo"
        return 0
    fi
    _ar_msg_warn "Servicio $s no pudo arrancar (revisar journalctl -u $s)"
    return 1
}

_ar_check_service() {
    local s="$1"; [[ -z "$s" ]] && return 0
    if systemctl is-active --quiet "$s"; then
        _ar_msg_ok "Servicio $s activo"
        return 0
    fi
    _ar_fix_service "$s"
}

_ar_check_banner() {
    local issue="/etc/issue.net"
    local bsh="/etc/movivip/usuarios/banner.sh"
    local sello="SISTEMA PROTEGIDO POR MOVIVIP NETWORK"
    if [[ -f "$issue" ]] && grep -Fq "$sello" "$issue" 2>/dev/null; then
        _ar_msg_ok "Banner SSH/Dropbear HTML correcto"
        return 0
    fi
    if [[ -x "$bsh" ]]; then
        bash "$bsh" --install >/dev/null 2>&1 || true
    fi
    if [[ -f "$issue" ]] && grep -Fq "$sello" "$issue" 2>/dev/null; then
        _ar_msg_fix "Banner SSH/Dropbear reinstalado"
        return 0
    fi
    _ar_msg_warn "Banner HTML no pudo verificarse (/etc/issue.net)"
    return 1
}

_ar_check_sshd() {
    if command -v sshd >/dev/null 2>&1; then
        if sshd -t >/dev/null 2>&1; then
            _ar_msg_ok "sshd_config válido"
            return 0
        fi
        _ar_msg_warn "sshd_config inválido (no se revirtió automáticamente aquí)"
        return 1
    fi
    return 0
}

_ar_check_haproxy() {
    local hcfg="/etc/haproxy/haproxy.cfg"
    if ! systemctl list-unit-files 2>/dev/null | grep -q '^haproxy\.service'; then
        return 0
    fi
    if [[ -f "$hcfg" ]] && haproxy -c -f "$hcfg" >/dev/null 2>&1; then
        _ar_msg_ok "HAProxy configuración válida"
        _ar_check_service haproxy
        return 0
    fi
    if [[ -x "$BASE/protocolos/ssl.sh" ]]; then
        bash "$BASE/protocolos/ssl.sh" --repair >/dev/null 2>&1 || true
    fi
    if [[ -f "$hcfg" ]] && haproxy -c -f "$hcfg" >/dev/null 2>&1; then
        _ar_msg_fix "HAProxy configuración reparada"
        _ar_check_service haproxy
        return 0
    fi
    _ar_msg_warn "HAProxy requiere revisión (cfg inválida)"
    _ar_check_service haproxy
    return 1
}

_ar_check_hcr() {
    [[ -f "$CONFIG" ]] && source "$CONFIG" 2>/dev/null || true
    if [[ "${HCR:-OFF}" != "ON" ]]; then
        return 0
    fi
    if [[ -x "$BASE/protocolos/hcr.sh" ]]; then
        bash "$BASE/protocolos/hcr.sh" --repair >/dev/null 2>&1 || true
    fi
    if systemctl is-active --quiet hcr 2>/dev/null; then
        _ar_msg_ok "HCR activo (multi-arch + qemu)"
        return 0
    fi
    _ar_msg_warn "HCR marcado ON pero no activo"
    return 1
}

_ar_check_ssl() {
    [[ -f "$CONFIG" ]] && source "$CONFIG" 2>/dev/null || true
    if [[ "${SSL:-OFF}" != "ON" && "${SSL_TUNNEL:-OFF}" != "ON" ]]; then
        return 0
    fi
    if [[ -x "$BASE/protocolos/ssl.sh" ]]; then
        bash "$BASE/protocolos/ssl.sh" --repair >/dev/null 2>&1 || true
    fi
    local ok_ssl=1
    ss -ltn 2>/dev/null | grep -q ':2001 ' || ok_ssl=0
    ss -ltn 2>/dev/null | grep -q ':2002 ' || ok_ssl=0
    if [[ "$ok_ssl" -eq 1 ]] && systemctl is-active --quiet haproxy 2>/dev/null; then
        _ar_msg_ok "SSL Tunnel + backends HTTPS (2001/2002) OK"
        return 0
    fi
    _ar_msg_warn "SSL Tunnel requiere verificación (backends 2001/2002 o haproxy)"
    return 1
}

_ar_check_protocols_registered() {
    for s in badvpn bhttp bot btun dtunnel hysteria openvpn shadowsocks slowdns socks5 squid xhttp ssh-ws-internal stunnel4; do
        if systemctl list-unit-files 2>/dev/null | grep -q "^${s}\.service"; then
            _ar_check_service "$s" >/dev/null 2>&1 || true
        fi
    done
}

auto_reparar() {
    echo -e "${MV_CYN:-\e[1;96m}── Autoreparación del sistema ──${MV_R:-\e[0m}"
    _mv_ar_ok=0; _mv_ar_fix=0; _mv_ar_warn=0

    _ar_check_banner
    _ar_check_sshd
    _ar_check_haproxy
    _ar_check_hcr
    _ar_check_ssl
    _ar_check_protocols_registered

    _ar_check_service haproxy 2>/dev/null || true
    _ar_check_service ssh 2>/dev/null || _ar_check_service sshd 2>/dev/null || true

    echo ""
    echo -e "${MV_WHT:-\e[1;97m}Autoreparación:${MV_R:-\e[0m} ${MV_GRN:-\e[1;92m}${_mv_ar_ok}${MV_R:-\e[0m} OK · ${MV_YLW:-\e[1;93m}${_mv_ar_fix}${MV_R:-\e[0m} corregidos · ${MV_DIM:-\e[1;90m}${_mv_ar_warn}${MV_R:-\e[0m} avisos"
    echo ""
    return 0
}
