#!/bin/bash
#====================================================================
# lib/duracion.sh — Duración días/horas/minutos
# Pregunta: 📅 Días · 🕐 Horas · ⏱ Minutos (Enter = por defecto)
#
# En CUALQUIER casilla se puede escribir con unidad o combinarla:
#     30        -> número plano, se interpreta en la unidad de la casilla
#     30m  30m  30 min  30min   -> 0 días, 0 horas, 30 minutos
#     3h   3 h   90m     1h30m   -> se reparte solo (90m = 1h30m)
#     2d   2 d
#     x / salir / volver / atras / cancelar / menu / back / q  -> cancela
#     0 ya NO cancela: 0 días es legítimo ("solo horas" o "solo minutos")
#
# Exporta:
#   DUR_DIAS  DUR_HORAS  DUR_MIN
#   DUR_FECHA (YYYY-MM-DD HH:MM:SS)   DUR_FECHA_DIA (YYYY-MM-DD)
#   DUR_TS    (epoch)                 DUR_MOSTRAR (DD/MM/YYYY HH:MM)
# Uso:   mv_ask_duracion [días_default] && echo "$DUR_FECHA"
#
# Defaults de entrada (los pone el llamador antes de llamar):
#   MV_DUR_DEF_DIAS   MV_DUR_DEF_HORAS   MV_DUR_DEF_MIN
#====================================================================

# La lib puede cargarse sin ui.sh: evita "unbound variable" bajo set -u
: "${RESET:=}${YELLOW:=}${GRAY:=}${GREEN:=}${RED:=}${CYAN:=}${BOLD:=}"

if ! declare -F trx >/dev/null 2>&1; then trx() { printf '%s' "$1"; }; fi

#---------------------------------------------------------------------
# mv_dur_parse <token> <unidad_por_defecto d|h|m>
#   Imprime "dias horas minutos" ya normalizados y desbordados.
#   Devuelve 1 si el token no se entiende.
#---------------------------------------------------------------------
mv_dur_parse() {
    local tok="${1:-}" def="${2:-d}"
    local resto num uni d=0 h=0 m=0

    resto=$(printf '%s' "$tok" \
        | tr '[:upper:]' '[:lower:]' \
        | tr -d ' \t:;,')

    # Palabras -> sufijos:  30min->30m   3horas->3h   2dias->2d
    resto="${resto//minutos/m}"; resto="${resto//minuto/m}"
    resto="${resto//mins/m}";    resto="${resto//min/m}"
    resto="${resto//horas/h}";   resto="${resto//hora/h}"
    resto="${resto//hrs/h}";     resto="${resto//hr/h}"
    resto="${resto//dias/d}";    resto="${resto//dia/d}"

    [[ -z "$resto" ]] && { echo "0 0 0"; return 0; }
    [[ "$resto" =~ ^[xy]$ ]] && return 2

    while [[ "$resto" =~ ^([0-9]+)([dhm]?) ]]; do
        num="${BASH_REMATCH[1]}"
        uni="${BASH_REMATCH[2]}"
        [[ -z "$uni" ]] && uni="$def"
        case "$uni" in
            d) d=$(( d + num )) ;;
            h) h=$(( h + num )) ;;
            m) m=$(( m + num )) ;;
        esac
        resto="${resto:${#BASH_REMATCH[0]}}"
    done

    # Sobró basura -> no se entiende
    [[ -n "$resto" ]] && return 1

    # Desbordes: 90 min -> 1h30 ;  30h -> 1d6h
    h=$(( h + m / 60 )); m=$(( m % 60 ))
    d=$(( d + h / 24 )); h=$(( h % 24 ))

    echo "$d $h $m"
    return 0
}

#---------------------------------------------------------------------
# Lee una casilla de duración, repregunta si no se entiende.
#   $1 etiqueta · $2 default · $3 unidad por defecto · $4 error a mostrar
#   Deja el resultado en la global MV_DUR_OUT="d h m"
#---------------------------------------------------------------------
mv_dur_casilla() {
    local etiqueta="$1" def="$2" uni="$3"
    local v rc

    while true; do
        read -rp "$(echo -e "${GREEN}$(printf '%s' "$etiqueta") [${def}]: ${RESET}")" v

        if [[ -z "$v" ]]; then
            MV_DUR_OUT="$(mv_dur_parse "$def" "$uni")"
            return 0
        fi

        # palabras/marcas de cancelar
        if [[ "$v" =~ ^(x|salir|volver|atras|atrás|cancelar|cancela|menu|menú|back|q)$ ]]; then
            MV_DUR_OUT=""
            return 1
        fi

        MV_DUR_OUT="$(mv_dur_parse "$v" "$uni")"; rc=$?
        if [[ $rc -eq 1 ]]; then
            echo -e "${RED}✖ $(trx 'No se entiende. Usa 30 · 30m · 3h · 1h30m')${RESET}"
            continue
        fi
        return 0
    done
}

#---------------------------------------------------------------------
mv_ask_duracion() {
    local _d _h _m nd nh nm cancel=0

    # Defaults de entrada = MV_DUR_DEF_* (los pone el llamador).
    # Deliberadamente NO se lee DUR_*: son la SALIDA de esta misma funcion,
    # y usarlos como default hacia que el valor de un alta se colase en la
    # siguiente dentro de la misma sesion.
    local DEF_DIAS="${MV_DUR_DEF_DIAS:-${1:-30}}"
    local DEF_HORAS="${MV_DUR_DEF_HORAS:-0}"
    local DEF_MIN="${MV_DUR_DEF_MIN:-0}"

    echo
    echo -e "${YELLOW}⏳ $(trx 'Duración de la cuenta')${RESET}"
    echo -e "${GRAY}  $(trx 'Enter = por defecto · sufijo opcional: 30m, 3h, 2d · combina: 1h30m')${RESET}"
    echo -e "${GRAY}  $(trx 'Escribe x para cancelar')${RESET}"

    # ── Días ────────────────────────────────────────────────────────
    mv_dur_casilla "📅 $(trx 'Días')"        "$DEF_DIAS" d || cancel=1
    read -r _d _h _m <<<"$MV_DUR_OUT"; nd=${_d:-0}; nh=${_h:-0}; nm=${_m:-0}
    [[ $cancel -eq 1 ]] && { echo -e "${YELLOW}← $(trx 'Cancelado')${RESET}"; return 1; }

    # ── Horas ───────────────────────────────────────────────────────
    mv_dur_casilla "🕐 $(trx 'Horas')"       "$DEF_HORAS" h || cancel=1
    read -r _d _h _m <<<"$MV_DUR_OUT"
    nh=$(( nh + ${_d:-0} )); nh=$(( nh + ${_h:-0} )); nm=$(( nm + ${_m:-0} ))
    [[ $cancel -eq 1 ]] && { echo -e "${YELLOW}← $(trx 'Cancelado')${RESET}"; return 1; }

    # ── Minutos ─────────────────────────────────────────────────────
    mv_dur_casilla "⏱ $(trx 'Minutos')"     "$DEF_MIN" m || cancel=1
    read -r _d _h _m <<<"$MV_DUR_OUT"
    nh=$(( nh + ${_d:-0} )); nh=$(( nh + ${_h:-0} )); nm=$(( nm + ${_m:-0} ))
    [[ $cancel -eq 1 ]] && { echo -e "${YELLOW}← $(trx 'Cancelado')${RESET}"; return 1; }

    # Desbordes finales
    nh=$(( nh + nm / 60 )); nm=$(( nm % 60 ))
    nd=$(( nd + nh / 24 )); nh=$(( nh % 24 ))

    # Una cuenta con 0 en las tres casillas nace muerta: no se permite
    if [[ "$nd" -eq 0 && "$nh" -eq 0 && "$nm" -eq 0 ]]; then
        echo -e "${RED}✖ $(trx 'La duración no puede ser 0. Pon al menos 1 minuto, o escribe x para cancelar.')${RESET}"
        mv_ask_duracion "$DEF_DIAS"
        return $?
    fi

    DUR_DIAS="$nd"; DUR_HORAS="$nh"; DUR_MIN="$nm"
    DUR_FECHA=$(date -d "+${DUR_DIAS} days +${DUR_HORAS} hours +${DUR_MIN} minutes" +"%Y-%m-%d %H:%M:%S" 2>/dev/null)
    [[ -z "$DUR_FECHA" ]] && DUR_FECHA=$(date -d "+${DUR_DIAS} days" +"%Y-%m-%d %H:%M:%S")
    DUR_FECHA_DIA=$(date -d "$DUR_FECHA" +"%Y-%m-%d" 2>/dev/null)
    DUR_TS=$(date -d "$DUR_FECHA" +%s 2>/dev/null)
    DUR_MOSTRAR=$(date -d "$DUR_FECHA" +"%d/%m/%Y %H:%M" 2>/dev/null)

    echo -e "${GRAY}   → $(trx 'Expira'):${RESET} ${CYAN}${DUR_MOSTRAR}${RESET}"
    return 0
}

# Guardar expiración exacta (USUARIO|EPOCH) para el verificador por minuto
mv_save_exp_exacta() {
    local U="$1" TS="$2"
    local CONF="${3:-/etc/movivip/sistema/expiraciones_exactas.conf}"
    [[ -z "$U" || -z "$TS" ]] && return 1
    mkdir -p "$(dirname "$CONF")" 2>/dev/null
    touch "$CONF" 2>/dev/null
    grep -v "^${U}|" "$CONF" > "$CONF.tmp" 2>/dev/null
    echo "${U}|${TS}" >> "$CONF.tmp"
    mv "$CONF.tmp" "$CONF" 2>/dev/null
    return 0
}

# Limpiar expiración exacta de un usuario
mv_clear_exp_exacta() {
    local U="$1"
    local CONF="${2:-/etc/movivip/sistema/expiraciones_exactas.conf}"
    [[ -f "$CONF" ]] && sed -i "/^${U}|/d" "$CONF" 2>/dev/null
    return 0
}