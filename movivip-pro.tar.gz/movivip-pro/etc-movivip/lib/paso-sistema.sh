#!/usr/bin/env bash
# ============================================================================
# PASO: SISTEMA BASE
# Paquetes esenciales, SSL/TLS, stunnel, firewall, limpieza, auto-update,
# SSH. Cada operación usa run_cmd/mv_correr.
# ============================================================================
set -uo pipefail

# Cargar gate de plan. No requiere que ningun guard este cargado antes: la
# validacion de licencia la hace ahora el binario, en cada script, y este paso
# solo consulta el plan que la licencia permite.
if [[ -f "${BASE:-/etc/movivip}/lib/plancheck.sh" ]]; then
    # shellcheck source=/dev/null
    source "${BASE:-/etc/movivip}/lib/plancheck.sh"
fi

# ---------------------------------------------------------------------------
# Helpers internos (no expuestos globalmente)
# ---------------------------------------------------------------------------
_sistema_pkg_update() {
    pkg_update
}

_sistema_pkg_install() {
    pkg_install "$@"
}

# ---------------------------------------------------------------------------
# Gate interno: ¿este plan incluye funciones avanzadas? (firewall)
# ---------------------------------------------------------------------------
_sistema_es_proveedor() {
    if declare -F es_proveedor >/dev/null 2>&1; then
        es_proveedor
    else
        # Fallback si plancheck no está disponible: asumir proveedor (compatibilidad)
        return 0
    fi
}

# ---------------------------------------------------------------------------
# 1. Actualizar repos e instalar paquetes base
# ---------------------------------------------------------------------------
sistema_paquetes_base() {
    run_cmd "Actualizando repositorios" "$LINENO" "_sistema_pkg_update"
    local base="curl wget gnupg2 ca-certificates lsb-release apt-transport-https \
        software-properties-common jq net-tools iproute2 ipset iptables \
        cron systemd-sysv ufw htop vim nano tar gzip unzip bzip2 \
        xz-utils zstd pigz pbzip2 lz4 rsync socat openssl"
    run_cmd "Paquetes esenciales" "$LINENO" "_sistema_pkg_install $base"
}

# ---------------------------------------------------------------------------
# 2. SSL/TLS + Crom + python3 (uno por uno; el motor SSL lo instala ssl.sh)
# ---------------------------------------------------------------------------
sistema_ssl_haproxy() {
    # OJO: "crom" NO es paquete apt (es el gestor interno /etc/crom/crom.conf
    # de abajo). Meterlo en el apt-get tumbaba la línea entera. Cada cosa por
    # separado: 1) motor SSL, 2) python3, 3) config crom.
    run_cmd "Instalando motor SSL" "$LINENO" "_sistema_pkg_install haproxy"
    run_cmd "Instalando python3" "$LINENO" "_sistema_pkg_install python3"
    # Resiliencia del servicio la configura ssl.sh (ensure_haproxy_resilience)
    # con el drop-in correcto ([Unit], no [Service]).

    # Crom: gestor de certificados SSL/TLS automatizado (config, no paquete)
    run_cmd "Configurando Crom (SSL auto)" "$LINENO" \
        "mkdir -p /etc/crom && \
        cat > /etc/crom/crom.conf << 'CROMEOF'
# Configuración Crom - JackSneider
domain = \"\${SERVER_DOMAIN}\"
email = \"admin@\${SERVER_DOMAIN}\"
ca = \"letsencrypt\"
key_type = \"rsa4096\"
renew_days = 30
reload_cmd = \"systemctl reload haproxy\"
CROMEOF
        chmod 600 /etc/crom/crom.conf"
}

# ---------------------------------------------------------------------------
# 3. stunnel4
# ---------------------------------------------------------------------------
sistema_stunnel() {
    run_cmd "Instalando stunnel4" "$LINENO" "_sistema_pkg_install stunnel4"
    run_cmd "Configurando directorio stunnel" "$LINENO" \
        "mkdir -p /run/stunnel4 && chown stunnel4:stunnel4 /run/stunnel4"
    run_cmd "Habilitando stunnel4" "$LINENO" "systemctl enable stunnel4"
    run_cmd "Iniciando stunnel4" "$LINENO" "systemctl restart stunnel4"
}

# ---------------------------------------------------------------------------
# 4. Firewall UDP (configuración específica del proyecto)
# ---------------------------------------------------------------------------
sistema_firewall_udp() {
    # Esta función es un stub — la lógica real está en protocolos/ o en el paso de firewall
    # Se mantiene por compatibilidad con el flujo original
    :
}

# ---------------------------------------------------------------------------
# 5. Firewall de seguridad (iptables persistente) — SOLO PROVEEDORES
# ---------------------------------------------------------------------------
sistema_firewall() {
    if ! _sistema_es_proveedor; then
        mv_detalle "Firewall avanzado saltado: plan ${LIC_PLAN:-desconocido} no incluye esta función."
        return 0
    fi
    run_cmd "Instalando iptables" "$LINENO" "_sistema_pkg_install iptables iptables-persistent netfilter-persistent"
    run_cmd "Forzando rehash PATH" "$LINENO" "hash -r"
    run_cmd "Creando cadena MOVIVIP_OUT" "$LINENO" \
        "iptables -N MOVIVIP_OUT 2>/dev/null; \
         iptables -C OUTPUT -j MOVIVIP_OUT 2>/dev/null || iptables -I OUTPUT 1 -j MOVIVIP_OUT"
    # Reglas base: SSH, HTTP, HTTPS, puertos VPN
    run_cmd "Reglas base firewall" "$LINENO" \
        "iptables -A MOVIVIP_OUT -p tcp --dport 22 -j ACCEPT; \
         iptables -A MOVIVIP_OUT -p tcp --dport 80 -j ACCEPT; \
         iptables -A MOVIVIP_OUT -p tcp --dport 443 -j ACCEPT; \
         iptables -A MOVIVIP_OUT -p tcp --dport 54321 -j ACCEPT; \
         iptables -A MOVIVIP_OUT -p tcp --dport 8012 -j ACCEPT"
    run_cmd "Persistencia de reglas" "$LINENO" \
        "mkdir -p /etc/iptables; iptables-save > /etc/iptables/rules.v4; \
         netfilter-persistent save 2>/dev/null || true"
    run_cmd "Habilitando persistencia de red" "$LINENO" \
        "chmod +x /etc/movivip/scripts/boot-network.sh 2>/dev/null; \
         systemctl daemon-reload; \
         systemctl enable movivip-boot-network.service 2>/dev/null || true"
}

# ---------------------------------------------------------------------------
# 6. Mantenimiento seguro (cron cada 6 horas; el script evita solapamientos)
# ---------------------------------------------------------------------------
sistema_limpieza_auto() {
    run_cmd "Creando directorio de scripts" "$LINENO" "mkdir -p /etc/movivip/scripts"
    # auto-cleanup.sh ya existe en payload/scripts/ y se copia en el staging
    run_cmd "Configurando cron auto-cleanup" "$LINENO" \
        "chmod +x /etc/movivip/scripts/auto-cleanup.sh 2>/dev/null; \
         (crontab -l 2>/dev/null | grep -v 'auto-cleanup'; \
          echo '0 */6 * * * bash /etc/movivip/scripts/auto-cleanup.sh >/dev/null 2>&1') | crontab -"
}

# ---------------------------------------------------------------------------
# 7. Auto-update (cada 2 días)
# ---------------------------------------------------------------------------
sistema_auto_update() {
    run_cmd "Configurando cron auto-update" "$LINENO" \
        "chmod +x /etc/movivip/auto-update.sh 2>/dev/null; \
         (crontab -l 2>/dev/null | grep -v 'auto-update'; \
          echo '0 3 */2 * * bash /etc/movivip/auto-update.sh >/dev/null 2>&1') | crontab -"
    run_cmd "Configurando cron expira-exacta (minuto)" "$LINENO" \
        "chmod +x /etc/movivip/scripts/expira-exacta.sh 2>/dev/null; \
         (crontab -l 2>/dev/null | grep -v 'expira-exacta'; \
          echo '* * * * * bash /etc/movivip/scripts/expira-exacta.sh >/dev/null 2>&1') | crontab -"
}

# ---------------------------------------------------------------------------
# 8. Guardar valores de red
# ---------------------------------------------------------------------------
sistema_guardar_red() {
    run_cmd "Guardando valores de red" "$LINENO" \
        "mkdir -p /etc/movivip/sistema; \
         ip -j addr show > /etc/movivip/sistema/ip_addr.json 2>/dev/null || true; \
         ip -j route show > /etc/movivip/sistema/ip_route.json 2>/dev/null || true"
}

# ---------------------------------------------------------------------------
# 9. Verificar recursos
# ---------------------------------------------------------------------------
sistema_verificar_recursos() {
    run_cmd "Verificando recursos" "$LINENO" \
        "df -h / | tail -1; free -h | head -2; uptime"
}

# ---------------------------------------------------------------------------
# 10. OpenSSH
# ---------------------------------------------------------------------------
sistema_ssh() {
    run_cmd "Instalando openssh-server" "$LINENO" "_sistema_pkg_install openssh-server"
    run_cmd "Habilitando servicio SSH" "$LINENO" "systemctl enable ssh"
    run_cmd "Reiniciando servicio SSH" "$LINENO" "systemctl restart ssh"
}

# ---------------------------------------------------------------------------
# Orquestador del paso sistema
# ---------------------------------------------------------------------------
paso_sistema() {
    mv_fase "Configuración del sistema base"

    # Estas funciones son idempotentes: si ya están hechas, run_cmd saldrá rápido
    sistema_paquetes_base
    sistema_ssl_haproxy
    sistema_stunnel
    sistema_firewall
    sistema_limpieza_auto
    sistema_auto_update
    sistema_guardar_red
    sistema_verificar_recursos
    sistema_ssh

    mv_ok "Sistema base configurado"
}