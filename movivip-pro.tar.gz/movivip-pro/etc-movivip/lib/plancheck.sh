#!/usr/bin/env bash
# ============================================================================
# LIB: PLAN CHECK
# Consulta el plan de la licencia actual y expone funciones para gates por tier.
#
# Antes se sourceaba despues de lib/licguard.sh, asi que la licencia ya estaba
# validada cuando este fichero se ejecutaba. Ese sourceo desaparecio al migrar
# los scripts del panel a /usr/local/bin/movivip-guard --gate, y con el tambien
# la dependencia: este fichero ya no necesita que nadie haya comprobado nada
# antes. Sigue siendo cierto que solo se usa en caminos ya validados, pero
# porque lo decide quien llama, no porque este fichero lo exija.
# ============================================================================
set -uo pipefail

# Caché del resultado para no llamar al binario repetidamente
__MV_PLAN_CACHE="${MV_PLAN_CACHE:-/etc/movivip/.plan_cache}"
__MV_LIC_FILE="${MV_LIC_FILE:-/etc/movivip/licencia.conf}"

# Planes con privilegios de proveedor/admin (acceso a Facturación, 3X-UI, Web MoviVIP)
PROVEEDOR_PLANES="admin super empresarial"
PROVEEDOR_TIPOS="admin superadmin super empresarial"

# Planes Premium+ (incluye las etiquetas A/B del gate heredado de CDN)
PREMIUM_PLANES="a b premium vitalicio vitalicia"
PREMIUM_TIPOS="premium"

# ---------------------------------------------------------------------------
# Obtiene el plan y tipo de la licencia actual (consulta al firmador con cache)
# Devuelve: PLAN_TIER="premium|vitalicio|..." y TIPO="admin|cliente|..."
# ---------------------------------------------------------------------------
plan_obtener() {
    local cache_age=0
    local key key_hash cached_key_hash
    key=$(sed -n 's/^KEY=//p' "$__MV_LIC_FILE" 2>/dev/null | head -n1 | tr -d '"')
    if [[ -n "$key" ]]; then
        key_hash=$(printf '%s' "$key" | sha256sum | awk '{print $1}')
    else
        key_hash=""
    fi
    if [[ -f "$__MV_PLAN_CACHE" ]]; then
        local now
        now=$(date +%s)
        local cached
        cached=$(stat -c %Y "$__MV_PLAN_CACHE" 2>/dev/null || echo 0)
        cache_age=$(( now - cached ))
    fi

    # Cache de 15 minutos (900s) atada a la key, para no preguntar al
    # firmador en cada consulta de plan.
    if [[ -n "$key_hash" && -f "$__MV_PLAN_CACHE" ]] \
        && (( cache_age < 900 && cache_age > 0 )); then
        # shellcheck source=/dev/null
        source "$__MV_PLAN_CACHE"
        cached_key_hash="${LIC_KEY_HASH:-}"
        if [[ "$cached_key_hash" == "$key_hash" ]]; then
            return 0
        fi
    fi

    local bin
    bin="${MV_LIC_BIN:-/usr/local/bin/movivip-lic}"
    [[ -x "$bin" ]] || bin="/etc/movivip/bin/movivip-lic"
    [[ -x "$bin" ]] || bin=$(command -v movivip-lic 2>/dev/null || true)

    if [[ ! -x "$bin" ]]; then
        return 1
    fi

    local out ok
    if ! out=$("$bin" --gate --json 2>/dev/null); then
        return 1
    fi
    if [[ -z "$out" ]]; then
        return 1
    fi

    # Parseo simple sin depender de jq
    local plan tipo
    ok=$(echo "$out" | sed -n 's/.*"ok"[[:space:]]*:[[:space:]]*\(true\|false\).*/\1/p')
    [[ "$ok" == "true" ]] || return 1
    plan=$(echo "$out" | sed -n 's/.*"plan"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
    tipo=$(echo "$out" | sed -n 's/.*"tipo"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')

    export LIC_PLAN="${plan:-desconocido}"
    export LIC_TIPO="${tipo:-desconocido}"

    # La cache local debe seguir a la key activa, no solo a su antigüedad.
    if [[ -n "$key_hash" ]]; then
        mkdir -p "$(dirname "$__MV_PLAN_CACHE")"
        {
            printf 'LIC_KEY_HASH=%q\n' "$key_hash"
            printf 'export LIC_PLAN=%q\n' "$LIC_PLAN"
            printf 'export LIC_TIPO=%q\n' "$LIC_TIPO"
        } > "$__MV_PLAN_CACHE"
        chmod 600 "$__MV_PLAN_CACHE"
    fi
}

# ---------------------------------------------------------------------------
# ¿El plan actual tiene privilegios de proveedor/admin?
# Uso: if es_proveedor; then ... fi
# ---------------------------------------------------------------------------
es_proveedor() {
    plan_obtener || return 1
    local p="${LIC_PLAN,,}" t="${LIC_TIPO,,}"
    case " $PROVEEDOR_PLANES " in
        *" $p "*) return 0 ;;
    esac
    case " $PROVEEDOR_TIPOS " in
        *" $t "*) return 0 ;;
    esac
    return 1
}

# ---------------------------------------------------------------------------
# ¿El plan actual es Premium+ (Bot, Webmin)?
# ---------------------------------------------------------------------------
es_premium() {
    plan_obtener || return 1
    local p="${LIC_PLAN,,}" t="${LIC_TIPO,,}"
    case " $PREMIUM_PLANES " in
        *" $p "*) return 0 ;;
    esac
    case " $PREMIUM_TIPOS " in
        *" $t "*) return 0 ;;
    esac
    return 1
}

# ---------------------------------------------------------------------------
# ¿Es plan Bronce/Plata/standard (sin optimizaciones avanzadas)?
# ---------------------------------------------------------------------------
es_bronze() {
    plan_obtener || return 1
    local p="${LIC_PLAN,,}"
    case "$p" in
        bronze|bronce|plata|platino|platinum|standard|basico|basica) return 0 ;;
        *) return 1 ;;
    esac
}

# ---------------------------------------------------------------------------
# Gate para funcionalidades de proveedor/admin
# Uso: proveedor_gate || return 1
# ---------------------------------------------------------------------------
proveedor_gate() {
    if ! es_proveedor; then
        mv_error "Esta función requiere plan proveedor/admin (admin, super, empresarial). Plan actual: ${LIC_PLAN:-desconocido}"
        return 1
    fi
}

# ---------------------------------------------------------------------------
# Gate para funcionalidades Premium+ (Bot, Webmin)
# ---------------------------------------------------------------------------
premium_gate() {
    if ! es_premium && ! es_proveedor; then
        mv_error "Esta función requiere plan Premium o superior (premium, vitalicia/vitalicio, admin, super, empresarial). Plan actual: ${LIC_PLAN:-desconocido}"
        return 1
    fi
}