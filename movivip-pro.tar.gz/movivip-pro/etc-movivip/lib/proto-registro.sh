#!/usr/bin/env bash
# ============================================================================
# REGISTRO DE PROTOCOLOS
# ----------------------------------------------------------------------------
# Guarda que protocolos se instalaron de verdad, cual fallo y cual quedo
# pendiente por falta de datos del usuario.
#
# Por que existe esto:
#
# El instalador tenia un menu de protocolos que mientia. proto_instalar ejecutaba
# "bash script --install || true", o sea que cualquier fallo se quedaba en el
# aire, y al final paso_protocolos imprimia "Protocolos instalados" y devolvia
# 0. El instalador entero se daba por bueno. Un cliente que paga recibia
# "instalado correctamente" sin un solo protocolo funcionando, y ni el usuario
# ni el soporte podian saber cual habia fallado: no habia registro de nada.
#
# Este fichero es ese registro. El resumen final lo lee, y por eso ahora puede
# listar los protocolos reales en vez de un "Instalado correctamente" generico.
#
# Formato del estado, TSV, un protocolo por linea:
#
#     <protocolo>\t<estado>\t<detalle>
#
# Estados posibles:
#
#     instalado  Se instalo y el script devolvio 0.
#     pendiente  Se necesita un dato del usuario que aun no se ha dado.
#                No es un fallo del script: es que no se le pudo preguntar.
#     fallo      El script se ejecuto y devolvio algo distinto de 0.
#     omitido    El plan actual no da acceso, o el usuario lo pidio omitirlo.
#
# Solo se admiten esos cuatro estados. proto_reg_registrar valida y rechaza
# cualquier otro, porque un estado mal escrito se cuela en el resumen final y
# vuelve a mentir, que es justo lo que este fichero viene a evitar.
# ============================================================================
set -uo pipefail

# Fichero de estado. Donde viven ya los .conf de estado del sistema, para no
# inventar un sitio nuevo que nadie vaya a leer.
PROTO_REG_DIR="${BASE:-/etc/movivip}/sistema"
PROTO_REG_FILE="${PROTO_REG_DIR}/protocolos.estado"

# Estados validos, para validar en un solo sitio.
PROTO_REG_ESTADOS=(instalado pendiente fallo omitido)

# ----------------------------------------------------------------------------
# proto_reg_file: ruta del fichero de estado
# ----------------------------------------------------------------------------
proto_reg_file() {
    printf '%s\n' "$PROTO_REG_FILE"
}

# ----------------------------------------------------------------------------
# proto_reg_asegurar: crear el directorio y el fichero si no existen
# ----------------------------------------------------------------------------
proto_reg_asegurar() {
    [[ -d "$PROTO_REG_DIR" ]] || mkdir -p "$PROTO_REG_DIR" || return 1
    [[ -f "$PROTO_REG_FILE" ]] || : > "$PROTO_REG_FILE" || return 1
    return 0
}

# ----------------------------------------------------------------------------
# proto_reg_limpiar_detalle: dejar el detalle en una sola linea, sin pestanas
#
# El detalle viene de codigo de salida y de texto de error, que puede traer
# saltos de linea y tabuladores. En un TSV eso parte la linea en varias y
# corrompe el registro entero.
# ----------------------------------------------------------------------------
proto_reg_limpiar_detalle() {
    local d="${1:-}"
    d="${d//$'\t'/ }"
    d="${d//$'\n'/ }"
    d="${d//$'\r'/ }"
    # Recortar a 200 caracteres: el resumen final es una pantalla, no un log.
    printf '%s' "$d" | cut -c1-200
}

# ----------------------------------------------------------------------------
# proto_reg_registrar: proto estado [detalle]
#
# Reescribe el fichero entero en vez de anadir al final. Asi un protocolo
# reinstallado queda con una sola linea y no con dos contradictorias, que es lo
# que pasa si simplemente se hace append.
# ----------------------------------------------------------------------------
proto_reg_registrar() {
    local proto="${1:-}" estado="${2:-}" detalle="${3:-}"

    [[ -n "$proto" ]] || return 1

    # Validar estado. Un estado no permitido se rechaza en vez de guardarse.
    local valido=0 e
    for e in "${PROTO_REG_ESTADOS[@]}"; do
        [[ "$estado" == "$e" ]] && { valido=1; break; }
    done
    (( valido )) || return 1

    detalle="$(proto_reg_limpiar_detalle "$detalle")"
    proto_reg_asegurar || return 1

    local tmp
    tmp="$(mktemp "${PROTO_REG_FILE}.XXXXXX" 2>/dev/null)" || return 1

    # Reutilizar las lineas de los demas protocolos.
    local p estado_prev detalle_prev
    while IFS=$'\t' read -r p estado_prev detalle_prev; do
        [[ -z "${p:-}" ]] && continue
        [[ "$p" == "$proto" ]] && continue
        printf '%s\t%s\t%s\n' "$p" "$estado_prev" "${detalle_prev:-}" >> "$tmp"
    done < "$PROTO_REG_FILE"

    printf '%s\t%s\t%s\n' "$proto" "$estado" "$detalle" >> "$tmp"

    # mv es atomico en el mismo sistema de ficheros: nunca queda un registro a
    # medias si algo se corta a mitad de la escritura.
    mv -f "$tmp" "$PROTO_REG_FILE"
}

# ----------------------------------------------------------------------------
# proto_reg_quitar: borrar un protocolo del registro
# ----------------------------------------------------------------------------
proto_reg_quitar() {
    local proto="${1:-}"
    [[ -n "$proto" && -f "$PROTO_REG_FILE" ]] || return 0
    proto_reg_registrar "$proto" omitido "retirado del registro" >/dev/null 2>&1
}

# ----------------------------------------------------------------------------
# proto_reg_listar: volcar el registro completo como "proto\testado\tdetalle"
# ----------------------------------------------------------------------------
proto_reg_listar() {
    [[ -f "$PROTO_REG_FILE" ]] || return 0
    local p e d
    while IFS=$'\t' read -r p e d; do
        [[ -z "${p:-}" ]] && continue
        printf '%s\t%s\t%s\n' "$p" "$e" "${d:-}"
    done < "$PROTO_REG_FILE"
}

# ----------------------------------------------------------------------------
# proto_reg_por_estado: volcar solo los que estan en un estado concreto
# ----------------------------------------------------------------------------
proto_reg_por_estado() {
    local estado="${1:-}"
    [[ -f "$PROTO_REG_FILE" ]] || return 0
    local p e d
    while IFS=$'\t' read -r p e d; do
        [[ -z "${p:-}" ]] && continue
        [[ "$e" == "$estado" ]] || continue
        printf '%s\n' "$p"
    done < "$PROTO_REG_FILE"
}

# ----------------------------------------------------------------------------
# proto_reg_cuenta: numero de protocolos en un estado
# ----------------------------------------------------------------------------
proto_reg_cuenta() {
    local estado="${1:-}"
    local n=0 p e d
    [[ -f "$PROTO_REG_FILE" ]] || { printf '0\n'; return 0; }
    while IFS=$'\t' read -r p e d; do
        [[ -z "${p:-}" ]] && continue
        [[ "$e" == "$estado" ]] && n=$(( n + 1 ))
    done < "$PROTO_REG_FILE"
    printf '%d\n' "$n"
}

# ----------------------------------------------------------------------------
# proto_reg_no_instalados: protocolos que no llegaron a instalarse
#
# Es la lista que se reintenta al volver a ejecutar el instalador. Include
# pendiente y fallo a proposito: si algo fallo por un motivo transitorio (una
# descarga que se corto, un paquete que aun no estaba) tiene que tener otra
# oportunidad, no quedar abandonado para siempre.
# ----------------------------------------------------------------------------
proto_reg_no_instalados() {
    local p e d
    [[ -f "$PROTO_REG_FILE" ]] || return 0
    while IFS=$'\t' read -r p e d; do
        [[ -z "${p:-}" ]] && continue
        case "$e" in
            instalado|omitido) continue ;;
        esac
        printf '%s\n' "$p"
    done < "$PROTO_REG_FILE"
}