#!/bin/bash
# =========================================================
#   MOVIVIP NETWORK — LIMPIADOR CRLF GLOBAL (rápido)
#   Normaliza TODOS los .sh de la base a LF.
#   v2: con marcador de estado — las ejecuciones repetidas salen
#   en milisegundos si el árbol no cambió (antes escaneaba todo
#   el árbol en CADA apertura del menú y parecía colgado).
# =========================================================

MV_BASE="${MV_BASE:-/etc/movivip}"
MV_CRLF_STATE="$MV_BASE/.crlf-state"

# Huella barata del árbol: cantidad + bytes + mtime máximo de los .sh.
_crlf_huella() {
    find "$1" -type f -name '*.sh' -printf '%s %T@\n' 2>/dev/null | awk '{n++; s+=$1; if($2>m)m=$2} END{print n":"s":"m}'
}

fix_crlf_all() {
    local base="$MV_BASE"
    [[ -d "$base" ]] || return 0
    local huella
    huella=$(_crlf_huella "$base")
    if [[ -f "$MV_CRLF_STATE" ]] && [[ "$(cat "$MV_CRLF_STATE" 2>/dev/null)" == "$huella" ]]; then
        return 0
    fi
    local f tmp
    while IFS= read -r -d '' f; do
        [[ -f "$f" && -w "$f" ]] || continue
        # grep -l para al primer CR (mucho más rápido que wc+tr del árbol)
        if grep -q $'\r' "$f" 2>/dev/null; then
            tmp=$(mktemp "$f.fix.XXXXXX" 2>/dev/null) || continue
            tr -d '\r' < "$f" > "$tmp" 2>/dev/null || { rm -f "$tmp"; continue; }
            chmod --reference="$f" "$tmp" 2>/dev/null || chmod 755 "$tmp" 2>/dev/null
            mv -f "$tmp" "$f" 2>/dev/null
            rm -f "$tmp" 2>/dev/null
        fi
    done < <(find "$base" -type f -name '*.sh' -print0 2>/dev/null)
    printf '%s' "$huella" > "$MV_CRLF_STATE" 2>/dev/null
    return 0
}

# Ejecutar de inmediato si se invoca directamente
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    fix_crlf_all
fi
