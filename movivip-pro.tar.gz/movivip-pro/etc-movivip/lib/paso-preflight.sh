#!/usr/bin/env bash
# ============================================================================
# PASO: PREFLIGHT
# Validaciones previas a la instalación. Fail-fast: si algo no cumple,
# la instalación se aborta con mensaje claro (mv_error) y código de salida != 0.
# ============================================================================
set -uo pipefail

ARCH_LIB="${BASE:-/etc/movivip}/lib/arch.sh"
if [[ ! -f "$ARCH_LIB" ]] || ! source "$ARCH_LIB"; then
    mv_error "Falta o no se pudo cargar la librería de arquitecturas: $ARCH_LIB"
    return 1
fi

# Estado de preflight para idempotencia
PREFLIGHT_STATE="/etc/movivip/.preflight_done"

preflight_ya_hecho() {
    [[ -f "$PREFLIGHT_STATE" ]]
}

preflight_marcar_hecho() {
    mkdir -p "$(dirname "$PREFLIGHT_STATE")"
    date '+%Y-%m-%d %H:%M:%S' > "$PREFLIGHT_STATE"
}

# ---------------------------------------------------------------------------
# 1. Root
# ---------------------------------------------------------------------------
preflight_root() {
    if (( EUID != 0 )); then
        mv_error "La instalación debe ejecutarse como root (sudo)."
        return 1
    fi
}

# ---------------------------------------------------------------------------
# 2. SO y versión
# ---------------------------------------------------------------------------
preflight_os() {
    local release
    if [[ ! -f /etc/os-release ]]; then
        mv_error "No se pudo detectar la distribución (/etc/os-release ausente)."
        return 1
    fi
    # shellcheck source=/dev/null
    source /etc/os-release
    case "${ID:-}" in
        ubuntu)
            local v="${VERSION_ID%%.*}"
            if (( v < 20 )); then
                mv_error "Ubuntu ${VERSION_ID} no soportado. Mínimo: 20.04 LTS."
                return 1
            fi
            ;;
        debian)
            local v="${VERSION_ID%%.*}"
            if (( v < 11 )); then
                mv_error "Debian ${VERSION_ID} no soportado. Mínimo: 11 (bullseye)."
                return 1
            fi
            ;;
        *)
            mv_warn "Distribución no probada: ${PRETTY_NAME:-desconocida}. Continuando bajo tu responsabilidad."
            ;;
    esac
    export DISTRO_ID="${ID:-unknown}"
    export DISTRO_VERSION="${VERSION_ID:-unknown}"
}

# ---------------------------------------------------------------------------
# 3. Arquitectura
# ---------------------------------------------------------------------------
preflight_arch() {
    local raw="${MOVIVIP_ARCH_OVERRIDE:-$(uname -m 2>/dev/null)}"
    local arch
    arch="$(mv_detect_arch "${MOVIVIP_ARCH_OVERRIDE:-}")" || {
        mv_error "Arquitectura no reconocida: $raw."
        mv_detalle "Soportadas: amd64, 386, armv5/6/7, armhf, arm64, riscv64, loong64, s390x, mips/mipsle/mips64/mips64le, ppc64/ppc64le."
        return 1
    }
    export ARCH="$arch"
    export MOVIVIP_ARCH="$arch"
}

# ---------------------------------------------------------------------------
# 4. Memoria RAM
# ---------------------------------------------------------------------------
preflight_memoria() {
    local mem_kb
    mem_kb=$(awk '/MemTotal/ {print $2}' /proc/meminfo 2>/dev/null || echo 0)
    local mem_mb=$(( mem_kb / 1024 ))
    if (( mem_mb < 512 )); then
        mv_error "RAM insuficiente: ${mem_mb} MB (mínimo 512 MB)."
        return 1
    fi
    export RAM_MB="$mem_mb"
}

# ---------------------------------------------------------------------------
# 5. Disco libre en /
# ---------------------------------------------------------------------------
preflight_disco() {
    local free_kb
    free_kb=$(df -k / | awk 'NR==2 {print $4}')
    local free_gb=$(( free_kb / 1024 / 1024 ))
    if (( free_gb < 2 )); then
        mv_error "Espacio libre insuficiente en /: ${free_gb} GB (mínimo 2 GB)."
        return 1
    fi
    export DISK_FREE_GB="$free_gb"
}

# ---------------------------------------------------------------------------
# 6. Conectividad de red (salida a Internet)
# ---------------------------------------------------------------------------
# Un solo curl con timeout corto no basta: en VPS recien arrancados el
# resolved todavia no ha hidratado el cache AAAA/A y el primer intento
# muere aunque la red este perfecta. Ademas hay VPS con IPv6 roto (solo
# link-local) donde el resolver devuelve AAAA primero y curl se queda
# esperando la conexion v6 hasta agotar el timeout.
#
# Estrategia: 3 pasadas, cada una prueba varios objetivos, y cada objetivo
# se intenta primero IPv4 (-4, que es lo que siempre funciona) y luego
# dual-stack. Solo si TODAS las pasadas fallan hay un problema real.
preflight_red() {
    local urls=(
        "https://1.1.1.1"          # IP directa: ni siquiera necesita DNS
        "https://cloudflare.com"   # nombre normal
        "https://google.com"       # respaldo DNS distinto
    )
    local intento paso fallo=""
    for intento in 1 2 3; do
        for url in "${urls[@]}"; do
            if curl -4 -s --max-time 8 --head "$url" >/dev/null 2>&1; then
                return 0
            fi
            if curl -s --max-time 8 --head "$url" >/dev/null 2>&1; then
                return 0
            fi
            fallo="$url"
        done
        # Pausa creciente: 2s, 4s (le da tiempo al resolved a hidratarse)
        sleep $(( intento * 2 ))
    done
    mv_error "Sin conectividad a Internet tras 3 intentos (ultimo objetivo: $fallo)."
    mv_detalle "Prueba manual: curl -4 -I https://1.1.1.1 — si eso falla, el problema es del VPS/proveedor."
    return 1
}

# ---------------------------------------------------------------------------
# 7. Puertos críticos libres
# ---------------------------------------------------------------------------
# El 22 NO se lista: es el SSH con el que el administrador esta conectado
# a la propia VPS, siempre esta en uso y el aviso era un falso positivo
# garantizado que solo generaba ruido y desconfianza.
preflight_puertos() {
    local ports=(80 443 54321 8012)
    local busy=()
    for p in "${ports[@]}"; do
        if ss -ltn "sport = :$p" 2>/dev/null | grep -q ":$p "; then
            busy+=("$p")
        fi
    done
    if (( ${#busy[@]} > 0 )); then
        mv_warn "Puertos ya en uso: ${busy[*]}. La instalación continuará pero puede haber conflictos."
    fi
}

# ---------------------------------------------------------------------------
# 8. Conflictos con instalación previa
# ---------------------------------------------------------------------------
preflight_conflictos() {
    if [[ -d /etc/movivip && -f /etc/movivip/version.txt ]]; then
        local prev
        prev=$(cat /etc/movivip/version.txt 2>/dev/null || echo "desconocida")
        mv_warn "Instalación previa detectada (versión $prev). Se actualizará in-place."
        export MOVIVIP_UPDATE=1
    else
        export MOVIVIP_UPDATE=0
    fi
}

# ---------------------------------------------------------------------------
# Orquestador del preflight
# ---------------------------------------------------------------------------
paso_preflight() {
    if preflight_ya_hecho; then
        mv_detalle "Preflight ya completado en ejecución anterior — saltando."
        return 0
    fi
    mv_fase "Validaciones previas (preflight)"

    local checks=(
        preflight_root
        preflight_os
        preflight_arch
        preflight_memoria
        preflight_disco
        preflight_red
        preflight_puertos
        preflight_conflictos
    )
    local failed=0
    for chk in "${checks[@]}"; do
        if ! "$chk"; then
            failed=1
        fi
    done
    if (( failed )); then
        mv_error "Preflight falló. Corrige los problemas arriba y reintenta."
        return 1
    fi
    preflight_marcar_hecho
    mv_ok "Preflight completado correctamente"
}