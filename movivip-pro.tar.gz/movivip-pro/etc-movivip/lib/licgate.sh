#!/bin/bash
# ============================================================
#  JackSneider - LICENSE GATE (adaptador)
#  -------------------------------------------------------------
#  Uso: licgate.sh check | check-bots | enforce | enforce-license | status
#    check      -> licencia activa (sin comprobar plan)
#    check-bots -> licencia activa y plan elegible para Telegram
#    enforce    -> invalida/no elegible: stop+mask bots | valida: restaura
#    status  -> muestra estado completo
#
#  ANTES: este archivo hacia `. /etc/movivip/licencia.conf` (archivo
#  editable por el cliente → ejecución de código como root), consultaba
#  Firebase con curl y parseaba el JSON con grep. La gracia de 72h la
#  manejaba un `stat` sobre un archivo que el propio cliente podía
#  escribir: bastaba `touch -d 'ahora' /etc/movivip/.lic_lastok` para
#  resetear la gracia.
#
#  AHORA: la decisión la toma `movivip-lic`, que verifica la firma y el
#  HWID. Aquí no queda ninguna
#  decisión de licencia: solo formatea el resultado y ejecuta la
#  acción de bloqueo, que es de systemd y sí sigue siendo de este
#  archivo.
#
# La consulta viva distingue licencia activa, Bronce por una falla
# temporal, modo consulta al vencer Bronce/regalo, y licencias invalidas.
# ============================================================
# ── i18n shim (auto) ───────────────────────────────
if ! declare -F trx >/dev/null 2>&1; then trx() { printf '%s' "$1"; }; fi
# ─────────────────────────────────────────────────────────
BASE="/etc/movivip"
LIC="$BASE/licencia.conf"
STAMP="$BASE/.lic_lastok"          # solo por compatibilidad de lectura
STATE_DIR="/var/lib/movivip/licgate"

mv_lic_bin() {
    local c
    for c in "${MV_LIC_BIN:-}" /usr/local/bin/movivip-lic \
             "$BASE/bin/movivip-lic" /etc/movivip/movivip-lic; do
        [ -n "$c" ] && [ -x "$c" ] && { printf '%s' "$c"; return 0; }
    done
    c="$(command -v movivip-lic 2>/dev/null || true)"
    [ -n "$c" ] && { printf '%s' "$c"; return 0; }
    return 1
}

# Lee un campo LIC_* de la salida del validador, sin eval.
_field() {
    local out="$1" want="$2" k v
    while IFS= read -r l; do
        k="${l%%=*}"; [[ "$k" == "$want" ]] || continue
        v="${l#*=}"
        case "$v" in \"*\") v="${v#\"}"; v="${v%\"}" ;; esac
        printf '%s' "$v"; return 0
    done <<<"$out"
    return 0
}

#  check_lic: 0 = validada o Bronce, 1 = no válida. El texto va a MV_MSG.
check_lic() {
    local bin out rc key detalle
    MV_MSG=""; MV_KEY=""; MV_PLAN=""; MV_TIPO=""

    if ! bin="$(mv_lic_bin)"; then
        MV_MSG="movivip-lic no esta instalado"
        return 1
    fi

    # --gate usa la caché firmada y solo refresca en su intervalo. Este
    # La consulta del watchdog es directa y se ejecuta con poca frecuencia;
    # los scripts de actividad usan --gate para aprovechar su cache breve.
    out="$("$bin" --gate 2>/dev/null)"
    rc=$?
    key="$(_field "$out" LIC_KEY)"
    detalle="$(_field "$out" LIC_DETALLE)"
    MV_KEY="$key"
    MV_PLAN="$(_field "$out" LIC_PLAN)"
    MV_TIPO="$(_field "$out" LIC_TIPO)"

    if [[ $rc -eq 0 ]]; then
        return 0
    fi
    # Un rc=2 aquí indica un fallo inesperado del validador. Las caidas
    # temporales ordinarias se degradan a Bronce dentro de movivip-lic.
    if [[ $rc -eq 2 ]]; then
        MV_MSG="$(trx 'no se pudo comprobar el estado de la licencia')"
    else
        MV_MSG="${detalle:-$(trx 'licencia no valida')}"
        [[ -n "$key" ]] && MV_MSG="KEY ${key:0:6}**** : $MV_MSG"
    fi
    return 1
}

check_bot_lic() {
    local plan tipo
    if ! check_lic; then
        return 1
    fi
    # Plan y tipo proceden del mismo sello firmado que validó check_lic;
    # no se hace una segunda consulta en vivo al firmador.
    plan="$(printf '%s' "${MV_PLAN:-}" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]-')"
    tipo="$(printf '%s' "${MV_TIPO:-}" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]-')"
    case "$plan:$tipo" in
        premium:*|premiumplus:*|premium_plus:*|vitalicio:*|vitalicia:*|lifetime:*|admin:*|super:*|superadmin:*|super_admin:*|administrador:*|superadministrador:*|*:admin|*:super|*:superadmin|*:super_admin|*:super-admin|*:administrador|*:superadministrador)
            return 0
            ;;
        *)
            MV_MSG="el plan activo no incluye los bots de Telegram"
            return 1
            ;;
    esac
}

cleanup_invalid_license() {
    local reason="${1:-licencia ausente, revocada o invalida}"
    logger -t movivip-licgate "LICENCIA INVALIDA: $reason -- desinstalando MoviVIP"
    if [[ -x "$BASE/uninstall.sh" ]]; then
        bash "$BASE/uninstall.sh" --license-cleanup
        return $?
    fi
    echo "ERROR: no se encontro el desinstalador de MoviVIP; no se puede completar la limpieza." >&2
    return 1
}

# Consulta directamente al firmador para el menu principal y el watchdog.
# MV_LICENSE_STATE queda como active, bronze o expired. Una falla temporal
# permite solo Bronce; un Bronce/regalo vencido queda en consulta; una
# respuesta negativa inicia la limpieza del producto.
live_license_policy() {
    local bin key out rc detail plan expiry now tipo
    MV_LICENSE_STATE=""
    MV_MSG=""
    MV_TIPO=""
    if ! bin="$(mv_lic_bin)"; then
        MV_MSG="movivip-lic no esta instalado"
        cleanup_invalid_license "$MV_MSG"
        return 1
    fi
    if [[ ! -s "$LIC" ]]; then
        MV_MSG="no hay licencia registrada"
        cleanup_invalid_license "$MV_MSG"
        return 1
    fi
    key="$(grep -m1 '^KEY=' "$LIC" 2>/dev/null | cut -d= -f2- | tr -d '"' | tr -d '\r')"
    if [[ -z "$key" ]]; then
        MV_MSG="la licencia registrada no contiene una clave"
        cleanup_invalid_license "$MV_MSG"
        return 1
    fi

    out="$("$bin" --export "$key" 2>/dev/null)"
    rc=$?
    detail="$(_field "$out" LIC_DETALLE)"
    plan="$(_field "$out" LIC_PLAN | tr '[:upper:]' '[:lower:]')"
    tipo="$(_field "$out" LIC_TIPO | tr '[:upper:]' '[:lower:]')"
    expiry="$(_field "$out" LIC_EXPIRA)"
    MV_TIPO="$tipo"
    case "$rc" in
        0)
            if [[ "$(_field "$out" LIC_OK)" != "true" ]]; then
                MV_MSG="${detail:-el firmador rechazo la licencia}"
                cleanup_invalid_license "$MV_MSG"
                return 1
            fi
            if [[ "$tipo" == "expirada_lectura" ]]; then
                MV_LICENSE_STATE="expired"
                MV_MSG="${detail:-el periodo de regalo vencio; renueva para reactivar el panel}"
                return 0
            fi
            now="$(date +%s)"
            if [[ "$expiry" =~ ^[0-9]+$ ]] && (( expiry > 0 && now > expiry )); then
                if [[ "$tipo" == "regalo" || "$plan" == "bronce" || "$plan" == "bronze" ]]; then
                    MV_LICENSE_STATE="expired"
                    MV_MSG="el periodo Bronce/regalo vencio; renueva para reactivar el panel"
                    return 0
                fi
                plan="bronce"
                detail="licencia vencida; acceso Bronce"
            fi
            if [[ "$plan" == "bronce" || "$detail" == *"Bronce"* || "$detail" == *"vencida"* ]]; then
                MV_LICENSE_STATE="bronze"
                MV_MSG="${detail:-licencia en nivel Bronce}"
                return 0
            fi
            MV_LICENSE_STATE="active"
            return 0
            ;;
        2)
            MV_LICENSE_STATE="bronze"
            MV_MSG="verificacion en vivo no disponible; acceso Bronce"
            return 0
            ;;
        *)
            MV_MSG="${detail:-licencia rechazada o invalida}"
            cleanup_invalid_license "$MV_MSG"
            return 1
            ;;
    esac
}

bot_units() {
    systemctl list-unit-files --type=service --no-legend 2>/dev/null |
        awk '{print $1}' |
        grep -E '^movivip-(bot-generador|.*-(admin|notif))\.service$' |
        awk 'NF && !seen[$0]++' || true
}

bloquear_bots() {
    local u estado habilitado activo enmascarado
    mkdir -p "$STATE_DIR"
    chmod 700 "$STATE_DIR"
    logger -t movivip-licgate "BLOQUEADO: $1 -- deteniendo bots"
    while IFS= read -r u; do
        [[ -n "$u" ]] || continue
        estado="$STATE_DIR/${u%.service}.state"
        if [[ ! -f "$estado" ]]; then
            habilitado=0
            activo=0
            enmascarado=0
            case "$(systemctl is-enabled "$u" 2>/dev/null)" in
                enabled|enabled-runtime) habilitado=1 ;;
                masked|masked-runtime) enmascarado=1 ;;
            esac
            systemctl is-active --quiet "$u" 2>/dev/null && activo=1
            printf '%s %s %s\n' "$habilitado" "$activo" "$enmascarado" > "$estado"
            chmod 600 "$estado"
        fi
        systemctl stop "$u" 2>/dev/null
        systemctl mask "$u" 2>/dev/null
    done < <(bot_units)
}

restaurar_bots() {
    local u estado habilitado activo enmascarado
    while IFS= read -r u; do
        [[ -n "$u" ]] || continue
        estado="$STATE_DIR/${u%.service}.state"
        [[ -f "$estado" ]] || continue
        read -r habilitado activo enmascarado < "$estado"
        if [[ "$enmascarado" == "1" ]]; then
            rm -f "$estado"
            continue
        fi
        systemctl unmask "$u" 2>/dev/null
        if [[ "$habilitado" == "1" ]]; then
            systemctl enable "$u" >/dev/null 2>&1
        fi
        if [[ "$activo" == "1" ]]; then
            systemctl start "$u" 2>/dev/null
        fi
        rm -f "$estado"
    done < <(bot_units)
}

# ── DISPATCHER (solo en ejecución directa) ────────────────────────────────
# install.sh y el panel hacen `. lib/licgate.sh` para reutilizar estas
# funciones (mv_lic_bin, check_lic, bloquear_bots...). SIN este guard, el
# `case` de abajo corría al hacer source, heredaba el $1 del llamante (la
# clave de licencia) y caía en `*)` -> `exit 2`, matando install.sh justo
# después de copiar el payload. Invocado como CLI (licgate.sh check|...)
# sigue funcionando igual.
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
case "${1:-status}" in
    check)
        if check_lic; then
            touch "$STAMP" 2>/dev/null
            echo "OK: licencia valida (${MV_KEY:0:6}****)"
            exit 0
        fi
        echo "INVALIDA: $MV_MSG"
        exit 1
        ;;
    check-bots)
        if check_bot_lic; then
            echo "OK: licencia y plan autorizados para bots (${FP_PLAN:-${PLAN:-}})"
            exit 0
        fi
        echo "BLOQUEADO: $MV_MSG"
        exit 1
        ;;
    enforce)
        if check_bot_lic; then
            touch "$STAMP" 2>/dev/null
            restaurar_bots
            echo "OK: licencia y plan elegibles -- bots operativos"
            exit 0
        fi
        bloquear_bots "$MV_MSG"
        echo "BLOQUEADO: $MV_MSG -- bots detenidos y bloqueados"
        exit 1
        ;;
    enforce-license)
        if live_license_policy; then
            if [[ "$MV_LICENSE_STATE" == "bronze" ]]; then
                echo "BRONCE: $MV_MSG"
            else
                echo "OK: licencia validada en vivo"
            fi
            exit 0
        fi
        exit 1
        ;;
    menu-policy)
        if live_license_policy; then
            if [[ "$MV_LICENSE_STATE" == "bronze" ]]; then
                echo "BRONCE: $MV_MSG"
            fi
            exit 0
        fi
        exit 1
        ;;
    status)
        echo "$(trx '== MoviVIP License Gate ==')"
        if [ -f "$LIC" ]; then
            grep -E '^(KEY|PLAN|CLIENTE|EXPIRA|LICENCIA_ACTIVA|FECHA_ACTIVACION)' "$LIC" 2>/dev/null || cat "$LIC"
        else
            echo "$(trx 'licencia.conf: NO EXISTE')"
        fi
        LAST=$(stat -c %Y "$STAMP" 2>/dev/null || echo 0)
        if [ "$LAST" != "0" ]; then
            AHORA=$(date +%s)
            echo "ultima validacion OK: hace $(( (AHORA - LAST) / 3600 ))h (gracia 72h)"
        else
            echo "$(trx 'nunca validado')"
        fi
        if check_bot_lic; then
            touch "$STAMP" 2>/dev/null
            echo "verificacion bots: VALIDA"
        else
            echo "verificacion bots: INVALIDA ($MV_MSG)"
        fi
        echo "$(trx '-- estado bots --')"
        while IFS= read -r u; do
            printf '  %-38s %s / %s\n' "$u" "$(systemctl is-active "$u" 2>/dev/null)" "$(systemctl is-enabled "$u" 2>/dev/null)"
        done < <(bot_units)
        ;;
    *)
        echo "uso: $0 check|check-bots|enforce|status"
        exit 2
        ;;
esac
fi