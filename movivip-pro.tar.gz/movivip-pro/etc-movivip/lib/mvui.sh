#!/bin/bash
# mvui.sh - presentacion de MoviVIP.
#
# Reglas de esta capa, en orden de prioridad:
#
#   1. El usuario nunca ve un codigo de error, un numero de linea ni un
#      comando crudo. Solo ve que paso, si funciono y que hacer si no.
#   2. Todo el detalle tecnico va al log. La pantalla es para personas.
#   3. Las barras de progreso son reales. Si no se sabe cuanto falta, se
#      muestra un spinner (indeterminado) en vez de inventar un porcentaje.
#   4. Si la salida no es un terminal (redireccion, CI, cron) el formato
#      se simplifica y no se emits codigos de control.
#   5. Este archivo es ASCII puro: los simbolos se escriben como escapes
#      \uXXXX de bash. Ningun caracter depende de como se guarde el
#      archivo, asi que no hay forma de que aparezca un simbolo roto.
#
# mvui.sh se carga desde install.sh y no debe ejecutarse solo.

[[ -n "${_MVUI_CARGADO:-}" ]] && return 0
_MVUI_CARGADO=1

# --- configuracion ----------------------------------------------------------

MVUI_LOG="${MVUI_LOG:-/var/log/movivip/instalacion.log}"
MVUI_ANCHO_MIN=52
MVUI_ANCHO_MAX=76

_mvui_es_tty() { [[ -t 1 ]]; }

# _mvui_color decide si se usan secuencias de escape. Se respeta NO_COLOR,
# una convencion que siguen muchas herramientas de terminal.
_mvui_color() {
  [[ -n "${NO_COLOR:-}" ]] && return 1
  [[ "${TERM:-dumb}" == "dumb" ]] && return 1
  _mvui_es_tty
}

_mvui_init() {
  if _mvui_color; then
    C_RESET=$'\033[0m';  C_BOLD=$'\033[1m';   C_DIM=$'\033[2m'
    C_RED=$'\033[31m';   C_GREEN=$'\033[32m'; C_YELLOW=$'\033[33m'
    C_BLUE=$'\033[34m';  C_CYAN=$'\033[36m';  C_GREY=$'\033[90m'
  else
    C_RESET=''; C_BOLD=''; C_DIM=''
    C_RED=''; C_GREEN=''; C_YELLOW=''
    C_BLUE=''; C_CYAN=''; C_GREY=''
  fi

  # Simbolos en escapes \u: el archivo queda en ASCII y el resultado es el
  # mismo en cualquier terminal y en cualquier codificacion de salida.
  if _mvui_es_tty; then
    S_CHECK=$'\u2714'   # checkmark
    S_CROSS=$'\u2718'   # X suave
    S_WARN=$'\u25B2'    # triangulo
    S_BULLET=$'\u25CF'  # circulo lleno
    S_ARROW=$'\u2192'   # flecha
    S_TIP=$'\u2139'     # informacion
    S_RULE=$'\u2500'    # linea horizontal
    S_TL=$'\u256D'; S_TR=$'\u256E'; S_BL=$'\u2570'; S_BR=$'\u256F'
    S_V=$'\u2502'       # vertical
    S_PROG_OK=$'\u2588'; S_PROG_NO=$'\u2591'
  else
    S_CHECK='OK'; S_CROSS='X'; S_WARN='!'; S_BULLET='*'
    S_ARROW='->'; S_TIP='i'; S_RULE='-'
    S_TL='+'; S_TR='+'; S_BL='+'; S_BR='+'
    S_V='|'; S_PROG_OK='#'; S_PROG_NO='.'
  fi

  _mvui_crear_log
}

_mvui_ancho() {
  local w
  w=$(tput cols 2>/dev/null || echo "$MVUI_ANCHO_MIN")
  [[ "$w" =~ ^[0-9]+$ ]] || w=$MVUI_ANCHO_MIN
  (( w < MVUI_ANCHO_MIN )) && w=$MVUI_ANCHO_MIN
  (( w > MVUI_ANCHO_MAX )) && w=$MVUI_ANCHO_MAX
  echo "$w"
}

# --- log --------------------------------------------------------------------

# El log lleva SIEMPRE el detalle completo: comando, codigo de salida y
# salida de error. Es lo unico que se consulta para diagnosticar.
_mvui_crear_log() {
  local dir; dir=$(dirname "$MVUI_LOG")
  [[ -d "$dir" ]] || mkdir -p "$dir" 2>/dev/null || return 0
  [[ -w "$dir" ]] || return 0
  touch "$MVUI_LOG" 2>/dev/null || return 0
  chmod 0640 "$MVUI_LOG" 2>/dev/null || true
}

_mvui_log() {
  [[ -w "$(dirname "$MVUI_LOG")" ]] || return 0
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >>"$MVUI_LOG" 2>/dev/null || true
}

# _mvui_log_cmd deja constancia de un comando y su resultado. Nunca se
# muestra en pantalla: es material de diagnostico.
_mvui_log_cmd() {
  _mvui_log "ejecutando: $*"
}

# --- salida basica ----------------------------------------------------------

_mvui_linea() { printf '%s' "${1:0:$(_mvui_ancho)}"; }

_mvui_p() { printf '%b\n' "$*"; }

_mvui_regla() {
  local w; w=$(_mvui_ancho)
  printf "${C_GREY}"
  printf "%${w}s" | tr ' ' "$S_RULE"
  printf "${C_RESET}\n"
}

# mv_banner: cabecera del instalador.
mv_banner() {
  local titulo="${1:-MoviVIP}"
  local sub="${2:-}"
  local w; w=$(_mvui_ancho)

  _mvui_p ""
  _mvui_p "${C_CYAN}  ${S_BULLET} ${C_BOLD}${titulo}${C_RESET}${C_CYAN} ${S_BULLET}${C_RESET}"
  # Si "sub" viene vacio, ese test es falso y mv_banner terminaba con el
  # codigo de salida de ese fallo en vez de con 0. Mismo patrón que hacia
  # mv_aviso y mv_pie: la funcion cumple su trabajo y aun asi miente sobre si
  # ha ido bien. Cualquier orquestador que la use en un condicional se para
  # sin motivo. mv_banner solo imprime, asi que su unico codigo de salida
  # legitimo es 0.
  [[ -n "$sub" ]] && _mvui_p "${C_GREY}      ${sub}${C_RESET}"
  _mvui_regla
  return 0
}

# mv_fase: encabezado de una fase. Es lo que el usuario ve avanzar.
mv_fase() {
  local titulo="$1"
  _mvui_p ""
  _mvui_p "${C_BOLD}${C_BLUE}${S_TIP} ${titulo}${C_RESET}"
}

# mv_item: announces una accion antes de ejecutarla.
mv_item() {
  printf "${C_GREY}   ${S_ARROW}${C_RESET} %s\n" "$(_mvui_linea "$1")"
}

# mv_ok: accion terminada correctamente.
mv_ok() {
  printf "   ${C_GREEN}${S_CHECK}${C_RESET} %s\n" "$(_mvui_linea "$1")"
}

# mv_aviso: algo que no impidio continuar pero que el usuario debe saber.
  #
  # El return 0 explicito no es cosmetico. Antes la ultima linea era
  #   [[ -n "${2:-}" ]] && printf ...
  # y sin segundo argumento esa prueba da falso: la funcion devolvia 1.
  # preflight_puertos la usa para avisar de puertos ocupados y continua
  # ("la instalacion continuara"), pero como devolvia 1 el orquestador lo leia
  # como fallo y abortaba toda la instalacion con un mensaje que no tenia nada
  # que ver con la causa. Cualquier consumidor que use el valor de retorno de
  # una funcion que solo imprime recibe ahora siempre 0.
  mv_aviso() {
    printf "   ${C_YELLOW}${S_WARN}${C_RESET} %s\n" "$(_mvui_linea "$1")"
    if [[ -n "${2:-}" ]]; then
      printf "     ${C_GREY}$(_mvui_linea "$2")${C_RESET}\n"
    fi
    return 0
  }

# mv_warn: alias de mv_aviso.
  #
  # paso-preflight.sh y paso-protocolos.sh lo invocan, pero nunca se define:
  # sin esto el preflight moria con "mv_warn: command not found" y abortaba
  # la instalacion entera con un error que no tenia nada que ver con la causa.
  # El aviso y el aviso-con-detalle son lo mismo aqui.
  if ! declare -F mv_warn >/dev/null 2>&1; then
    mv_warn() { mv_aviso "$@"; }
  fi

  # mv_p: linea tal cual, con el saneado de CRLF del resto de la libreria.
  #
  # install.sh la usa para el bloque de contacto al pedir la clave por
  # pantalla. Ese camino es el interactivo: el que recorre un cliente de
  # verdad, y con la variable MOVIVIP_LICENSE_KEY nunca se ejercita, asi que
  # el fallo se escondia en las pruebas automaticas.
  if ! declare -F mv_p >/dev/null 2>&1; then
    mv_p() { printf '%s\n' "$(_mvui_linea "$1")"; }
  fi

  # mv_detalle: subnota explicativa, en gris.
mv_detalle() {
  printf "     ${C_GREY}%s${C_RESET}\n" "$(_mvui_linea "$1")"
}

# mv_pregunta: pide un dato por pantalla y escribe la respuesta en el nombre
# indicado. Sin segundo argumento, escribe en REPLY.
#
#   read -r DOMINIO < <(mv_pregunta "Dominio del panel: ")
#   read -r CLAVE   < <(mv_pregunta "Clave de licencia: " "CLAVE")
#
# install.sh la usaba sin existir:
#
#   read -rp "$(mv_pregunta 'Dominio: ')" SERVER_DOMAIN
#
# Un \$( ) con un comando inexistente no aborta: se sustituye por vacio. O sea
# que el prompt no se veia, el usuario no escribia nada, SERVER_DOMAIN se
# quedaba vacia y la instalacion moria con "Dominio requerido". Y solo en
# installs interactivos, porque en headless SERVER_DOMAIN viene por entorno y
# esa rama no se ejecuta. El camino por el que entra un cliente de verdad no
# se habia probado nunca.
#
# Dos correcciones sobre el uso original:
#   * Devuelve el texto por stdout en vez de imprimirlo, para poder capturarlo
#     con read. Imprimir el prompt desde dentro de \$( ) lo haria desaparecer,
#     que es justo el bug de arriba.
#   * Si no hay terminal, dice por stderr por que no puede preguntar y no se
#     queda esperando a un input que no va a llegar.
mv_pregunta() {
  local texto="$1" destino="${2:-REPLY}" respuesta

  if [[ ! -t 0 ]]; then
    printf "   ${C_YELLOW}${S_WARN}${C_RESET} hace falta un dato (%s) y no hay terminal para preguntarlo.\n" \
      "$(_mvui_linea "$texto")" >&2
    printf "     ${C_GREY}Pasalo por entorno, p.ej. SERVER_DOMAIN=panel.tudominio.com${C_RESET}\n" >&2
    return 1
  fi

  printf "   ${C_CYAN}?${C_RESET} %s " "$(_mvui_linea "$texto")" >&2
  IFS= read -r respuesta || respuesta=""
  printf -v "$destino" '%s' "$respuesta"
  return 0
}

# mv_error: fallo con explicacion y, si se sabe, que hacer.
#
#   mv_error "No se pudo instalar el protocolo" \
#            "El servidor no tiene memoria suficiente." \
#            "Reduce los protocolos o reinicia con mas RAM."
#
# El segundo argumento es la causa real (solo al log). El tercero es la
# ayuda para el usuario. Ninguno de los dos se imprime completo si son largos.
mv_error() {
  local que="$1" causa="${2:-}" ayuda="${3:-}"
  printf "   ${C_RED}${S_CROSS}${C_RESET} %s\n" "$(_mvui_linea "$que")"
  [[ -n "$causa" ]]  && printf "     ${C_GREY}$(_mvui_linea "$causa")${C_RESET}\n"
  if [[ -n "$ayuda" ]]; then
    printf "     ${C_CYAN}${S_TIP} %s${C_RESET}\n" "$(_mvui_linea "$ayuda")"
  fi
  [[ -n "$causa" ]] && _mvui_log "  causa: $causa"
  return 1
}

# mv_dato: par clave/valor alineado.
mv_dato() {
  printf "   ${C_GREY}%-22s${C_RESET} %s\n" "${1:-}" "${2:-}"
  return 0
}

# --- spinner: progreso indeterminado real -----------------------------------

# Se usa cuando el trabajo no tiene un total conocido. Un porcentaje aqui
# seria mentira, asi que se gira un guion.
MVUI_SPIN_PID=""
MVUI_SPIN_MSG=""
# U+280B .. U+280F, en escapes para no depender de la codificacion del
# archivo. En terminal sin Unicode el spinner se ve como un bloque simple.
_MVUI_SPIN_FRAMAS=('\u280b' '\u2819' '\u2839' '\u2838' '\u283c'
                   '\u2834' '\u2826' '\u2827' '\u2807' '\u280f')

mv_spin_iniciar() {
  local msg="$1"
  _mvui_es_tty || return 0
  MVUI_SPIN_MSG="$msg"
  (
    trap 'printf "\033[K"; exit 0' INT TERM
    local i=0
    while :; do
      local f=${_MVUI_SPIN_FRAMAS[$(( i % 10 ))]}
      printf "\r   ${C_CYAN}%s${C_RESET} %-46s" "$f" "${msg:0:46}"
      sleep 0.1
      i=$(( i + 1 ))
    done
  ) &
  MVUI_SPIN_PID=$!
  disown 2>/dev/null || true
}

mv_spin_terminar() {
  local estado="${1:-ok}"
  [[ -z "$MVUI_SPIN_PID" ]] && return 0
  kill "$MVUI_SPIN_PID" 2>/dev/null || true
  wait "$MVUI_SPIN_PID" 2>/dev/null || true
  MVUI_SPIN_PID=""
  printf "\r\033[K"
  case "$estado" in
    ok)   mv_ok   "$MVUI_SPIN_MSG" ;;
    fail) mv_error "$MVUI_SPIN_MSG" ;;
    warn) mv_aviso "$MVUI_SPIN_MSG" ;;
  esac
  MVUI_SPIN_MSG=""
}

# --- progreso: pasos contables ----------------------------------------------

# Solo se usa cuando hay un total real (por ejemplo, 12 protocolos de 15).
MVUI_PROG_TOTAL=0
MVUI_PROG_HECHO=0
MVUI_PROG_MSG=""

mv_prog_iniciar() {
  local msg="$1" total="$2"
  MVUI_PROG_MSG="$msg"
  MVUI_PROG_TOTAL="$total"
  MVUI_PROG_HECHO=0
  [[ "$total" -le 0 ]] && return 0
  _mvui_es_tty && printf "\n   ${C_CYAN}%s${C_RESET} (0/%d)\n" "$msg" "$total"
}

mv_prog_avanzar() {
  MVUI_PROG_HECHO=$(( MVUI_PROG_HECHO + 1 ))
  _mvui_es_tty || return 0
  local pct=0
  (( MVUI_PROG_TOTAL > 0 )) && pct=$(( MVUI_PROG_HECHO * 100 / MVUI_PROG_TOTAL ))
  local ancho=24 lleno=$(( MVUI_PROG_TOTAL > 0 ? MVUI_PROG_HECHO * ancho / MVUI_PROG_TOTAL : 0 ))
  local barra=""
  (( lleno > ancho )) && lleno=$ancho
  local i
  for (( i=0; i<lleno; i++ )); do barra+="$S_PROG_OK"; done
  for (( i=lleno; i<ancho; i++ )); do barra+="$S_PROG_NO"; done
  printf "   ${C_CYAN}[%s${C_CYAN}]${C_RESET} %3d%%  %s %d/%d\n" \
    "$barra" "$pct" "$(_mvui_linea "$MVUI_PROG_MSG")" "$MVUI_PROG_HECHO" "$MVUI_PROG_TOTAL"
}

# --- ejecucion segura -------------------------------------------------------

# mv_correr ejecuta un comando mostrando spinner y, si falla, un mensaje
# legible en vez de un error tecnico.
#
#   mv_correr "Descargando protocolo" "El servidor no tiene acceso a Internet." \
#             "curl -fsSL https://... -o /tmp/x"
#
# Devuelve el codigo del comando para que el llamante decida.
mv_correr() {
  local desc="$1" causa_help="${2:-}" cmd="${3:-}"
  [[ -z "$cmd" ]] && { mv_ok "$desc"; return 0; }

  _mvui_log_cmd "$cmd"
  mv_spin_iniciar "$desc"

  local salida rc=0
  salida=$(eval "$cmd" 2>&1) || rc=$?

  if (( rc == 0 )); then
    mv_spin_terminar ok
    [[ -n "$salida" ]] && _mvui_log "  salida: ${salida:0:500}"
    return 0
  fi

  mv_spin_terminar fail
  # El codigo y el comando crudo SOLO al log. En pantalla, la causa legible.
  _mvui_log "  fallo (codigo $rc)"
  _mvui_log "  salida: ${salida:0:1000}"
  _mvui_log "  comando: $cmd"
  local causa
  causa=$(_mvui_explicar "$salida" "$rc")
  mv_error "$desc" "$causa" "$causa_help"
  return "$rc"
}

# _mvui_explicar traduce una salida de error tipica a lenguaje llano.
# Es una tabla, no un parser: cubre los fallos que se ven en la practica y
# cae en un texto generico para el resto.
_mvui_explicar() {
  local salida="$1" rc="$2"
  local bajo="${salida,,}"

  if   [[ "$bajo" == *"no space left"*   ]]; then echo "El disco esta lleno."
  elif [[ "$bajo" == *"cannot allocate memory"* || "$bajo" == *"out of memory"* ]]; then
       echo "El servidor se queda sin memoria."
  elif [[ "$bajo" == *"could not resolve host"* || "$bajo" == *"temporary failure in name resolution"* ]]; then
       echo "El servidor no puede resolver los nombres de dominio."
  elif [[ "$bajo" == *"connection timed out"* || "$bajo" == *"network is unreachable"* ]]; then
       echo "No hay salida a Internet desde el servidor."
  elif [[ "$bajo" == *"permission denied"* ]]; then
       echo "Faltan permisos para escribir en esa ubicacion."
  elif [[ "$bajo" == *"command not found"* ]]; then
       echo "Falta una herramienta de sistema en el servidor."
  elif [[ "$bajo" == *"package "*"not found"* || "$bajo" == *"no such file or directory"* ]]; then
       echo "El repositorio de paquetes no ofrece lo necesario."
  elif [[ "$bajo" == *"address already in use"* || "$bajo" == *"port is already allocated"* ]]; then
       echo "El puerto pedido ya lo esta usando otro servicio."
  elif [[ "$rc" == "127" ]]; then
       echo "Una herramienta necesaria no esta instalada."
  else
       echo "El comando termino con error."
  fi
}

# mv_verificar ejecuta una comprobacion y solo informa si fallo.
mv_verificar() {
  local desc="$1" cmd="$2"
  _mvui_log_cmd "$cmd"
  local salida rc=0
  salida=$(eval "$cmd" 2>&1) || rc=$?
  if (( rc == 0 )); then
    mv_ok "$desc"
  else
    _mvui_log "  verificacion fallo: $salida"
    mv_aviso "$desc" "Se continua igualmente."
  fi
  return 0
}

# --- cierre -----------------------------------------------------------------

# mv_resumen cierra la instalacion con lo que el usuario necesita saber:
# donde entrar y que hacer ahora. Sin codigos, sin comandos.
mv_resumen() {
  local w; w=$(_mvui_ancho)
  _mvui_p ""
  _mvui_regla
  _mvui_p "${C_GREEN}${C_BOLD}${S_CHECK} Instalacion terminada${C_RESET}"
  _mvui_regla
  _mvui_p ""
}

# mv_caja dibuja un recuadro con titulo y lineas de contenido.
mv_caja() {
  local titulo="$1"; shift
  local w; w=$(_mvui_ancho)
  local interior=$(( w - 4 ))

  _mvui_p ""
  _mvui_p "${C_CYAN}${S_TL}${S_RULE} ${C_BOLD}${titulo}${C_RESET}${C_CYAN} ${S_RULE}${S_TR}${C_RESET}"
  local linea
  for linea in "$@"; do
    [[ -z "$linea" ]] && continue
    _mvui_p "${C_CYAN}${S_V}${C_RESET} ${C_RESET}$(printf "%${interior}s" "${linea:0:$interior}")${C_RESET}${C_CYAN}${S_V}${C_RESET}"
  done
  _mvui_p "${C_CYAN}${S_BL}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_RULE}${S_BR}${C_RESET}"
}

# mv_pie imprime las notas de cierre que siempre deben verse.
mv_pie() {
  _mvui_p ""
  _mvui_p "${C_GREY}$(_mvui_linea "$1")${C_RESET}"
  [[ -n "${2:-}" ]] && _mvui_p "${C_GREY}$(_mvui_linea "$2")${C_RESET}"
  return 0
}

# --- modo diagnostico -------------------------------------------------------

# MVUI_DEBUG=1 muestra en pantalla lo que normalmente solo va al log. Se
# activa con --debug y es lo primero que se le pide a un usuario que reporta
# un problema.
mv_debug() {
  [[ "${MVUI_DEBUG:-0}" == "1" ]] || return 0
  printf "   ${C_GREY}[debug] %s${C_RESET}\n" "$1"
}

_mvui_init