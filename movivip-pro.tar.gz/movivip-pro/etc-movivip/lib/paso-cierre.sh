#!/usr/bin/env bash
# ============================================================================
# PASO: CIERRE Y RESUMEN
# Permisos, launchers, ficheros, iptables, monitoreo, limpieza del banner
# retirado, banner de login, ofuscacion del payload y resumen final.
# ============================================================================
set -uo pipefail

# ---------------------------------------------------------------------------
# 1. Permisos del directorio
# ---------------------------------------------------------------------------
cierre_permisos() {
    # Antes: chmod -R 777 /etc/movivip.
    #
    # 777 deja todo el arbol del producto legible, escribible y ejecutable
    # por CUALQUIER cuenta del servidor: un usuario de soporte, un usuario
    # de correo, un servicio comprometido... Podian leer los scripts, y
    # tambien reescribirlos (por ejemplo, meter un backdoor en menu.sh o en
    # el validador). El objetivo del producto es justo lo contrario.
    #
    # Se pasa a root-only: directorios 700, ficheros 600, y 700 para los
    # .sh y todo lo que ya era ejecutable. Root lee y escribe; nadie mas.
    # Los cron, los launchers y el guard corren como root, asi que siguen
    # funcionando igual.
    run_cmd "Ajustando permisos (solo root)" "$LINENO" \
        "chown -R root:root /etc/movivip && \
         find /etc/movivip -type d -exec chmod 700 {} + && \
         find /etc/movivip -type f -perm -u+x -exec chmod 700 {} + && \
         find /etc/movivip -type f -name '*.sh' -exec chmod 700 {} + && \
         find /etc/movivip -type f ! -perm -u+x -exec chmod 600 {} +"
}

# ---------------------------------------------------------------------------
# 2. Launchers (menu, protocolos, herramientas, usuarios)
# ---------------------------------------------------------------------------
cierre_launchers() {
    run_cmd "Creando comandos de menú (launchers seguros)" "$LINENO" \
        "mkdir -p /usr/local/bin && \
         for L in menu protocolos herramientas usuarios; do \
             cp -f \"/etc/movivip/launchers/\$L\" \"/usr/local/bin/\$L\" 2>/dev/null && chmod +x \"/usr/local/bin/\$L\"; \
         done; \
         if [ ! -x /usr/local/bin/menu ]; then \
             printf '#!/bin/bash\nexec bash /etc/movivip/lib/launch.sh /etc/movivip/menu.sh \"\$@\"\n' > /usr/local/bin/menu; \
             chmod +x /usr/local/bin/menu; \
         fi"
}

# ---------------------------------------------------------------------------
# 3. Ficheros desde payload (fix CRLF, verificación crítica)
# ---------------------------------------------------------------------------
cierre_ficheros() {
    run_cmd "Fix CRLF en scripts" "$LINENO" "find /etc/movivip -name '*.sh' -type f -exec sed -i 's/\r$//' {} + 2>/dev/null"
    # El guard compilado entra en la lista de criticos y se comprueba tambien
    # que sea ejecutable. Antes esta lista exigia lib/licguard.sh, que era
    # justo el fichero que el gate dejo de usar: verificar que estuviera
    # presente solo demostraba que el administrador no lo habia borrado, no
    # que la puerta real siguiera en su sitio. Lo que importa es que exista
    # /usr/local/bin/movivip-guard con permiso de ejecucion, porque ahi esta
    # la puerta que los 107 scripts del panel llaman.
    run_cmd "Verificando archivos críticos" "$LINENO" \
        "for f in /etc/movivip/install.sh /etc/movivip/lib/mvui.sh /etc/movivip/lib/plancheck.sh /usr/local/bin/movivip-guard; do \
             [[ -f \"\$f\" ]] || { echo \"FALTA: \$f\"; exit 1; }; \
         done; \
         [[ -x /usr/local/bin/movivip-guard ]] || { echo \"movivip-guard no es ejecutable\"; exit 1; }"
}

# ---------------------------------------------------------------------------
# 4. Iptables finales
# ---------------------------------------------------------------------------
cierre_iptables() {
    # /etc/iptables no viene en una Ubuntu recien instalada: la redireccion
    # fallaba con "No such file or directory" y el paso se marcaba como FALLO
    # aunque iptables funcionase. paso-sistema.sh:146 ya creaba el directorio;
    # aqui faltaba. Mismo patron que ahi.
    run_cmd "Guardando reglas iptables finales" "$LINENO" \
        "mkdir -p /etc/iptables; iptables-save > /etc/iptables/rules.v4"
}

# ---------------------------------------------------------------------------
# 5. Monitoreo de red (snapshot + cron)
# ---------------------------------------------------------------------------
cierre_monitoreo_red() {
    # network_snapshot.sh es un menu interactivo (while true + read -rp).
    # Llamado sin --auto se quedaba esperando teclado indefinidamente y la
    # instalacion se comia el timeout entero. Con --auto crea el snapshot y
    # sale; el menu sigue igual cuando lo abre un usuario.
    run_cmd "Ejecutando snapshot inicial" "$LINENO" \
        "mkdir -p /etc/movivip/sistema; \
         chmod +x /etc/movivip/herramientas/network_snapshot.sh; \
         rm -f /etc/movivip/sistema/network_state.conf; \
         bash /etc/movivip/herramientas/network_snapshot.sh --auto"
    run_cmd "Configurando cron network_snapshot" "$LINENO" \
        "(crontab -l 2>/dev/null | grep -v 'network_snapshot'; \
         echo '* * * * * bash /etc/movivip/herramientas/network_snapshot.sh --auto >/dev/null 2>&1') | crontab -"
}

# ---------------------------------------------------------------------------
# 6. Monitoreo de usuarios (online_movi.sh + cron)
# ---------------------------------------------------------------------------
cierre_monitoreo_usuarios() {
    run_cmd "Ejecutando online_movi.sh inicial" "$LINENO" \
        "mkdir -p /etc/movivip/sistema; \
         chmod +x /etc/movivip/usuarios/online_movi.sh; \
         bash /etc/movivip/usuarios/online_movi.sh --quiet"
    run_cmd "Creando archivo de límites de conexiones" "$LINENO" \
        "mkdir -p /etc/movivip/sistema; touch /etc/movivip/sistema/limites_conexiones.conf"
    run_cmd "Configurando cron online_movi.sh" "$LINENO" \
        "(crontab -l 2>/dev/null | grep -vE 'online(_movi)?\\.sh --quiet'; \
         echo '*/2 * * * * bash /etc/movivip/usuarios/online_movi.sh --quiet >/dev/null 2>&1') | crontab -"
}

# ---------------------------------------------------------------------------
# 7. Banner SSH — retirado
# ---------------------------------------------------------------------------
# El instalador creaba /etc/issue.net con arte ASCII y lo cableaba en
# sshd_config y en /etc/default/dropbear. Ese bloque se ha eliminado del
# instalador: el banner ya no se escribe.
#
# No basta con dejar de escribirlo. En una reinstalacion o una actualizacion
# sobre un servidor que ya lo tenia, /etc/ssh/sshd_config y
# /etc/default/dropbear se quedan apuntando a un fichero que ya no existe:
# sshd avisa por consola en cada conexion ("Could not open banner") y
# dropbear, para el que -b no es opcional, sigue leyendo el valor viejo.
# Por eso el paso se conserva, pero solo para limpiar esas referencias.
cierre_banner_limpieza() {
    local sshd_cfg="/etc/ssh/sshd_config"
    local dj="/etc/default/dropbear"
    local bak cambia=0

    if grep -qE '^[[:space:]]*Banner[[:space:]]+/etc/issue\.net' "$sshd_cfg" 2>/dev/null; then
        bak="$sshd_cfg.movivip-bak"
        cp -a "$sshd_cfg" "$bak"
        sed -i -E '/^[[:space:]]*Banner[[:space:]]+\/etc\/issue\.net[[:space:]]*$/d' "$sshd_cfg"
        # Si el fichero queda invalido se restaura el original. Un
        # sshd_config roto significa que ssh no arranca, y no vale la pena
        # arriesgar el acceso al servidor por quitar una linea de banner.
        if sshd -t >/dev/null 2>&1; then
            rm -f "$bak"
            cambia=1
            mv_ok "Banner retirado de $sshd_cfg"
        else
            cp -a "$bak" "$sshd_cfg"
            rm -f "$bak"
            mv_error "sshd_config quedaria invalido al quitar el banner"
            mv_detalle "  Se ha restaurado el fichero original."
        fi
    fi

    if grep -qE '^[[:space:]]*DROPBEAR_BANNER=.*/etc/issue\.net' "$dj" 2>/dev/null; then
        sed -i -E '/^[[:space:]]*DROPBEAR_BANNER=.*\/etc\/issue\.net/d' "$dj"
        cambia=1
        mv_ok "Banner retirado de $dj"
    fi

    if [[ -e /etc/issue.net ]]; then
        rm -f /etc/issue.net
        cambia=1
        mv_ok "Fichero /etc/issue.net eliminado"
    fi

    if (( cambia )); then
        mv_detalle "SSH no se reinicia: el ajuste afecta a las conexiones siguientes."
        mv_detalle "Un reinicio fallido de ssh dejaria el servidor inalcanzable."
    fi
    return 0
}

# ---------------------------------------------------------------------------
# 7a. Banner v4.0 (HTML) — instalar y cablear a SSH + Dropbear
# ---------------------------------------------------------------------------
# El banner que ve el CLIENTE es ahora un HTML en /etc/issue.net generado por
# usuarios/banner.sh (v4.0): sello obligatorio inyectado antes de </span></div>,
# sin links, y con sshd y dropbear apuntando a el. El paso de arriba (7)
# retiro las referencias viejas; este reinstala limpio con el banner generico
# + sello. banner.sh vive bajo /etc/movivip/usuarios/, que el guard clasifica
# como ModoPermitir, asi que el gate no depende de la red y no puede bloquear
# el cierre. Se arranca con "no-restart": no se reinicia ssh/dropbear aqui.
cierre_banner_instalar() {
    local b="/etc/movivip/usuarios/banner.sh"
    if [[ ! -f "$b" ]]; then
        mv_error "No se encontro $b"
        mv_detalle "  El banner HTML v4.0 no se instalara."
        return 0
    fi
    run_cmd "Instalando banner SSH/Dropbear (HTML v4.0)" "$LINENO" \
        "bash '$b' --install"
}

# ---------------------------------------------------------------------------
# 7b. Banner de login — /etc/profile.d/MoviVIP-banner.sh (v2.1)
# ---------------------------------------------------------------------------
# El banner de /etc/issue.net (HTML v4.0) lo reinstala el paso 7a; el que ve
# el usuario al autenticarse en shell es OTRO: /etc/profile.d/MoviVIP-banner.sh,
# que bash ejecuta en cada login interactivo. Este paso lo reescribe siempre:
# una instalacion fresca se lo instala, y una reinstalacion sobre un
# servidor que ya lo tenia lo deja identico (incluida la caja de planes).
#
# El contenido va como heredoc con comillas simples: bash no expande nada
# y el fichero resultante sale byte a byte como el del servidor existente.
# Se comprueba la sintaxis con bash -n antes de darlo por bueno.
cierre_banner_login() {
    local rc=0

    cat > /etc/profile.d/MoviVIP-banner.sh << 'BEOF'
#!/bin/bash
#==================================================
# JackSneider - Premium Welcome Banner v2.1
# Diseño profesional - alineación exacta de panel
#==================================================
[[ $- != *i* ]] && return
clear

# ── Datos del sistema ─────────────────────────────
SERVER=$(hostname)
IP_LOCAL=$(hostname -I 2>/dev/null | awk '{print $1}')
DOMAIN="-"
TG_CHANNEL=""
TG_GROUP=""
if [[ -f /etc/movivip/config.conf ]]; then
    source /etc/movivip/config.conf
    DOMAIN="${SERVER_DOMAIN:-"$IP_LOCAL"}"
    TG_CHANNEL="${TG_CHANNEL:-}"
    TG_GROUP="${TG_GROUP:-}"
fi
UPTIME=$(uptime -p 2>/dev/null | sed 's/up //')
FECHA=$(date +"%d-%m-%Y")
HORA=$(date +"%H:%M:%S")
ONLINE=$(who 2>/dev/null | wc -l)

# ── Colores (ANSI 256) ────────────────────────────
C_RESET="\e[0m"
C_CIAN="\e[38;5;45m"
C_CIAN2="\e[38;5;51m"
C_AZUL="\e[38;5;39m"
C_AZUL2="\e[38;5;33m"
C_DORADO="\e[38;5;220m"
C_AMARILLO="\e[38;5;226m"
C_BLANCO="\e[38;5;255m"
C_GRIS="\e[38;5;245m"
C_VERDE="\e[38;5;82m"
C_ROJO="\e[38;5;203m"
C_MORADO="\e[38;5;201m"
C_NARANJA="\e[38;5;208m"
BOLD="\e[1m"

# ── Utilidades ────────────────────────────────────
COLS=$(tput cols 2>/dev/null || echo 80)

# long: ancho visible de un texto (sin ANSI), cuenta emojis como 2 cols
long() {
    local s
    s=$(printf '%b' "$1" | sed -r 's/\x1B\[[0-9;]*[mK]//g')
    local n
    n=$(printf '%s' "$s" | LC_ALL=C.UTF-8 wc -m 2>/dev/null)
    [[ -z "$n" || "$n" -eq 0 ]] && n=${#s}
    local ne
    ne=$(printf '%s' "$s" | LC_ALL=C.UTF-8 grep -oP '[\x{1F000}-\x{1FAFF}\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}\x{2B00}-\x{2BFF}\x{FE0F}]' 2>/dev/null | wc -l)
    [[ -z "$ne" ]] && ne=0
    echo $(( n + ne ))
}
# center: centra texto (soporta códigos ANSI)
center() {
    local text="$1"
    local len
    len=$(long "$text")
    local pad=$(( (COLS - len) / 2 ))
    [[ $pad -lt 0 ]] && pad=0
    printf '%*s' "$pad" ""
    printf '%b\n' "$text"
}
# hr: línea horizontal adaptada al ancho
hr() {
    local char="${1:-═}"
    local line=""
    local i
    for ((i=0; i<COLS; i++)); do line+="$char"; done
    printf '%b\n' "${C_AZUL}${line}${C_RESET}"
}

# ── Panel (ancho fijo, alineación perfecta) ───────
PW=46                      # ancho interior del panel (celdas)
PL=$(( (COLS - PW - 2) / 2 ))   # padding izquierdo
[[ $PL -lt 0 ]] && PL=0

# p_linea <contenido (sin bordes)>
p_linea() {
    local content="$1"
    local len
    len=$(long "$content")
    local fill=$(( PW - len ))
    [[ $fill -lt 0 ]] && fill=0
    printf '%*s' "$PL" ""
    printf '%b' "${C_MORADO}${BOLD}│${C_RESET}${content}"
    printf '%*s' "$fill" ""
    printf '%b\n' "${C_MORADO}${BOLD}│${C_RESET}"
}
# p_marco_sup / p_marco_inf
_repeat() {
    local char="$1" n="$2" out="" i
    for ((i=0; i<n; i++)); do out+="$char"; done
    printf '%s' "$out"
}
p_marco_sup() {
    printf '%*s' "$PL" ""
    printf '%b' "${C_MORADO}${BOLD}┌"
    printf '%b' "${C_MORADO}$(_repeat '─' "$PW")"
    printf '%b\n' "${C_MORADO}${BOLD}┐${C_RESET}"
}
p_marco_inf() {
    printf '%*s' "$PL" ""
    printf '%b' "${C_MORADO}${BOLD}└"
    printf '%b' "${C_MORADO}$(_repeat '─' "$PW")"
    printf '%b\n' "${C_MORADO}${BOLD}┘${C_RESET}"
}
# p_fila <icono(1celda)> <label> <valor>
p_fila() {
    local icon="$1" label="$2" valor="$3"
    local txt
    txt="  ${C_NARANJA}${icon}${C_RESET} ${C_CIAN}${BOLD}${label}${C_RESET}"
    local len_lbl
    len_lbl=$(( 2 + 1 + 1 + ${#label} + 1 ))   # espacios + icono + espacio + label + :
    local len_val=${#valor}
    local dots=$(( PW - len_lbl - len_val ))
    [[ $dots -lt 1 ]] && dots=1
    local gap=""
    local i
    for ((i=0; i<dots; i++)); do gap+=" "; done
    p_linea "${txt}${gap}${C_BLANCO}${valor}${C_RESET}"
}

# ==================================================
#  BANNER PRINCIPAL
# ==================================================
hr "═"
center ""
center "${C_CIAN2}${BOLD}   ███╗   ███╗ ██████╗ ██╗   ██╗██╗██╗   ██╗██╗██████╗ ${C_RESET}"
center "${C_CIAN}${BOLD}   ████╗ ████║██╔═══██╗██║   ██║██║██║   ██║██║██╔══██╗${C_RESET}"
center "${C_CIAN}${BOLD}   ██╔████╔██║██║   ██║██║   ██║██║██║   ██║██║██████╔╝${C_RESET}"
center "${C_AZUL}${BOLD}   ██║╚██╔╝██║██║   ██║╚██╗ ██╔╝██║╚██╗ ██╔╝██║██╔═══╝ ${C_RESET}"
center "${C_AZUL}${BOLD}   ██║ ╚═╝ ██║╚██████╔╝ ╚████╔╝ ██║ ╚████╔╝ ██║██║     ${C_RESET}"
center "${C_AZUL2}${BOLD}   ╚═╝     ╚═╝ ╚═════╝   ╚═══╝  ╚═╝  ╚═══╝  ╚═╝╚═╝     ${C_RESET}"
center ""
center "${C_DORADO}${BOLD}  ──  ◆  M O V I V I P   N E T W O R K  ◆  ──  ${C_RESET}"
center "${C_AMARILLO}${BOLD}        🚀  EDICIÓN PREMIUM — 2026  🚀${C_RESET}"
center ""
hr "═"
center ""

# ── Panel de información ──────────────────────────
p_marco_sup
p_linea "${C_BLANCO}${BOLD}          📊  INFORMACIÓN DEL SERVIDOR          ${C_RESET}"
p_marco_inf
p_marco_sup
p_fila "▶" "Servidor"   "${SERVER}"
p_fila "●" "Dominio"    "${DOMAIN}"
p_fila "◈" "IP Pública" "${IP_LOCAL}"
p_fila "⚡" "Uptime"     "${UPTIME}"
p_fila "✪" "Conectados" "${ONLINE}"
p_fila "◆" "Fecha"      "${FECHA}"
p_fila "◉" "Hora"       "${HORA}"
if [[ -n "$TG_CHANNEL" ]]; then
    p_fila "❯" "Canal"  "${TG_CHANNEL}"
fi
if [[ -n "$TG_GROUP" ]]; then
    p_fila "❯" "Grupo"  "${TG_GROUP}"
fi
p_marco_inf
center ""

# ── Panel de planes y precios (informativo, estatico en USDT) ──
p_marco_sup
p_linea "${C_BLANCO}${BOLD}          💰  PLANES Y PRECIOS  💰          ${C_RESET}"
p_marco_inf
p_marco_sup
p_fila "❯" "BRONCE"        "5 USDT   - 1 dispositivo"
p_fila "❯" "PREMIUM"       "15 USDT  - 2 dispositivos"
p_fila "❯" "BETA/VITALICIA" "100 USDT - Ilimitado"
p_marco_inf
center ""

# ── Usuario / acción ──────────────────────────────
if [[ $EUID -ne 0 ]]; then
    center "${C_ROJO}${BOLD}👑 Usuario${C_RESET}   : ${C_BLANCO}$(whoami)${C_RESET}"
    center "${C_ROJO}${BOLD}⚠️  Advertencia${C_RESET} : ${C_AMARILLO}No eres root — ejecuta:${C_RESET} ${C_VERDE}sudo -i${C_RESET}"
else
    center "${C_DORADO}${BOLD}👑 Usuario${C_RESET}   : ${C_BLANCO}root${C_RESET}"
    center "${C_DORADO}${BOLD}⚡ Comando${C_RESET}   : ${C_VERDE}Escribe:${C_RESET} ${C_BLANCO}menu${C_RESET}"
fi
center ""

hr "═"
center ""
center "${C_VERDE}${BOLD}✨  Gracias por usar nuestros servicios  ✨${C_RESET}"
# Sello de marca: SOLO visible para cliente normal. Admin/SuperAdmin pueden quitarlo.
_SELLO_OK=1
if [[ -f /etc/movivip/licencia.conf ]]; then
    source /etc/movivip/licencia.conf
    case "${TIPO:-}" in
        admin|superadmin) _SELLO_OK=0 ;;
    esac
    case "${PLAN:-}" in
        super) _SELLO_OK=0 ;;
    esac
fi
if [[ "$_SELLO_OK" == "1" ]]; then
    center "${C_ROJO}${BOLD}🛡️  SISTEMA PROTEGIDO POR MOVIVIP NETWORK  🛡️${C_RESET}"
else
    center "${C_GRIS}─  Acceso autorizado. Conexiones monitoreadas las 24 horas.  ─${C_RESET}"
fi
center "${C_GRIS}─  Powered by JackSneider — Uso autorizado  ─${C_RESET}"
center ""
hr "═"
printf '\n'
BEOF
    rc=$?

    if (( rc != 0 )); then
        mv_error "No se pudo escribir /etc/profile.d/MoviVIP-banner.sh"
        mv_detalle "El banner de login no estara disponible en este servidor."
        return 0
    fi
    if bash -n /etc/profile.d/MoviVIP-banner.sh 2>/dev/null; then
        chmod +x /etc/profile.d/MoviVIP-banner.sh 2>/dev/null || true
        mv_ok "Banner de login instalado (/etc/profile.d/MoviVIP-banner.sh)"
    else
        mv_error "El banner de login no pasa la comprobacion de sintaxis"
        mv_detalle "Se ha dejado el fichero en su sitio para revision."
    fi
    return 0
}

# ---------------------------------------------------------------------------
# 7c. Ofuscacion del payload (anti-copia)
# ---------------------------------------------------------------------------
# ofusc_arbol (lib/ofuscar.sh) recorre /etc/movivip y las copias de los
# launchers en /usr/local/bin y reescribe cada script como envoltorio
# opaco: en disco solo quedan cabecera, marca MV-OFUSC y base64. Es el
# ultimo paso antes del resumen, para que ningun paso posterior espere
# codigo en claro en el disco.
#
# IMPORTANTE: El propio ofuscador se AUTO-ELIMINA tras ofuscar para que el
# metodo de ofuscacion no quede expuesto en la VPS del cliente.
cierre_ofuscar() {
    if ! declare -F ofusc_arbol >/dev/null 2>&1; then
        mv_error "No se encuentra la libreria de ofuscacion"
        mv_detalle "lib/ofuscar.sh no se ha cargado: el payload queda en claro."
        return 0
    fi
    run_cmd "Ofuscando scripts (anti-copia)" "$LINENO" "ofusc_arbol"
    
    # Auto-eliminar el ofuscador para que el metodo no quede en la VPS
    local OFUSCAR_SCRIPT="/etc/movivip/lib/ofuscar.sh"
    if [[ -f "$OFUSCAR_SCRIPT" ]]; then
        run_cmd "Eliminando ofuscador (seguridad)" "$LINENO" "rm -f \"$OFUSCAR_SCRIPT\""
        mv_ok "Ofuscador eliminado de la VPS"
    fi
    return 0
}

# ---------------------------------------------------------------------------
# 7c. Verificación final y vigilancia de licencia
# ---------------------------------------------------------------------------
cierre_license_watchdog() {
    if [[ ! -f /etc/movivip/lib/licgate.sh ]]; then
        mv_error "No se encontro el verificador de licencia al cierre"
        return 1
    fi
    if ! bash /etc/movivip/lib/licgate.sh enforce-license; then
        mv_error "La licencia no pudo validarse al cierre; MoviVIP fue retirado"
        return 1
    fi
    if [[ ! -d /etc/movivip ]]; then
        return 1
    fi
    if ! {
        printf '%s\n' 'SHELL=/bin/bash' 'PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
        printf '%s\n' '*/15 * * * * root /bin/bash /etc/movivip/lib/licgate.sh enforce-license >/dev/null 2>&1'
    } > /etc/cron.d/movivip-license-watchdog; then
        mv_error "No se pudo instalar la comprobacion periodica de licencia"
        return 1
    fi
    chmod 644 /etc/cron.d/movivip-license-watchdog
    mv_ok "Verificacion viva configurada cada 15 minutos"
}

# ---------------------------------------------------------------------------
# 8. Resumen final
# ---------------------------------------------------------------------------
cierre_resumen() {
    # Antes de pintar nada verde, comprobar que de verdad se ha hecho todo.
    #
    # Pasaba esto: paso_protocols no existia (typo de una letra) y se quedaba
    # en "command not found", el instalador no se enteraba, seguia adelante y
    # terminaba con un cartel de "Instalacion completada" y "JackSneider
    # instalado correctamente". Sin un solo protocolo. Un cliente que paga
    # recibe "instalado correctamente" y no tiene nada, y lo peor es que ni
    # el usuario ni el soporte pueden saber si lo que fallo fue la red o fue
    # esto.
    #
    # Si algo no se completo, no se dice "instalado". Se dice que falta.
    local _incompleto=0 _p

    # Este bloque antes hacia "return 1" aqui mismo, y ahi estaba el fallo:
    # en cuanto un paso no se completaba, el cierre se cortaba ANTES del
    # resumen de protocolos. O sea, justo cuando mas falta hace saber que
    # protocols se quedaron fuera, el usuario se enteraba unicamente de
    # "pasos que no se completaron" y se quedaba sin el listado de
    # protocolos, que es lo que pedia y lo que necesita soporte para
    # diagnosticar.
    #
    # Ahora el estado se calcula aqui, pero no se corta nada: se imprime el
    # detalle completo y el fallo se devuelve al final.
    if ! mv_pasos_completos; then
        _incompleto=1
    fi

    # ------------------------------------------------------------------------
    # Resumen de protocolos
    #
    # Esto es lo que faltaba y lo que se venia quejando el usuario. El cierre decia
    # "JackSneider instalado correctamente" y a continuacion cuatro lineas
    # de version, plan, directorio y comando. Ni un solo protocolo. Ni los que
    # funcionaron ni los que fallaron. El usuario no se enteraba de que le
    # faltaban cosas hasta que las buscaba, y el soporte tampoco tenia forma de
    # saber que habia fallado.
    #
    # Ahora se lee el registro que deja paso_protocolos y se lista cada
    # protocolo con su estado real.
    # ------------------------------------------------------------------------
    local _inst=0 _pend=0 _fall=0 _omit=0
    if declare -F proto_reg_cuenta >/dev/null 2>&1 &&
       declare -F proto_reg_listar >/dev/null 2>&1; then
        _inst=$(proto_reg_cuenta instalado)
        _pend=$(proto_reg_cuenta pendiente)
        _fall=$(proto_reg_cuenta fallo)
        _omit=$(proto_reg_cuenta omitido)
    fi

    if (( _incompleto )); then
        mv_fase "Instalación incompleta"
        mv_error "La instalación NO ha terminado bien"
    elif (( _pend > 0 )); then
        mv_fase "Instalado, con pendientes"
        mv_ok "JackSneider instalado"
        mv_warn "$_pend protocolo(s) quedaron pendientes por falta de datos"
    else
        mv_fase "Instalación completada"
        mv_ok "JackSneider instalado correctamente"
    fi
    echo ""

    # Los pasos que faltaron se listan DESPUES del encabezado, no antes, para
    # que el orden sea: que paso esta fallando -> que protocolos se quedaron
    # fuera -> datos de la instalacion.
    if (( _incompleto )); then
        mv_detalle "Pasos que no se completaron:"
        # Un paso puede entrar dos veces en FALTANTES: una por no estar en
        # OK y otra por estar en KO. Se imprime una sola vez.
        local _vistos=() _dup=0 _v
        for _p in ${MV_PASOS_FALTANTES[@]+"${MV_PASOS_FALTANTES[@]}"}; do
            _dup=0
            for _v in ${_vistos[@]+"${_vistos[@]}"}; do
                [[ "$_v" == "$_p" ]] && { _dup=1; break; }
            done
            (( _dup )) && continue
            _vistos+=("$_p")
            mv_detalle "  - $_p"
        done
        mv_detalle ""
        mv_detalle "El panel puede no funcionar. Revisa el log y no des por buena"
        mv_detalle "esta instalacion hasta resolverlo."
        echo ""
    fi

    # OJO: la variable se declara arriba como _fall (dos ele). Usar _fail
    # aqui rompia con "set -u" porque _fail nunca receives valor.
    if (( _inst + _pend + _fall + _omit > 0 )); then
        mv_dato "Protocolos"     "$_inst instalados"
        (( _pend > 0 )) && mv_dato "Pendientes"   "$_pend (necesitan datos)"
        (( _fall > 0 )) && mv_dato "Con fallo"    "$_fall"
        (( _omit > 0 )) && mv_dato "Omitidos"     "$_omit (requieren otro plan)"
        echo ""
        local _p _e _d
        while IFS=$'\t' read -r _p _e _d; do
            [[ -z "${_p:-}" ]] && continue
            # Detalle: los instalados ANTES solo salian con el nombre y el
            # detalle "ok", asi que el usuario veia una lista de nombres sin
            # saber que tenia detrás (¿con puerto? ¿de que version?). Ahora
            # el instalado tambien enseña su detalle: puerto de escucha, o el
            # que deje el registro.
            [[ "$_d" == "ok" ]] && _d=""
            case "$_e" in
                instalado) mv_ok     "  ${_p}${_d:+ — $_d}" ;;
                pendiente) mv_warn   "  ${_p} — pendiente: ${_d:-faltan datos}" ;;
                fallo)     mv_error  "  ${_p} — fallo: ${_d:-sin detalle}" ;;
                omitido)   mv_detalle "  ${_p} — omitido: ${_d:-otro plan}" ;;
            esac
        done < <(proto_reg_listar)
        echo ""
    fi

    # La version se lee de version.txt (fuente de verdad). El hardcode
    # anterior decia 8.2.16 mientras el banner del instalador ya mostraba
    # v8.2.20: el resumen final mentia sobre la version instalada.
    local _ver_mv
    _ver_mv="$(tr -d ' \n\r' < "$BASE/version.txt" 2>/dev/null)"
    mv_dato "Versión"    "${_ver_mv:-${VERSION:-desconocida}}"
    mv_dato "Plan"       "${LIC_PLAN:-desconocido}"
    # El dominio se muestra aqui para que quede claro que quedo registrado.
    # Si se perdio (config borrada, instalacion reanudada) se avisa en vez
    # de imprimir "desconocido" como si fuera un dato valido.
    if [[ -n "${SERVER_DOMAIN:-}" ]]; then
        mv_dato "Dominio"   "$SERVER_DOMAIN"
    else
        mv_warn "No hay dominio configurado: el panel no sera accesible"
    fi
    mv_dato "Directorio" "/etc/movivip"
    mv_dato "Comando"    "menu (o bash /etc/movivip/menu.sh)"
    echo ""
    mv_detalle "Ejecuta 'menu' para acceder al panel de control."
    mv_detalle "Logs de instalación: /var/log/movivip/instalacion.log"
    echo ""

    # Se devuelve el fallo al FINAL, con el resumen ya impreso. Antes se
    # retornaba aqui arriba y todo lo de abajo se perdia.
    (( _incompleto == 0 ))
}

# ---------------------------------------------------------------------------
# Orquestador del paso cierre
# ---------------------------------------------------------------------------
paso_cierre() {
    mv_fase "Finalizando instalación"

    cierre_permisos
    cierre_launchers
    cierre_ficheros
    cierre_iptables
    cierre_monitoreo_red
    cierre_monitoreo_usuarios
    cierre_banner_limpieza
    cierre_banner_instalar
    cierre_banner_login
    cierre_ofuscar
    cierre_license_watchdog || return 1
    # Autoreparación automática al finalizar la instalación
    if [[ -f "${BASE}/lib/autoreparar.sh" ]]; then
        # shellcheck source=/dev/null
        source "${BASE}/lib/autoreparar.sh"
        auto_reparar || true
    fi
    cierre_resumen
}