#!/bin/bash

MV_LINKED_BASE="${BASE:-/etc/movivip}"
MV_LINKED_PROTOCOLS="$MV_LINKED_BASE/sistema/usuario_protocolos.conf"

mv_linked_user_has_protocol() {
    local user="$1" protocol="$2" list
    list=$(awk -F'|' -v u="$user" '$1 == u { print $2; exit }' "$MV_LINKED_PROTOCOLS" 2>/dev/null)
    [[ ",$list," == *",$protocol,"* ]]
}

mv_linked_setting_on() {
    local key="$1" value
    value=$(grep -E "^${key}=" "$MV_LINKED_BASE/config.conf" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d "\"'[:space:]")
    [[ "$value" == "ON" ]]
}

mv_linked_user_active() {
    local user="$1" state expiry expiry_ts
    id "$user" >/dev/null 2>&1 || return 1
    state=$(passwd -S "$user" 2>/dev/null | awk '{print $2}')
    [[ "$state" != "L" ]] || return 1
    expiry=$(chage -l "$user" 2>/dev/null | awk -F': ' '/Account expires/ {print $2; exit}')
    [[ -z "$expiry" || "$expiry" == "never" || "$expiry" == "Never" ]] && return 0
    expiry_ts=$(date -d "$expiry" +%s 2>/dev/null) || return 1
    (( expiry_ts > $(date +%s) ))
}

mv_linked_user_ssh_password() {
    local user="$1"
    awk -v u="$user" '
        index($0, u "=") == 1 {
            sub(/^[^=]*=/, "")
            print
            exit
        }
    ' "$MV_LINKED_BASE/sistema/passwords.conf" 2>/dev/null
}

mv_linked_protocols_sync_user() {
    local user="$1" password="" result=0
    [[ -n "$user" ]] || return 2

    if mv_linked_user_has_protocol "$user" shadowsocks; then
        if mv_linked_user_active "$user"; then
            bash "$MV_LINKED_BASE/protocolos/shadowsocks.sh" --account-enable "$user" || result=1
        else
            bash "$MV_LINKED_BASE/protocolos/shadowsocks.sh" --account-suspend "$user" || result=1
        fi
    fi

    if mv_linked_user_has_protocol "$user" btun && mv_linked_setting_on BTUN; then
        if mv_linked_user_active "$user"; then
            password=$(mv_linked_user_ssh_password "$user")
            if [[ -z "$password" || "$password" == *:* ]]; then
                printf 'No se pudo sincronizar BTUN para %s: contraseña SSH vacía o con ":" incompatible con el formato users.\n' "$user" >&2
                result=1
            else
                printf '%s\n' "$password" | bash "$MV_LINKED_BASE/protocolos/btun.sh" --account-sync "$user" || result=1
            fi
        else
            bash "$MV_LINKED_BASE/protocolos/btun.sh" --account-suspend "$user" || result=1
        fi
    fi

    return "$result"
}

mv_linked_protocols_reconcile_all() {
    local user
    declare -A seen=()
    if [[ -f /etc/shadowsocks-libev/movivip-users.conf ]]; then
        while IFS='|' read -r user _; do
            [[ -n "$user" ]] && seen["$user"]=1
        done < /etc/shadowsocks-libev/movivip-users.conf
    fi
    if [[ -f /etc/btun/movivip-users ]]; then
        while IFS= read -r user; do
            [[ -n "$user" ]] && seen["$user"]=1
        done < /etc/btun/movivip-users
    fi
    for user in "${!seen[@]}"; do
        mv_linked_protocols_sync_user "$user" || return 1
    done
}

mv_linked_protocols_delete_user() {
    local user="$1" result=0
    [[ -n "$user" ]] || return 2
    bash "$MV_LINKED_BASE/protocolos/shadowsocks.sh" --account-remove "$user" || result=1
    bash "$MV_LINKED_BASE/protocolos/btun.sh" --account-remove "$user" || result=1
    return "$result"
}
