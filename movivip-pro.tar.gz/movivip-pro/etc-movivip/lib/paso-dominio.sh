#!/usr/bin/env bash
#====================================================================
# paso-dominio.sh - Pregunta y valida el dominio del panel
#
# Solo se pregunta EL DOMINIO. Da igual quien lo tenga: el instalador
# no pregunta por el proveedor ni por credenciales de DNS, porque eso no
# es necesario para dejar el panel funcionando y hacia el instalador
# mas lento y mas fragil a cambio de nada.
#
# Exporta:
#   SERVER_DOMAIN  dominio normalizado (sin esquema, sin puerto, sin ruta)
#
# Se puede pasar por entorno para instalar sin terminal:
#   SERVER_DOMAIN=panel.tudominio.com bash install.sh
#====================================================================

# Dominios validos: etiquetas alfanumericas separadas por puntos, TLD de 2 a 63.
#
# El TLD NO se restringe a una lista. No hay .com, .com.ar ni .uk "oficiales":
# el TLD es lo que sea, y restringirse a los conocidos rejects dominios
# buenos. Aqui solo se comprueba FORMA, no existencia: para eso haria falta
# la Public Suffix List, que son varios MB y no cabe en un instalador.
#
#   - el grupo de etiquetas es "(...)+" a proposito: admite TLDs compuestos
#     como .com.ar, .co.uk o .gob.pe sin ningun caso especial
#   - se permiten digitos en el TLD para no quedarnos cortos el dia que
#     exista uno numerico
#   - punycode (xn--p1ai) entra porque el TLD admite guiones internos.
#     Con un TLD de "solo letras y digitos" los TLDs punycode se rechazan,
#     y son reales: .xn--p1ai es el dominio nacional de Rusia en IDN.
#   - una IP NO vale: sin SNI no hay certificado, y el panel no arranca
#
# Etiqueta: empieza y acaba en alfanumerico (nada de -mal.com), 1-63 chars.
# TLD: igual pero minimo 2 caracteres, porque no existe un TLD de 1.
_MV_DOMINIO_LABEL='[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?'
_MV_DOMINIO_TLD='[a-z0-9][a-z0-9-]{0,61}[a-z0-9]'
_MV_DOMINIO_RE="^(${_MV_DOMINIO_LABEL}\.)+${_MV_DOMINIO_TLD}$"

#--------------------------------------------------------------------
# mv_dominio_normalizar "cadena"
#
# Limpia lo que la gente escribe de memoria: "https://Panel.MiDominio.com/"
# es un dominio valido, no una URL. Sin esto el certificado falla y el
# error aparece mucho mas tarde, cuando ya es dificil de explicar.
#--------------------------------------------------------------------
mv_dominio_normalizar() {
    local d="${1:-}"
    d="${d,,}"                        # bash 4+: a minusculas
    d="${d#http://}"; d="${d#https://}"
    d="${d#*://}"                     # cualquier otro esquema
    d="${d%%/*}"                      # quita la ruta
    d="${d%%:*}"                      # quita el puerto
    d="${d%.}"                        # quita el punto final (FQDN)
    d="${d#.}"                        # quita punto inicial
    while [[ "$d" == *..* ]]; do d="${d//../.}"; done
    d="${d// /}"                      # espacios sueltos
    printf '%s' "$d"
}

#--------------------------------------------------------------------
# mv_dominio_valido "dominio"  -> 0 valido, 1 no
#--------------------------------------------------------------------
mv_dominio_valido() {
    local d="${1:-}"
    [[ -z "$d" ]] && return 1
    # IP pura: no sirve como dominio para un panel con TLS.
    [[ "$d" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && return 1
    [[ "$d" =~ $_MV_DOMINIO_RE ]] || return 1
    return 0
}

#--------------------------------------------------------------------
# _mv_ip_valida "cadena"  -> 0 valido, 1 no
#
# Para el fallback headless: si no hay dominio, el panel se instala y queda
# accesible por la IP del servidor. mv_dominio_valido() RECHAZA las IPs a
# proposito (no sirven para un certificado con SNI), asi que aqui hace falta
# una comprobacion de IP. Sin esto, el fallback validaba la IP con
# mv_dominio_valido, la descartaba, y la instalacion sin terminal moria
# siempre con "No se pudo determinar un dominio ni la IP del servidor".
#--------------------------------------------------------------------
_mv_ip_valida() {
    local d="${1:-}"
    [[ "$d" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]] || return 1
    local o
    for o in ${d//./ }; do (( o >= 0 && o <= 255 )) || return 1; done
    return 0
}

#--------------------------------------------------------------------
# mv_preguntar_dominio
#
# Pregunta hasta que el dominio sea valido (3 intentos). En headless usa
# SERVER_DOMAIN y, si no esta, falla con un mensaje util en vez de dejar
# SERVER_DOMAIN vacio y romper mas downstream.
#--------------------------------------------------------------------
mv_preguntar_dominio() {
    local actual="" intento=1

    # Sin terminal: se respeta lo que venga por entorno.
    if [[ ! -t 0 ]]; then
        actual="$(mv_dominio_normalizar "${SERVER_DOMAIN:-}")"
        if mv_dominio_valido "$actual"; then
            SERVER_DOMAIN="$actual"
            return 0
        fi
        if [[ -n "${SERVER_DOMAIN:-}" ]]; then
            mv_error "El dominio de SERVER_DOMAIN no es valido" \
                     "SERVER_DOMAIN='${SERVER_DOMAIN}'" \
                     "Pon un dominio real, p.ej. SERVER_DOMAIN=panel.tudominio.com"
        fi

        # Sin dominio no se aborta: se cae a la IP publica del servidor. Antes
        # esto era return 1 y install.sh terminaba ahi, de modo que quien
        # instalaba sin terminal se quedaba sin instalacion y sin error claro
        # (el panel arranca, escribe en /etc/movivip y se para). El panel es
        # accesible por IP igual que por dominio, asi que es una base valida y
        # el dominio se puede fijar despues desde menu -> Dominio.
        local ip_fallback=""
        local url
        for url in "https://api.ipify.org" "https://ifconfig.me/ip" "https://icanhazip.com"; do
            ip_fallback="$(curl -4 -fsS --max-time 5 "$url" 2>/dev/null | tr -d '[:space:]' || true)"
            if _mv_ip_valida "${ip_fallback:-}"; then
                break
            fi
            ip_fallback=""
        done
        if [[ -z "$ip_fallback" ]]; then
            ip_fallback="$(hostname -I 2>/dev/null | tr ' ' '\n' | grep -v '^127\.' | grep -v '^$' | head -1 || true)"
        fi
        if ! _mv_ip_valida "${ip_fallback:-}"; then
            # Sin IP tampoco: no hay dominio con el que seguir.
            mv_error "No se pudo determinar un dominio ni la IP del servidor" \
                     "" \
                     "Instalando sin terminal debe pasarse por entorno: SERVER_DOMAIN=panel.tudominio.com"
            return 1
        fi
        SERVER_DOMAIN="$ip_fallback"
        mv_dato "Dominio" "$SERVER_DOMAIN" \
                "Sin terminal y sin SERVER_DOMAIN: se usa la IP del servidor."
        return 0
    fi

    while (( intento <= 3 )); do
        mv_pregunta "Dominio del panel (ej. panel.tudominio.com): " "actual" || true
        actual="$(mv_dominio_normalizar "${actual:-}")"
        if mv_dominio_valido "$actual"; then
            SERVER_DOMAIN="$actual"
            return 0
        fi
        if [[ -z "$actual" ]]; then
            mv_warn "El dominio no puede estar vacio"
        else
            mv_warn "'$actual' no parece un dominio" \
                    "Debe ser algo como panel.tudominio.com (no IP, ni http://, ni ruta)"
        fi
        actual=""; intento=$((intento+1))
    done

    mv_error "No se pudo obtener un dominio valido" \
             "" \
             "El panel necesita un dominio para funcionar. Reejecuta y escribelo bien."
    return 1
}

#--------------------------------------------------------------------
# mv_configurar_dominio
#
# Pregunta el dominio y lo deja normalizado en SERVER_DOMAIN. No toca
# DNS: crear el registro A es responsabilidad del titular del dominio y
# se indica al final como hacerlo.
#--------------------------------------------------------------------
mv_configurar_dominio() {
    mv_fase "Dominio del panel"

    if mv_preguntar_dominio; then
        mv_ok "Dominio: $SERVER_DOMAIN"
        mv_detalle "Crea un registro DNS A apuntando a la IP del servidor:"
        mv_dato "Tipo" "A"
        mv_dato "Nombre" "$SERVER_DOMAIN"
        mv_dato "Valor" "${SERVER_IP:-<IP del servidor>}"
        return 0
    fi

    return 1
}