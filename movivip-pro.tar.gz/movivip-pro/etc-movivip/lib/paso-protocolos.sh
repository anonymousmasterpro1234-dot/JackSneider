#!/usr/bin/env bash
# ============================================================================
# PASO: PROTOCOLOS
# Selección e instalación de protocolos. Cada protocolo ya incluye su
# licguard interno, pero aquí orquestamos el flujo de selección.
#
# Lo importante de este paso es que no mienta. Antes hacia:
#
#     bash "$script_path" --install || true
#     ...
#     mv_ok "Protocolos instalados"
#
# El "|| true" se comia cualquier fallo, el paso terminaba con 0 y el
# instalador entero se daba por bueno. Un cliente recibia "instalado
# correctamente" sin un solo protocolo funcionando, y no habia forma de saber
# cual habia fallado ni por que. Ahora cada protocolo deja su veredicto en
# lib/proto-registro.sh, el paso devuelve codigo distinto de 0 si algo quedo
# mal, y el resumen final lista la verdad.
# ============================================================================
set -uo pipefail

# Cargar gate de plan
if [[ -f "${BASE:-/etc/movivip}/lib/plancheck.sh" ]]; then
    # shellcheck source=/dev/null
    source "${BASE:-/etc/movivip}/lib/plancheck.sh"
fi

# nav.sh aporta nav_pick, el selector de dos columnas que usa el menu de
  # protocolos de mas abajo. Sin esto sale "nav_pick: command not found" y la
  # lista de protocolos no llega a mostrarse.
  if [[ -f "${BASE:-/etc/movivip}/lib/nav.sh" ]]; then
      # shellcheck source=/dev/null
      source "${BASE:-/etc/movivip}/lib/nav.sh"
  fi

  # Cargar el registro de protocolos. Si no esta, el paso no puede saber la
  # verdad, y es mejor decirlo que fingir: se avisa y se sigue, porque el
  # instalador tiene que ser utilizable aunque falte un fichero.
if [[ -f "${BASE:-/etc/movivip}/lib/proto-registro.sh" ]]; then
    # shellcheck source=/dev/null
    source "${BASE:-/etc/movivip}/lib/proto-registro.sh"
else
    _proto_sin_registro=1
fi

# ---------------------------------------------------------------------------
# Mapeo de protocolos disponibles (clave -> script en protocolos/)
#
# Solo se listan scripts que existen de verdad. Comprobarlo aqui evita el
# "Script no encontrado: dnstt.sh" que se llevaba un protocolo entero por
# delante: dnstt estaba en el mapa pero el fichero no existia nunca.
# bot, en cambio, si existe y es PREMIUM+, pero no estaba en el mapa, con lo
# cual era imposible instalarlo desde el instalador.
# ---------------------------------------------------------------------------
declare -A PROTO_SCRIPTS=(
    [badvpn]="badvpn.sh"
    [bhttp]="bhttp.sh"
    [bot]="bot.sh"
    [btun]="btun.sh"
    [dropbear]="dropbear.sh"
    [dtunnel]="dtunnel.sh"
    [fastly]="fastly.sh"
    [hcr]="hcr.sh"
    [hysteria]="hysteria.sh"
    [openssh]="openssh.sh"
    [openvpn]="openvpn.sh"
    [shadowsocks]="shadowsocks.sh"
    [singbox]="singbox.sh"
    [slowdns]="slowdns.sh"
    [socks5]="socks5.sh"
    [squid]="squid.sh"
    [ssl]="ssl.sh"
    [systemdns]="systemdns.sh"
    [udpcustom]="udpcustom.sh"
    [v2ray]="v2ray.sh"
    [web]="web.sh"
    [webmin]="webmin.sh"
    [wireguard]="wireguard.sh"
    [xhttp]="xhttp.sh"
    [xui]="movivip-panel.sh"
    [zipvpn]="zipvpn.sh"
)

# Protocolos que requieren plan PROVEEDOR/ADMIN (Facturación, MOVIVIP-PANEL, Web MOVIVIP)
PROTO_PROVEEDOR=(wireguard web webmin xui)

# Protocolos que requieren plan PREMIUM+ (Bot, Webmin)
PROTO_PREMIUM=(bot webmin)

# ---------------------------------------------------------------------------
# Protocolos que no se pueden instalar solos: necesitan un dato del usuario
#
# Estos no son un fallo del script. Es que el instalador no tiene con quien
# preguntar, asi que se marcan "pendiente" y se reintentan al volver a ejecutar
# el instalador. Es justo el caso que se quejaba el usuario: se elegian todos,
# se paraban porque faltaban datos, y al repetir el instalador habia que
# empezar otra vez desde el principio.
#
# slowdns: necesita un dominio CON NS delegados. Se comprueba de verdad con
#   dig (o DoH si no hay dig), porque un dominio sin NS no tiene tunel y
#   slowdns.sh solo crearia el servicio sin responder a nada. Si
#   SLOWDNS_DOMAIN no esta, se acepta el SERVER_DOMAIN del instalador
#   cuando tiene NS; si no lo tiene, instalacion manual.
#
# dtunnel: necesita el TOKEN OFICIAL del equipo DTunnel (DTUNNEL_TOKEN).
#   dtunnel.sh lo valida ONLINE contra el servidor de ellos: un token
#   inventado no vale. Sin token, dtunnel.sh abria su propio prompt y el
#   instalador se quedaria esperando teclado, asi que aqui se marca
#   pendiente y la instalacion es manual (menu del panel o dtunnel.sh a mano).
# ---------------------------------------------------------------------------
declare -A PROTO_DATOS=(
    [slowdns]="SLOWDNS_DOMAIN:dominio con NS delegados para SlowDNS (instalacion manual si tu dominio no tiene NS)"
    [dtunnel]="DTUNNEL_TOKEN:token oficial de DTunnel (instalacion manual desde el panel si no lo tienes)"
    [singbox]="SERVER_DOMAIN:dominio cubierto por el certificado SSL existente"
)

# Protocolos cuyo fallo se clasifica como "pendiente" y no como error de
# instalacion, porque dependen de datos queTodavia no se han proporcionado.
PROTO_DATOS_DEPENDIENTES=(dtunnel slowdns singbox)

# ---------------------------------------------------------------------------
# Dependencias entre protocolos.
#
# ssl regenera la configuración base de HAProxy y vuelve a inyectar las rutas
# de los protocolos que ya están instalados. XHTTP es una dependencia directa;
# HCR y V2Ray también deben quedar instalados antes de esa regeneración.
# Al final del paso se reconcilian de nuevo las rutas para cubrir cualquier
# orden de selección interactivo.
# ---------------------------------------------------------------------------
declare -A PROTO_DEPS=(
    [ssl]="xhttp"
)

# ---------------------------------------------------------------------------
# Puertos por defecto de cada protocolo
#
# SOLO los verificados en el script de cada protocolo o en la pantalla de
# puertos de nav.sh (lib/nav.sh L518-521). Los que no aparecen aqui no se
# inventan: en el resumen salen con su nombre y nada mas.
# ---------------------------------------------------------------------------
declare -A PROTO_PUERTOS=(
    [badvpn]="7200·7300"
    [bhttp]="80·443·8080·8443 (/bhttp con SSL)"
    [btun]="7900"
    [dropbear]="90·109·143"
    [dtunnel]="4443"
    [fastly]="80·443"
    [hcr]="8883"
    [hysteria]="36600/UDP"
    [openssh]="22"
    [openvpn]="1194"
    [shadowsocks]="8388"
    [singbox]="TUIC 36713/UDP · AnyTLS 36714/TCP · Naive 36715/TCP"
    [slowdns]="53·5300"
    [squid]="3128"
    [ssl]="443"
    [udpcustom]="36712"
    [v2ray]="443"
    [web]="9617"
    [wireguard]="51820"
    [xhttp]="443"
    [zipvpn]="5667/UDP"
)

# Contadores del paso, para el codigo de salida.
PROTO_N_INSTALADOS=0
PROTO_N_FALLOS=0
PROTO_N_PENDIENTES=0

# ----------------------------------------------------------------------------
# proto_registrar: guardar el veredicto, o avisar si el registro no esta
# ----------------------------------------------------------------------------
proto_registrar() {
    local proto="$1" estado="$2" detalle="${3:-}"
    if [[ "${_proto_sin_registro:-0}" == "1" ]]; then
        # Sin registro no hay persistencia, pero el paso sigue siendo util.
        case "$estado" in
            instalado) (( PROTO_N_INSTALADOS++ )) ;;
            fallo)     (( PROTO_N_FALLOS++ )) ;;
            pendiente) (( PROTO_N_PENDIENTES++ )) ;;
        esac
        return 0
    fi
    proto_reg_registrar "$proto" "$estado" "$detalle"
    case "$estado" in
        instalado) (( PROTO_N_INSTALADOS++ )) ;;
        fallo)     (( PROTO_N_FALLOS++ )) ;;
        pendiente) (( PROTO_N_PENDIENTES++ )) ;;
    esac
}

# ----------------------------------------------------------------------------
# proto_dominio_con_ns: ¿este dominio tiene NS delegados?
#
# Sin NS, un dominio no puede resolver el tunel de slowdns. Se comprueba con
# dig (que slowdns.sh y menu.sh ya usan) y, si no hay dig, contra el DoH de
# Google con curl. IP a secas no vale: una IP no tiene zona DNS propia.
# ----------------------------------------------------------------------------
proto_dominio_con_ns() {
    local d="$1" ns=""
    [[ -n "$d" ]] || return 1
    [[ "$d" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]] && return 1
    if command -v dig >/dev/null 2>&1; then
        ns="$(dig +short +time=3 +tries=1 NS "$d" 2>/dev/null | head -1)"
    elif command -v curl >/dev/null 2>&1; then
        ns="$(curl -s --max-time 5 "https://dns.google/resolve?name=${d}&type=NS" 2>/dev/null \
              | grep -o '"data":"[^"]*"' | head -1)"
    fi
    [[ -n "$ns" ]]
}

# ----------------------------------------------------------------------------
# proto_dominio_slowdns: dominio usable para slowdns, o nada
#
# Orden: SLOWDNS_DOMAIN explicito, luego SERVER_DOMAIN del instalador.
# Solo se devuelve si el dominio tiene NS delegados.
# ----------------------------------------------------------------------------
proto_dominio_slowdns() {
    local d="${SLOWDNS_DOMAIN:-}"
    if [[ -n "$d" ]]; then
        proto_dominio_con_ns "$d" || return 1
        printf '%s' "$d"
        return 0
    fi
    d="${SERVER_DOMAIN:-}"
    [[ -n "$d" ]] || return 1
    proto_dominio_con_ns "$d" || return 1
    printf '%s' "$d"
    return 0
}

# ----------------------------------------------------------------------------
# proto_requiere_datos: cual es el dato que falta, o nada si esta todo
# ----------------------------------------------------------------------------
proto_requiere_datos() {
    local proto="$1" spec="${PROTO_DATOS[$proto]:-}"
    [[ -z "$spec" ]] && return 1
    local var="${spec%%:*}" desc="${spec#*:}"
    local valor="${!var:-}"

    # slowdns: el dato no es una variable vacia/no vacia, sino un dominio
    # con NS. SERVER_DOMAIN vale como sustituto si tiene NS delegados.
    if [[ "$proto" == "slowdns" ]]; then
        if proto_dominio_slowdns >/dev/null; then
            return 1
        fi
        if [[ -n "${SERVER_DOMAIN:-}" && -z "${SLOWDNS_DOMAIN:-}" ]]; then
            printf '%s\n' "el dominio ${SERVER_DOMAIN} no tiene NS delegados (slowdns: instalacion manual)"
            return 0
        fi
        printf '%s\n' "$desc"
        return 0
    fi

    if [[ -z "$valor" ]]; then
        printf '%s\n' "$desc"
        return 0
    fi
    return 1
}

# ----------------------------------------------------------------------------
# proto_depende_de_datos: true si este protocolo no se puede instalar sin que
# el usuario de un dato primero
# ----------------------------------------------------------------------------
proto_depende_de_datos() {
    local proto="$1" p
    for p in ${PROTO_DATOS_DEPENDIENTES[@]+"${PROTO_DATOS_DEPENDIENTES[@]}"}; do
        [[ "$proto" == "$p" ]] && return 0
    done
    return 1
}

# ---------------------------------------------------------------------------
# Verifica si un protocolo está disponible para el plan actual
# ---------------------------------------------------------------------------
proto_disponible() {
    local proto="$1"
    local script="${PROTO_SCRIPTS[$proto]:-}"
    if [[ -z "$script" ]]; then
        return 1
    fi
    
    # 1. Gate de proveedor/admin
    for p in "${PROTO_PROVEEDOR[@]}"; do
        if [[ "$proto" == "$p" ]]; then
            if declare -F es_proveedor >/dev/null 2>&1; then
                if ! es_proveedor; then
                    return 1
                fi
            fi
            return 0
        fi
    done
    
    # 2. Gate de premium+
    for p in "${PROTO_PREMIUM[@]}"; do
        if [[ "$proto" == "$p" ]]; then
            if declare -F es_premium >/dev/null 2>&1; then
                if ! es_premium && ! es_proveedor; then
                    return 1
                fi
            fi
            return 0
        fi
    done
    
    # 3. Protocolos básicos (bronze/standard)
    return 0
}

# ---------------------------------------------------------------------------
# Ejecuta la instalación de un protocolo
#
# Devuelve 0 solo si el script devolvio 0. Cualquier otra cosa se registra y se
# propaga: aqui no se traga ningun error.
# ----------------------------------------------------------------------------
_proto_ya_instalado() {
    local p="$1"
    declare -F proto_reg_por_estado >/dev/null 2>&1 || return 1
    proto_reg_por_estado instalado 2>/dev/null | grep -qx -- "$p"
}

proto_instalar() {
    local proto="$1"

    # Dependencias: instalar la base antes (ssl exige xhttp bindeando 2001/2002).
    # Guarda anti-recursion: las dependencias de una dependencia no se expanden.
    # No continuar si la base falla: SSL no debe activarse con sus backends DOWN.
    if [[ -z "${_proto_deps_fase:-}" ]]; then
        local _dep _dep_rc
        for _dep in ${PROTO_DEPS[$proto]:-}; do
            [[ -n "${PROTO_SCRIPTS[$_dep]:-}" ]] || continue
            _proto_ya_instalado "$_dep" && continue
            mv_detalle "Dependencia de $proto: instalando $_dep primero"
            _dep_rc=0
            _proto_deps_fase=1 proto_instalar "$_dep" || _dep_rc=$?
            if (( _dep_rc != 0 )); then
                if (( _dep_rc == 2 )); then
                    mv_warn "$proto queda pendiente: falta completar la dependencia $_dep."
                    proto_registrar "$proto" pendiente "dependencia $_dep pendiente"
                    return 2
                fi
                mv_error "$proto no se instala: fallo su dependencia $_dep."
                proto_registrar "$proto" fallo "dependencia $_dep fallo (codigo $_dep_rc)"
                return 1
            fi
        done
    fi

    local script="${PROTO_SCRIPTS[$proto]:-}"
    if [[ -z "$script" ]]; then
        mv_error "Protocolo desconocido: $proto"
        proto_registrar "$proto" fallo "no esta en el mapa de protocolos"
        return 1
    fi
    local script_path="${BASE:-/etc/movivip}/protocolos/$script"
    if [[ ! -f "$script_path" ]]; then
        mv_error "Script no encontrado: $script_path"
        proto_registrar "$proto" fallo "falta el script $script"
        return 1
    fi

    # Si falta un dato conocido, no se ejecuta: se deja pendiente y se explica
    # cual. Ejecutar a ciegas solo produce un error confuso.
    local falta
    if falta="$(proto_requiere_datos "$proto")"; then
        mv_warn "$proto: falta ${falta}. Queda pendiente."
        mv_detalle "  Se instalara solo cuando ese dato este disponible."
        proto_registrar "$proto" pendiente "falta ${falta}"
        return 2
    fi

    mv_fase "Instalando $proto"
    local rc=0
    # slowdns recibe el dominio por variable de entorno (asi lo lee
    # slowdns.sh: SLOWDNS_DOMAIN manda sobre su prompt). Sin ella caeria
    # en la instalacion manual, que es justo lo que proto_requiere_datos
    # acaba de comprobar que no toca.
    if [[ "$proto" == "slowdns" ]]; then
        local dom
        if dom="$(proto_dominio_slowdns)"; then
            SLOWDNS_DOMAIN="$dom" bash "$script_path" --install || rc=$?
        else
            mv_warn "slowdns: sin dominio con NS. Instalacion manual."
            proto_registrar "$proto" pendiente "sin dominio con NS (instalacion manual)"
            return 2
        fi
    else
        bash "$script_path" --install || rc=$?
    fi

    if (( rc == 0 )); then
        # Detalle para el resumen: el puerto de escucha verificado del
        # protocolo. Sin dato no se inventa y sale solo el nombre.
        local det=""
        [[ -n "${PROTO_PUERTOS[$proto]:-}" ]] && det="puerto ${PROTO_PUERTOS[$proto]}"
        mv_ok "${proto}${det:+ — $det}"
        proto_registrar "$proto" instalado "$det"
        return 0
    fi

    # Un protocolo que depende de datos y falla no es un instalador roto: es un
    # dato que no se pudo pedir. Se marca pendiente para reintentarlo luego.
    if proto_depende_de_datos "$proto"; then
        mv_warn "$proto fallo (codigo $rc). Necesita datos que faltan."
        proto_registrar "$proto" pendiente "requiere datos, codigo $rc"
        return 2
    fi

    mv_error "$proto fallo (codigo $rc)"
    proto_registrar "$proto" fallo "codigo $rc"
    return 1
}

# ---------------------------------------------------------------------------
# Reintento: lo que quedo pendiente o fallo en una ejecucion anterior
#
# Es lo que hace que repetir el instalador continue donde se quedo en vez de
# empezar de cero. Solo se reintentan los que el plan actual permite.
# ---------------------------------------------------------------------------
proto_reanudar() {
    local pendientes
    pendientes="$(proto_reg_no_instalados)"
    [[ -z "$pendientes" ]] && return 0

    local lista=()
    local p
    while IFS= read -r p; do
        [[ -z "$p" ]] && continue
        proto_disponible "$p" && lista+=("$p")
    done <<< "$pendientes"

    (( ${#lista[@]} == 0 )) && return 0

    mv_fase "Reanudando instalacion anterior"
    mv_detalle "Protocolos pendientes de la ultima ejecucion: ${lista[*]}"
    for p in "${lista[@]}"; do
        # El resultado ya no importa aqui: se acumula en los contadores y lo
        # decide el codigo de salida de paso_protocolos.
        proto_instalar "$p" || true
    done
    return 0
}

# ---------------------------------------------------------------------------
# Instalacion en lote (modo headless: lista separada por comas, o "todos")
# ---------------------------------------------------------------------------
proto_instalar_lote() {
    local lista="$1"
    IFS=',' read -ra protos <<< "$lista"
    local orden=() ssl_solicitado=0
    for proto in "${protos[@]}"; do
        proto="$(echo "$proto" | xargs)"  # trim
        [[ -n "$proto" ]] || continue
        if [[ "$proto" == "ssl" ]]; then
            ssl_solicitado=1
            continue
        fi
        orden+=("$proto")
    done
    (( ssl_solicitado )) && orden+=(ssl)

    for proto in "${orden[@]}"; do
        if proto_disponible "$proto"; then
            proto_instalar "$proto" || true
        else
            mv_warn "Protocolo no disponible para tu plan: $proto"
            proto_registrar "$proto" omitido "requiere otro plan"
        fi
    done
}

# ---------------------------------------------------------------------------
# Modo "todos"
#
# Instala todo lo disponible. Los protocolos que necesitan un dato no se
# ejecutan a ciegas: quedan pendientes con el motivo, y el resumen final lo
# dice. Volver a ejecutar el instalador los reintenta solos.
# ---------------------------------------------------------------------------
proto_instalar_todos() {
    mv_fase "Instalando todos los protocolos disponibles"

    # Recorrer en orden estable: PROTO_SCRIPTS es asociativo y Bash no
    # garantiza el orden de las claves, asi que un "todos" podia instalar en
    # orden distinto en cada ejecucion.
    local orden=(badvpn bhttp bot btun dropbear dtunnel hcr hysteria openssh
                 openvpn shadowsocks slowdns socks5 squid xhttp systemdns
                 udpcustom v2ray web webmin wireguard xui zipvpn ssl)
    local proto
    for proto in "${orden[@]}"; do
        [[ -n "${PROTO_SCRIPTS[$proto]:-}" ]] || continue
        if proto_disponible "$proto"; then
            proto_instalar "$proto" || true
        else
            mv_warn "$proto: no disponible para tu plan"
            proto_registrar "$proto" omitido "requiere otro plan"
        fi
    done
}

# ---------------------------------------------------------------------------
# Menú interactivo de selección de protocolos
# ---------------------------------------------------------------------------
proto_menu_seleccion() {
    # Defensa headless: sin terminal nav_pick no puede leer y el bucle de
    # abajo gira para siempre ("Seleccion invalida: 0"). Si no hay TTY, se
    # instalan todos los disponibles (equivalente a PROTOCOLOS=todos) en vez
    # de colgar el instalador.
    if [[ ! -t 0 ]]; then
        mv_warn "Sin terminal: se instalan todos los protocolos disponibles." \
                "Para elegir, pasa por entorno: PROTOCOLOS=\"ssl,v2ray\" o PROTOCOLOS=\"todos\"."
        proto_instalar_todos
        return 0
    fi

    local disponibles=() etiquetas=()
    # RED solo la define lib/anim.sh, que este fichero no sourcea. Con
    # "set -u" (activo arriba) "$RED" a secas abortaba el instalador entero
    # al primer protocolo no disponible, en modo no interactivo o sin TTY.
    # Mismo patron que los 10 protocolos: valor por defecto vacio.
    local RED="${MV_RED:-$'\033[31m'}"
    local CYAN="${MV_CYN:-$'\033[36m'}"
    local GREEN="${MV_GRN:-$'\033[32m'}"
    local YELLOW="${MV_YLW:-$'\033[33m'}"
    local RESET="${MV_R:-$'\033[0m'}"
    # Orden ESTABLE (los arrays asociativos iteran aleatorio y la lista
    # cambiaba en cada ejecución). Mismo orden que proto_instalar_todos.
    local orden_estable=(badvpn bhttp bot btun dropbear dtunnel hcr hysteria openssh
                         openvpn shadowsocks slowdns socks5 squid systemdns
                         udpcustom v2ray web webmin wireguard xhttp xui zipvpn ssl)
    local proto
    for proto in "${orden_estable[@]}"; do
        [[ -n "${PROTO_SCRIPTS[$proto]:-}" ]] || continue
        # AMBOS arrays siempre sincronizados: disponibles[i] <-> etiquetas[i].
        # Antes los no-disponibles solo iban a etiquetas[] y los índices se
        # desalineaban: elegir "xray" instalaba otro (ej. btun).
        disponibles+=("$proto")
        if proto_disponible "$proto"; then
            # Etiqueta con indicador de tier
            local label="$proto"
            for p in "${PROTO_PROVEEDOR[@]}"; do
                [[ "$proto" == "$p" ]] && label+=" ${CYAN}[PROVEEDOR]${RESET}"
            done
            for p in "${PROTO_PREMIUM[@]}"; do
                [[ "$proto" == "$p" ]] && label+=" ${GREEN}[PREMIUM+]${RESET}"
            done
            etiquetas+=("$label")
        else
            local label="$proto"
            for p in "${PROTO_PROVEEDOR[@]}"; do
                [[ "$proto" == "$p" ]] && label+=" ${RED}(requiere PROVEEDOR)${RESET}"
            done
            for p in "${PROTO_PREMIUM[@]}"; do
                [[ "$proto" == "$p" ]] && label+=" ${YELLOW}(requiere PREMIUM+)${RESET}"
            done
            etiquetas+=("$label")
        fi
    done

    # Los pendientes de una ejecucion anterior van primero: si el usuario vuelve
    # a ejecutar el instalador, lo que quiere es acabar lo que quedo a medias.
    local reabrir=()
    if declare -F proto_reg_no_instalados >/dev/null 2>&1; then
        local p
        while IFS= read -r p; do
            [[ -z "$p" ]] && continue
            proto_disponible "$p" || continue
            # Localizar su indice en la lista de disponibles.
            local i idx
            for i in "${!disponibles[@]}"; do
                if [[ "${disponibles[$i]}" == "$p" ]]; then
                    idx=$(( i + 1 ))
                    reabrir+=("$idx")
                fi
            done
        done < <(proto_reg_no_instalados)
        if (( ${#reabrir[@]} > 0 )); then
            mv_detalle "Pendientes de la ultima ejecucion: ${reabrir[*]}"
        fi
    fi

    local n_proto="${#etiquetas[@]}"
    etiquetas+=("Instalar todos los disponibles")
    local idx_todos=$(( n_proto + 1 ))
    etiquetas+=("Terminar seleccion")

    while true; do
        mv_fase "Seleccion de protocolos"
        local sel
        sel=$(nav_pick "Protocolos a instalar:" "${etiquetas[@]}") || return 1
        
        # Terminar seleccion
        if (( sel == n_proto + 2 )); then
            break
        fi
        
        # Instalar todos (opcion idx_todos = n_proto + 1)
        if (( sel == idx_todos )); then
            proto_instalar_todos
            continue
        fi
        
        # Protocolo individual - SOLO este, validar rango y plan
        if (( sel >= 1 && sel <= n_proto )); then
            local proto="${disponibles[sel-1]:-}"
            if [[ -n "$proto" ]]; then
                if ! proto_disponible "$proto"; then
                    mv_warn "$proto: no disponible para tu plan (requiere otro tier)"
                    proto_registrar "$proto" omitido "requiere otro plan"
                else
                    mv_detalle "Instalando solo: $proto"
                    proto_instalar "$proto" || true
                fi
            fi
        else
            mv_warn "Seleccion invalida: $sel (rango 1-$n_proto)"
        fi
    done
}

# ---------------------------------------------------------------------------
# Orquestador del paso protocolos
# ---------------------------------------------------------------------------
proto_finalizar_rutas_ssl() {
    local config="${BASE:-/etc/movivip}/config.conf"
    local ssl_state ssl_script="${BASE:-/etc/movivip}/protocolos/ssl.sh"

    [[ -f "$config" ]] || return 0
    ssl_state="$(grep '^SSL=' "$config" 2>/dev/null | tail -n 1 | cut -d= -f2- | tr -d "\"'[:space:]")"
    [[ "$ssl_state" == "ON" ]] || return 0

    if [[ ! -f "$ssl_script" ]]; then
        mv_error "SSL está activado, pero falta $ssl_script para finalizar las rutas de HAProxy."
        return 1
    fi

    mv_fase "Finalizando rutas SSL/HAProxy"
    if bash "$ssl_script" --repair; then
        mv_ok "Rutas SSL/HAProxy verificadas después de instalar los protocolos."
        return 0
    fi

    mv_error "No se pudieron finalizar las rutas SSL/HAProxy."
    mv_detalle "Revisa /var/log/movivip-install.log y ejecuta: bash $ssl_script --repair"
    return 1
}

proto_instalar_protocolos_respaldo() {
    local helper="${BASE:-/etc/movivip}/lib/format-backup.sh"
    local anteriores rc proto no_disponibles=0

    [[ -f "$helper" ]] || return 0
    if anteriores="$(bash "$helper" --pending-protocols)"; then
        :
    else
        rc=$?
        if (( rc == 3 )); then
            return 0
        fi
        mv_error "No se pudo leer la lista de protocolos del backup de formateo."
        return 1
    fi
    [[ -n "$anteriores" ]] || return 0

    mv_fase "Recuperando protocolos anteriores al formateo"
    while IFS= read -r proto; do
        [[ -n "$proto" ]] || continue
        if _proto_ya_instalado "$proto"; then
            continue
        fi
        if ! proto_disponible "$proto"; then
            mv_warn "$proto: no está disponible en el plan actual; sus datos seguirán respaldados."
            no_disponibles=1
            continue
        fi
        mv_detalle "Reinstalando $proto para poder recuperar sus cuentas."
        proto_instalar "$proto" || {
            mv_error "No se pudo reinstalar $proto desde el backup previo."
            return 1
        }
    done <<< "$anteriores"

    if (( no_disponibles )); then
        mv_detalle "El backup seguirá pendiente hasta que todos los protocolos estén disponibles."
    fi
    return 0
}

proto_finalizar_respaldo() {
    local helper="${BASE:-/etc/movivip}/lib/format-backup.sh" rc=0

    [[ -f "$helper" ]] || return 0
    proto_instalar_protocolos_respaldo || return 1
    bash "$helper" --restore || rc=$?
    if (( rc == 2 )); then
        mv_warn "Algunos datos siguen pendientes; el backup se conservará para el próximo intento."
        return 0
    elif (( rc != 0 )); then
        mv_error "No se pudo completar la restauración del backup de formateo."
        return 1
    fi
    return 0
}

paso_protocolos() {
    mv_fase "Instalacion de protocolos"

    # Antes de nada: intentar cerrar lo que quedo a medias.
    proto_reanudar

    # Modo headless: PROTOCOLOS="badvpn,ssl,web" bash install.sh
    #              PROTOCOLOS="todos"          bash install.sh
    if [[ -n "${PROTOCOLOS:-}" ]]; then
        if [[ "${PROTOCOLOS//[[:space:]]/}" == "todos" ]]; then
            proto_instalar_todos
        else
            proto_instalar_lote "$PROTOCOLOS"
        fi
    else
        proto_menu_seleccion
    fi

    local backup_restore_rc=0
    proto_finalizar_respaldo || backup_restore_rc=$?

    # ssl.sh reconstruye HAProxy durante --install. Reconciliar al terminar
    # asegura que las rutas de protocolos elegidos después (por ejemplo
    # V2Ray/Xray) también queden activas en una instalación limpia.
    local ssl_reconcile_rc=0
    proto_finalizar_rutas_ssl || ssl_reconcile_rc=$?

    echo ""

    # Decir la verdad sobre lo que ha pasado, en vez de un "Protocolos
    # instalados" que no significaba nada.
    if declare -F proto_reg_cuenta >/dev/null 2>&1; then
        local inst="${PROTO_N_INSTALADOS}" fall="${PROTO_N_FALLOS}" pend="${PROTO_N_PENDIENTES}"
        if (( pend > 0 )); then
            mv_warn "Protocolos pendientes por falta de datos: $pend"
            local p
            while IFS= read -r p; do
                [[ -z "$p" ]] && continue
                mv_detalle "  - $p"
            done < <(proto_reg_por_estado pendiente)
            mv_detalle "  Vuelve a ejecutar el instalador para instalarlos."
        fi
        if (( fall > 0 )); then
            mv_error "Protocolos con fallo: $fall"
            local p
            while IFS= read -r p; do
                [[ -z "$p" ]] && continue
                mv_detalle "  - $p"
            done < <(proto_reg_por_estado fallo)
        fi
    fi

    # Con fallos o pendientes, este paso NO va bien. Antes devolvia 0 siempre y
    # por eso el instalador entero anunciaba exito sin tener nada.
    if (( PROTO_N_FALLOS > 0 || ssl_reconcile_rc != 0 || backup_restore_rc != 0 )); then
        return 1
    fi

    mv_ok "Protocolos instalados: $PROTO_N_INSTALADOS"
    if (( PROTO_N_PENDIENTES > 0 )); then
        mv_detalle "Pendientes: $PROTO_N_PENDIENTES"
    fi
    return 0
}