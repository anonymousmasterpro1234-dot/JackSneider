#!/bin/bash

MV_HWID_SSH_GROUP="${MV_HWID_SSH_GROUP:-movivip-hwid}"
MV_HWID_SSH_DROPIN="${MV_HWID_SSH_DROPIN:-/etc/ssh/sshd_config.d/99-movivip-hwid.conf}"
MV_HWID_KEYS_DIR="${MV_HWID_KEYS_DIR:-${BASE:-/etc/movivip}/hwid-keys}"
MV_HWID_AUTHORIZED_KEYS_DIR="${MV_HWID_AUTHORIZED_KEYS_DIR:-/etc/ssh/movivip-hwid-keys}"

mv_hwid_ssh_key_fingerprint() {
    local user="$1"
    ssh-keygen -lf "$MV_HWID_KEYS_DIR/$user/id_ed25519.pub" 2>/dev/null \
        | awk '{print $2}'
}

mv_hwid_ssh_forget_password() {
    local user="$1" file="${BASE:-/etc/movivip}/sistema/passwords.conf" tmp
    [[ "$user" =~ ^[a-z0-9_]{3,20}$ ]] || return 2
    [[ -f "$file" ]] || return 0
    tmp=$(mktemp "${file}.XXXXXX") || return 1
    awk -F= -v user="$user" '$1 != user { print }' "$file" > "$tmp" || {
        rm -f "$tmp"
        return 1
    }
    chmod 600 "$tmp" && mv -f "$tmp" "$file"
}

mv_hwid_ssh_remove_user() {
    local user="$1"
    [[ "$user" =~ ^[a-z0-9_]{3,20}$ ]] || return 2
    rm -rf -- "$MV_HWID_KEYS_DIR/$user"
    rm -rf -- "$MV_HWID_AUTHORIZED_KEYS_DIR/$user"
}

mv_hwid_ssh_dropin_content() {
    cat <<EOF
# MoviVIP HWID accounts use per-account SSH public keys only.
Match Group $MV_HWID_SSH_GROUP
    AuthenticationMethods publickey
    PasswordAuthentication no
    KbdInteractiveAuthentication no
    PubkeyAuthentication yes
    AuthorizedKeysFile $MV_HWID_AUTHORIZED_KEYS_DIR/%u/authorized_keys
Match all
EOF
}

mv_hwid_ssh_sync_authorized_keys() {
    local source user destination
    install -d -o root -g root -m 711 "$MV_HWID_AUTHORIZED_KEYS_DIR" || return 1
    for source in "$MV_HWID_KEYS_DIR"/*/authorized_keys; do
        [[ -f "$source" ]] || continue
        user="${source%/authorized_keys}"
        user="${user##*/}"
        [[ "$user" =~ ^[a-z0-9_]{3,20}$ ]] || continue
        destination="$MV_HWID_AUTHORIZED_KEYS_DIR/$user"
        install -d -o root -g root -m 711 "$destination" || return 1
        install -o root -g root -m 644 "$source" "$destination/authorized_keys" || return 1
    done
}

mv_hwid_ssh_rollback_dropin() {
    local had_dropin="$1" backup="$2"
    if [[ "$had_dropin" == "yes" ]]; then
        install -o root -g root -m 644 "$backup" "$MV_HWID_SSH_DROPIN" || return 1
    else
        rm -f -- "$MV_HWID_SSH_DROPIN" || return 1
    fi
}

mv_hwid_ssh_enable_policy() {
    local user="$1" service backup tmp had_dropin=no effective
    [[ "$user" =~ ^[a-z0-9_]{3,20}$ ]] || return 2
    command -v sshd >/dev/null 2>&1 || {
        echo "No se encontró sshd; no se puede activar autenticación por llave." >&2
        return 1
    }
    [[ -d "$(dirname "$MV_HWID_SSH_DROPIN")" ]] || {
        printf 'No existe %s; falta soporte de configuración SSH drop-in.\n' "$(dirname "$MV_HWID_SSH_DROPIN")" >&2
        return 1
    }
    getent group "$MV_HWID_SSH_GROUP" >/dev/null 2>&1 || groupadd --system "$MV_HWID_SSH_GROUP" || {
        echo "No se pudo crear el grupo SSH $MV_HWID_SSH_GROUP." >&2
        return 1
    }
    id "$user" >/dev/null 2>&1 || {
        echo "No existe la cuenta SSH $user." >&2
        return 1
    }

    tmp=$(mktemp -d) || return 1
    backup="$tmp/dropin.previous"
    if [[ -f "$MV_HWID_SSH_DROPIN" ]]; then
        cp -a "$MV_HWID_SSH_DROPIN" "$backup" || { rm -rf "$tmp"; return 1; }
        had_dropin=yes
    fi

    if ! usermod -aG "$MV_HWID_SSH_GROUP" "$user"; then
        echo "No se pudo asignar $user al grupo $MV_HWID_SSH_GROUP." >&2
        rm -rf "$tmp"
        return 1
    fi

    mv_hwid_ssh_dropin_content > "$tmp/dropin.new" || {
        echo "No se pudo generar la política SSH de HWID." >&2
        rm -rf "$tmp"
        return 1
    }
    install -o root -g root -m 644 "$tmp/dropin.new" "$MV_HWID_SSH_DROPIN" || {
        echo "No se pudo instalar la política SSH de HWID." >&2
        rm -rf "$tmp"
        return 1
    }

    if ! mv_hwid_ssh_sync_authorized_keys; then
        mv_hwid_ssh_rollback_dropin "$had_dropin" "$backup" || true
        gpasswd -d "$user" "$MV_HWID_SSH_GROUP" >/dev/null 2>&1 || true
        echo "No se pudieron publicar las llaves autorizadas para sshd." >&2
        rm -rf "$tmp"
        return 1
    fi

    if ! sshd -t; then
        mv_hwid_ssh_rollback_dropin "$had_dropin" "$backup" || true
        gpasswd -d "$user" "$MV_HWID_SSH_GROUP" >/dev/null 2>&1 || true
        echo "sshd rechazó la política HWID; se restauró la configuración anterior." >&2
        rm -rf "$tmp"
        return 1
    fi
    effective=$(sshd -T -C "user=$user,host=localhost,addr=127.0.0.1" 2>/dev/null) || {
        mv_hwid_ssh_rollback_dropin "$had_dropin" "$backup" || true
        gpasswd -d "$user" "$MV_HWID_SSH_GROUP" >/dev/null 2>&1 || true
        echo "No se pudo consultar la política SSH efectiva para $user." >&2
        rm -rf "$tmp"
        return 1
    }
    if ! grep -qx 'authenticationmethods publickey' <<< "$effective" \
        || ! grep -qx 'passwordauthentication no' <<< "$effective" \
        || ! grep -qx 'kbdinteractiveauthentication no' <<< "$effective" \
        || ! grep -qx 'pubkeyauthentication yes' <<< "$effective" \
        || ! grep -Fqx "authorizedkeysfile $MV_HWID_AUTHORIZED_KEYS_DIR/%u/authorized_keys" <<< "$effective"; then
        mv_hwid_ssh_rollback_dropin "$had_dropin" "$backup" || true
        gpasswd -d "$user" "$MV_HWID_SSH_GROUP" >/dev/null 2>&1 || true
        echo "La política SSH efectiva no fuerza llave pública para $user; se revirtió." >&2
        rm -rf "$tmp"
        return 1
    fi

    if systemctl reload ssh 2>/dev/null; then
        service=ssh
    elif systemctl reload sshd 2>/dev/null; then
        service=sshd
    else
        mv_hwid_ssh_rollback_dropin "$had_dropin" "$backup" || true
        gpasswd -d "$user" "$MV_HWID_SSH_GROUP" >/dev/null 2>&1 || true
        systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || true
        echo "No se pudo recargar OpenSSH; se restauró la política anterior." >&2
        rm -rf "$tmp"
        return 1
    fi
    if ! systemctl is-active --quiet "$service"; then
        mv_hwid_ssh_rollback_dropin "$had_dropin" "$backup" || true
        gpasswd -d "$user" "$MV_HWID_SSH_GROUP" >/dev/null 2>&1 || true
        systemctl reload "$service" 2>/dev/null || true
        echo "OpenSSH no quedó activo tras recargar la política HWID." >&2
        rm -rf "$tmp"
        return 1
    fi
    rm -rf "$tmp"
}

mv_hwid_ssh_set_unusable_password() {
    local user="$1" mode="${2:-rotate}" random_password password_hash was_locked=no
    [[ "$user" =~ ^[a-z0-9_]{3,20}$ ]] || return 2
    if [[ "$mode" != "new" ]] \
        && passwd -S "$user" 2>/dev/null | awk '$2 == "L" || $2 == "LK" {found=1} END{exit !found}'; then
        was_locked=yes
    fi
    random_password=$(openssl rand -hex 32) || return 1
    password_hash=$(openssl passwd -6 "$random_password") || return 1
    unset random_password
    usermod -p "$password_hash" "$user" || return 1
    unset password_hash
    if [[ "$was_locked" == "yes" ]]; then
        passwd -l "$user" >/dev/null 2>&1 || return 1
    fi
}

mv_hwid_ssh_provision_user() {
    local user="$1" mode="${2:-rotate}" tmp keydir authkeydir had_keys=no had_auth_keys=no had_password_file=no
    local passfile old_shadow
    [[ "$user" =~ ^[a-z0-9_]{3,20}$ ]] || return 2
    command -v ssh-keygen >/dev/null 2>&1 || {
        echo "No se encontró ssh-keygen; no se pudo generar la llave de $user." >&2
        return 1
    }
    id "$user" >/dev/null 2>&1 || {
        echo "No existe la cuenta SSH $user." >&2
        return 1
    }
    tmp=$(mktemp -d) || return 1
    keydir="$MV_HWID_KEYS_DIR/$user"
    authkeydir="$MV_HWID_AUTHORIZED_KEYS_DIR/$user"
    passfile="${BASE:-/etc/movivip}/sistema/passwords.conf"
    install -d -o root -g root -m 755 "$MV_HWID_KEYS_DIR" || {
        rm -rf "$tmp"
        echo "No se pudo asegurar el directorio de llaves HWID." >&2
        return 1
    }
    if [[ -d "$keydir" ]]; then
        cp -a "$keydir" "$tmp/keys.previous" || {
            rm -rf "$tmp"
            echo "No se pudo respaldar la llave actual de $user." >&2
            return 1
        }
        had_keys=yes
    fi
    if [[ -d "$authkeydir" ]]; then
        cp -a "$authkeydir" "$tmp/authorized.previous" || {
            rm -rf "$tmp"
            echo "No se pudo respaldar la llave autorizada actual de $user." >&2
            return 1
        }
        had_auth_keys=yes
    fi
    if [[ -f "$passfile" ]]; then
        cp -a "$passfile" "$tmp/passwords.previous" || {
            rm -rf "$tmp"
            echo "No se pudo respaldar passwords.conf." >&2
            return 1
        }
        had_password_file=yes
    fi
    old_shadow=$(getent shadow "$user" 2>/dev/null | awk -F: 'NR == 1 { print $2 }')
    if [[ -z "$old_shadow" ]]; then
        rm -rf "$tmp"
        echo "No se pudo respaldar el estado de autenticación de $user." >&2
        return 1
    fi
    if ! ssh-keygen -q -t ed25519 -N "" -C "MoviVIP-HWID:$user" -f "$tmp/id_ed25519"; then
        rm -rf "$tmp"
        echo "No se pudo generar la llave SSH de $user." >&2
        return 1
    fi

    install -d -o root -g root -m 700 "$keydir" \
        && install -o root -g root -m 600 "$tmp/id_ed25519" "$keydir/id_ed25519" \
        && install -o root -g root -m 644 "$tmp/id_ed25519.pub" "$keydir/authorized_keys" \
        || {
            rm -rf -- "$keydir"
            if [[ "$had_keys" == yes ]]; then cp -a "$tmp/keys.previous" "$keydir" || echo "No se pudo restaurar la llave previa de $user." >&2; fi
            rm -rf "$tmp"
            echo "No se pudo guardar la llave SSH de $user." >&2
            return 1
        }
    install -o root -g root -m 644 "$tmp/id_ed25519.pub" "$keydir/id_ed25519.pub" || {
        rm -rf -- "$keydir"
        if [[ "$had_keys" == yes ]]; then cp -a "$tmp/keys.previous" "$keydir" || echo "No se pudo restaurar la llave previa de $user." >&2; fi
        rm -rf "$tmp"
        echo "No se pudo guardar la llave pública de $user." >&2
        return 1
    }

    if ! mv_hwid_ssh_set_unusable_password "$user" "$mode" \
        || ! mv_hwid_ssh_forget_password "$user" \
        || ! mv_hwid_ssh_enable_policy "$user"; then
        local restore_failed=0
        rm -rf -- "$keydir" || restore_failed=1
        if [[ "$had_keys" == yes ]]; then
            cp -a "$tmp/keys.previous" "$keydir" || restore_failed=1
        fi
        rm -rf -- "$authkeydir" || restore_failed=1
        if [[ "$had_auth_keys" == yes ]]; then
            cp -a "$tmp/authorized.previous" "$authkeydir" || restore_failed=1
        fi
        usermod -p "$old_shadow" "$user" || restore_failed=1
        if [[ "$had_password_file" == yes ]]; then
            install -o root -g root -m 600 "$tmp/passwords.previous" "$passfile" || restore_failed=1
        fi
        rm -rf "$tmp"
        if [[ "$restore_failed" -ne 0 ]]; then
            echo "FALLO: no se pudo restaurar por completo la autenticación previa de $user." >&2
        fi
        return 1
    fi
    rm -rf "$tmp"
}

mv_hwid_ssh_show_private_key() {
    local user="$1" file="$MV_HWID_KEYS_DIR/$1/id_ed25519"
    [[ "$user" =~ ^[a-z0-9_]{3,20}$ && -f "$file" ]] || return 1
    cat -- "$file"
}

mv_hwid_ssh_update_record() {
    local file="$1" hwid="$2" fingerprint="$3" tmp
    [[ -f "$file" && "$hwid" =~ ^[A-Za-z0-9_:.-]{4,64}$ \
        && "$fingerprint" =~ ^SHA256:[A-Za-z0-9+/]+$ ]] || return 1
    tmp=$(mktemp "${file}.XXXXXX") || return 1
    awk -v hwid="$hwid" -v fingerprint="$fingerprint" -v changed="$(date '+%Y-%m-%d %H:%M:%S')" '
        /^HWID:/ { print "HWID: " hwid; hwid_done=1; next }
        /^PASS:/ { next }
        /^AUTH_METHOD:/ { print "AUTH_METHOD: SSH_KEY"; auth_done=1; next }
        /^KEY_SHA256:/ { print "KEY_SHA256: " fingerprint; key_done=1; next }
        /^CHANGED:/ { print "CHANGED: " changed; changed_done=1; next }
        { print }
        END {
            if (!hwid_done) print "HWID: " hwid
            if (!auth_done) print "AUTH_METHOD: SSH_KEY"
            if (!key_done) print "KEY_SHA256: " fingerprint
            if (!changed_done) print "CHANGED: " changed
        }
    ' "$file" > "$tmp" || { rm -f "$tmp"; return 1; }
    chmod 600 "$tmp" && mv -f "$tmp" "$file"
}
