#!/usr/bin/env bash
set -uo pipefail

ROOT=/
BACKUP_DIR=/root/MoviVIP-backups
ACTION=""

usage() {
    printf 'Uso: %s --create|--restore|--pending-protocols [--root DIR] [--backup-dir DIR]\n' "$0" >&2
}

while (($#)); do
    case "$1" in
        --create|--restore|--pending-protocols)
            [[ -z "$ACTION" ]] || { usage; exit 2; }
            ACTION="$1"
            shift
            ;;
        --root)
            (($# >= 2)) || { usage; exit 2; }
            ROOT="${2%/}"
            [[ -n "$ROOT" ]] || ROOT=/
            shift 2
            ;;
        --backup-dir)
            (($# >= 2)) || { usage; exit 2; }
            BACKUP_DIR="${2%/}"
            [[ -n "$BACKUP_DIR" ]] || BACKUP_DIR=/
            shift 2
            ;;
        *)
            usage
            exit 2
            ;;
    esac
done

[[ -n "$ACTION" ]] || { usage; exit 2; }

root_path() {
    if [[ "$ROOT" == "/" ]]; then
        printf '/%s' "${1#/}"
    else
        printf '%s/%s' "$ROOT" "${1#/}"
    fi
}

copy_from_root() {
    local rel="$1" source
    source="$(root_path "$rel")"
    [[ -e "$source" || -L "$source" ]] || return 0
    mkdir -p "$(dirname "$STAGE/$rel")" || return 1
    cp -a -- "$source" "$STAGE/$rel"
}

read_flag() {
    local key="$1" config value
    config="$(root_path /etc/movivip/config.conf)"
    [[ -f "$config" ]] || return 1
    value="$(sed -n "s/^${key}=//p" "$config" | tail -n 1 | tr -d "\"'[:space:]")"
    [[ "$value" == ON ]]
}

create_backup() {
    local stamp archive temp_archive marker protocols=() rel
    mkdir -p "$BACKUP_DIR" || return 1
    chmod 700 "$BACKUP_DIR" || return 1
    marker="$BACKUP_DIR/.format-restore-pending"
    if [[ -e "$marker" || -L "$marker" ]]; then
        printf 'ERROR: ya hay una restauración pendiente; complétala antes de volver a formatear.\n' >&2
        return 1
    fi
    umask 077
    STAGE="$(mktemp -d "$BACKUP_DIR/.format-stage.XXXXXX")" || return 1
    TEMP_ARCHIVE=""
    trap 'rm -rf -- "$STAGE"; [[ -z "$TEMP_ARCHIVE" ]] || rm -f -- "$TEMP_ARCHIVE"' EXIT

    for rel in \
        /etc/passwd /etc/shadow /etc/group /etc/gshadow \
        /etc/movivip/sistema \
        /usr/local/etc/xray/config.json \
        /usr/local/etc/v2ray/config.json \
        /etc/zivpn/config.json /etc/zivpn/expira.conf \
        /etc/zivpn/limites.conf /etc/zivpn/suspendidos.conf \
        /etc/zivpn/bloqueadas.txt; do
        copy_from_root "$rel" || {
            printf 'ERROR: no se pudo incluir %s en el backup.\n' "$rel" >&2
            return 1
        }
    done

    if read_flag V2RAYCORE || [[ -f "$STAGE/usr/local/etc/xray/config.json" || -f "$STAGE/usr/local/etc/v2ray/config.json" ]]; then
        protocols+=(v2ray)
    fi
    if read_flag ZIPVPN || [[ -f "$STAGE/etc/zivpn/config.json" ]]; then
        protocols+=(zipvpn)
    fi
    printf '%s\n' "${protocols[@]}" > "$STAGE/format-protocols.list" || return 1

    stamp="$(date -u '+%Y%m%d-%H%M%S')"
    archive="format-$stamp-$$.tar.gz"
    TEMP_ARCHIVE="$BACKUP_DIR/.$archive.tmp"
    temp_archive="$TEMP_ARCHIVE"
    tar -czf "$temp_archive" -C "$STAGE" . || {
        printf 'ERROR: no se pudo empaquetar el backup del formateo.\n' >&2
        return 1
    }
    chmod 600 "$temp_archive" || return 1
    mv -f -- "$temp_archive" "$BACKUP_DIR/$archive" || return 1
    TEMP_ARCHIVE=""

    local marker_tmp="$BACKUP_DIR/.format-restore-pending.tmp"
    printf '%s\n' "$archive" > "$marker_tmp" || return 1
    chmod 600 "$marker_tmp" || return 1
    mv -f -- "$marker_tmp" "$BACKUP_DIR/.format-restore-pending" || return 1
    printf 'Backup previo al formateo creado: %s/%s\n' "$BACKUP_DIR" "$archive"
    printf 'Protocolos a recuperar: %s\n' "${protocols[*]:-ninguno}"
}

read_pending_archive() {
    local marker archive
    marker="$BACKUP_DIR/.format-restore-pending"
    [[ -f "$marker" ]] || return 3
    IFS= read -r archive < "$marker" || return 1
    [[ "$archive" =~ ^format-[0-9]{8}-[0-9]{6}-[0-9]+\.tar\.gz$ ]] || {
        printf 'ERROR: el marcador de restauración no contiene un nombre de backup válido.\n' >&2
        return 1
    }
    [[ -f "$BACKUP_DIR/$archive" ]] || {
        printf 'ERROR: no se encuentra el backup pendiente %s.\n' "$BACKUP_DIR/$archive" >&2
        return 1
    }
    printf '%s' "$BACKUP_DIR/$archive"
}

validate_archive() {
    local archive="$1" entries entry
    if ! entries="$(tar -tzf "$archive" 2>/dev/null)"; then
        printf 'ERROR: no se pudo inspeccionar el archivo de backup.\n' >&2
        return 1
    fi
    [[ -n "$entries" ]] || {
        printf 'ERROR: el archivo de backup está vacío.\n' >&2
        return 1
    }
    while IFS= read -r entry; do
        [[ "$entry" != /* && ! "/$entry/" =~ /(\.\.)/ ]] || {
            printf 'ERROR: ruta no segura dentro del backup: %s\n' "$entry" >&2
            return 1
        }
        case "$entry" in
            ./|.|./etc/*|etc/*|./usr/*|usr/*|./format-protocols.list|format-protocols.list) ;;
            *)
                printf 'ERROR: elemento inesperado dentro del backup: %s\n' "$entry" >&2
                return 1
                ;;
        esac
    done <<< "$entries"
}

pending_protocols() {
    local archive protocols
    archive="$(read_pending_archive)" || return $?
    validate_archive "$archive" || return 1
    protocols="$(tar -xOzf "$archive" ./format-protocols.list 2>/dev/null)" || {
        printf 'ERROR: el backup no contiene la lista de protocolos.\n' >&2
        return 1
    }
    if [[ -n "$protocols" ]] && ! grep -xE 'v2ray|zipvpn' <<< "$protocols" >/dev/null; then
        printf 'ERROR: la lista de protocolos del backup no es válida.\n' >&2
        return 1
    fi
    grep -xE 'v2ray|zipvpn' <<< "$protocols" || true
}

account_exists() {
    local file="$1" username="$2"
    [[ -f "$file" ]] && awk -F: -v name="$username" '$1 == name { found=1 } END { exit !found }' "$file"
}

uid_exists() {
    local file="$1" uid="$2"
    [[ -f "$file" ]] && awk -F: -v id="$uid" '$3 == id { found=1 } END { exit !found }' "$file"
}

group_exists() {
    local file="$1" group="$2"
    [[ -f "$file" ]] && awk -F: -v name="$group" '$1 == name { found=1 } END { exit !found }' "$file"
}

restore_accounts() {
    local stage="$1" passwd_file shadow_file group_file root_passwd root_shadow root_group
    local username marker uid gid gecos home shell shadow_line password last min max warn inactive expire
    local group_record group_name group_gid members extra added=0
    passwd_file="$stage/etc/passwd"
    shadow_file="$stage/etc/shadow"
    group_file="$stage/etc/group"
    root_passwd="$(root_path /etc/passwd)"
    root_shadow="$(root_path /etc/shadow)"
    root_group="$(root_path /etc/group)"

    [[ -f "$passwd_file" && -f "$shadow_file" && -f "$group_file" ]] || return 0
    while IFS=: read -r username marker uid gid gecos home shell; do
        [[ "$uid" =~ ^[0-9]+$ && "$uid" -ge 1000 && "$uid" -ne 65534 ]] || continue
        [[ "$username" =~ ^[a-zA-Z_][a-zA-Z0-9_.-]*\$?$ ]] || {
            printf 'ERROR: nombre de usuario SSH no válido en el backup; no se restauró.\n' >&2
            return 1
        }
        account_exists "$root_passwd" "$username" && continue
        if uid_exists "$root_passwd" "$uid"; then
            printf 'ERROR: no se puede restaurar %s: UID %s ya pertenece a otra cuenta.\n' "$username" "$uid" >&2
            return 1
        fi

        shadow_line="$(awk -F: -v name="$username" '$1 == name { print; exit }' "$shadow_file")"
        [[ -n "$shadow_line" ]] || {
            printf 'ERROR: falta la contraseña cifrada de la cuenta %s en el backup.\n' "$username" >&2
            return 1
        }
        IFS=: read -r _ password last min max warn inactive expire _ <<< "$shadow_line"
        [[ -n "$password" ]] || password='!'

        group_record="$(awk -F: -v id="$gid" '$3 == id { print; exit }' "$group_file")"
        [[ -n "$group_record" ]] || {
            printf 'ERROR: falta el grupo primario de la cuenta %s en el backup.\n' "$username" >&2
            return 1
        }
        IFS=: read -r group_name _ group_gid _ <<< "$group_record"
        if ! group_exists "$root_group" "$group_name"; then
            if uid_exists "$root_group" "$group_gid"; then
                printf 'ERROR: no se puede restaurar el grupo primario de %s: GID %s ya está en uso.\n' "$username" "$group_gid" >&2
                return 1
            fi
            groupadd --root "$ROOT" --gid "$group_gid" "$group_name" || return 1
        fi

        useradd --root "$ROOT" --no-create-home --uid "$uid" --gid "$gid" \
            --home-dir "$home" --shell "$shell" --comment "$gecos" --password "$password" "$username" || {
            printf 'ERROR: no se pudo restaurar la cuenta SSH %s.\n' "$username" >&2
            return 1
        }
        if [[ -n "$last$min$max$warn$inactive$expire" ]]; then
            chage --root "$ROOT" --lastday "${last:--1}" --mindays "${min:--1}" \
                --maxdays "${max:--1}" --warndays "${warn:--1}" \
                --inactive "${inactive:--1}" --expiredate "${expire:--1}" "$username" || return 1
        fi
        ((added += 1))
    done < "$passwd_file"

    while IFS=: read -r group_name _ group_gid members; do
        [[ -n "$members" ]] || continue
        IFS=, read -ra extra <<< "$members"
        for username in "${extra[@]}"; do
            account_exists "$root_passwd" "$username" || continue
            group_exists "$root_group" "$group_name" || continue
            usermod --root "$ROOT" --append --groups "$group_name" "$username" || return 1
        done
    done < "$group_file"

    (( added == 0 )) || printf 'Cuentas SSH ausentes restauradas: %s\n' "$added"
}

merge_client_config() {
    local old_config="$1" new_config="$2" tmp
    jq -e '.inbounds | type == "array"' "$old_config" >/dev/null 2>&1 || {
        printf 'ERROR: la configuración guardada no tiene inbounds válidos: %s\n' "$old_config" >&2
        return 1
    }
    jq -e '.inbounds | type == "array"' "$new_config" >/dev/null 2>&1 || {
        printf 'ERROR: la configuración nueva no tiene inbounds válidos: %s\n' "$new_config" >&2
        return 1
    }
    tmp="$(mktemp "$(dirname "$new_config")/.format-restore.XXXXXX")" || return 1
    if ! jq --slurpfile old "$old_config" '
        .inbounds |= map(
            if .tag != null and (.settings | type == "object") then
                . as $current
                | ($old[0].inbounds // []
                    | map(select(.tag == $current.tag))
                    | .[0].settings.clients // null) as $clients
                | if ($clients | type) == "array"
                    then .settings.clients = $clients
                    else .
                  end
            else .
            end
        )
    ' "$new_config" > "$tmp"; then
        rm -f -- "$tmp"
        return 1
    fi
    chmod --reference="$new_config" "$tmp" && chown --reference="$new_config" "$tmp" \
        && mv -f -- "$tmp" "$new_config" || {
        rm -f -- "$tmp"
        return 1
    }
}

merge_zipvpn_config() {
    local old_config="$1" new_config="$2" tmp
    jq -e '.auth.config | type == "array"' "$old_config" >/dev/null 2>&1 || {
        printf 'ERROR: el backup ZiVPN no contiene una lista de usuarios válida.\n' >&2
        return 1
    }
    jq -e '.auth.config | type == "array"' "$new_config" >/dev/null 2>&1 || {
        printf 'ERROR: la configuración ZiVPN nueva no contiene una lista de usuarios.\n' >&2
        return 1
    }
    tmp="$(mktemp "$(dirname "$new_config")/.format-restore.XXXXXX")" || return 1
    if ! jq --slurpfile old "$old_config" '.auth.config = $old[0].auth.config' "$new_config" > "$tmp"; then
        rm -f -- "$tmp"
        return 1
    fi
    chmod --reference="$new_config" "$tmp" && chown --reference="$new_config" "$tmp" \
        && mv -f -- "$tmp" "$new_config" || {
        rm -f -- "$tmp"
        return 1
    }
}

restart_service_if_present() {
    local service="$1"
    [[ "$ROOT" == "/" ]] || return 0
    systemctl list-unit-files "${service}.service" >/dev/null 2>&1 || return 0
    systemctl restart "$service"
}

restore_backup() {
    local archive rc stage pending=0 rel old new core marker completed state_dir
    archive="$(read_pending_archive)" || {
        rc=$?
        (( rc == 3 )) && return 0
        return "$rc"
    }
    validate_archive "$archive" || return 1
    STAGE="$(mktemp -d)" || return 1
    trap 'rm -rf -- "$STAGE"' EXIT
    tar -xzf "$archive" -C "$STAGE" --no-same-owner || return 1

    restore_accounts "$STAGE" || return 1
    if [[ -d "$STAGE/etc/movivip/sistema" ]]; then
        state_dir="$(root_path /etc/movivip/sistema)"
        mkdir -p "$state_dir" || return 1
        cp -a "$STAGE/etc/movivip/sistema/." "$state_dir/" || return 1
    fi

    for core in xray v2ray; do
        old="$STAGE/usr/local/etc/$core/config.json"
        new="$(root_path "/usr/local/etc/$core/config.json")"
        [[ -f "$old" ]] || continue
        if [[ ! -f "$new" ]]; then
            printf 'Pendiente: no se instaló el protocolo %s; se conserva el backup.\n' "$core"
            pending=1
            continue
        fi
        merge_client_config "$old" "$new" || return 1
        restart_service_if_present "$core" || return 1
        printf 'Usuarios y UUID conservados: %s\n' "$core"
    done

    old="$STAGE/etc/zivpn/config.json"
    new="$(root_path /etc/zivpn/config.json)"
    if [[ -f "$old" ]]; then
        if [[ ! -f "$new" ]]; then
            printf 'Pendiente: ZiVPN no está instalado; se conserva el backup.\n'
            pending=1
        else
            merge_zipvpn_config "$old" "$new" || return 1
            for rel in expira.conf limites.conf suspendidos.conf bloqueadas.txt; do
                [[ -f "$STAGE/etc/zivpn/$rel" ]] || continue
                cp -a "$STAGE/etc/zivpn/$rel" "$(root_path "/etc/zivpn/$rel")" || return 1
            done
            restart_service_if_present zivpn || return 1
            printf 'Usuarios y credenciales ZiVPN conservados.\n'
        fi
    fi

    if (( pending )); then
        printf 'La restauración quedó parcial; el backup se conservará para reintentar.\n' >&2
        return 2
    fi

    marker="$BACKUP_DIR/.format-restore-pending"
    completed="$BACKUP_DIR/.format-restore-completed-$(date -u '+%Y%m%d-%H%M%S')-$$"
    mv -- "$marker" "$completed" || return 1
    printf 'Backup restaurado. Copia de seguridad conservada en %s.\n' "$archive"
}

case "$ACTION" in
    --create)
        create_backup
        ;;
    --restore)
        restore_backup
        ;;
    --pending-protocols)
        pending_protocols
        ;;
esac
