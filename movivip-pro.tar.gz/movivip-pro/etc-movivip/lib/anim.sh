#!/bin/bash
#=========================================================
# JackSneider — lib/anim.sh · CYBER-VIP ANIMATION SYSTEM v9.0
# Sistema de animación, progreso y ejecución silenciosa
# ========================================================
#  • Barra de progreso animada (\r) con porcentaje real
#  • Ejecución 100% silenciosa: CERO fugas de comandos ni errores
#  • Modo adaptativo para terminal móvil y PC
#  • Verificación y reinicio de servicios con feedback visual
#=========================================================

# ── Colores Cyber-VIP ──
MV_R=$'\e[0m'
MV_BLD=$'\e[1m'
MV_RED=$'\e[38;5;203m'
MV_GRN=$'\e[38;5;82m'
MV_GLD=$'\e[38;5;220m'
MV_YLW=$'\e[38;5;226m'
MV_BLU=$'\e[38;5;39m'
MV_CYN=$'\e[38;5;45m'
MV_CYN2=$'\e[38;5;51m'
MV_PUR=$'\e[38;5;141m'
MV_WHT=$'\e[38;5;255m'
MV_DIM=$'\e[38;5;244m'
MV_DARK=$'\e[38;5;238m'

# ── Compatibilidad con variables legacy ──
CYAN="${MV_CYN2}"; GOLD="${MV_GLD}"; GREEN="${MV_GRN}"; RED="${MV_RED}"
WHITE="${MV_WHT}"; GRAY="${MV_DIM}"; MAGENTA="${MV_PUR}"; RESET="${MV_R}"

ANIM_LOG="${ANIM_LOG:-/tmp/movivip_exec.log}"
ANIM_WIDTH="${ANIM_WIDTH:-20}"

anim_is_mobile() {
    [[ "${MV_MOBILE:-}" == "1" ]] && return 0
    if [[ -z "${MV_MOBILE:-}" ]]; then
        local _c
        _c=$(tput cols 2>/dev/null || echo 80)
        if [[ "$_c" =~ ^[0-9]+$ && "$_c" -gt 0 && "$_c" -lt 58 ]] 2>/dev/null; then
            return 0
        fi
    fi
    return 1
}

# ── Barra animada en línea ──
anim_bar() {
    local pct="$1" label="$2"
    local width="$ANIM_WIDTH"
    local filled=$(( width * pct / 100 ))
    [[ $filled -gt $width ]] && filled=$width
    [[ $filled -lt 0 ]] && filled=0
    local empty=$(( width - filled ))
    local bar="" i
    for ((i=0; i<filled; i++)); do bar+="█"; done
    for ((i=0; i<empty; i++)); do bar+="░"; done
    printf "\r      ${MV_PUR}[${MV_GRN}%s${MV_DARK}%s${MV_PUR}]${MV_WHT} %3d%%${MV_DIM} %-36s${MV_R}" \
        "${bar:0:filled}" "${bar:filled}" "$pct" "${label:0:34}"
}

ANIM_STEP=0
ANIM_TOTAL=0

anim_init() {
    ANIM_TOTAL="${1:-0}"
    ANIM_STEP=0
}

anim_step() {
    local desc="$1"
    ANIM_STEP=$(( ANIM_STEP + 1 ))
    if anim_is_mobile; then
        printf "  ${MV_CYN}▸${MV_R} ${MV_WHT}%s${MV_R} ${MV_DIM}[%s/%s]${MV_R}\n" \
            "$desc" "$ANIM_STEP" "$ANIM_TOTAL"
        return
    fi
    echo ""
    local target=100
    [[ "$ANIM_TOTAL" -gt 0 ]] && target=$(( ANIM_STEP * 100 / ANIM_TOTAL ))
    local p=0
    while [[ $p -lt $target ]]; do
        p=$(( p + 8 ))
        [[ $p -gt $target ]] && p=$target
        anim_bar "$p" "PASO $ANIM_STEP/$ANIM_TOTAL · $desc"
        sleep 0.03
    done
    printf "\n"
}

# ── Ejecutar comando con barra de progreso silenciosa ──
anim_run() {
    local desc="$1"
    shift
    local tmp_err show_failure_output="${ANIM_SHOW_FAILURE_OUTPUT:-0}"
    tmp_err=$(mktemp 2>/dev/null || echo "/tmp/mv_err_$$")
    
    # Ejecuta en subshell con salidas protegidas
    "$@" </dev/null >/dev/null 2>"$tmp_err" &
    local pid=$!

    if anim_is_mobile; then
        wait "$pid"
        local rc=$?
        if (( rc != 0 )) && [[ "$show_failure_output" == "1" ]] && [[ -s "$tmp_err" ]]; then
            printf '\n[ERROR] Detalle de: %s\n' "$desc" >&2
            sed -n '1,100p' "$tmp_err" >&2
            if [[ "$(wc -l < "$tmp_err")" -gt 100 ]]; then
                printf '[ERROR] Salida adicional truncada; se mostraron las primeras 100 líneas.\n' >&2
            fi
        fi
        rm -f "$tmp_err"
        if [[ $rc -eq 0 ]]; then
            printf "  ${MV_GRN}✔${MV_R} %-44s ${MV_GRN}[ LISTO ]${MV_R}\n" "${desc:0:42}"
        else
            printf "  ${MV_RED}✘${MV_R} %-44s ${MV_RED}[ ERROR ]${MV_R}\n" "${desc:0:42}"
        fi
        return $rc
    fi

    local pct=0
    while kill -0 "$pid" 2>/dev/null; do
        pct=$(( pct + 4 ))
        [[ $pct -gt 92 ]] && pct=92
        anim_bar "$pct" "$desc..."
        sleep 0.1
    done
    wait "$pid"
    local rc=$?
    if (( rc != 0 )) && [[ "$show_failure_output" == "1" ]] && [[ -s "$tmp_err" ]]; then
        printf '\n[ERROR] Detalle de: %s\n' "$desc" >&2
        sed -n '1,100p' "$tmp_err" >&2
        if [[ "$(wc -l < "$tmp_err")" -gt 100 ]]; then
            printf '[ERROR] Salida adicional truncada; se mostraron las primeras 100 líneas.\n' >&2
        fi
    fi
    rm -f "$tmp_err"
    if [[ $rc -eq 0 ]]; then
        printf "\r\033[K      ${MV_GRN}✔${MV_R} %-44s ${MV_GRN}[ LISTO ]${MV_R}\n" "${desc:0:42}"
    else
        printf "\r\033[K      ${MV_RED}✘${MV_R} %-44s ${MV_RED}[ ERROR ]${MV_R}\n" "${desc:0:42}"
    fi
    return $rc
}

# ── Feedbacks de Estado ──
anim_done() { printf "  ${MV_GRN}✔ %s${MV_R}\n" "$1"; }
anim_fail() { printf "  ${MV_RED}✘ %s${MV_R}\n" "$1"; }
anim_info() { printf "  ${MV_CYN2}ℹ %s${MV_R}\n" "$1"; }
anim_warn() { printf "  ${MV_GLD}⚠ %s${MV_R}\n" "$1"; }

# ── Detección de Estado de Servicios ──
svc_up() {
    local unit="$1" bin="${2:-}"
    if command -v systemctl >/dev/null 2>&1; then
        if systemctl is-active --quiet "$unit" 2>/dev/null; then
            return 0
        fi
        if systemctl list-unit-files 2>/dev/null | grep -q "^${unit}\.service"; then
            return 1
        fi
    fi
    if [[ -n "$bin" ]]; then
        pgrep -x "$bin" >/dev/null 2>&1 && return 0
        pgrep -f "$bin" >/dev/null 2>&1 && return 0
    fi
    return 1
}

svc_status_text() {
    if svc_up "$1" "$2"; then
        echo "🟢 ACTIVO"
    else
        echo "🔴 DETENIDO"
    fi
}

svc_status_colored() {
    local s
    s=$(svc_status_text "$1" "$2")
    case "$s" in
        *ACTIVO*) echo "${MV_GRN}${s}${MV_R}" ;;
        *)        echo "${MV_RED}${s}${MV_R}" ;;
    esac
}

svc_line() {
    local label="$1" unit="$2" bin="${3:-}" portv="${4:-}"
    local st
    st=$(svc_status_colored "$unit" "$bin")
    if [[ -n "$portv" ]]; then
        echo -e " ${label} : $st   ${MV_DIM}puerto ${MV_GLD}${portv}${MV_R}"
    else
        echo -e " ${label} : $st"
    fi
}

svc_restart_anim() {
    local unit="$1" desc="$2"
    anim_run "$desc" systemctl restart "$unit"
    sleep 1.5
    if svc_up "$unit"; then
        anim_done "Servicio reiniciado correctamente."
        return 0
    else
        anim_fail "El servicio no arrancó."
        return 1
    fi
}