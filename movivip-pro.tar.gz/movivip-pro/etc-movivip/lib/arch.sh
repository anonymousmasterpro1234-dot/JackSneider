#!/usr/bin/env bash

mv_normalizar_arch() {
    local arch="${1,,}"
    case "$arch" in
        x86_64|amd64) printf 'amd64' ;;
        i386|i486|i586|i686|x86|386) printf '386' ;;
        aarch64|arm64) printf 'arm64' ;;
        armv5*|arm5*) printf 'armv5' ;;
        armv6*|arm6*) printf 'armv6' ;;
        armv7*|arm7*) printf 'armv7' ;;
        armhf) printf 'armhf' ;;
        riscv64) printf 'riscv64' ;;
        loongarch64|loong64) printf 'loong64' ;;
        s390x) printf 's390x' ;;
        mips) printf 'mips' ;;
        mipsel|mipsle) printf 'mipsle' ;;
        mips64) printf 'mips64' ;;
        mips64el|mips64le) printf 'mips64le' ;;
        ppc64|powerpc64) printf 'ppc64' ;;
        ppc64le|powerpc64le) printf 'ppc64le' ;;
        *) return 1 ;;
    esac
}

mv_detect_arch() {
    local arch="${1:-}"
    [[ -n "$arch" ]] || arch="$(uname -m 2>/dev/null)"
    if [[ "$arch" == "mips" || "$arch" == "mips64" ]] && command -v dpkg >/dev/null 2>&1; then
        case "$(dpkg --print-architecture 2>/dev/null)" in
            mipsel)   arch="mipsle" ;;
            mips64el) arch="mips64le" ;;
        esac
    fi
    mv_normalizar_arch "$arch"
}

mv_arch_from_elf() {
    local file="$1" m1 m2 m3 m4 class endian b1 b2 machine
    [[ -f "$file" ]] || { printf 'unknown'; return 1; }
    read -r m1 m2 m3 m4 class endian < <(od -An -t x1 -N 6 "$file" 2>/dev/null)
    [[ "${m1:-}${m2:-}${m3:-}${m4:-}" == "7f454c46" ]] || {
        printf 'unknown'
        return 1
    }
    [[ "${class:-}" == "01" || "${class:-}" == "02" ]] || {
        printf 'unknown'
        return 1
    }
    [[ "${endian:-}" == "01" || "${endian:-}" == "02" ]] || {
        printf 'unknown'
        return 1
    }
    read -r b1 b2 < <(od -An -t u1 -j 18 -N 2 "$file" 2>/dev/null)
    [[ "${b1:-}" =~ ^[0-9]+$ && "${b2:-}" =~ ^[0-9]+$ ]] || {
        printf 'unknown'
        return 1
    }
    if [[ "$endian" == "02" ]]; then
        machine=$((b1 * 256 + b2))
    else
        machine=$((b1 + b2 * 256))
    fi
    case "$machine" in
        3)   printf '386' ;;
        8)
            if [[ "$class" == "02" ]]; then
                [[ "$endian" == "02" ]] && printf 'mips64' || printf 'mips64le'
            else
                [[ "$endian" == "02" ]] && printf 'mips' || printf 'mipsle'
            fi
            ;;
        21)  [[ "$endian" == "02" ]] && printf 'ppc64' || printf 'ppc64le' ;;
        22)  printf 's390x' ;;
        40)  printf 'armv7' ;;
        62)  printf 'amd64' ;;
        183) printf 'arm64' ;;
        243) printf 'riscv64' ;;
        258) printf 'loong64' ;;
        *)   printf 'unknown'; return 1 ;;
    esac
}
