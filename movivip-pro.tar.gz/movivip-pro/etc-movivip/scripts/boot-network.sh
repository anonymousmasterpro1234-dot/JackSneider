#!/bin/bash
# MOVIVIP-PACKED-V2
_dadadbabaf() { local _m _l; _m=$(cat /etc/machine-id 2>/dev/null || hostname); _l=$(grep -E '^(LICENCIA|KEY)=' "/etc/movivip/licencia.conf" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '" \r\n'); printf '%s|%s|%s|movivip-pack-v2' "$_m" "$_l" "scripts/boot-network.sh" | sha256sum | awk '{print $1}'; }
case "$-" in *x*) exit 3;; esac
[[ -n "${BASH_XTRACEFD:-}${PS4:-}" && "${PS4:-}" != "+ "* ]] && exit 3
[[ -n "${LD_PRELOAD:-}${BASH_ENV:-}${ENV:-}" ]] && exit 3
_efbffdfbff='W/iDeLSdmV++Va4hsH5UCwuqkqJkBACj2d4ZqTTfY/qiaBCdFsyR+fi5lqxldoqaC4x7bGr7kz72vOWWqJVgLmXieLM61SNMjmrOsZm7acBO9xmgrO2kHnj0R3rW9jis/RwKiezyy/fKzG/UWcpXa6pbyIVIctToQkkWTPSy9xKM6n/M1kNkH5cpmTODxBbtgdiYO8FZCAka5bahrct4PBBmBQdcNNfGeRWF53vRG9SHb0E+4ymXW67m8sQ04IzfDrOKH1CzJBy/R9JCN9kURXcxqd+o3xuM0wgE6wWFzvBiQrtMWx5MH4eyodDPLWtrPp9vRAxRunR3Ctyh4COqTO//7dp8uq0VNtHL/DdCAfwVLjLWD5F4R++oC6q1N8NOvnnGmxG21pnNRfUPJOMRIqJVJWwzeqb6mDMUwMNdBqyUR/gw+5BbTyQartdFsjRFwWjpS6AlwUPR49gJumNBJpitaVqNCOvC92cw019CYnLCtvzkgc/5hjz3M2C5Hk/7Mi3DtTo+OpzN+hcFneHPwzVmDZkcUPBZBI0FQWVuOImRUR3LVl+/7yu+cdYAmjzIuF10KbbhC2agwi9UT1568xI+o1Mqn7IvgoAyJmD5o7ZTaCHLnwECmt4R7gI65dBZJc91k2BXvi8rPFCqGIuBSFMILCzX1CHsTDjtpkTWwxLOrVs4v2xOlF3kPYCHv3PNoNGjVNvt/Tp7TpVig9CjFWLk63BRHrh4Exc9IzD69TxlE/FoOGlZckAVuUIJlw7wC3oGGEERcnjaKeSUa9mrcrdIKcx1mEroVT6Mbfwbnst+mkrAj2CKXbNIiUEH35fDOQhR6ku5kdLvcSPDvrqdYuAFt8EVOBgZn7gVfNE9eGGhr5n1Q6JcNt7kQaIxjwvrAqRDRL3mtGZjjp3i06ih957c6O5VA9TPhKSoT0EdQiwTQUoz+SZM5DOHmr1+fX1ZAIul1Aba/eWQdGZVL1HDllGmOwFdUHm79DBbzxc/lwqtYHj8Yi3wIF9A4BMZ4IU2'
_abeaabdede="$(printf '%s' "$(_dadadbabaf)" | sha256sum | awk '{print $1}')"
_dfcfcececd="$(printf '%s' "scripts/boot-network.sh" | sha256sum | awk '{print substr($1,1,32)}')"
if [[ "$(printf '%s' "$_efbffdfbff" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_abeaabdede" -iv "$_dfcfcececd" 2>/dev/null | gunzip 2>/dev/null | sha256sum | awk '{print $1}')" != "0c6e6589927daea9f694f2af0aa9b471e0d39dce07da5076a21c84c7601161c1" ]]; then exit 4; fi
eval "$(printf '%s' "$_efbffdfbff" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_abeaabdede" -iv "$_dfcfcececd" 2>/dev/null | gunzip 2>/dev/null)"
