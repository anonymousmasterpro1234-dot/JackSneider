#!/usr/bin/env bash
# ============================================================================
# JackSneider — Desinstalador completo
# ----------------------------------------------------------------------------
#  Borra TODO lo que el instalador crea en el servidor:
#    · /etc/movivip (árbol completo del panel)
#    · /etc/crom (gestor de certificados)
#    · crons de movivip (auto-cleanup, auto-update, expira-exacta,
#      network_snapshot y cualquier otro que apunte a /etc/movivip)
#    · servicios systemd propios (MoviVIP prefijados o con marca MoviVIP)
#    · cadena iptables MOVIVIP_OUT + su salto en OUTPUT
#    · binarios /usr/local/bin/movivip-lic y movivip-guard
#    · banner de login /etc/profile.d/MoviVIP-banner.sh
#    · /etc/issue.net (banner HTML; solo se borra si es el nuestro)
#
#  Opcionales:
#    --usuarios   además borra cuentas sin shell de inicio de sesión
#                 (uid>=1000, nologin/false; excluye root y el usuario actual)
#    --paquetes   además desinstala paquetes que puso el instalador
#                 (stunnel4, haproxy, iptables-persistent)
#    --license-cleanup  modo no interactivo para retirar el producto ante
#                 una licencia ausente o rechazada; conserva cuentas SSH y
#                 paquetes compartidos con otros servicios
#    -y/--yes     sin pedir confirmación
#
#  Uso:
#    bash /etc/movivip/uninstall.sh            # interactivo
#    bash /etc/movivip/uninstall.sh -y         # sin preguntar
#    bash /etc/movivip/uninstall.sh -y --usuarios --paquetes   # limpieza ampliada
#
#  Nota: este script NO pasa por el guard de licencia a propósito:
#  tiene que poder ejecutarse aunque la licencia haya vencido, el guard
#  se haya borrado o el servidor esté a medio instalar.
# ============================================================================
set -uo pipefail

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'; C='\033[0;36m'; N='\033[0m'
ok()   { echo -e "${G}[ok]${N} $*"; }
info() { echo -e "${C}[··]${N} $*"; }
warn() { echo -e "${Y}[!!]${N} $*"; }
err()  { echo -e "${R}[xx]${N} $*"; }

# ── Root ────────────────────────────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
    err "Este desinstalador necesita root."
    echo "   Ejecuta: sudo bash $0"
    exit 1
fi

# ── Argumentos ──────────────────────────────────────────────────────────────
YES=0; BORRAR_USUARIOS=0; QUITAR_PAQUETES=0
for a in "$@"; do
    case "$a" in
        -y|--yes)        YES=1 ;;
        --license-cleanup) YES=1 ;;
        --usuarios)      BORRAR_USUARIOS=1 ;;
        --paquetes)      QUITAR_PAQUETES=1 ;;
        -h|--help)
            sed -n '2,30p' "$0"; exit 0 ;;
        *) err "Opción desconocida: $a (usa --help)"; exit 1 ;;
    esac
done

BASE="/etc/movivip"

# ── ¿Hay algo que desinstalar? ─────────────────────────────────────────────
HAY_NADA=0
[[ -d "$BASE" ]] && HAY_NADA=1
[[ -d /var/lib/movivip || -d /var/log/movivip ]] && HAY_NADA=1
[[ -f /usr/local/bin/movivip-lic || -f /usr/local/bin/movivip-guard ]] && HAY_NADA=1
[[ -f /etc/cron.d/movivip-license-watchdog ]] && HAY_NADA=1
crontab -l 2>/dev/null | grep -q '/etc/movivip' && HAY_NADA=1
systemctl list-unit-files --type=service --no-legend 2>/dev/null |
    grep -q '^movivip-' && HAY_NADA=1
if [[ $HAY_NADA -eq 0 ]]; then
    warn "No se detectó ninguna instalación de MoviVIP en este servidor."
    info "Nada que hacer. Si quedaron restos manuales, revísalos a mano."
    exit 0
fi

# ── Aviso de qué se va a borrar ────────────────────────────────────────────
echo ""
echo -e "${R}╔══════════════════════════════════════════════════════════╗${N}"
echo -e "${R}║     DESINSTALAR MOVIVIP NETWORK — BORRADO TOTAL         ║${N}"
echo -e "${R}╚══════════════════════════════════════════════════════════╝${N}"
echo ""
echo " Esto eliminará:"
echo "   · $BASE (panel, protocolos, usuarios, configs)"
echo "   · /etc/crom (certificados automáticos)"
echo "   · Crons de MoviVIP (auto-cleanup, auto-update, expira-exacta…)"
echo "   · Servicios systemd identificados como propios de MoviVIP"
echo "   · Firewall: cadena MOVIVIP_OUT"
echo "   · Binarios: /usr/local/bin/movivip-lic, movivip-guard"
echo "   · Banner de login: /etc/profile.d/MoviVIP-banner.sh"
[[ $BORRAR_USUARIOS  -eq 1 ]] && echo "   · + Usuarios VPN creados por el panel (--usuarios)"
[[ $QUITAR_PAQUETES  -eq 1 ]] && echo "   · + Paquetes: stunnel4, haproxy, iptables-persistent (--paquetes)"
echo ""
echo -e "${Y} La configuración SSH y las reglas de firewall ajenas se conservan.${N}"
echo ""

if [[ $YES -eq 0 ]]; then
    printf " ► Escribe CONFIRMAR para desinstalar: "
    read -r RESP
    if [[ "$RESP" != "CONFIRMAR" ]]; then
        echo -e "${G}[ok]${N} Desinstalación cancelada. Nada se tocó."
        exit 0
    fi
fi

echo ""
info "Iniciando desinstalación..."

# ── 1. Servicios: parar, deshabilitar, borrar unidades ─────────────────────
# Solo los que son del ecosistema MoviVIP/protocolos. ssh y cron NUNCA.
while IFS= read -r svc; do
    [[ -n "$svc" ]] || continue
    unit_file="/etc/systemd/system/$svc"
    own_unit=0
    [[ "$svc" == movivip-* ]] && own_unit=1
    if [[ $own_unit -eq 0 && -f "$unit_file" && ! -L "$unit_file" ]] &&
        grep -Eiq 'MoviVIP|movivip-|/etc/movivip|/etc/crom' "$unit_file"; then
        own_unit=1
    fi
    if [[ $own_unit -eq 1 ]]; then
        systemctl stop "$svc" 2>/dev/null || true
        systemctl disable "$svc" 2>/dev/null || true
        rm -f "$unit_file" 2>/dev/null || true
        info "Servicio MoviVIP $svc detenido y eliminado"
    fi
done < <(systemctl list-unit-files --type=service --no-legend 2>/dev/null |
    awk '{print $1}')
rm -f /etc/systemd/system/movivip*.timer 2>/dev/null || true
systemctl daemon-reload 2>/dev/null || true
ok "Servicios systemd limpiados"
rm -f /etc/cron.d/movivip-license-watchdog 2>/dev/null || true

# ── 2. Crons de MoviVIP (conserva ajenos) ──────────────────────────────────
if crontab -l >/dev/null 2>&1; then
    crontab -l 2>/dev/null | grep -v '/etc/movivip' | crontab - 2>/dev/null || true
    ok "Crons de MoviVIP eliminados (los ajenos se conservan)"
fi

# ── 3. Firewall: cadena MOVIVIP_OUT ────────────────────────────────────────
# Quitar el salto y la cadena. NO se hace flush global: las reglas ajenas
# del proveedor (y el propio SSH) se quedan intactas.
iptables -D OUTPUT -j MOVIVIP_OUT 2>/dev/null || true
iptables -F MOVIVIP_OUT 2>/dev/null || true
iptables -X MOVIVIP_OUT 2>/dev/null || true
# Persistir el resultado (solo si existe el mecanismo)
if command -v netfilter-persistent >/dev/null 2>&1; then
    mkdir -p /etc/iptables 2>/dev/null || true
    iptables-save > /etc/iptables/rules.v4 2>/dev/null || true
    netfilter-persistent save 2>/dev/null || true
fi
ok "Cadena MOVIVIP_OUT eliminada del firewall"

# ── 4. Binarios del guard y del validador ──────────────────────────────────
rm -f /usr/local/bin/movivip-lic /usr/local/bin/movivip-guard 2>/dev/null || true
rm -f /usr/local/bin/menu /usr/local/bin/protocolos \
      /usr/local/bin/herramientas /usr/local/bin/usuarios 2>/dev/null || true
ok "Binarios /usr/local/bin/movivip-{lic,guard} eliminados"

# ── 5. Banner de login ─────────────────────────────────────────────────────
rm -f /etc/profile.d/MoviVIP-banner.sh 2>/dev/null || true
ok "Banner de login eliminado"

# ── 6. /etc/issue.net (solo si es el nuestro) ──────────────────────────────
# Si el proveedor tenía su propio issue.net antes de instalar, no se toca:
# solo lo borramos si lleva la firma MoviVIP o el HTML del panel.
if [[ -f /etc/issue.net ]]; then
    if grep -qiE 'movivip|mv-panel|MoviVIP-banner' /etc/issue.net 2>/dev/null; then
        rm -f /etc/issue.net 2>/dev/null || true
        ok "/etc/issue.net (banner MoviVIP) eliminado"
    else
        info "/etc/issue.net existe pero no es de MoviVIP — se conserva"
    fi
fi

# ── 7. Directorios de datos ────────────────────────────────────────────────
# cd / antes del rm: si el cwd está dentro de /etc/movivip el borrado
# puede dejar el directorio "fantasma" abierto por el shell.
cd / 2>/dev/null || true
rm -rf "$BASE" /etc/crom /var/lib/movivip /var/log/movivip 2>/dev/null || true
ok "Directorios y datos propios de MoviVIP eliminados"

# ── 8. (Opcional) Usuarios VPN ─────────────────────────────────────────────
if [[ $BORRAR_USUARIOS -eq 1 ]]; then
    info "Buscando cuentas sin shell de inicio de sesión (uid>=1000)…"
    ME="$(id -un)"
    BORRADOS=0
    while IFS=: read -r U _ UID _ _ _ SHELL; do
        [[ "$U" == "root" || "$U" == "$ME" ]] && continue
        [[ "$UID" -lt 1000 ]] && continue
        case "$SHELL" in */nologin|*/false) ;; *) continue ;; esac
        if userdel -r "$U" 2>/dev/null; then
            info "Cuenta sin shell eliminada: $U"
            BORRADOS=$((BORRADOS+1))
        fi
    done < <(getent passwd)
    ok "Usuarios VPN eliminados: $BORRADOS"
else
    info "Usuarios VPN conservados (usa --usuarios para borrarlos)."
fi

# ── 9. (Opcional) Paquetes ─────────────────────────────────────────────────
if [[ $QUITAR_PAQUETES -eq 1 ]]; then
    info "Desinstalando paquetes del ecosistema…"
    systemctl stop stunnel4 haproxy 2>/dev/null || true
    systemctl disable stunnel4 haproxy 2>/dev/null || true
    rm -rf /etc/stunnel 2>/dev/null || true
    DEBIAN_FRONTEND=noninteractive apt-get purge -y stunnel4 haproxy \
        iptables-persistent netfilter-persistent 2>/dev/null \
        && ok "Paquetes desinstalados" \
        || warn "Algunos paquetes no se pudieron purgar (puede que no estuvieran)."
else
    info "Paquetes conservados (usa --paquetes para quitar stunnel4/haproxy)."
fi

# ── Verificación final ─────────────────────────────────────────────────────
echo ""
RESTOS=0
[[ -d "$BASE" ]] && { err "Queda $BASE"; RESTOS=1; }
[[ -d /var/lib/movivip ]] && { err "Quedan datos en /var/lib/movivip"; RESTOS=1; }
[[ -d /var/log/movivip ]] && { err "Quedan logs en /var/log/movivip"; RESTOS=1; }
[[ -f /usr/local/bin/movivip-lic ]] && { err "Queda movivip-lic"; RESTOS=1; }
[[ -f /usr/local/bin/movivip-guard ]] && { err "Queda movivip-guard"; RESTOS=1; }
[[ -f /etc/cron.d/movivip-license-watchdog ]] && { err "Queda el watchdog de licencia"; RESTOS=1; }
crontab -l 2>/dev/null | grep -q '/etc/movivip' && { err "Quedan crons"; RESTOS=1; }
iptables -L MOVIVIP_OUT -n >/dev/null 2>&1 && { err "Queda la cadena MOVIVIP_OUT"; RESTOS=1; }

echo ""
if [[ $RESTOS -eq 0 ]]; then
    echo -e "${G}╔══════════════════════════════════════════════════════════╗${N}"
    echo -e "${G}║        COMPONENTES MOVIVIP DESINSTALADOS                 ║${N}"
    echo -e "${G}║        Sistema operativo y acceso SSH conservados.       ║${N}"
    echo -e "${G}║        Cuentas y paquetes compartidos conservados.       ║${N}"
    echo -e "${G}╚══════════════════════════════════════════════════════════╝${N}"
    echo ""
    exit 0
else
    err "Desinstalación incompleta — revisa los restos listados arriba."
    exit 1
fi
