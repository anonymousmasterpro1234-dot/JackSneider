#!/bin/bash
# MOVIVIP-PACKED-V2
_ffeeefeacf() { local _m _l; _m=$(cat /etc/machine-id 2>/dev/null || hostname); _l=$(grep -E '^(LICENCIA|KEY)=' "/etc/movivip/licencia.conf" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '" \r\n'); printf '%s|%s|%s|movivip-pack-v2' "$_m" "$_l" "auto-update.sh" | sha256sum | awk '{print $1}'; }
case "$-" in *x*) exit 3;; esac
[[ -n "${BASH_XTRACEFD:-}${PS4:-}" && "${PS4:-}" != "+ "* ]] && exit 3
[[ -n "${LD_PRELOAD:-}${BASH_ENV:-}${ENV:-}" ]] && exit 3
_acebdbfcae='9tRVKIJNCvZT+kpR+mU6Q5SuKqNfSOHZ+EY8kVMTmIlCICtUU321qYM5uopHJQynImwHX1OGNaJNjbVxjOVQ18FDaZmejSggcxHPS6Fz4VqDx20Bygj6iaqbqWpAHnRNsVCz52ApqujSZ1R7U7okBvvRz515RCjd+8C686P2dIlENoklL5oEHGkFyH3ISslSROJZ1sr3dlN7rw0BhlZ5UCCNRN+A5E5dffeh6xrZ17cSk2d2rOd1eG3oEIWTsToFAAUWxqiMuobIoWnEg4+bEA=='
_cacabeacea="$(printf '%s' "$(_ffeeefeacf)" | sha256sum | awk '{print $1}')"
_befabcdbdf="$(printf '%s' "auto-update.sh" | sha256sum | awk '{print substr($1,1,32)}')"
if [[ "$(printf '%s' "$_acebdbfcae" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_cacabeacea" -iv "$_befabcdbdf" 2>/dev/null | gunzip 2>/dev/null | sha256sum | awk '{print $1}')" != "2d0c131837452e64ff50c7de069e76ae1cf633041c1fce30ca2cfdcd91440134" ]]; then exit 4; fi
eval "$(printf '%s' "$_acebdbfcae" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_cacabeacea" -iv "$_befabcdbdf" 2>/dev/null | gunzip 2>/dev/null)"
