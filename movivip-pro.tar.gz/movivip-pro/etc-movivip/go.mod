module movivip

go 1.22
