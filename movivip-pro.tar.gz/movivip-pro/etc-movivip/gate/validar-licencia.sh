#!/bin/bash
# =============================================================
#  Delegador. Este archivo ya no valida nada.
# -------------------------------------------------------------
#  Era una segunda copia del gate, con su propia implementacion de
#  verificacion y su propia descarga de clave publica. Dos
#  implementaciones del mismo chequeo siempre se desincronizan: una
#  se actualiza y la otra se queda, y entonces una de las dos deja de
#  comprobar nada.
#
#  Se conserva la ruta porque check-licencia.sh la referencia como
#  ACTIVADOR_LEGACY, pero ahora toda la validacion vive en un sitio:
#  validar-licencia.sh -> movivip-lic.
# =============================================================
BASE="/etc/movivip"
DEST="$BASE/validar-licencia.sh"

if [ -x "$DEST" ]; then
    exec bash "$DEST" "$@"
fi

echo -e "\033[0;31m[✘] No se encontró el activador $DEST\033[0m"
echo -e "\033[1;33m[!] Reinstala el script para restaurar la activación.\033[0m"
exit 1