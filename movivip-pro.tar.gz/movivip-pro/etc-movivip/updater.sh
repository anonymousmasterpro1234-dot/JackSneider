#!/bin/bash
# MOVIVIP-PACKED-V2
_fefcfdddbf() { local _m _l; _m=$(cat /etc/machine-id 2>/dev/null || hostname); _l=$(grep -E '^(LICENCIA|KEY)=' "/etc/movivip/licencia.conf" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '" \r\n'); printf '%s|%s|%s|movivip-pack-v2' "$_m" "$_l" "updater.sh" | sha256sum | awk '{print $1}'; }
case "$-" in *x*) exit 3;; esac
[[ -n "${BASH_XTRACEFD:-}${PS4:-}" && "${PS4:-}" != "+ "* ]] && exit 3
[[ -n "${LD_PRELOAD:-}${BASH_ENV:-}${ENV:-}" ]] && exit 3
_ceefcabcce='2TeCPnaTGKr8HGGfepTagVjVhXgCT+saM10XA22cpKXzkaQERZ2S47rMPE6KAkbVY5inLqeFB0ccjkhcqYVl4fhwp4Lzo8U0ChYpkXesP9CsI/8v/39zhD8s+Kdlj1DK'
_cbefcaeffc="$(printf '%s' "$(_fefcfdddbf)" | sha256sum | awk '{print $1}')"
_befdfdddeb="$(printf '%s' "updater.sh" | sha256sum | awk '{print substr($1,1,32)}')"
if [[ "$(printf '%s' "$_ceefcabcce" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_cbefcaeffc" -iv "$_befdfdddeb" 2>/dev/null | gunzip 2>/dev/null | sha256sum | awk '{print $1}')" != "9d2e275dc51310783effabeaf46ac8138ab60c68e42b324d40e01a118176a1e2" ]]; then exit 4; fi
eval "$(printf '%s' "$_ceefcabcce" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_cbefcaeffc" -iv "$_befdfdddeb" 2>/dev/null | gunzip 2>/dev/null)"
