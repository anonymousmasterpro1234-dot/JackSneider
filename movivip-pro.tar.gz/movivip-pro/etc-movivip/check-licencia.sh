#!/bin/bash
# =============================================================
#  MOVIVIP NETWORK — CHECK LICENCIA
#  -------------------------------------------------------------
#  ADAPTOR. Antes este archivo:
#    * hacia `source /etc/movivip/licencia.conf`
#    * consultaba Firebase RTDB con curl
#    * parseaba el JSON a mano con grep/sed
#    * si no habia key, descargaba un script de GitHub con curl -fsSL
#      y lo ejecutaba con bash
#
#  Las cuatro cosas eran fallos de seguridad, no solo antiguedad:
#
#    1. `source` de un archivo 644 = el cliente mete codigo arbitrario
#       en licencia.conf y se ejecuta como root en cada protocolo.
#    2. curl es un binario del PATH: sustituirlo por otro devuelve
#       "validado" sin validar nada. jq igual.
#    3. Descargar y ejecutar codigo remoto en el camino de error
#       convierte una caída de Firebase en ejecucion de codigo.
#    4. La clave publica del proveedor no esta aqui, esta en el binario.
#
#  Ahora la ÚNICA fuente de verdad es `movivip-lic`, firmado por el
#  proveedor. Este archivo formatea el resultado y mantiene el
#  contrato que los consumidores ya esperan.
#
#  USO (no cambiar, lo usan los protocolos y el bot):
#      bash /etc/movivip/check-licencia.sh || exit 1
#
#  CÓDIGOS DE SALIDA (intactos):
#    0  = licencia VÁLIDA  (activa + no vencida) → se permite operar
#    1  = NO VÁLIDA / vencida / sin key / binario ausente → BLOQUEA
#    2  = error de red o de confianza               → BLOQUEA
#
#  REGLA DE NEGOCIO (sin cambios):
#    - La validación es siempre en línea (con caché de 15 min).
#    - El archivo local solo guarda QUÉ key es; quién decide es el binario.
#    - expira=0 o vacía → VITALICIA.
#    - Sin internet → se permite la gracia de red que ya gestiona el
#      propio binario, no este archivo.
# =============================================================

BASE_DIR="/etc/movivip"
LICENCIA_FILE="$BASE_DIR/licencia.conf"
ACTIVADOR="$BASE_DIR/validar-licencia.sh"
ACTIVADOR_LEGACY="$BASE_DIR/gate/validar-licencia.sh"

# ================= COLORES =================
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

# ================= CONTACTO (venta) =================
mostrar_contacto() {
    echo -e "${RED}──────────────────────────────────────────────────────${NC}"
    echo -e "${RED}  ⛔ ACCESO BLOQUEADO — LICENCIA NO VÁLIDA${NC}"
    echo -e "${RED}──────────────────────────────────────────────────────${NC}"
    echo -e "${YELLOW}  Este protocolo requiere una clave de licencia activa.${NC}"
    echo ""
    echo -e "${CYAN}  🔑 Adquiere o renueva tu licencia aquí:${NC}"
    echo -e "${CYAN}  ─────────────────────────────────────────────${NC}"
    echo -e "  💬 Telegram : ${GREEN}JackSneider${NC}"
    echo -e "  📱 WhatsApp : ${GREEN}3181882682${NC}"
    echo -e "  🌐 Web      : ${GREEN}https://${NC}"
    echo -e "  📢 Canal    : ${GREEN}https://t.me/+I-VOBBPsGSZjOGE5${NC}"
    echo -e "  👥 Grupo    : ${GREEN}https://t.me/+I-VOBBPsGSZjOGE5${NC}"
    echo -e "${CYAN}  ─────────────────────────────────────────────${NC}"
    echo ""
}

# ================= HELPERS =================
mv_lic_bin() {
    local c
    for c in "${MV_LIC_BIN:-}" /usr/local/bin/movivip-lic \
             "$BASE_DIR/bin/movivip-lic" /etc/movivip/movivip-lic; do
        [ -n "$c" ] && [ -x "$c" ] && { printf '%s' "$c"; return 0; }
    done
    c="$(command -v movivip-lic 2>/dev/null || true)"
    [ -n "$c" ] && { printf '%s' "$c"; return 0; }
    return 1
}

# Lee la KEY del archivo local SIN ejecutarlo.
#
# El archivo lo escribe el binario con %q de Go, pero en instalaciones
# viejas quedó 644 y el cliente lo pudo editar. `source` de un archivo
# controlado por el cliente es ejecución de código como root, así que
# aquí solo se leen líneas que empiecen por KEY= y se desenvuelven las
# comillas. Nunca se evalúa el contenido.
key_guardada() {
    local l
    [ -f "$LICENCIA_FILE" ] || return 0
    while IFS= read -r l || [ -n "$l" ]; do
        case "$l" in
            KEY=*)
                l="${l#KEY=}"
                l="${l%\"}"; l="${l#\"}"
                l="${l%\'}"; l="${l#\'}"
                printf '%s' "$l"
                return 0
                ;;
        esac
    done < "$LICENCIA_FILE"
}

# NO se reescribe licencia.conf aqui, y esta decision es deliberada.
#
# Antes esta funcion (sincronizar_conf) reescribia el archivo entero con
# PLAN/CLIENTE/TIPO/EXPIRA/DIAS/HWID/IP en cada arranque de protocolo.
# El binario tambien lo escribia, pero con un subconjunto de campos.
#
# Dos escritores del mismo archivo es una condicion de carrera: cada uno
# pisa los campos del otro. El resultado observables era que un cliente
# podia ver el CLIENTE de la licencia anterior pegado al PLAN nuevo, y
# que el archivo crecia con campos duplicados en cada validacion.
#
# Ahora el binario escribe TODOS los campos de una vez, de forma atomica
# (tmp + rename) y con 0600, y este archivo solo LEE y formatea.
#
# Se eliminan tambien las dos razones que justificaban sanear el texto:
# el valor %q de Go escapa comillas, barra y ademas el cliente se sanea
# al generarse la licencia en el proveedor, no al copiarse.

# ================= MAIN =================
main() {
    local KEY="" BIN rc

    BIN="$(mv_lic_bin)" || {
        mostrar_contacto
        echo -e "${RED}[✘] Falta el validador movivip-lic. Reinstala el script.${NC}"
        exit 1
    }

    KEY="$(key_guardada)"

    # 1) Sin key → activar. Solo se usa el activador LOCAL.
    #    Antes, si faltaba, se descargaba uno de GitHub y se ejecutaba.
    #    Ese camino queda eliminado a propósito.
    if [[ -z "$KEY" ]]; then
        echo -e "${YELLOW}[!] No hay licencia guardada en este servidor.${NC}"
        local act=""
        [[ -x "$ACTIVADOR" ]] && act="$ACTIVADOR"
        [[ -z "$act" && -x "$ACTIVADOR_LEGACY" ]] && act="$ACTIVADOR_LEGACY"
        if [[ -z "$act" ]]; then
            mostrar_contacto
            echo -e "${RED}[✘] No hay módulo de activación instalado.${NC}"
            exit 1
        fi
        bash "$act" || exit 1
        KEY="$(key_guardada)"
        if [[ -z "$KEY" ]]; then
            mostrar_contacto
            echo -e "${RED}[✘] No se pudo registrar una clave de licencia.${NC}"
            exit 1
        fi
    fi

    # 2) Decisión del binario. --export usa caché de 15 min, la gracia de
    #    red y el registro de HWID/IP; no hay que replicar nada aquí.
    "$BIN" --export >/dev/null 2>&1
    rc=$?

    case "$rc" in
        0)
            # El binario ya dejo licencia.conf actualizado y atomico
            # al validar. Este script no lo reescribe: un solo
            # escritor, ver la nota de arriba.
            exit 0
            ;;
        2)
            mostrar_contacto
            echo -e "${RED}[✘] No se pudo confirmar la licencia con el servidor.${NC}"
            echo -e "${YELLOW}[!] Revisa la conexión a internet y reintenta.${NC}"
            exit 2
            ;;
        *)
            mostrar_contacto
            echo -e "${RED}[✘] La clave '${KEY:0:6}****' no existe, está inactiva o vencida.${NC}"
            exit 1
            ;;
    esac
}

main "$@"
exit $?