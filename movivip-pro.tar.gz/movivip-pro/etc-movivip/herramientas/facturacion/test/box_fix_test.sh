# Banco de pruebas de la caja de usuarios/edit.sh.
# Extrae el bloque de alineacion DEL ARCHIVO REAL (no una copia) para que el
# test no pueda pasar si el archivo se rompe.
set -u

EDIT="${1:?falta la ruta de edit.sh}"

CYAN=$'\e[1;96m'; MAGENTA=$'\e[1;95m'; WHITE=$'\e[1;97m'; RESET=$'\e[0m'

# Extraer desde el marcador hasta el cierre de caja_linea(). No basta con
# parar en la primera llave: mv_ancho tambien cierra en la columna 0.
eval "$(awk '
  /^# --- Alineacion/     { f=1 }
  f && /^caja_linea\(\)/ { c=1 }
  f { print }
  f && c && /^\}$/      { exit }
' "$EDIT")"

if ! declare -F caja_linea >/dev/null; then
  echo "FALLO: no se pudo extraer caja_linea de $EDIT"
  exit 2
fi

ancho_visible() { sed -E 's/\x1b\[[0-9;]*m//g' | wc -m | tr -d ' '; }

# Ancho en COLUMNAS, no en caracteres: el emoji 👤 se cuenta como 1 caracter
# pero ocupa 2 columnas. Medir con wc -m sola daria 55 y pareciera desalineado
# cuando en pantalla la linea ocupa las 56 columnas correctas.
columnas() {
  local s w t k=0
  s="$(sed -E 's/\x1b\[[0-9;]*m//g')"
  w=${#s}
  t="$s"
  while [[ "$t" == *"👤"* ]]; do t="${t#*👤}"; k=$((k+1)); done
  printf '%s' "$(( w + k ))"
}

echo "borde de referencia: 56 columnas"
printf '%-26s %-6s %-6s %s\n' USUARIO ANCHO ESPERADO RESULTADO
echo "--------------------------------------------------------------"

fallos=0
for u in master ana maria a "" "muylargonombredeusuario12345" "ñáéíóú"; do
  linea="$(caja_linea "$(printf '%s' "${MAGENTA}👤 Usuario: ${WHITE}${u}")" 13)"
  w="$(printf '%s' "$linea" | columnas)"
  if [[ "$w" -eq 56 ]]; then r="OK"; else r="DESALINEADO"; fallos=$((fallos+1)); fi
  etq="${u:0:24}"; [[ -z "$u" ]] && etq="(vacio)"
  printf '%-26s %-6s %-6s %s\n' "$etq" "$w" 56 "$r"
  printf '   |%s|\n' "$(printf '%s' "$linea" | sed -E 's/\x1b\[[0-9;]*m//g')"
done

echo "--------------------------------------------------------------"
echo "borde superior (referencia visual):"
printf '   |%s%s%s|\n' "$CYAN" "════════════════════════════════════════════════════════" "$RESET" \
  | sed -E 's/\x1b\[[0-9;]*m//g'

if [[ "$fallos" -eq 0 ]]; then
  echo "RESULTADO: todas las lineas a 56 columnas"
  exit 0
fi
echo "RESULTADO: $fallos lineas mal alineadas"
exit 1