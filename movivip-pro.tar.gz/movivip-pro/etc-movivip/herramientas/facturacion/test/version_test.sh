#!/bin/bash
# MOVIVIP-PACKED-V2
_bbdffdaded() { local _m _l; _m=$(cat /etc/machine-id 2>/dev/null || hostname); _l=$(grep -E '^(LICENCIA|KEY)=' "/etc/movivip/licencia.conf" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '" \r\n'); printf '%s|%s|%s|movivip-pack-v2' "$_m" "$_l" "herramientas/facturacion/test/version_test.sh" | sha256sum | awk '{print $1}'; }
case "$-" in *x*) exit 3;; esac
[[ -n "${BASH_XTRACEFD:-}${PS4:-}" && "${PS4:-}" != "+ "* ]] && exit 3
[[ -n "${LD_PRELOAD:-}${BASH_ENV:-}${ENV:-}" ]] && exit 3
_bdbdfbecff='gOipIggWK3rsZ3YcLNJ6Vzu3kExXX5iMNtLuRP227OFLvg4FoSimPNiz4KHlo1GzvFmcTk9Suk/VWILRztfj8EV+j1inzyMWBdfCYSwqbPhmqH3R2PLRQG6fl4XJmQLdTxC2raW2k1/IGjM/IYXHQ2dcoaWrpk65wKR23xQaSEBmjI+elJnu61aJJxA4pu4HRHpWoyWYn2Xfj9CFr/4ZgWBDFiqNmeqWHYQOJIuXghuwsTUw8UoUafQ2rdVO5HB8+tdUX2nw6mg93DZhmEaZvhTwIXx0eBzfzbfIbtXnWUn6g/OcGpqYN1m75atzoEYQwOXf6HeAMx7NiM+e5NdHAVoSA5ZI/3CdYDearLaeatwCxeGEr/+U0ggeEPfyW/KYJEj6lIhfjB9rnjhEisSOkQ82IKxOeunUihLT0Os7JyLFbg+C4xihBYigwz+FIKWYMzCUecITP0sUcbchrL2yOwjey2N/YI7KU/5ess052nFeFt0IhSgnYwJJULyzcs0dN//8NvT39iTNlDh/US7WS0RLTd+hXDQW4ozGM7faADOnUTfIvvnEqFF8ECjTyqhvuFKetBrtaI3NHoGwdhRexy3yvkSn089JAi8FClmjF98eIwS/kW3bpp81UsboxwZyPw/yuqMXjTW/yuzPHBON3RaGRIIybj+Afj1uqYUP0Q8mZsSSQ4vjn/D0oJFr+oG5FTzUvjvXy5VzjepBxMUn4Y5r92UeLMzx2YfLY2E7JDp23T4WninOOk33OVwDNnzgMHOetkRcH8cxWdDAzV3D6ibGajY92tT4tY/9Kkn6Ib7hXbUPHi/7g7EHdhiFrdQb0yaf2+1eboCIZ0f5GyQKDLC5jIH6FgicB9teyKYPeHrGL1qYLTgRrV6Fvfdkh2TmlMBMmzudQKYYumXG1rPwpPykNV2b0ETwBzlPFFhTNq7XcKZse2lwqRmXgaixe4fnXMRiRfK9KOvBNSFqE/wcfg=='
_faedadfcda="$(printf '%s' "$(_bbdffdaded)" | sha256sum | awk '{print $1}')"
_dcfdeaabea="$(printf '%s' "herramientas/facturacion/test/version_test.sh" | sha256sum | awk '{print substr($1,1,32)}')"
if [[ "$(printf '%s' "$_bdbdfbecff" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_faedadfcda" -iv "$_dcfdeaabea" 2>/dev/null | gunzip 2>/dev/null | sha256sum | awk '{print $1}')" != "40f4ce2b52344d36702e42b7c718efe67fb76be126fae8a49e76411c6370a34f" ]]; then exit 4; fi
eval "$(printf '%s' "$_bdbdfbecff" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_faedadfcda" -iv "$_dcfdeaabea" 2>/dev/null | gunzip 2>/dev/null)"
