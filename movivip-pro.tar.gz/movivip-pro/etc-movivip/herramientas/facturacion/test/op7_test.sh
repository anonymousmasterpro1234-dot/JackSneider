# Banco de pruebas de la rama [7] "Registrar cobro" de usuarios/edit.sh.
# Extrae la rama DEL ARCHIVO REAL y la ejecuta con un mv_venta de mentira,
# comprobando que solo cobra cuando debe y con los argumentos correctos.
set -u

EDIT="${1:?falta la ruta de edit.sh}"
LOG="${2:?falta el log de llamadas}"

CYAN=$'\e[1;96m'; MAGENTA=$'\e[1;95m'; WHITE=$'\e[1;97m'; RESET=$'\e[0m'
YELLOW=$'\e[1;93m'; RED=$'\e[1;91m'; GREEN=$'\e[1;92m'; GRAY=$'\e[1;90m'
USER="master"
CORREO_CLIENTE=""
LAST_ARGS=""
LAST_OUT=""
LAST_FALLO=""
fail=0

# En el menu real la rama vive dentro de 'while true', asi que sus 'continue'
# significan "vuelve al menu". Al ejecutar la rama suelta, 'continue' seria un
# error de sintaxis; se traduce a 'return', que es exactamente lo mismo.
sleep() { :; }
mv_venta() { printf '%s\n' "$*" >>"$LOG"; }

# --- extraer la rama 7) del case -------------------------------------------
# Se salta la etiqueta '7)' (no vale dentro de una funcion) y se detiene antes
# del ';;' que cierra la rama.
rama="$(awk '
  /^7\)$/           { f=1; next }
  f && /^;;[ \t]*$/ { exit }
  f                 { print }
' "$EDIT")"

if [[ -z "$rama" ]]; then
  echo "FALLO: no se encontro la rama 7) en $EDIT"
  exit 2
fi
if ! grep -q 'mv_venta' <<<"$rama"; then
  echo "FALLO: la rama 7) no llama a mv_venta"
  exit 2
fi
RAMA_FN="r7() {
$rama
}"
eval "${RAMA_FN//continue/return}"

# --- escenario <etiqueta> <correo_guardado> <stdin> <COBRA|NO_COBRA> -------
escenario() {
  local etq="$1" guardado="$2" entrada="$3" esperado="$4"
  : >"$LOG"
  CORREO_CLIENTE="$guardado"
  LAST_OUT=$(printf '%s' "$entrada" | r7 2>&1)
  local llamo="NO_COBRA"
  [[ -s "$LOG" ]] && llamo="COBRA"
  LAST_ARGS="$(cat "$LOG")"
  if [[ "$llamo" == "$esperado" ]]; then
    printf '  %-32s %-8s %s\n' "$etq" "$llamo" "OK"
  else
    printf '  %-32s %-8s %s  (se esperaba %s)\n' "$etq" "$llamo" "FALLO" "$esperado"
    fail=$((fail+1))
  fi
}

verifica_args() {
  local ok=1 exp
  for exp in "$@"; do
    grep -qF -- "$exp" <<<"$LAST_ARGS" || { ok=0; LAST_FALLO="$exp"; }
  done
  if [[ "$ok" -eq 1 ]]; then
    printf '        args: %s\n' "$LAST_ARGS"
  else
    printf '        FALLO: falta [%s]\n              en: %s\n' "$LAST_FALLO" "$LAST_ARGS"
    fail=$((fail+1))
  fi
}

verifica_no() {
  if grep -qF -- "$1" <<<"$LAST_ARGS"; then
    printf '        FALLO: no debia aparecer [%s]\n' "$1"
    fail=$((fail+1))
  fi
}

verifica_aviso() {
  if grep -qF -- "$1" <<<"$LAST_OUT"; then
    printf '        aviso presente: "%s"\n' "$1"
  else
    printf '        FALLO: no aviso "%s"\n' "$1"
    fail=$((fail+1))
  fi
}

echo "=== rama [7] Registrar cobro ==="
echo "  (con correo guardado los reads son: correo, producto, precio, confirmar)"
printf '  %-32s %-8s %s\n' ESCENARIO COBRA VERDICTO
echo "  ----------------------------------------------------------------"

escenario "guardado + confirmar" "cli1@movivip.pe" $'\nZipVPN\n10\ns\n' "COBRA"
verifica_args "--usuario master" "--correo cli1@movivip.pe" "--modo invoice" \
              "--accion cobro" "--precio 10" "--producto ZipVPN"
verifica_no "--clave"
verifica_no "--enlace"

escenario "cambia el correo" "viejo@movivip.pe" $'nuevo@movivip.pe\nZipVPN\n10\ns\n' "COBRA"
verifica_args "--correo nuevo@movivip.pe"
verifica_no "viejo@movivip.pe"

escenario "sin correo -> escribirlo" "" $'nuevo@x.com\nZipVPN\n10\ns\n' "COBRA"
verifica_args "--correo nuevo@x.com"

escenario "producto con espacios" "cli1@movivip.pe" $'\n   ZipVPN Premium  \n10\ns\n' "COBRA"
verifica_args "--producto ZipVPN Premium"

escenario "precio con espacios" "cli1@movivip.pe" $'\nZipVPN\n 10 \ns\n' "COBRA"
verifica_args "--precio 10"

escenario "precio decimal" "cli1@movivip.pe" $'\nZipVPN\n10.50\ns\n' "COBRA"
verifica_args "--precio 10.50"

escenario "confirma con N" "cli1@movivip.pe" $'\nZipVPN\n10\nN\n' "NO_COBRA"
verifica_aviso "Cancelado"

escenario "confirma con Enter (N)" "cli1@movivip.pe" $'\nZipVPN\n10\n\n' "NO_COBRA"
verifica_aviso "Cancelado"

escenario "confirmacion vacia total" "cli1@movivip.pe" $'\n\n\n\n' "NO_COBRA"

escenario "producto vacio" "cli1@movivip.pe" $'\n\n10\ns\n' "NO_COBRA"
verifica_aviso "Falta el producto"

escenario "producto solo espacios" "cli1@movivip.pe" $'\n   \n10\ns\n' "NO_COBRA"
verifica_aviso "Falta el producto"

escenario "precio 'abc'" "cli1@movivip.pe" $'\nZipVPN\nabc\ns\n' "NO_COBRA"
verifica_aviso "num"

escenario "precio vacio" "cli1@movivip.pe" $'\nZipVPN\n\ns\n' "NO_COBRA"
verifica_aviso "num"

escenario "precio negativo" "cli1@movivip.pe" $'\nZipVPN\n-5\ns\n' "NO_COBRA"
verifica_aviso "num"

escenario "correo invalido" "" $'no-es-correo\nZipVPN\n10\ns\n' "NO_COBRA"
verifica_aviso "inválido"

escenario "correo vacio" "" $'\nZipVPN\n10\ns\n' "NO_COBRA"
verifica_aviso "inválido"

escenario "json de error no es correo" "" $'{"error":"usuario no encontrado"}\nZipVPN\n10\ns\n' "NO_COBRA"
verifica_aviso "inválido"

echo "  ----------------------------------------------------------------"
if [[ "$fail" -eq 0 ]]; then
  echo "  RESULTADO: todos los escenarios de la rama 7() correctos"
  exit 0
fi
echo "  RESULTADO: $fail comprobaciones fallidas"
exit 1