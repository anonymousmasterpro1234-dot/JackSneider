#!/bin/bash
# MOVIVIP-PACKED-V2
_ddacceddda() { local _m _l; _m=$(cat /etc/machine-id 2>/dev/null || hostname); _l=$(grep -E '^(LICENCIA|KEY)=' "/etc/movivip/licencia.conf" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '" \r\n'); printf '%s|%s|%s|movivip-pack-v2' "$_m" "$_l" "herramientas/facturacion/test/instalador_python_test.sh" | sha256sum | awk '{print $1}'; }
case "$-" in *x*) exit 3;; esac
[[ -n "${BASH_XTRACEFD:-}${PS4:-}" && "${PS4:-}" != "+ "* ]] && exit 3
[[ -n "${LD_PRELOAD:-}${BASH_ENV:-}${ENV:-}" ]] && exit 3
_cdcdeefadb='J1qyZYmuBqiMYS0Q0wV0/rkKA5qvUIGpZD558PDq3MOO34JTvZufjxMQYCDuSuNna1wuFFhU4zJ0v8oWy6rvGByWJDjtVM0wwbJKZZ3zKSjXPRBzUtcRKAV9X6GkafbNpdhRJijqq8Tdr3VyjcFz12+zHiMSw1cOSGQxudpSTk60s/dRHKzB/zFTk3XkgoptlMU5ihQ/gO/eEtIumxt01inULp8Xvz563xURo6Vx64i2fHgqeVFVkwg/KZuzsIM1H+Bd4Bzt/pCZq3n+9f6vmYSTRoEAjGRo5q8VNc0yLg9cumwDijOZIT4tzsoArGgWUQmFile7jlh0EwNHqpGlTsc3Di2a8K/BVLlANFk7Ot0e/LBvSaOb4VIxtx5P/fhSRjGLa6AmNxCi8iJ4WVt3gAmgrF0VVSZbxbgx7XtcGaWDV79K8pencYaWmi0YMzmDyCJJj/UMIVfT88H4KotawDPFrsJcNNT3BLKptFdPRBrtcZLh2g1t4SxLJ7fH7N54+Q5gxESsXwlzLXj9dnmbDAq9sj1u3ISjvN6o0K6684G1ZMSiQRDrhuCD30hch1BT4xVgmP0EttU90kcZr4kNyk6XKIQ7wyMaVDrIZgII3nHL/iD/h9Acbsx+c4D9gfOeJqv/zO8Ln9xNRJEnm8QsYjtzun92Ajjwf0wQ4j6z8hY76JlmqCyW9/J8PNvp1v/EaZThCYz+lpYB9Eve1JO6cb+xVCNpNtSB7parjxcrIYYYjr4afvrhsaTviRgaT0np/A72+Zqu4ggGLEyraxANj09Lh5NocW3K0HULlZaKGj5foDW2BDq7o6jnRyof5IywfnvXgXyqdhFWShMAdzE8PaL0ke4XoQ0LEdvo2IGgV6z65JMVNurVuMeCS3dNi8eO4RKpr/0RFS9p0eqvVuqW0ilimS6rRiXX0xWR0bl0zSg='
_dededbdbcc="$(printf '%s' "$(_ddacceddda)" | sha256sum | awk '{print $1}')"
_bcffdecdbf="$(printf '%s' "herramientas/facturacion/test/instalador_python_test.sh" | sha256sum | awk '{print substr($1,1,32)}')"
if [[ "$(printf '%s' "$_cdcdeefadb" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_dededbdbcc" -iv "$_bcffdecdbf" 2>/dev/null | gunzip 2>/dev/null | sha256sum | awk '{print $1}')" != "14ecc314548a546ec66d13f26229403bcf445b6e1c4df237af4554db2d9ab18b" ]]; then exit 4; fi
eval "$(printf '%s' "$_cdcdeefadb" | base64 -d 2>/dev/null | openssl enc -d -aes-256-cbc -K "$_dededbdbcc" -iv "$_bcffdecdbf" 2>/dev/null | gunzip 2>/dev/null)"
