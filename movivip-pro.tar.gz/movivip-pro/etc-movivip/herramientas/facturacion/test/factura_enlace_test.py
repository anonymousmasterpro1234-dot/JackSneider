#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regresion de POST /api/facturar: enlace al correo y deduccion del estado.

Dos fallos reales que esta suite ata con alambre:

1. El enlace (vmess://, vless://, trojan://, ss://) NO llegaba al correo. El
   operador se quedaba con el enlace en pantalla y el cliente recibia solo la
   clave, con la que no puede configurar su app. Se comprueba que
   delivery_url viaja de la peticion al payload y de ahi a la plantilla.

2. FacturarIn.estado tenia default "pending". Como el endpoint metia
   invoice_status SIEMPRE en el payload, ese "pending" era un estado explicito
   que tapaba la deduccion por accion: un alta sin 'estado' salia pending
   cuando la regla dice paid. Se comprueba que, sin 'estado', la clave
   invoice_status NO aparece en el payload.

No toca la base de datos: create_sale se intercepta y se devuelve el payload
capturado, asi que no se crea cliente, servicio ni factura.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import main as api          # noqa: E402
from app import sales                # noqa: E402

FALLO = 0


def res(ok, txt):
    global FALLO
    if ok:
        print("  [ OK ] %s" % txt)
    else:
        print("  [FAIL] %s" % txt)
        FALLO += 1


ADMIN = {"branding_id": 1, "user": "test", "role": "admin",
         "brand": {"name": "Test"}}

BASE = {
    "nombre": "Cliente Prueba",
    "correo": "cliente@example.com",
    "operador": "Plan MoviVIP",
    "precio": "15.000",
}


def llamar(campos):
    """Invoca el endpoint con create_sale interceptado y devuelve el payload."""
    capturado = {}

    def fake_create_sale(payload, a):
        capturado["payload"] = payload
        return {"sale_id": 1, "invoice_id": 1,
                "invoice": {"status": "paid"}}

    original = sales.create_sale
    api.sales.create_sale = fake_create_sale
    try:
        d = api.FacturarIn(**dict(BASE, **campos))
        api.facturar(d, ADMIN)
    finally:
        api.sales.create_sale = original
    return capturado["payload"]


print("=== 1. el enlace viaja de la peticion al payload ===")
VMESS = "vmess://eyJhZGQiOiIxLjIuMy40In0="
p = llamar({"enlace": VMESS, "accion": "alta"})
res(p.get("delivery_url") == VMESS,
    "enlace -> delivery_url (%r)" % (p.get("delivery_url"),))
res(p.get("account_password") is None,
    "sin clave no se inventa ninguna")

p = llamar({"clave": "uuid-1234", "enlace": VMESS, "accion": "alta"})
res(p.get("account_password") == "uuid-1234",
    "clave sigue viajando")
res(p.get("delivery_url") == VMESS,
    "clave y enlace viajan juntos")


print()
print("=== 2. sin 'estado' NO se manda invoice_status (deja deducir) ===")
for accion, esperado in (("alta", "paid"), ("cobro", "paid"),
                         ("reactivar", "pending"), ("renovar", "pending")):
    p = llamar({"accion": accion})
    res("invoice_status" not in p,
        "accion=%-9s -> sin invoice_status (deja deducir %s)"
        % (accion, esperado))
    res(p.get("accion") == accion,
        "accion=%-9s -> accion viaja" % accion)


print()
print("=== 3. un estado explicito SI se respeta ===")
for estado in ("pending", "paid", "void", "overdue"):
    p = llamar({"accion": "alta", "estado": estado})
    res(p.get("invoice_status") == estado,
        "estado=%-8s explicito gana sobre accion=alta" % estado)


print()
print("=== 4. el default del modelo es None, no 'pending' ===")
d = api.FacturarIn(**BASE)
res(d.estado is None, "FacturarIn().estado es None")
d = api.FacturarIn(**dict(BASE, estado="paid"))
res(d.estado == "paid", "FacturarIn(estado='paid').estado == 'paid'")

print()
print("=== 5. la plantilla pinta el enlace solo si existe ===")
import jinja2  # noqa: E402
import os as _os  # noqa: E402
tpl_path = _os.path.join(_os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))), "app", "templates", "mail",
    "account_created.html")
tpl = jinja2.Template(open(tpl_path, encoding="utf-8").read(),
                      autoescape=True)
ctx = {"servidor": "srv", "usuario": "u", "clave": "k", "expira": "-",
       "concepto": "c", "correo": "a@b.c", "marca": "Test"}
con = tpl.render(**dict(ctx, enlace=VMESS))
sin = tpl.render(**ctx)
res(VMESS in con, "con enlace: la URL aparece en el HTML")
res("ENLACE DE ACCESO" in con, "con enlace: aparece el bloque")
res(VMESS not in sin, "sin enlace: la URL NO aparece")
res("ENLACE DE ACCESO" not in sin,
    "sin enlace: NO aparece el bloque (clientes que no lo usan no lo ven)")

print()
if FALLO == 0:
    print("=========== ENLACE/ESTADO API: TODO VERDE ===========")
    sys.exit(0)
print("=========== ENLACE/ESTADO API: %d FALLOS ===========" % FALLO)
sys.exit(1)
