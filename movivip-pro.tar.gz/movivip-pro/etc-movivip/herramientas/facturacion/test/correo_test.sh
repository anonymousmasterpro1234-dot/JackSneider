# Prueba de correo_guardado() contra un 'mvb' falso.
# El peligro real: 'mvb buscar' imprime un JSON de error cuando el contacto no
# existe, y si eso se cuela como correo la factura se manda a la nada.
set -u

EDIT="${1:?falta edit.sh}"
# Directorio POSIX a proposito: dentro de Git Bash una ruta 'C:\...' con
# separadores Windows no la resuelven cat/mkdir de forma fiable y el contador
# del mock se quedaba siempre en 0.
D="/tmp/mv_correo_test"
rm -rf "$D"
mkdir -p "$D"

# --- mvb falso --------------------------------------------------------------
# Se monta ANTES de extraer la funcion: la funcion resuelve MVB_BIN en el
# momento de cargarse (MVB_MENU_BIN="${MVB_BIN:-/usr/local/bin/mvb}"), asi que
# si se exporta despues se queda con la ruta real y el mock no se usa nunca.
cat >"$D/mvb" <<'MOCK'
#!/usr/bin/env bash
# Devuelve exactamente lo que el test haya escrito en $CASO_DIR/caso.
# Sin contador: cada prueba sobrescribe ese archivo.
[[ -f "$CASO_DIR/caso" ]] && cat "$CASO_DIR/caso"
exit 0
MOCK
chmod +x "$D/mvb"
export MVB_BIN="$D/mvb"
export CASO_DIR="$D"

# --- extraer la funcion real del archivo -----------------------------------
fn="$(awk '
  /^MVB_MENU_BIN=/  { f=1 }
  f                 { print }
  f && /^\}$/       { exit }
' "$EDIT")"

if ! grep -q 'correo_guardado' <<<"$fn"; then
  echo "FALLO: no se extrajo correo_guardado"; exit 2
fi
eval "$fn"

# comprobar que la funcion apunto al mock y no a /usr/local/bin
case "$MVB_MENU_BIN" in
  "$D"/*) : ;;
  *) echo "FALLO: MVB_MENU_BIN apunto a '$MVB_MENU_BIN', no al mock"; exit 2 ;;
esac

caso() { printf '%s' "$2" >"$D/caso"; }

prueba() {
  local etq="$1" salida="$2" esperado="$3"
  caso 1 "$salida"
  local got
  got="$(correo_guardado master)"
  if [[ "$got" == "$esperado" ]]; then
    printf '  %-40s %-28s %s\n' "$etq" "'${got:0:26}'" "OK"
  else
    printf '  %-40s %-28s FALLO (esperaba '${esperado:0:26}')\n' "$etq" "'${got:0:26}'"
    fail=$((fail+1))
  fi
}
fail=0

echo "=== correo_guardado() con mvb simulado ==="
printf '  %-40s %-28s %s\n' CASO DEVUELTO VERDICTO
echo "  ----------------------------------------------------------------"

prueba "correo normal"           "cli1@movivip.pe"        "cli1@movivip.pe"
prueba "correo con espacios/CR"   "  cli2@movivip.pe  "    "cli2@movivip.pe"
prueba "sin contacto (vacio)"     ""                       ""
prueba "JSON de error"            '{"error":"no encontrado"}' ""
prueba "JSON con ok:false"        '{"ok":false,"error":"x"}' ""
prueba "cadena no-correo"         "usuario-no-encontrado"  ""
prueba "correo sin arroba"        "climovivip.pe"          ""
prueba "correo sin TLD"           "cli1@localhost"         ""
prueba "correo con espacios"      "no es correo"           ""
prueba "texto libre del backend"  "Warning: algo fallo"    ""
prueba "clave ssh"                "PRIVATEKEYDATA"         ""
prueba "dos lineas, correo en la 1a" $'cli1@movivip.pe\notra'   "cli1@movivip.pe"
# Una sola cadena que ya viene pegada es indistinguible de un email raro pero
# legitimo, asi que se acepta. Lo que no puede pasar es que el propio script
# la pegue: eso lo cubre el caso de dos lineas de arriba.
prueba "cadena pegada, ya venia pegada" "cli1@movivip.peotra"    "cli1@movivip.peotra"
prueba "basura en 1a, correo en 2a"   $'WARNING\ncli1@x.com'    ""
prueba "html de error"                "<html>500 error</html>" ""

echo "  ----------------------------------------------------------------"
if [[ "$fail" -eq 0 ]]; then
  echo "  RESULTADO: correo_guardado nunca acepta algo que no sea un correo"
  exit 0
fi
echo "  RESULTADO: $fail casos fallidos"
exit 1