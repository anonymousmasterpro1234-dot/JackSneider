#!/usr/bin/env python3
"""Prueba la regla de estado de factura sin importar reportlab ni la app.

    uso: estado_test.py <ruta-a-billing.py>
Extrae billing.estado_invoice por AST (igual que precio_py.py) para que la
prueba corra sin dependencias.
"""
import ast
import sys
from datetime import datetime


def cargar(path):
    src = open(path, encoding="utf-8").read()
    mod = ast.parse(src)
    ns = {"datetime": datetime}
    for n in mod.body:
        if isinstance(n, ast.FunctionDef) and n.name == "estado_invoice":
            exec(compile(ast.Module(body=[n], type_ignores=[]), "<t>", "exec"), ns)
        if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", "") in (
                "ESTADOS_INVOICE", "ACCIONES_PAGADAS"):
            exec(compile(ast.Module(body=[n], type_ignores=[]), "<t>", "exec"), ns)
    return ns


# (estado explicito, accion, status esperado, paid_at debe ser None?)
CASOS = [
    (None, "alta",      "paid",    False),
    (None, "cobro",     "paid",    False),
    (None, "reactivar", "pending", True),
    (None, "renovar",   "pending", True),
    (None, "",          "pending", True),
    (None, None,        "pending", True),
    ("pending", "alta", "pending", True),   # lo explicito MANDA sobre la accion
    ("paid", "renovar", "paid",    False),
    ("void",  "alta",   "void",    True),   # nunca se rellena paid_at
    ("overdue", "alta", "overdue", True),
    ("basura", "alta",  "paid",    False),  # estado invalido -> deduce de la accion
]


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "app/billing.py"
    ns = cargar(path)
    fn = ns.get("estado_invoice")
    if fn is None:
        print("ERROR: no se encontro estado_invoice en", path)
        return 2

    fallos = 0
    print("=== estado_invoice: (estado, accion) -> status / paid_at ===")
    for estado, accion, esp_status, esp_null in CASOS:
        got_status, got_paid = fn(estado, accion)
        ok = got_status == esp_status and (got_paid is None) == esp_null
        marca = "OK  " if ok else "FALLA"
        if not ok:
            fallos += 1
        paid_txt = "NULL" if got_paid is None else got_paid
        print(f"  [{marca}] estado={str(estado):<8} accion={str(accion):<10} "
              f"-> {got_status:<8} paid_at={paid_txt}")

    # paid_at debe ser una fecha real cuando se rellena
    st, paid = fn(None, "alta")
    if not paid or len(str(paid)) < 10:
        print(f"  [FALLA] paid_at no parece una fecha: {paid!r}")
        fallos += 1
    else:
        print(f"  [OK  ] paid_at con formato de fecha: {paid!r}")

    if fallos:
        print(f"=========== ESTADO: {fallos} fallo(s) ===========")
        return 1
    print("=========== ESTADO: TODO VERDE ===========")
    return 0


if __name__ == "__main__":
    sys.exit(main())
