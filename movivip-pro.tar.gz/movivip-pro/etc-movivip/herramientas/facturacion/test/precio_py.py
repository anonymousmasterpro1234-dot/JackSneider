"""Ejecuta la parse_precio REAL de app/billing.py sin importar el paquete.

Importar app.billing arrastra reportlab y los modulos .config/.db/.security,
y en una maquina de pruebas puede que no esten. Aqui no se reimplementa la
funcion: se saca del fuente con ast y se ejecuta tal cual, de modo que lo que
se prueba es exactamente lo que se despliega.

Salida: una linea por caso, "caso|ok|fallo", y "PYFALL n" al final.
"""
from __future__ import annotations

import ast
import pathlib
import re
import sys
import typing


def cargar_parse_precio(billing_py: pathlib.Path):
    src = billing_py.read_text(encoding="utf-8")
    tree = ast.parse(src)
    keep = []
    for node in tree.body:
        if isinstance(node, ast.Assign):
            nombres = [t.id for t in node.targets if isinstance(t, ast.Name)]
            if any(n.startswith("_P_") for n in nombres):
                keep.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name == "parse_precio":
            keep.append(node)
    if not keep:
        raise SystemExit("no se encontro parse_precio ni los patrones _P_ en el fuente")
    mod = ast.Module(body=keep, type_ignores=[])
    ns = {"Any": typing.Any, "re": re}
    exec(compile(mod, str(billing_py), "exec"), ns)  # noqa: S102
    return ns["parse_precio"]


def main() -> int:
    billing_py = pathlib.Path(sys.argv[1])
    cases = pathlib.Path(sys.argv[2])
    parse_precio = cargar_parse_precio(billing_py)

    fallos = 0
    for raw in cases.read_text(encoding="utf-8").splitlines():
        if not raw.strip() or raw.startswith("#"):
            continue
        entrada, esperado = raw.rsplit("|", 1)
        try:
            got = f"{parse_precio(entrada):.2f}"
        except ValueError as e:
            got = "RECHAZA"
            if "no valido" not in str(e):
                got = "ERROR"
        if got == esperado:
            print(f"{entrada}|ok|{got}")
        else:
            print(f"{entrada}|FALLO|{got}|{esperado}")
            fallos += 1
    print(f"PYFALL {fallos}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
