#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""mvb-preview.py - Envia la plantilla de factura REAL a una direccion cualquiera.

POR QUE EXISTE
--------------
`mvb correo-probar` no sirve para esto. Mirando app/mailer.py:

    def test_connection(branding_id):
        to = cfg.get("sender_email") ...
        _try_send_raw(cfg, to, "MoviVIP Billing - prueba de envio",
                      "<p>Configuracion de correo verificada correctamente.</p>")

O sea: comprueba que el SMTP responda y manda un <p> de texto al PROPIO
remitente. No renderiza invoice.html, no adjunta el logo y no acepta
destinatario. Por eso "enviar correo de prueba" no llegaba a ningun sitio.

Este script hace lo que si espera el operador: renderiza invoice.html con la
marca de AHORA MISMO (el logo y los colores que se acaban de cambiar), le
embebe el logo igual que lo hace mailer.send_now, y lo manda a la direccion
que se le pase. No crea nada en la base de datos: ni factura, ni cola, ni
servicio. Es una vista previa, no una venta.

    ./mvb-preview.py --to cliente@correo.com
    ./mvb-preview.py --to cliente@correo.com --factura 8
    ./mvb-preview.py --to cliente@correo.com --prov movivip
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app import branding, mailer, sales          # noqa: E402
from app.config import settings                 # noqa: E402
from app.db import init_db, q1                  # noqa: E402
from app.security import dec, fmt_date, money        # noqa: E402


def die(msg: str, code: int = 2) -> None:
    print(json.dumps({"ok": False, "error": msg}, ensure_ascii=False), file=sys.stderr)
    raise SystemExit(code)


def out(obj) -> None:
    print(json.dumps(obj, ensure_ascii=False))


def resolve_branding(slug: str | None) -> int:
    """Mismo criterio que cli.resolve_branding, sin importar argparse."""
    cand = (slug or os.environ.get("PROVEEDOR_SLUG")
            or os.environ.get("MVB_PROVEEDOR") or "").strip()
    if cand:
        r = q1("SELECT branding_id FROM providers WHERE slug=?", (cand,))
        if not r:
            die(f"proveedor desconocido: '{cand}'")
        return int(r["branding_id"])
    r = q1("SELECT branding_id FROM providers WHERE active=1 ORDER BY id LIMIT 1")
    if r:
        return int(r["branding_id"])
    r = q1("SELECT id FROM branding ORDER BY id LIMIT 1")
    if r:
        # La columna de la tabla branding es "id". Aqui se ponia
        # r["branding_id"] y reventaba con KeyError en el camino de
        # reserva, o sea justo cuando no hay proveedor activo.
        return int(r["id"])
    die("no hay ninguna marca configurada; usa mvb init")


def pick_invoice(branding_id: int, wanted: int | None) -> dict:
    """Una factura REAL de esta marca. Nunca inventa una de mentira si hay
    al menos una real: la idea es ver el correo tal y como lo recibe el
    cliente, con sus mismos datos."""
    if wanted:
        r = q1("SELECT * FROM invoices WHERE id=? AND branding_id=?",
               (wanted, branding_id))
        if not r:
            die(f"no hay una factura {wanted} de esta marca")
        return dict(r)
    r = q1("SELECT * FROM invoices WHERE branding_id=? ORDER BY id DESC LIMIT 1",
           (branding_id,))
    if r:
        return dict(r)
    return _sample_invoice(branding_id)


def _sample_invoice(branding_id: int) -> dict:
    """Solo si la marca no tiene ninguna factura. Datos-evidentes para que
    nadie los confunda con una venta real."""
    brand = branding.get_brand(branding_id) or {}
    return {
        "id": 0, "number": "PREVIEW-0001", "branding_id": branding_id,
        "customer_name": "Cliente de ejemplo", "customer_email": "cliente@ejemplo.com",
        "customer_tax_id": "00000000000", "operator_label": "PLAN DEMO",
        "description": "Vista previa de plantilla (no es una venta real)",
        "subtotal": 50.0, "tax_rate": 0.0, "tax_amount": 0.0, "total": 50.0,
        "currency": brand.get("currency") or "PEN",
        "issued_at": "2026-01-01", "due_at": "2026-01-31", "status": "pending",
    }


def build_html(branding_id: int, d: dict) -> str:
    """Replica _queue_invoice_email de app/sales.py, con la marca actual."""
    brand = branding.get_brand(branding_id) or {}
    ctx = sales.default_mail_context(brand)

    svc = None
    if d.get("service_id"):
        svc = q1("SELECT * FROM services WHERE id=?", (d["service_id"],))
    svc = dict(svc) if svc else {}

    return mailer.render_mail("invoice.html", {
        **ctx,
        "factura": d, "inv": d,
        "numero": d["number"],
        "total": money(float(d["total"]), d["currency"]),
        "subtotal": money(float(d["subtotal"]), d["currency"]),
        "impuestos": money(float(d["tax_amount"]), d["currency"]),
        "concepto": d.get("description") or d.get("operator_label") or "-",
        "fecha_emision": fmt_date(d.get("issued_at")),
        "fecha_vencimiento": fmt_date(d.get("due_at")),
        # invoice.html:49 pinta "Periodo {{ inicio }} -> {{ fin }}". En el
        # flujo normal create_sale mete estas dos claves en ctx (sales.py:201)
        # y _queue_invoice_email las hereda con **ctx. Este preview arma su
        # contexto solo con default_mail_context, asi que sin estas lineas
        # Jinja las sustituye por cadena vacia y el periodo sale en blanco
        # SIN dar ningun error (el Environment no usa StrictUndefined).
        "inicio": fmt_date(d.get("period_start")),
        "fin": fmt_date(d.get("period_end")),
        # Los mismos campos que pone _queue_account_email. La plantilla de
        # factura no los usa todos, pero si una version nueva los empieza a
        # usar, el preview no sale con huecos.
        "servidor": svc.get("server_hostname") or svc.get("server_ip") or "-",
        "ip": svc.get("server_ip") or "-",
        "usuario": svc.get("account_username") or "-",
        "clave": dec(svc.get("account_password")) if svc.get("account_password") else "-",
        "expira": fmt_date(svc.get("expires_at")),
        "especificaciones": svc.get("specs") or {},
        "notas": svc.get("account_notes") or "",
    })


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Envia la plantilla de factura real a un correo cualquiera")
    # required=False a proposito: con --render no hay destinatario porque no
    # se manda nada. La comprobacion de que viene uno u otro esta en main().
    ap.add_argument("--to", default=None, help="destinatario de la vista previa")
    ap.add_argument("--factura", type=int, default=None,
                    help="id de una factura concreta (por defecto, la ultima)")
    ap.add_argument("--prov", "--proveedor", dest="prov", default=None,
                    help="slug del proveedor, si hay varios")
    ap.add_argument("--asunto", default=None, help="override del asunto")
    ap.add_argument("--render", metavar="RUTA", default=None,
                    help="escribe el HTML a RUTA y NO envia nada. Para abrirlo "
                         "en un navegador y ver la plantilla sin mandar correo")
    args = ap.parse_args()

    to = (args.to or "").strip()
    if not to and not args.render:
        ap.error("hace falta --to (o --render para solo guardar el HTML)")
    if to and ("@" not in to or to.startswith("@") or to.endswith("@")):
        die(f"direccion invalida: '{to}'")

    init_db()
    branding.ensure_default_brand()
    bid = resolve_branding(args.prov)
    brand = branding.get_brand(bid) or {}
    if not brand.get("name"):
        die("la marca no tiene nombre configurado")

    cfg = mailer.mail_config(bid)
    if not cfg:
        die("esta marca no tiene correo configurado; usa la seccion 5 del asistente")

    sender_email = cfg.get("sender_email") or settings.from_email
    sender_name = cfg.get("sender_name") or settings.from_name
    if not sender_email:
        die("no hay remitente configurado para esta marca")

    d = pick_invoice(bid, args.factura)
    html = build_html(bid, d)

    # El logo va como cid: en la plantilla. resolve_logo_html lo convierte en
    # adjunto; build_mime lo mete en el MIME. Sin esto el preview saldria
    # con el logo roto, que es justo lo que se quiere comprobar.
    body, inline = mailer.resolve_logo_html(html, brand)

    # --render: guarda el HTML con el logo en un data: URI, que es lo unico
    # que un navegador entiende. El cid: solo vale dentro de un MIME.
    if args.render:
        import base64
        if inline:
            _cid, data, mime = inline[0]
            uri = f"data:{mime};base64,{base64.b64encode(data).decode('ascii')}"
            body = body.replace(f"cid:{_cid}", uri)
        Path(args.render).write_text(body, "utf-8")
        out({"ok": True, "html": args.render,
             "factura": d["number"], "marca": brand.get("name"),
             "logo_incrustado": bool(inline), "enviado": False})
        return 0

    subject = args.asunto or f"Vista previa de factura - {brand.get('name')}"
    raw = mailer.build_mime(to, None, subject, body,
                            sender_email, sender_name, None, inline)

    try:
        if (cfg.get("provider") or "gmail_api") == "gmail_api":
            mailer._send_gmail(cfg, raw)
        else:
            mailer._send_smtp(cfg, raw)
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({
            "ok": False, "error": str(exc)[:400], "factura": d["number"],
            "marca": brand.get("name"), "remitente": sender_email,
            "logo_incrustado": bool(inline),
        }, ensure_ascii=False), file=sys.stderr)
        return 1

    out({"ok": True, "detalle": "Enviado", "para": to,
         "factura": d["number"], "marca": brand.get("name"),
         "remitente": sender_email, "logo_incrustado": bool(inline),
         "es_factura_real": bool(d.get("id"))})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
