"""API JSON mínima para disparar facturas desde Termux / Termius / scripts.

Sin interfaz web. Solo endpoints. Autenticación por token Bearer.

Endpoints:
  GET  /health                     estado del servicio
  GET  /api/ping                   comprobación simple
  POST /api/facturar               crea cliente + servicio + factura y envía
  POST /api/logo                   sube el logo de la marca
  POST /api/correo/gmail           guarda credenciales Gmail OAuth2
  POST /api/correo/smtp            guarda credenciales SMTP
  POST /api/correo/probar          envía un correo de prueba
  POST /api/vencimientos           dispara el escaneo de vencimientos
  GET  /api/servicios              lista servicios
  GET  /api/facturas               lista facturas
"""
from __future__ import annotations

import os
from typing import Any

from fastapi import Depends, FastAPI, File, Header, HTTPException, UploadFile
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from . import billing, branding, expiry, mailer, sales
from .config import settings
from .db import init_db, q, q1
from .security import enc, money, parse_dt

app = FastAPI(title="MoviVIP Billing API", version="1.0.0", docs_url="/docs", redoc_url=None)

# El logo se referencia desde los correos con una URL ABSOLUTA
# (MVB_PUBLIC_URL/uploads/...). Sin este montaje, esa URL devuelve 404 y el
# cliente ve la plantilla sin marca.
app.mount("/uploads", StaticFiles(directory=str(settings.upload_dir)), name="uploads")

API_TOKEN = os.environ.get("MVB_API_TOKEN", "")


def auth(x_api_token: str | None = Header(default=None, alias="X-Token"),
         authorization: str | None = Header(default=None)) -> dict:
    """Token por header X-Token o `Authorization: Bearer <token>`."""
    token = x_api_token
    if not token and authorization and authorization.lower().startswith("bearer "):
        token = authorization[7:].strip()
    if not API_TOKEN:
        raise HTTPException(503, "MVB_API_TOKEN no configurado en el servidor")
    if not token or token != API_TOKEN:
        raise HTTPException(401, "Token inválido")
    b = branding.ensure_default_brand()
    return {"branding_id": int(b["id"]), "brand": b}


class FacturarIn(BaseModel):
    nombre: str = Field(..., description="Nombre completo del cliente")
    correo: str = Field(..., description="Correo del cliente")
    telefono: str | None = None
    documento: str | None = Field(None, description="RUC/NIT/DNI (opcional)")

    operador: str = Field(..., description="Nombre del operador/plan")
    # Acepta numero o texto: "15.000" son quince mil, no 15.00. Ver
    # billing.parse_precio, que aplica las mismas reglas que el bash.
    precio: float | str = Field(..., description="Importe (lo digita el administrador)")
    periodo: str = Field("mensual", description="mensual|bimestral|trimestral|semestral|anual|unico")
    modo: str = Field("invoice", description="invoice|cuenta|ambos")
    # Estado inicial de la factura. Si se omite se deduce de la accion con
    # billing.estado_invoice: alta/cobro -> paid, reactivar/renovar -> pending.
    #
    # El default es None y NO "pending": con "pending" el campo llegaba siempre
    # informado, la deducción por 'accion' no se ejecutaba nunca y un alta sin
    # 'estado' salía pending cuando la regla dice paid. None = "no informado".
    estado: str | None = Field(None, description="pending|paid|void|overdue")
    accion: str = Field("alta", description="alta|cobro|reactivar|renovar")

    inicio: str | None = None
    fin: str | None = None

    ip: str | None = None
    servidor: str | None = None
    usuario: str | None = None
    clave: str | None = None
    # Enlace de acceso que se envia en el correo de la cuenta creada. Antes solo
    # viajaba la clave, con la que el cliente no puede configurar su app.
    enlace: str | None = Field(None, description="vmess://, vless://, trojan://, ss://")
    notas_cuenta: str | None = None
    specs: dict[str, Any] = Field(default_factory=dict, description="CPU/RAM/disc/puertos etc.")

    concepto: str | None = None
    notas: str | None = None
    emitir_factura: bool = True
    enviar: bool = True

    @field_validator("precio", mode="before")
    @classmethod
    def _precio_a_float(cls, v: Any) -> float:
        """Convierte el importe con las reglas de billing.parse_precio.

        Sin esto, Pydantic haria float("15.000") = 15.0 y la factura saldria
        por un centesimo de lo que el operador quiso cobrar.
        """
        try:
            return billing.parse_precio(v)
        except ValueError as e:
            raise ValueError(str(e)) from e


class GmailIn(BaseModel):
    client_id: str
    client_secret: str
    refresh_token: str
    remitente: str | None = None
    nombre_remitente: str | None = None
    enviar_como: str | None = None


class SmtpIn(BaseModel):
    host: str
    puerto: int = 587
    usuario: str
    clave: str
    seguro: bool = True
    remitente: str
    nombre_remitente: str | None = None


@app.on_event("startup")
def _startup() -> None:
    init_db()
    branding.ensure_default_brand()


@app.get("/health")
def health() -> dict:
    b = branding.get_brand(1) or {}
    mail = mailer.mail_config(1)
    return {
        "ok": True,
        "marca": b.get("name"),
        "correo_configurado": bool(mail),
        "correo_verificado": bool(mail and mail.get("verified_at")),
        "token_configurado": bool(API_TOKEN),
    }


# --- Provider config endpoint (public, solo localhost via hook) ---
@app.get("/api/provider/{slug}/config")
def provider_config(slug: str, token: str | None = None) -> dict:
    """Config de facturacion de un proveedor.

    La consume `facturas.sh` en el mismo servidor, asi que va sin
    `Depends(auth)` (la API escucha solo en 127.0.0.1). A cambio, el correo de
    contacto solo se devuelve si el solicitante trae el token de la API: el hook
    no lo necesita para facturar y no es un dato que deba ir en abierto.

    Antes devolvia `b.secondary_color` y `b.template_name`, columnas que el DDL
    no declaraba (solo existian porque se anadieron a mano en el servidor), y
    protocolo/precio venian hardcodeados: por eso todo facturaba como SSH/50.
    """
    row = q1("""
        SELECT p.id, p.slug, p.license, p.branding_id,
               b.name as brand_name, b.logo_path, b.template_name,
               b.primary_color,
               COALESCE(b.secondary_color, b.accent_color) as secondary_color,
               COALESCE(s.protocol, 'SSH')  as protocol,
               COALESCE(s.price, 50.0)     as price,
               s.contact_email,
               COALESCE(s.currency, b.currency) as currency
        FROM providers p
        JOIN branding b ON b.id = p.branding_id
        LEFT JOIN provider_settings s ON s.provider_id = p.id
        WHERE p.slug = ? AND p.active = 1
    """, (slug,))
    if not row:
        raise HTTPException(404, "Proveedor no encontrado")
    data = {
        "branding_id": row["branding_id"],
        "license": row["license"],
        "marca": row["brand_name"],
        "protocolo": row["protocol"],
        "operador": f"{row['brand_name']} Premium",
        "precio": row["price"],
        "moneda": row["currency"],
        "color_primario": row["primary_color"],
        "color_secundario": row["secondary_color"],
        "logo": row["logo_path"],
        "plantilla": row["template_name"],
    }
    if row["contact_email"] and (token or not API_TOKEN):
        data["correo"] = row["contact_email"]
    return data


@app.get("/api/ping")
def ping(a: dict = Depends(auth)) -> dict:
    return {"ok": True, "marca": a["brand"]["name"]}


@app.post("/api/facturar")
def facturar(d: FacturarIn, a: dict = Depends(auth)) -> dict:
    """Crea la venta y envía los correos. Este es el endpoint principal.

    OJO: create_sale() recibe UN payload dict, no kwargs. Esta ruta llamandolo
    con branding_id=..., customer_name=... reventaba con TypeError, o sea que
    el endpoint HTTP estaba muerto y solo vivia el CLI (mvb facturar). Se
    construye el mismo payload que arma el CLI para que las dos entradas
    produzcan exactamente la misma factura.
    """
    modo_api = {"invoice": "invoice", "factura": "invoice",
                "cuenta": "account", "ambos": "both",
                "both": "both"}.get((d.modo or "invoice").lower(), "invoice")
    payload = {
        "customer_name": d.nombre, "customer_email": d.correo,
        "phone": d.telefono, "document_id": d.documento,
        "operator_label": d.operador, "price_amount": d.precio,
        "billing_period": d.periodo, "delivery_mode": modo_api,
        "start_at": d.inicio, "expires_at": d.fin,
        "server_ip": d.ip, "server_hostname": d.servidor,
        "server_specs": d.specs, "account_username": d.usuario,
        "account_password": d.clave, "account_notes": d.notas_cuenta,
        "delivery_url": d.enlace,
        "description": d.concepto, "notes": d.notas,
        "generate_invoice": d.emitir_factura,
        "accion": d.accion,
        "enviar": d.enviar,
    }
    # 'invoice_status' solo entra si el cliente lo informo. Se manda ausente
    # cuando no se omite, para que billing.estado_invoice deduzca por 'accion'
    # (alta/cobro -> paid). Ver la nota del default en FacturarIn.estado.
    if d.estado:
        payload["invoice_status"] = d.estado
    res = sales.create_sale(payload, a)
    return {"ok": True, "sale_id": res.get("sale_id"),
            "invoice_id": res.get("invoice_id"),
            "estado": (res.get("invoice") or {}).get("status")}


@app.post("/api/logo")
async def logo(file: UploadFile = File(...), a: dict = Depends(auth)) -> dict:
    data = await file.read()
    path = branding.save_logo(a["branding_id"], data, file.content_type)
    return {"ok": True, "path": path, "mime": file.content_type}


@app.post("/api/correo/gmail")
def correo_gmail(d: GmailIn, a: dict = Depends(auth)) -> dict:
    from .db import db
    with db() as c:
        c.execute(
            """INSERT INTO mail_config (branding_id, provider, gmail_client_id, gmail_client_secret,
              gmail_refresh_token, sender_email, sender_name, send_as)
              VALUES (?, 'gmail_api', ?, ?, ?, ?, ?, ?)
              ON CONFLICT(branding_id) DO UPDATE SET
              provider='gmail_api', gmail_client_id=excluded.gmail_client_id,
              gmail_client_secret=excluded.gmail_client_secret,
              gmail_refresh_token=excluded.gmail_refresh_token,
              sender_email=excluded.sender_email, sender_name=excluded.sender_name,
              send_as=excluded.send_as, updated_at=datetime('now')""",
            (a["branding_id"], d.client_id, enc(d.client_secret), enc(d.refresh_token),
             d.remitente or a["brand"]["email"], d.nombre_remitente or a["brand"]["name"],
             d.enviar_como),
        )
    return {"ok": True}


@app.post("/api/correo/smtp")
def correo_smtp(d: SmtpIn, a: dict = Depends(auth)) -> dict:
    from .db import db
    with db() as c:
        c.execute(
            """INSERT INTO mail_config (branding_id, provider, smtp_host, smtp_port, smtp_user,
              smtp_pass, smtp_secure, sender_email, sender_name)
              VALUES (?, 'smtp', ?, ?, ?, ?, ?, ?, ?)
              ON CONFLICT(branding_id) DO UPDATE SET
              provider='smtp', smtp_host=excluded.smtp_host, smtp_port=excluded.smtp_port,
              smtp_user=excluded.smtp_user, smtp_pass=excluded.smtp_pass,
              smtp_secure=excluded.smtp_secure, sender_email=excluded.sender_email,
              sender_name=excluded.sender_name, updated_at=datetime('now')""",
            (a["branding_id"], d.host, d.puerto, d.usuario, enc(d.clave),
             1 if d.seguro else 0, d.remitente, d.nombre_remitente or a["brand"]["name"]),
        )
    return {"ok": True, "metodo": "smtp", "host": d.host, "remitente": d.remitente}


@app.post("/api/correo/probar")
def correo_probar(a: dict = Depends(auth)) -> dict:
    ok, msg = mailer.test_connection(a["branding_id"])
    return {"ok": ok, "detalle": msg}


@app.post("/api/vencimientos")
def vencimientos(dry_run: bool = False, a: dict = Depends(auth)) -> dict:
    return expiry.scan(dry_run=dry_run)


@app.get("/api/servicios")
def servicios(estado: str | None = None, a: dict = Depends(auth)) -> dict:
    sql = """SELECT s.id, s.operator_label, s.price_amount, s.status, s.start_at, s.expires_at,
             u.name as cliente, u.email as correo
             FROM services s JOIN users u ON u.id = s.user_id
             WHERE s.branding_id = ?"""
    params = [a["branding_id"]]
    if estado:
        sql += " AND s.status = ?"
        params.append(estado)
    sql += " ORDER BY s.id DESC LIMIT 100"
    rows = q(sql, tuple(params))
    return {"servicios": [dict(r) for r in rows]}


@app.get("/api/facturas")
def facturas(estado: str | None = None, a: dict = Depends(auth)) -> dict:
    sql = """SELECT i.id, i.number, i.customer_name, i.customer_email, i.operator_label,
             i.subtotal, i.tax_amount, i.total, i.status, i.issued_at, i.sent_at
             FROM invoices i
             WHERE i.branding_id = ?"""
    params = [a["branding_id"]]
    if estado:
        sql += " AND i.status = ?"
        params.append(estado)
    sql += " ORDER BY i.id DESC LIMIT 100"
    rows = q(sql, tuple(params))
    return {"facturas": [dict(r) for r in rows]}