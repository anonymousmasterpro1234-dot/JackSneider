"""Configuracion leida del entorno / .env"""
from __future__ import annotations
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path | None = None) -> None:
    # 1) .env en la raiz del proyecto (desarrollo)
    p1 = path or (BASE_DIR / ".env")
    # 2) .env en el directorio de datos (produccion segun instalador)
    p2 = Path(os.environ.get("MVB_DATA_DIR", "")) / ".env" if os.environ.get("MVB_DATA_DIR") else None
    for p in (p1, p2):
        if p and p.exists():
            for raw in p.read_text(encoding="utf-8").splitlines():
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k, v = k.strip(), v.strip().strip('"').strip("'")
                os.environ.setdefault(k, v)


_load_dotenv()


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


class Settings:
    """Rutas y parametros.

    Antes eran atributos de clase evaluados al importar el modulo, y `db_path`
    apuntaba a BASE_DIR/data aunque se configurara MVB_DATA_DIR: la variable
    existia pero no hacia nada (la BD se creaba siempre en el repo). Ahora se
    resuelven en __init__ y derivan todas de `data_dir`, de modo que
    MVB_DATA_DIR=... mueve la BD, los adjuntos y los PDF juntos.
    """

    def __init__(self) -> None:
        self.base_dir: Path = BASE_DIR

        self.data_dir: Path = Path(os.environ.get("MVB_DATA_DIR") or (BASE_DIR / "data"))
        self.db_path: Path = Path(
            os.environ.get("MVB_DB") or (self.data_dir / "app.db")
        )
        # los adjuntos cuelgan de data_dir salvo que se fuerce MVB_UPLOAD_DIR
        self.upload_dir: Path = Path(
            os.environ.get("MVB_UPLOAD_DIR") or (self.data_dir / "uploads")
        )
        self.template_dir: Path = BASE_DIR / "app" / "templates"
        self.static_dir: Path = BASE_DIR / "static"

        # --- servidor
        self.host: str = os.environ.get("MVB_HOST", "127.0.0.1")
        self.port: int = _int("MVB_PORT", 8090)
        self.public_url: str = os.environ.get(
            "MVB_PUBLIC_URL", f"http://127.0.0.1:{self.port}"
        )
        self.secret_key: str = os.environ.get("MVB_SECRET", "cambia-esto-en-produccion")
        self.session_days: int = _int("MVB_SESSION_DAYS", 7)

        # --- correo saliente (por defecto usa el de la configuracion de la marca)
        self.from_email: str = os.environ.get("MVB_FROM_EMAIL", "")
        self.from_name: str = os.environ.get("MVB_FROM_NAME", "JackSneider")

        # --- limites
        self.max_upload_mb: int = _int("MVB_MAX_UPLOAD_MB", 4)
        self.session_cookie_secure: bool = os.environ.get("MVB_COOKIE_SECURE", "0") == "1"
        self.debug: bool = os.environ.get("MVB_DEBUG", "0") == "1"

        # Crea el arbol de directorios. db_path puede vivir fuera de data_dir.
        for d in (self.data_dir, self.upload_dir, self.upload_dir / "branding", self.db_path.parent):
            d.mkdir(parents=True, exist_ok=True)


settings = Settings()
