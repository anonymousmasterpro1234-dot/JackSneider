"""Avisos de vencimiento.

Se ejecuta desde un timer de systemd (no desde un hilo del proceso web), asi
que sobrevive reinicios y es facil de depurar con `journalctl`.

Idempotencia: `expiry_notices` tiene UNIQUE(service_id, kind, days_left). Si el
correo falla y se reintenta, el aviso no se duplica hacia el cliente.
"""
from __future__ import annotations

from datetime import datetime, timezone

from . import mailer, sales
from .db import db, q, q1
from .security import dec, days_until, fmt_date, money


def _already_sent(service_id: int, kind: str, days_left: int) -> bool:
    return q1(
        "SELECT 1 FROM expiry_notices WHERE service_id=? AND kind=? AND days_left=?",
        (service_id, kind, days_left),
    ) is not None


def _record(service_id: int, kind: str, days_left: int, email_id: int | None) -> None:
    try:
        with db() as c:
            c.execute(
                "INSERT OR IGNORE INTO expiry_notices (service_id, kind, days_left, email_id) VALUES (?,?,?,?)",
                (service_id, kind, days_left, email_id),
            )
    except Exception:  # noqa: BLE001
        pass


def _service_rows() -> list[dict]:
    rows = q(
        """SELECT s.*, u.full_name AS customer_name, u.email AS customer_email
           FROM services s JOIN users u ON u.id = s.customer_id
           WHERE s.status='active' AND s.expires_at IS NOT NULL AND u.is_active=1"""
    )
    return [dict(r) for r in rows]


def scan(dry_run: bool = False) -> dict:
    """Recorre servicios activos y encola los avisos que correspondan."""
    pending: list[tuple[int, str, int, dict]] = []
    expiring_soon = marked_expired = 0

    for s in _service_rows():
        d = days_until(s["expires_at"])
        if d is None:
            continue

        # La marca se resuelve UNA vez por servicio, antes de cualquier rama.
        # Antes solo se cargaba en las ramas de "vencido", asi que la rama de
        # aviso previo (d > 0) leia `brand` de la iteracion anterior o lo
        # encontraba sin definir en la primera.
        brand = sales.get_brand_context(s["branding_id"])

        if d < 0:
            # ya vencio
            if _already_sent(s["id"], "expired", d):
                continue
            if not brand.get("notify_expired", 1):
                continue
            pending.append((s["id"], "expired", d, s))
            marked_expired += 1
            continue

        if d == 0:
            if _already_sent(s["id"], "expired", 0):
                continue
            if brand.get("notify_expired", 1):
                pending.append((s["id"], "expired", 0, s))
                marked_expired += 1
            continue

        warn_days = [int(x) for x in str(brand.get("warn_days") or "").split(",") if x.strip().isdigit()]
        if d in warn_days and not _already_sent(s["id"], "warn", d):
            pending.append((s["id"], "warn", d, s))
            expiring_soon += 1

    if dry_run:
        return {"dry_run": True, "would_send": len(pending),
                "items": [{"service_id": p[0], "kind": p[1], "days_left": p[2], "customer": p[3]["customer_email"]}
                          for p in pending]}

    queued = sent = 0
    for service_id, kind, d, s in pending:
        eid = _queue_expiry_email(s, kind, d)
        if eid is None:
            continue
        queued += 1
        _record(service_id, kind, d, eid)
        if mailer.send_now(eid):
            sent += 1

    # actualizar estado a expirado
    for service_id, kind, d, _ in pending:
        if kind == "expired" and d <= 0:
            with db() as c:
                c.execute("UPDATE services SET status='expired', updated_at=datetime('now') WHERE id=?", (service_id,))

    return {"scanned": len(_service_rows()), "queued": queued, "sent": sent,
            "expiring_soon": expiring_soon, "marked_expired": marked_expired}


def _queue_expiry_email(s: dict, kind: str, d: int) -> int | None:
    brand = sales.get_brand_context(s["branding_id"])
    ctx = sales.default_mail_context(brand)
    ctx.update({
        "cliente": s["customer_name"], "correo_cliente": s["customer_email"],
        "operador": s["operator_label"],
        "precio": money(float(s.get("price_amount") or 0), brand.get("currency") or "PEN"),
        "periodo": s.get("billing_period") or "mensual",
        "inicio": fmt_date(s["start_at"]), "fin": fmt_date(s["expires_at"]),
        "dias": abs(d),
        "servidor": s.get("server_hostname") or s.get("server_ip") or "-",
        "usuario": s.get("account_username") or "-",
    })

    if kind == "expired":
        tpl = "expired.html"
        subject = f"Tu servicio ha vencido - {s['operator_label']} | {brand.get('name')}"
    else:
        tpl = "expiry_warning.html"
        subject = f"Tu servicio vence en {d} dias - {s['operator_label']} | {brand.get('name')}"

    try:
        html = mailer.render_mail(tpl, ctx)
    except Exception:  # noqa: BLE001 - plantilla corrupta no debe parar el escaneo
        return None

    return mailer.enqueue(
        s["branding_id"], "expired" if kind == "expired" else "expiry_warning",
        s["customer_email"], subject, html, to_name=s["customer_name"],
        customer_id=s["customer_id"], service_id=s["id"],
    )
