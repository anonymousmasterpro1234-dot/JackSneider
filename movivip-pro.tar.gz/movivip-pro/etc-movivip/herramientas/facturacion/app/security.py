"""Passwords, sesiones, cifrado de secretos y utilidades de fecha."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
from datetime import datetime, timedelta, timezone

from cryptography.fernet import Fernet, InvalidToken

from .config import settings

# ------------------------------------------------------------------ passwords
# PBKDF2-HMAC-SHA256. Sin dependencias nativas (argon2/bcrypt exigirian compile).
_PBKDF2_ROUNDS = 260_000


def hash_password(pw: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, _PBKDF2_ROUNDS)
    return f"pbkdf2_sha256${_PBKDF2_ROUNDS}${salt.hex()}${dk.hex()}"


def verify_password(pw: str, stored: str | None) -> bool:
    if not stored or not pw:
        return False
    try:
        algo, rounds, salt_hex, dk_hex = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt_hex), int(rounds))
        return hmac.compare_digest(dk.hex(), dk_hex)
    except (ValueError, TypeError):
        return False


# ------------------------------------------------------------------ cifrado
# Clave derivada de MVB_SECRET: cambiar MVB_SECRET hace ilegibles los secretos
# viejos (hay que re-guardarlos desde el panel).
def _fernet() -> Fernet:
    key = hashlib.sha256(settings.secret_key.encode()).digest()
    return Fernet(base64.urlsafe_b64encode(key))


def enc(value: str | None) -> str | None:
    if value is None or value == "":
        return None
    return _fernet().encrypt(value.encode()).decode()


def dec(token: str | None) -> str | None:
    if not token:
        return None
    try:
        return _fernet().decrypt(token.encode()).decode()
    except (InvalidToken, ValueError):
        return None


# ------------------------------------------------------------------ sesiones
def new_session_token() -> str:
    return secrets.token_urlsafe(32)


def session_expiry() -> str:
    return (datetime.now(timezone.utc) + timedelta(days=settings.session_days)).strftime("%Y-%m-%d %H:%M:%S")


# ------------------------------------------------------------------ fechas
def parse_dt(s: str | None) -> datetime | None:
    if not s:
        return None
    s = s.strip().replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%d/%m/%Y %H:%M", "%d/%m/%Y"):
        try:
            return datetime.strptime(s, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def fmt_dt(s: str | None, with_time: bool = True) -> str:
    d = parse_dt(s)
    if not d:
        return "-"
    return d.strftime("%d/%m/%Y %H:%M" if with_time else "%d/%m/%Y")


def fmt_date(s: str | None) -> str:
    d = parse_dt(s)
    return d.strftime("%d/%m/%Y") if d else "-"


def days_until(s: str | None) -> int | None:
    d = parse_dt(s)
    if not d:
        return None
    today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    return (d.replace(hour=0, minute=0, second=0, microsecond=0) - today).days


# ------------------------------------------------------------------ varios
def money(amount: float, currency: str = "PEN") -> str:
    sym = {"PEN": "S/", "USD": "$", "EUR": "€", "MXN": "$", "COP": "$", "ARS": "$", "CLP": "$"}.get(currency, "")
    return f"{sym} {amount:,.2f}".strip()


def slugify(text: str) -> str:
    t = "".join(c.lower() if c.isalnum() else "-" for c in text.strip())
    while "--" in t:
        t = t.replace("--", "-")
    return t.strip("-") or "marca"


def safe_json(raw: str | None) -> dict:
    if not raw:
        return {}
    try:
        v = json.loads(raw)
        return v if isinstance(v, dict) else {}
    except (json.JSONDecodeError, TypeError):
        return {}


def random_password(n: int = 12) -> str:
    alphabet = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(secrets.choice(alphabet) for _ in range(n))
