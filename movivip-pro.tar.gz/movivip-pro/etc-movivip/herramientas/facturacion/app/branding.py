"""Gestion de marca y logo."""
from __future__ import annotations

import re
import secrets
import io
from mimetypes import guess_type
from pathlib import Path

from .config import settings
from .db import db, q1

ALLOWED_MIME = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "image/gif": ".gif", "image/svg+xml": ".svg"}
# 600 px de lado es de sobra: en el correo se ve a ~300 px y en el PDF a ~300 px
# de impresion. El logo original del usuario pesaba 2.4 MB, y embebido eso
# multiplicaba el tamano de cada correo.
MAX_SIDE = 600
# lado de la variante que se incrusta en el correo
EMAIL_SIDE = 200
MAX_BYTES = 120_000


def get_brand(branding_id: int) -> dict | None:
    r = q1("SELECT * FROM branding WHERE id=?", (branding_id,))
    return dict(r) if r else None


def save_logo(branding_id: int, filename: str, content: bytes, content_type: str) -> str:
    """Valida, normaliza y guarda el logo. Devuelve la ruta relativa."""
    ext = ALLOWED_MIME.get((content_type or "").lower())
    if not ext:
        # fallback por extension
        guess = Path(filename or "").suffix.lower()
        ext = {".png": ".png", ".jpg": ".jpg", ".jpeg": ".jpg", ".webp": ".webp", ".gif": ".gif", ".svg": ".svg"}.get(guess)
    if not ext:
        raise ValueError("Formato no permitido. Usa PNG, JPG, WEBP, GIF o SVG.")

    limit = settings.max_upload_mb * 1024 * 1024
    if len(content) > limit:
        raise ValueError(f"El logo supera el limite de {settings.max_upload_mb} MB.")

    rel_dir = Path("branding") / str(branding_id)
    dest_dir = settings.upload_dir / rel_dir
    dest_dir.mkdir(parents=True, exist_ok=True)

    # borra el logo anterior con otra extension
    brand = get_brand(branding_id) or {}
    if brand.get("logo_path"):
        old = settings.upload_dir / brand["logo_path"]
        if old.is_file():
            try:
                old.unlink()
            except OSError:
                pass

    dest = dest_dir / f"logo-{secrets.token_hex(4)}{ext}"
    dest.write_bytes(content)

    if ext != ".svg":
        _normalize(dest)

    rel = str(rel_dir / dest.name).replace("\\", "/")
    with db() as c:
        c.execute(
            "UPDATE branding SET logo_path=?, logo_mime=?, updated_at=datetime('now') WHERE id=?",
            (rel, f"image/{ext.lstrip('.')}" if ext != ".jpg" else "image/jpeg", branding_id),
        )
    return rel


def _email_variant(path: Path) -> Path | None:
    """Copia reducida del logo para incrustarlo en el correo.

    Outlook no respeta `max-width` en el estilo inline y pinta la imagen a su
    tamano natural: con el logo de 600 px ocupaba media pantalla. Guardando una
    variante de 200 px, incluso el cliente mas tosco lo muestra a un tamano
    razonable. Se cachea junto al original.
    """
    small = path.with_name(f"{path.stem}-sm{path.suffix}")
    if small.is_file() and small.stat().st_mtime >= path.stat().st_mtime:
        return small
    try:
        from PIL import Image

        with Image.open(path) as im:
            im = im.convert("RGBA") if im.mode in ("P", "LA") else im
            if max(im.size) > EMAIL_SIDE:
                r = EMAIL_SIDE / max(im.size)
                im = im.resize((int(im.width * r), int(im.height * r)), Image.LANCZOS)
            buf = io.BytesIO()
            im.save(buf, format="PNG", optimize=True)
            if len(buf.getvalue()) > 60_000:
                im = im.convert("P", palette=Image.ADAPTIVE, colors=128)
                im.save(small, optimize=True)
            else:
                small.write_bytes(buf.getvalue())
        return small
    except Exception:  # noqa: BLE001 - si no se puede reducir, serve el original
        return path


def logo_file(brand: dict) -> Path | None:
    """Ruta absoluta del logo de una marca, si existe en disco."""
    rel = (brand or {}).get("logo_path")
    if not rel:
        return None
    if str(rel).startswith("http"):
        return None
    p = settings.upload_dir / str(rel).lstrip("/")
    return p if p.is_file() else None


def logo_bytes(brand: dict) -> tuple[bytes, str] | None:
    """Logo como (contenido, mime) para embeberlo en el correo."""
    p = logo_file(brand)
    if p is None:
        return None
    use = _email_variant(p)
    if use is None:
        return None
    try:
        data = use.read_bytes()
    except OSError:
        return None
    if not data:
        return None
    mime = (brand or {}).get("logo_mime") or guess_type(use.name)[0] or "image/png"
    return data, mime


def _normalize(path: Path) -> None:
    """Recorta, redimensiona y comprime para que el correo y el PDF no engorden."""
    try:
        from PIL import Image
    except ImportError:
        return
    try:
        with Image.open(path) as im:
            im = im.convert("RGBA") if im.mode in ("P", "LA") else im
            w, h = im.size
            if max(w, h) > MAX_SIDE:
                ratio = MAX_SIDE / max(w, h)
                im = im.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)

            # Un PNG de 1254x1254 con degradado sigue pesando MB. Si tras
            # redimensionar sigue siendo grande, se reduce la paleta a 256
            # colores: para un logo es visualmente identico.
            if path.suffix.lower() == ".png":
                buf = io.BytesIO()
                im.save(buf, format="PNG", optimize=True)
                if len(buf.getvalue()) > MAX_BYTES:
                    im = im.convert("P", palette=Image.ADAPTIVE, colors=256)
                    im.save(path, optimize=True)
                    return
                path.write_bytes(buf.getvalue())
                return

            im.save(path, optimize=True)
    except Exception:  # noqa: BLE001 - un logo raro se guarda tal cual
        pass


def delete_logo(branding_id: int) -> None:
    brand = get_brand(branding_id) or {}
    if brand.get("logo_path"):
        p = settings.upload_dir / brand["logo_path"]
        if p.is_file():
            try:
                p.unlink()
            except OSError:
                pass
    with db() as c:
        c.execute("UPDATE branding SET logo_path=NULL, logo_mime=NULL, updated_at=datetime('now') WHERE id=?", (branding_id,))


EDITABLE_FIELDS = [
    "name", "legal_name", "tax_id", "tax_rate", "currency", "email_title",
    "primary_color", "accent_color", "contact_email", "support_handle", "phone",
    "whatsapp", "website", "address", "telegram_channel", "telegram_group",
    "footer_html", "signature_html", "warn_days", "notify_expired",
]

COLOR_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")


def update_brand(branding_id: int, data: dict) -> dict:
    sets, args = [], []
    for f in EDITABLE_FIELDS:
        if f not in data:
            continue
        v = data[f]
        if f in ("primary_color", "accent_color"):
            v = (v or "").strip()
            if not COLOR_RE.match(v):
                raise ValueError(f"{f}: color hexadecimal invalido")
        elif f in ("tax_rate",):
            try:
                v = float(v or 0)
            except (TypeError, ValueError):
                raise ValueError("tax_rate debe ser numerico")
        elif f in ("warn_days",):
            v = ",".join(x.strip() for x in str(v or "").split(",") if x.strip().isdigit())
        elif f in ("notify_expired",):
            v = 1 if str(v).lower() in ("1", "on", "true", "yes", "si") else 0
        elif isinstance(v, str):
            v = v.strip()
        sets.append(f"{f}=?")
        args.append(v)

    if not sets:
        return get_brand(branding_id) or {}
    args += [branding_id]
    with db() as c:
        c.execute(f"UPDATE branding SET {', '.join(sets)}, updated_at=datetime('now') WHERE id=?", args)
    return get_brand(branding_id) or {}


def ensure_default_brand(name: str = "JackSneider") -> dict:
    """Crea la marca por defecto si la BD esta vacia."""
    from .security import slugify
    b = get_brand(1)
    if b:
        return b
    slug = slugify(name)
    # contact_email se deja vacio a proposito: ningun correo personal debe ir
    # incrustado en el codigo ni en el tarball. El administrador lo define en su
    # instalacion con:  mvb marca --set contact_email=correo@su-dominio
    with db() as c:
        c.execute(
            """INSERT INTO branding (slug, name, email_title, telegram_channel, telegram_group,
                                     support_handle, website, contact_email, warn_days)
               VALUES (?,?,?,?,?,?,?,?, '7,3,1')""",
            (slug, name, "PREMIUM", "JackSneiderNetwork", "JackSneiderNet", "JackSneider",
             "https://", ""),
        )
    return get_brand(1) or {}
