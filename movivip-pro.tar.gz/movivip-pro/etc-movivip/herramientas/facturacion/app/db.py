"""Acceso a SQLite. Un solo fichero, WAL, sin ORM.

Motivo: `sqlite3` viene en la libreria estandar de Python, asi que no hace
falta compilar nada (better-sqlite3 exigiria gcc en un servidor de 921 MB).
Para el volumen de este sistema es de sobra.
"""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Iterable

from .config import settings

_SCHEMA = None


def _schema() -> str:
    global _SCHEMA
    if _SCHEMA is None:
        from .schema import DDL
        _SCHEMA = DDL
    return _SCHEMA


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


@contextmanager
def db():
    """Conexion con commit/rollback automaticos."""
    conn = sqlite3.connect(settings.db_path, timeout=30, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    try:
        # BEGIN IMMEDIATE (no diferido): toma el candado de escritura al abrir.
        # Con un BEGIN diferido, dos procesos pueden leer el mismo MAX(seq) y
        # calcular el mismo numero de factura. Aqui se serializan los escritores
        # (carga baja: un administrador) y `busy_timeout` absorbe la espera.
        conn.execute("BEGIN IMMEDIATE")
        yield conn
        conn.execute("COMMIT")
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise
    finally:
        conn.close()


@contextmanager
def db_read():
    conn = sqlite3.connect(settings.db_path, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    try:
        yield conn
    finally:
        conn.close()


# Migraciones ligeras. `CREATE TABLE IF NOT EXISTS` no añade columnas a una base
# ya creada, asi que cada columna nueva se declara aqui y se aplica con
# ALTER TABLE ... ADD COLUMN (idempotente: si ya existe, no hace nada).
_MIGRATIONS: list[tuple[str, str, str]] = [
    ("services", "quantity", "INTEGER NOT NULL DEFAULT 1"),
    ("branding", "warn_days", "TEXT NOT NULL DEFAULT '7,3,1'"),
    ("branding", "notify_expired", "INTEGER NOT NULL DEFAULT 1"),
    # Estas tres se anadieron a mano en el servidor. Sin ellas, la consulta de
    # /api/provider/{slug}/config revienta con "no such column".
    # `provider_id` se declara sin REFERENCES a proposito: providers.branding_id
    # ya apunta a branding, y un ciclo de FK complica el ALTER TABLE.
    ("branding", "provider_id", "INTEGER"),
    ("branding", "template_name", "TEXT"),
    ("branding", "secondary_color", "TEXT NOT NULL DEFAULT '#29b6f6'"),
]


def migrate(conn: sqlite3.Connection) -> list[str]:
    """Aplica las columnas que falten. Devuelve la lista de las anadidas."""
    applied: list[str] = []
    for table, column, decl in _MIGRATIONS:
        try:
            cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
        except sqlite3.Error:
            continue
        if not cols:
            continue  # la tabla no existe todavia; la creara el DDL
        if column in cols:
            continue
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")
            applied.append(f"{table}.{column}")
        except sqlite3.Error:
            pass
    return applied


def init_db() -> None:
    """Crea el esquema si no existe.

    NO se usa `db()` a proposito: `executescript()` emite un COMMIT implicito
    antes de ejecutar el script, lo que deja la transaccion explicita huerfana
    y hace fallar el COMMIT final con
    "cannot commit - no transaction is active".
    El DDL es idempotente (IF NOT EXISTS), asi que basta con autocommit.
    """
    conn = sqlite3.connect(settings.db_path, timeout=30, isolation_level=None)
    try:
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=30000")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript(_schema())
        migrate(conn)
    finally:
        conn.close()


# ------------------------------------------------------------------ helpers
def q(sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
    with db_read() as c:
        return c.execute(sql, tuple(params)).fetchall()


def q1(sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
    with db_read() as c:
        return c.execute(sql, tuple(params)).fetchone()


def scalar(sql: str, params: Iterable[Any] = (), default: Any = 0) -> Any:
    r = q1(sql, params)
    if r is None:
        return default
    v = r[0]
    return default if v is None else v


def execute(sql: str, params: Iterable[Any] = ()) -> sqlite3.Cursor:
    with db() as c:
        return c.execute(sql, tuple(params))


def insert(sql: str, params: Iterable[Any] = ()) -> int:
    with db() as c:
        cur = c.execute(sql, tuple(params))
        return int(cur.lastrowid)


def row_to_dict(row: sqlite3.Row | None) -> dict | None:
    return dict(row) if row is not None else None


def rows_to_dicts(rows: Iterable[sqlite3.Row]) -> list[dict]:
    return [dict(r) for r in rows]
