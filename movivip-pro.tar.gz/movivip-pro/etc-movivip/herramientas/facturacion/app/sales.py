"""Venta: el flujo que crea cliente, servicio, factura y dispara los correos.

Es la unica funcion que el administrador usa para "dar de alta" a alguien.
Si `delivery_mode` es `account` o `both`, ademas genera y encola la plantilla
de cuenta creada con los datos del servidor.
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone

from . import billing, contactos, mailer
from .db import db, now, q1
from .security import enc, fmt_date, hash_password, money, random_password, safe_json, slugify

DELIVERY_LABELS = {"invoice": "Solo factura", "account": "Solo cuenta creada", "both": "Factura + cuenta creada"}


def get_brand(branding_id: int) -> dict | None:
    r = q1("SELECT * FROM branding WHERE id=?", (branding_id,))
    return dict(r) if r else None


def get_brand_context(branding_id: int) -> dict:
    b = get_brand(branding_id) or {}
    ctx = dict(b)
    ctx["warn_days_list"] = [
        int(x) for x in str(b.get("warn_days") or "7,3,1").split(",") if x.strip().isdigit()
    ]
    return ctx


def default_mail_context(brand: dict) -> dict:
    """Variables comunes a todas las plantillas de correo."""
    from .config import settings
    # El logo viaja EMBEBIDO en el correo (cid:), no como URL: asi se ve en
    # Gmail, Outlook y movil aunque el servidor no tenga URL publica. Si el
    # logo no estuviera, `mailer.resolve_logo_html` lo cambia por la URL o por
    # un pixel transparente en el momento del envio.
    logo_url = f"cid:{mailer.LOGO_CID}" if brand.get("logo_path") else ""
    logo_url_public = ""
    if brand.get("logo_path"):
        rel = str(brand["logo_path"])
        # URL ABSOLUTA: el cliente de correo no resuelve rutas relativas.
        if rel.startswith("http"):
            logo_url_public = rel
        else:
            logo_url_public = f"{settings.public_url.rstrip('/')}/uploads/{rel.lstrip('/')}"
    return {
        "brand": brand,
        "marca": brand,
        "logo_url": logo_url,
        "logo_url_public": logo_url_public,
        "nombre_marca": brand.get("name"),
        "titulo": brand.get("email_title") or "PREMIUM",
        "color_principal": brand.get("primary_color") or "#FFD700",
        "color_acento": brand.get("accent_color") or "#29b6f6",
        "soporte": brand.get("support_handle"),
        "canal": brand.get("telegram_channel"),
        "grupo": brand.get("telegram_group"),
        "web": brand.get("website"),
        "correo_marca": brand.get("contact_email"),
        "telefono": brand.get("phone"),
        "whatsapp": brand.get("whatsapp"),
        "footer_html": brand.get("footer_html") or "",
    }


def find_or_create_customer(branding_id: int, email: str, full_name: str,
                            phone: str | None = None, document_id: str | None = None) -> tuple[int, bool]:
    """Devuelve (user_id, created). Reutiliza el cliente si el correo ya existe."""
    email = (email or "").strip().lower()
    full_name = (full_name or "").strip()

    existing = q1("SELECT * FROM users WHERE email=?", (email,))
    if existing:
        u = dict(existing)
        patch, args = [], []
        # El nombre de la venta manda sobre el que hubiera guardado. Antes solo
        # se rellenaba si estaba vacio, asi que un cliente creado una vez como
        # "testuser" seguia apareciendo con ese nombre en todas las facturas y
        # correos aunque el alta se hiciera con otro usuario.
        if full_name and full_name != (u.get("full_name") or "").strip():
            patch.append("full_name=?")
            args.append(full_name)
        if phone and phone != (u.get("phone") or "").strip():
            patch.append("phone=?")
            args.append(phone)
        if document_id and document_id != (u.get("document_id") or "").strip():
            patch.append("document_id=?")
            args.append(document_id)
        if patch:
            args += [u["id"]]
            with db() as c:
                c.execute(f"UPDATE users SET {', '.join(patch)}, updated_at=datetime('now') WHERE id=?", args)
        return int(u["id"]), False

    with db() as c:
        cur = c.execute(
            """INSERT INTO users (branding_id, email, full_name, phone, document_id, role, password_hash, must_reset)
               VALUES (?,?,?,?,?, 'customer', ?, 1)""",
            (branding_id, email, full_name or email.split("@")[0], phone, document_id,
             hash_password(random_password(16))),
        )
        return int(cur.lastrowid), True


def create_sale(payload: dict, admin: dict) -> dict:
    """Crea la venta completa. Devuelve un resumen con ids y avisos de envio.

    Claves esperadas en `payload`:
      customer_name, customer_email, operator_label, price_amount, billing_period,
      delivery_mode, start_at, expires_at, server_ip, server_hostname, server_specs(dict),
      account_username, account_notes, description, notes, generate_invoice(bool)
    """
    branding_id = int(admin["branding_id"])
    brand = get_brand_context(branding_id)
    if not brand:
        raise ValueError("Marca no encontrada")

    email = (payload.get("customer_email") or "").strip().lower()
    name = (payload.get("customer_name") or "").strip()
    if not email or "@" not in email:
        raise ValueError("Correo del cliente invalido")
    if not name:
        raise ValueError("Nombre del cliente obligatorio")

    # Nada de float() crudo aqui: float("15.000") es 15.0 y convertia quince
    # mil en quince soles. parse_precio es la unica puerta de entrada.
    price = billing.parse_precio(payload.get("price_amount"))
    period = payload.get("billing_period") or "mensual"
    delivery = payload.get("delivery_mode") or "invoice"
    if delivery not in DELIVERY_LABELS:
        raise ValueError("Modo de entrega invalido")

    start_at = (payload.get("start_at") or "").strip() or datetime.now(timezone.utc).strftime("%Y-%m-%d")
    expires_at = (payload.get("expires_at") or "").strip() or billing.period_end_from(start_at, period)
    specs = payload.get("server_specs") or {}
    if isinstance(specs, str):
        specs = safe_json(specs)

    customer_id, _created = find_or_create_customer(
        branding_id, email, name,
        payload.get("phone"), payload.get("document_id"),
    )

    # ---- servicio
    try:
        quantity = max(1, int(payload.get("quantity") or 1))
    except (TypeError, ValueError):
        quantity = 1
    with db() as c:
        cur = c.execute(
            """INSERT INTO services
               (branding_id, customer_id, operator_id, operator_label, price_amount, quantity,
                billing_period, delivery_mode, server_ip, server_hostname, server_specs,
                account_username, account_password, account_notes, start_at, expires_at, status)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'active')""",
            (branding_id, customer_id, payload.get("operator_id") or None,
             (payload.get("operator_label") or "").strip() or "Servicio",
             price, quantity, period, delivery,
             payload.get("server_ip"), payload.get("server_hostname"),
             json.dumps(specs, ensure_ascii=False) if specs else None,
             payload.get("account_username"),
             enc(payload.get("account_password")) if payload.get("account_password") else None,
             payload.get("account_notes"), start_at, expires_at),
        )
        service_id = int(cur.lastrowid)

    service = _service_bundle(service_id)

    # ---- factura
    invoice_id = None
    if payload.get("generate_invoice", True) and delivery in ("invoice", "both"):
        invoice_id = _make_invoice(service, brand, payload)

    # ---- registro central de contactos
    # Se guarda SIEMPRE (protocolo incluido), incluso si no se manda correo:
    # es lo que permite facturar luego una reanimacion o emitirla a mano.
    protocol = (payload.get("protocol") or payload.get("operator_label") or "ssh").strip().lower()
    account_user = (payload.get("account_username") or "").strip()
    if account_user:
        contactos.registrar(
            account_user=account_user, protocol=protocol, email=email,
            full_name=name, phone=payload.get("phone"),
            notes=payload.get("notes"), branding_id=branding_id,
        )
        contactos.enlazar(account_user, protocol, customer_id=customer_id,
                          service_id=service_id, branding_id=branding_id)

    # ---- correos
    queued, failed = [], []
    base = default_mail_context(brand)
    base.update({
        "cliente": name, "correo_cliente": email,
        "operador": service["operator_label"],
        "precio": money(price, brand.get("currency") or "PEN"),
        "periodo": billing.period_label(period),
        "inicio": fmt_date(start_at), "fin": fmt_date(expires_at),
        # Enlace de acceso del cliente. Antes no habia forma de mandarlo: el
        # correo llevaba la clave suelta y el cliente no podia configurar nada.
        # Solo se usa en el correo de cuenta creada; no se guarda en la BD de
        # servicios (si se guardara, habria que migrar el esquema).
        "enlace": (payload.get("delivery_url") or "").strip(),
    })

    if delivery in ("account", "both"):
        eid = _queue_account_email(branding_id, service, base, invoice_id, customer_id)
        queued.append(eid)

    if delivery in ("invoice", "both") and invoice_id:
        eid = _queue_invoice_email(branding_id, service, base, invoice_id, customer_id)
        queued.append(eid)

    # `enviar=False` deja los correos EN COLA sin despacharlos. Antes esto se
    # ignoraba: los correos salian igualmente y el CLI/API solo reportaba 0.
    enviar = payload.get("enviar", True)
    if not enviar:
        return {
            "service_id": service_id, "customer_id": customer_id, "invoice_id": invoice_id,
            "emails_queued": queued, "emails_sent": 0, "emails_failed": [],
            "expires_at": expires_at, "solo_registro": True,
        }

    ok = 0
    for eid in queued:
        if mailer.send_now(eid, attachments_for_email(eid)):
            ok += 1
        else:
            failed.append(eid)

    return {
        "service_id": service_id,
        "customer_id": customer_id,
        "invoice_id": invoice_id,
        "emails_queued": queued,
        "emails_sent": ok,
        "emails_failed": failed,
        "expires_at": expires_at,
    }


def facturar_por_usuario(account_user: str, admin: dict, price_amount: float | None = None,
                          protocol: str | None = None, operator_label: str | None = None,
                          expires_at: str | None = None, **extra) -> dict:
    """Factura una cuenta existente usando el contacto YA REGISTRADO.

    Es la ruta que usa la reanimacion (`usuarios/reactivar.sh`): el alta original
    guardo el correo en `contactos`, asi que aqui no se vuelve a preguntar nada.

    Si el contacto no tiene correo se lanza ValueError con un mensaje claro, para
    que el hook pueda avisar al administrador en vez de fallar en silencio.
    """
    user = (account_user or "").strip()
    if not user:
        raise ValueError("Falta el usuario del sistema")

    contacto = contactos.buscar(user, protocol, admin["branding_id"])
    if not contacto or not (contacto.get("email") or "").strip():
        raise ValueError(
            f"El usuario '{user}' no tiene correo registrado. "
            f"Registralo con: mvb contacto --usuario {user} --correo <correo>"
        )

    svc = contacto.get("last_service_id")
    base_payload: dict = {
        "customer_name": contacto.get("full_name") or user,
        "customer_email": contacto["email"],
        "customer_phone": contacto.get("phone"),
        "operator_label": operator_label or (contacto.get("protocol") or "ssh").upper(),
        "price_amount": price_amount if price_amount is not None else 0,
        "account_username": user,
        "protocol": contacto.get("protocol") or protocol or "ssh",
    }
    if expires_at:
        base_payload["expires_at"] = expires_at
        base_payload["start_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    base_payload.update(extra)
    return create_sale(base_payload, admin)


def _service_bundle(service_id: int) -> dict:
    r = q1(
        """SELECT s.*, u.full_name AS customer_name, u.email AS customer_email,
                  u.document_id AS customer_document, o.name AS operator_name
           FROM services s
           JOIN users u ON u.id = s.customer_id
           LEFT JOIN operators o ON o.id = s.operator_id
           WHERE s.id=?""",
        (service_id,),
    )
    d = dict(r)
    d["specs"] = safe_json(d.get("server_specs"))
    return d


def _make_invoice(service: dict, brand: dict, payload: dict) -> int:
    price = float(service.get("price_amount") or 0)
    tax_rate = float(brand.get("tax_rate") or 0)
    sub, tax, total = billing.totals(price, tax_rate)
    year = datetime.now(timezone.utc).year

    # El concepto refleja la cantidad de dispositivos cuando es > 1.
    desc = payload.get("description") or None
    qty = int(service.get("quantity") or 1)
    if qty > 1:
        base_desc = desc or service["operator_label"]
        desc = f"{base_desc} ({qty} dispositivos)"

    with db() as c:
        # El estado lo decide billing.estado_invoice: alta/cobro nacen pagadas
        # (el dinero ya esta dentro) y reactivar/renovar nacen pendientes.
        status, paid_at = billing.estado_invoice(
            payload.get("invoice_status"), payload.get("accion"))

        # Numero e INSERT en la MISMA transaccion: sin ventana de colision.
        number, seq = billing.next_number_in(c, int(brand["id"]), prefix="F", year=year)
        cur = c.execute(
            """INSERT INTO invoices
               (branding_id, service_id, number, seq, year, customer_id, customer_name,
                customer_email, customer_tax_id, operator_label, description, subtotal, tax_rate,
                tax_amount, total, currency, period_start, period_end, due_at, status, paid_at,
                notes)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (brand["id"], service["id"], number, seq, year,
             service["customer_id"], service["customer_name"], service["customer_email"],
             service.get("customer_document"), service["operator_label"],
             desc, sub, tax_rate, tax, total,
             brand.get("currency") or "PEN", service["start_at"], service.get("expires_at"),
             service.get("expires_at"), status, paid_at, payload.get("notes")),
        )
        return int(cur.lastrowid)


def _queue_account_email(branding_id: int, service: dict, ctx: dict, invoice_id: int | None,
                        customer_id: int) -> int:
    from .security import dec
    html = mailer.render_mail("account_created.html", {
        **ctx,
        "servidor": service.get("server_hostname") or service.get("server_ip") or "-",
        "ip": service.get("server_ip") or "-",
        "usuario": service.get("account_username") or "-",
        "clave": dec(service.get("account_password")) or "-",
        "expira": fmt_date(service.get("expires_at")),
        "especificaciones": service.get("specs") or {},
        "notas": service.get("account_notes") or "",
    })
    subject = f"Cuenta creada - {service['operator_label']} | {ctx.get('nombre_marca')}"
    return mailer.enqueue(branding_id, "account_created", service["customer_email"], subject,
                          html, to_name=service["customer_name"], customer_id=customer_id,
                          service_id=service["id"], invoice_id=invoice_id)


def _queue_invoice_email(branding_id: int, service: dict, ctx: dict, invoice_id: int,
                         customer_id: int) -> int:
    inv = q1("SELECT * FROM invoices WHERE id=?", (invoice_id,))
    d = dict(inv)
    html = mailer.render_mail("invoice.html", {
        **ctx, "factura": d, "inv": d,
        "numero": d["number"],
        "total": money(float(d["total"]), d["currency"]),
        "subtotal": money(float(d["subtotal"]), d["currency"]),
        "impuestos": money(float(d["tax_amount"]), d["currency"]),
        "concepto": d.get("description") or d["operator_label"],
        "fecha_emision": fmt_date(d["issued_at"]),
        "fecha_vencimiento": fmt_date(d.get("due_at")),
    })
    subject = f"Factura {d['number']} - {d['operator_label']} | {ctx.get('nombre_marca')}"
    return mailer.enqueue(branding_id, "invoice", service["customer_email"], subject,
                          html, to_name=service["customer_name"], customer_id=customer_id,
                          service_id=service["id"], invoice_id=invoice_id)


def attachments_for_email(email_id: int) -> list[tuple[str, bytes, str]] | None:
    """Adjuntos que corresponden a un correo de la cola, segun SU PROPIA fila.

    Se apoya solo en la BD (no en parametros del alta) para que el reintento de
    `mailer.process_queue` pueda reconstruir el PDF. Antes el adjunto se pasaba
    como parametro desde `create_sale`, de modo que un correo fallido se
    reenviaba sin el PDF de la factura.
    """
    row = q1("SELECT kind, invoice_id, branding_id FROM emails WHERE id=?", (email_id,))
    if not row:
        return None
    if row["kind"] != "invoice" or not row["invoice_id"]:
        return None

    inv = q1("SELECT * FROM invoices WHERE id=?", (row["invoice_id"],))
    if not inv:
        return None
    d = dict(inv)

    if not d.get("pdf_path"):
        brand = get_brand(int(row["branding_id"])) or {}
        try:
            billing.store_pdf(d["id"], d, brand)
        except Exception:
            return None
        fresh = q1("SELECT pdf_path FROM invoices WHERE id=?", (d["id"],))
        if fresh and fresh["pdf_path"]:
            d["pdf_path"] = fresh["pdf_path"]
    if not d.get("pdf_path"):
        return None

    p = settings_upload() / d["pdf_path"]
    if not p.is_file():
        return None
    return [(f"{d['number']}.pdf", p.read_bytes(), "application/pdf")]


def settings_upload():
    from .config import settings
    return settings.upload_dir
