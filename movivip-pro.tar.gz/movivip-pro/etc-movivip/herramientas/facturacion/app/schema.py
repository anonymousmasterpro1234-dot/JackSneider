"""Esquema de base de datos - MoviVIP Billing.

Multitenancy: todo cuelga de `branding_id` (cada proveedor es una marca).
Un unico SQLite, en disco, con WAL. Escala de sobra para este caso.
"""

SCHEMA_VERSION = 1

DDL = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

-- ============================================================ MARCA
CREATE TABLE IF NOT EXISTS branding (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    slug               TEXT NOT NULL UNIQUE,
    name               TEXT NOT NULL,
    legal_name         TEXT,
    tax_id             TEXT,              -- RUC / NIT / etc
    tax_rate           REAL NOT NULL DEFAULT 0,   -- 0.18 = IGV Peru
    currency           TEXT NOT NULL DEFAULT 'PEN',

    -- identidade visual
    logo_path          TEXT,
    logo_mime          TEXT,
    primary_color      TEXT NOT NULL DEFAULT '#FFD700',
    accent_color       TEXT NOT NULL DEFAULT '#29b6f6',
    email_title        TEXT NOT NULL DEFAULT 'PREMIUM',

    -- contacto / enlaces (todo editable)
    contact_email      TEXT,
    support_handle     TEXT,
    phone              TEXT,
    whatsapp           TEXT,
    website            TEXT,
    address            TEXT,
    telegram_channel   TEXT,
    telegram_group     TEXT,

    -- plantillas editables (Jinja2)
    footer_html        TEXT,
    signature_html     TEXT,

    -- avisos de vencimiento
    warn_days          TEXT NOT NULL DEFAULT '7,3,1',
    notify_expired     INTEGER NOT NULL DEFAULT 1,

    created_at         TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at         TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============================================================ CORREO
CREATE TABLE IF NOT EXISTS mail_config (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    branding_id        INTEGER NOT NULL UNIQUE REFERENCES branding(id) ON DELETE CASCADE,
    provider           TEXT NOT NULL DEFAULT 'gmail_api',   -- gmail_api | smtp
    gmail_client_id    TEXT,          -- cifrado
    gmail_client_secret TEXT,         -- cifrado
    gmail_refresh_token TEXT,         -- cifrado
    gmail_send_as      TEXT,
    smtp_host          TEXT,
    smtp_port          INTEGER DEFAULT 587,
    smtp_user          TEXT,
    smtp_pass          TEXT,          -- cifrado
    smtp_secure        INTEGER NOT NULL DEFAULT 1,
    sender_email       TEXT,
    sender_name        TEXT,
    verified_at        TEXT,
    last_error         TEXT,
    created_at         TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at         TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============================================================ OPERADORES / PLANES
CREATE TABLE IF NOT EXISTS operators (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    branding_id        INTEGER NOT NULL REFERENCES branding(id) ON DELETE CASCADE,
    name               TEXT NOT NULL,
    description        TEXT,
    default_price      REAL,
    default_period     TEXT,
    is_active          INTEGER NOT NULL DEFAULT 1,
    sort_order         INTEGER NOT NULL DEFAULT 0,
    created_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_operators_branding ON operators(branding_id, is_active);

-- ============================================================ USUARIOS
CREATE TABLE IF NOT EXISTS users (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    branding_id        INTEGER NOT NULL REFERENCES branding(id) ON DELETE CASCADE,
    email              TEXT NOT NULL,
    full_name          TEXT NOT NULL,
    phone              TEXT,
    document_id        TEXT,
    password_hash      TEXT,
    role               TEXT NOT NULL DEFAULT 'customer',  -- admin | premium | customer
    is_active          INTEGER NOT NULL DEFAULT 1,
    must_reset         INTEGER NOT NULL DEFAULT 0,
    last_login_at      TEXT,
    created_at         TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
-- el email es unico GLOBAL: un mismo correo no puede ser cliente de dos marcas
CREATE UNIQUE INDEX IF NOT EXISTS ux_users_email ON users(email);
CREATE INDEX IF NOT EXISTS ix_users_branding ON users(branding_id, role);

-- ============================================================ PROVEEDORES
-- Un proveedor = una marca (`branding`) + un administrador + unos valores por
-- defecto de facturacion. Se declara despues de `users` porque su FK lo exige.
-- Esta tabla SIEMPRE se creo a mano en el servidor; aqui queda en el DDL para
-- que una instalacion limpia no reviente en /api/provider/{slug}/config.
CREATE TABLE IF NOT EXISTS providers (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    name               TEXT NOT NULL,
    slug               TEXT NOT NULL UNIQUE,
    license            TEXT NOT NULL DEFAULT 'free',   -- free | premium
    admin_user_id      INTEGER NOT NULL,
    branding_id        INTEGER NOT NULL UNIQUE,
    active             INTEGER NOT NULL DEFAULT 1,
    created_at         TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (branding_id) REFERENCES branding(id),
    FOREIGN KEY (admin_user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_providers_slug  ON providers(slug);
CREATE INDEX IF NOT EXISTS idx_providers_admin ON providers(admin_user_id);

-- Valores por defecto con los que se factura cuando el hook no los impone.
-- Antes vivian hardcodeados en el endpoint (protocolo SSH, precio 50), lo que
-- hacia que el multi-proveedor no significase nada.
CREATE TABLE IF NOT EXISTS provider_settings (
    provider_id        INTEGER PRIMARY KEY REFERENCES providers(id) ON DELETE CASCADE,
    protocol           TEXT NOT NULL DEFAULT 'SSH',
    price              REAL NOT NULL DEFAULT 50.0,
    contact_email      TEXT,
    currency           TEXT NOT NULL DEFAULT 'PEN',
    updated_at         TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============================================================ SERVICIOS VENDIDOS
CREATE TABLE IF NOT EXISTS services (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    branding_id        INTEGER NOT NULL REFERENCES branding(id) ON DELETE CASCADE,
    customer_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    operator_id        INTEGER REFERENCES operators(id) ON DELETE SET NULL,

    -- el administrador puede escribir el operador a mano (lo mas comun)
    operator_label     TEXT NOT NULL,

    -- precio SIEMPRE manual, lo digita el administrador
    price_amount       REAL NOT NULL DEFAULT 0,
    -- numero de dispositivos/entregas incluidas. El precio es el TOTAL.
    quantity           INTEGER NOT NULL DEFAULT 1,
    billing_period     TEXT NOT NULL DEFAULT 'mensual',  -- mensual|trimestral|semestral|anual|unico
    delivery_mode      TEXT NOT NULL DEFAULT 'invoice',  -- invoice | account | both

    -- datos del servidor / entrega
    server_ip          TEXT,
    server_hostname    TEXT,
    server_specs       TEXT,        -- JSON libre: cpu, ram, disco, puertos...
    account_username   TEXT,
    account_password   TEXT,        -- cifrado
    account_notes      TEXT,

    start_at           TEXT NOT NULL,
    expires_at         TEXT,
    auto_renew         INTEGER NOT NULL DEFAULT 0,
    status             TEXT NOT NULL DEFAULT 'active',   -- active|suspended|expired|cancelled

    created_at         TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_services_customer  ON services(customer_id);
CREATE INDEX IF NOT EXISTS ix_services_expiry    ON services(status, expires_at);
CREATE INDEX IF NOT EXISTS ix_services_branding  ON services(branding_id, status);
CREATE INDEX IF NOT EXISTS ix_services_user      ON services(account_username);

-- ============================================================ REGISTRO DE CONTACTOS
-- Tabla central del sistema. Es lo que hace que la facturacion funcione en
-- TODOS los protocolos y no solo en SSH.
--
-- Se escribe en el momento del ALTA (hook en add.sh / zipvpn.sh / etc.) y se
-- LEE en la reanimacion (reactivar.sh) para no volver a pedir el correo.
--
-- account_user = login del sistema ("juan" en SSH, el id en ZIPVPN, el email
-- del cliente en x-ui de Xray). No es una FK a users: existe aunque el cliente
-- todavia no tenga ficha ni factura.
CREATE TABLE IF NOT EXISTS contactos (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    branding_id      INTEGER NOT NULL REFERENCES branding(id) ON DELETE CASCADE,
    account_user     TEXT NOT NULL,        -- login/protocolo id
    protocol         TEXT NOT NULL DEFAULT 'ssh',   -- ssh|zipvpn|xray|hcr|...
    email            TEXT,
    full_name        TEXT,
    phone            TEXT,
    customer_id      INTEGER REFERENCES users(id) ON DELETE SET NULL,
    last_service_id  INTEGER REFERENCES services(id) ON DELETE SET NULL,
    notes            TEXT,
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
-- un contacto por (usuario, protocolo): re-alta actualiza en vez de duplicar
CREATE UNIQUE INDEX IF NOT EXISTS ux_contactos_user_proto
    ON contactos(branding_id, account_user, protocol);
CREATE INDEX IF NOT EXISTS ix_contactos_email ON contactos(email);
CREATE INDEX IF NOT EXISTS ix_contactos_user  ON contactos(account_user);

-- ============================================================ FACTURAS
CREATE TABLE IF NOT EXISTS invoices (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    branding_id        INTEGER NOT NULL REFERENCES branding(id) ON DELETE CASCADE,
    service_id         INTEGER REFERENCES services(id) ON DELETE SET NULL,
    number             TEXT NOT NULL,             -- F-2026-0001
    seq                INTEGER NOT NULL,
    year               INTEGER NOT NULL,

    customer_id        INTEGER REFERENCES users(id) ON DELETE SET NULL,
    customer_name      TEXT NOT NULL,
    customer_email     TEXT NOT NULL,
    customer_tax_id    TEXT,

    operator_label     TEXT NOT NULL,
    description        TEXT,

    subtotal           REAL NOT NULL DEFAULT 0,
    tax_rate           REAL NOT NULL DEFAULT 0,
    tax_amount         REAL NOT NULL DEFAULT 0,
    total              REAL NOT NULL DEFAULT 0,
    currency           TEXT NOT NULL DEFAULT 'PEN',

    period_start       TEXT,
    period_end         TEXT,
    issued_at          TEXT NOT NULL DEFAULT (datetime('now')),
    due_at             TEXT,
    paid_at            TEXT,
    status             TEXT NOT NULL DEFAULT 'pending',  -- pending|paid|void|overdue

    pdf_path           TEXT,
    notes              TEXT,
    created_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_invoices_number ON invoices(branding_id, number);
CREATE INDEX IF NOT EXISTS ix_invoices_customer ON invoices(customer_id, status);
CREATE INDEX IF NOT EXISTS ix_invoices_status   ON invoices(branding_id, status);

-- ============================================================ COLA DE CORREOS
CREATE TABLE IF NOT EXISTS emails (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    branding_id        INTEGER NOT NULL REFERENCES branding(id) ON DELETE CASCADE,
    customer_id        INTEGER REFERENCES users(id) ON DELETE SET NULL,
    service_id         INTEGER REFERENCES services(id) ON DELETE SET NULL,
    invoice_id         INTEGER REFERENCES invoices(id) ON DELETE SET NULL,
    kind               TEXT NOT NULL,   -- account_created|invoice|expiry_warning|expired|manual
    to_email           TEXT NOT NULL,
    to_name            TEXT,
    subject            TEXT NOT NULL,
    body_html          TEXT NOT NULL,
    status             TEXT NOT NULL DEFAULT 'queued',  -- queued|sending|sent|failed
    attempts           INTEGER NOT NULL DEFAULT 0,
    last_error         TEXT,
    provider_msg_id    TEXT,
    queued_at          TEXT NOT NULL DEFAULT (datetime('now')),
    sent_at            TEXT,
    created_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_emails_status ON emails(status, queued_at);
CREATE INDEX IF NOT EXISTS ix_emails_kind   ON emails(branding_id, kind, created_at);

-- ============================================================ CONTROL DE AVISOS
-- la clave UNIQUE evita enviar dos veces el mismo aviso
CREATE TABLE IF NOT EXISTS expiry_notices (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    service_id         INTEGER NOT NULL REFERENCES services(id) ON DELETE CASCADE,
    kind               TEXT NOT NULL,       -- warn|expired
    days_left          INTEGER NOT NULL,
    email_id           INTEGER REFERENCES emails(id) ON DELETE SET NULL,
    sent_at            TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(service_id, kind, days_left)
);

-- ============================================================ AUDITORIA
CREATE TABLE IF NOT EXISTS audit (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id            INTEGER REFERENCES users(id) ON DELETE SET NULL,
    action             TEXT NOT NULL,
    entity             TEXT,
    entity_id          INTEGER,
    detail             TEXT,
    ip                 TEXT,
    created_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_audit_created ON audit(created_at);

-- ============================================================ SESIONES
CREATE TABLE IF NOT EXISTS sessions (
    token              TEXT PRIMARY KEY,
    user_id            INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at         TEXT NOT NULL DEFAULT (datetime('now')),
    expires_at         TEXT NOT NULL
);
"""
