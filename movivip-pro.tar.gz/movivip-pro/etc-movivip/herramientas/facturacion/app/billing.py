"""Facturacion: numeracion por marca/ano y generacion de PDF.

Numeracion atomica: se calcula el siguiente `seq` dentro de la misma
transaccion que inserta la fila, con reintento ante colision. El indice UNIQUE
(branding_id, number) es la red de seguridad.
"""
from __future__ import annotations

import io
import re
import sqlite3
import sys
import time
from datetime import datetime, timezone
from typing import Any

# Formatos de importe que acepta parse_precio(). El orden importa: primero los
# de miles (grupo de EXACTOS 3 digitos), despues los decimales de 1-2 digitos.
# "15.000" solo puede ser miles, "15.50" solo puede ser decimal.
_P_THOUSANDS_DOT = re.compile(r"^\d{1,3}(\.\d{3})+(,\d{1,2})?$")
_P_THOUSANDS_COMMA = re.compile(r"^\d{1,3}(,\d{3})+(\.\d{1,2})?$")
_P_DECIMAL_COMMA = re.compile(r"^\d+,\d{1,2}$")
_P_DECIMAL_DOT = re.compile(r"^\d+\.\d{1,2}$")
_P_INT = re.compile(r"^\d+$")

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from .config import settings
from .db import db, q1, scalar
from .security import money, parse_dt

PERIOD_LABELS = {
    "mensual": "Mensual",
    "bimestral": "Bimestral",
    "trimestral": "Trimestral",
    "semestral": "Semestral",
    "anual": "Anual",
    "unico": "Pago unico",
}

PERIOD_MONTHS = {
    "mensual": 1,
    "bimestral": 2,
    "trimestral": 3,
    "semestral": 6,
    "anual": 12,
    "unico": 1,
}


def period_label(p: str) -> str:
    return PERIOD_LABELS.get(p or "mensual", p or "Mensual")


def period_end_from(start: str, period: str) -> str | None:
    start_dt = parse_dt(start)
    if not start_dt or period == "unico":
        return None
    months = PERIOD_MONTHS.get(period, 1)
    year = start_dt.year + (start_dt.month - 1 + months) // 12
    month = (start_dt.month - 1 + months) % 12 + 1
    try:
        end = start_dt.replace(year=year, month=month, day=1)
    except ValueError:
        end = start_dt.replace(year=year, month=month, day=28)
    return end.strftime("%Y-%m-%d")


def next_number_in(conn, branding_id: int, prefix: str = "F", year: int | None = None) -> tuple[str, int]:
    """Reserva el siguiente numero DENTRO de la transaccion abierta por el
    llamante.

    Es la unica variante segura: leer el MAX(seq) y el INSERT deben ocurrir en la
    misma transaccion (y con `BEGIN IMMEDIATE`, ver `db.db`). `next_number()`
    se mantiene por compatibilidad, pero no es atomico.
    """
    year = year or datetime.now(timezone.utc).year
    row = conn.execute(
        "SELECT COALESCE(MAX(seq),0) FROM invoices WHERE branding_id=? AND year=?",
        (branding_id, year),
    ).fetchone()
    seq = int(row[0] or 0) + 1
    return f"{prefix}-{year}-{seq:04d}", seq


def next_number(branding_id: int, prefix: str = "F", year: int | None = None) -> tuple[str, int]:
    """Devuelve (numero, seq) SIN reservar. Deprecated: usar `next_number_in`."""
    year = year or datetime.now(timezone.utc).year
    return next_number_in(_ReadConn(branding_id), branding_id, prefix, year)


class _ReadConn:
    """Adaptador minimo para poder llamar a `next_number_in` con una conexion
    ya abierta por el llamante."""

    def __init__(self, branding_id: int) -> None:
        self._bid = branding_id
        self._c = sqlite3.connect(settings.db_path, timeout=30)
        self._c.row_factory = sqlite3.Row

    def execute(self, sql: str, params: tuple = ()):
        return self._c.execute(sql, params)

    def close(self) -> None:
        self._c.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def parse_precio(raw: Any) -> float:
    """Normaliza un importe escrito a mano a float.

    Es el gemelo de mv_normaliza_precio() en lib/facturacion.sh. Las reglas
    tienen que ser las mismas en los dos lados o la factura mostrada y la
    guardada no cuadran.

    Por que existe: en Peru el administrador escribe "15.000" queriendo decir
    quince mil. Sin esto, float("15.000") es 15.0 y la factura salia con
    S/ 15.00: un factor de mil perdido, y en silencio.

    Reglas, en orden y sin adivinar:
        15000      -> 15000.0    entero
        15.000     -> 15000.0    punto de miles (grupo de EXACTOS 3 digitos)
        15,000     -> 15000.0    coma de miles
        1.500,50   -> 1500.5     miles + coma decimal
        1,500.50   -> 1500.5     miles + punto decimal
        15.50      -> 15.5       punto decimal (1-2 digitos)
        15,50      -> 15.5       coma decimal (1-2 digitos)

    "15.50" no se confunde con "15.000" porque el grupo de miles exige tres
    digitos y el decimal admite dos como mucho. Lo que no encaja en ninguna
    regla se rechaza con ValueError en vez de interpretado a medias.
    """
    if isinstance(raw, (int, float)) and not isinstance(raw, bool):
        v = float(raw)
        if v < 0:
            raise ValueError("el precio no puede ser negativo")
        return round(v, 2)

    p = re.sub(r"\s+", "", str(raw or ""))
    if not p:
        raise ValueError("falta el precio")

    m = _P_THOUSANDS_DOT.match(p)          # 1.500 / 1.500,50
    if m:
        entero, resto = p.split(".", 1)
        resto = resto.replace(".", "").replace(",", ".")
        return round(float(entero + resto), 2)

    m = _P_THOUSANDS_COMMA.match(p)        # 1,500 / 1,500.50
    if m:
        entero, resto = p.split(",", 1)
        resto = resto.replace(",", "")
        return round(float(entero + resto), 2)

    m = _P_DECIMAL_COMMA.match(p)          # 15,50
    if m:
        return round(float(p.replace(",", ".")), 2)

    m = _P_DECIMAL_DOT.match(p)            # 15.50
    if m:
        return round(float(p), 2)

    if _P_INT.match(p):                    # 15000
        return round(float(p), 2)

    raise ValueError(
        f"precio no valido: {raw!r}. Use 15000, 15.000, 15,50 o 15.50"
    )


# --- estado de la factura ---------------------------------------------------
# Antes el INSERT fijaba 'pending' a pelo: la columna status y la paid_at
# existian en el esquema pero NADA las escribia nunca, asi que toda factura
# salia "Estado: PENDING" en el PDF aunque el dinero ya estuviera cobrado.
#
# REGLA: se factura en el momento en que se cobra. El alta y el cobro
# registro ya tienen el dinero dentro, asi que la factura nace PAGADA.
# Reactivar y renovar se emiten por adelantado, asi que nacen PENDIENTES y
# el operador las marca con la rama [8] cuando entra el pago.
#
# mv_estado_invoice en lib/facturacion.sh aplica EXACTAMENTE la misma regla;
# las dos copias deben decidir igual o el PDF y el correo se contradicen.
ESTADOS_INVOICE = ("pending", "paid", "void", "overdue")
ACCIONES_PAGADAS = ("alta", "cobro")


def estado_invoice(estado=None, accion=None) -> tuple[str, str | None]:
    """Devuelve (status, paid_at) para la factura a insertar.

    - estado explicito manda, si es valido.
    - si no, se deduce de la accion: alta/cobro -> paid, resto -> pending.
    - paid_at se rellena solo (hoy) cuando el estado es paid; para pending se
      deja NULL, que es lo que significa "sin pagar todavia".
    """
    est = str(estado or "").strip().lower()
    if est not in ESTADOS_INVOICE:
        act = str(accion or "").strip().lower()
        est = "paid" if act in ACCIONES_PAGADAS else "pending"
    if est == "paid":
        return "paid", datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")
    return est, None


def totals(subtotal: float, tax_rate: float) -> tuple[float, float, float]:
    tax = round(subtotal * float(tax_rate or 0), 2)
    return round(subtotal, 2), tax, round(subtotal + tax, 2)


# ------------------------------------------------------------------ PDF
def _hex(c: str | None, fallback: str) -> colors.Color:
    v = (c or fallback).strip()
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", v):
        v = fallback
    return colors.HexColor(v)


def render_invoice_pdf(inv: dict, brand: dict) -> bytes:
    """Genera el PDF de la factura. Devuelve bytes."""
    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=16 * mm, rightMargin=16 * mm, topMargin=14 * mm, bottomMargin=16 * mm,
        title=f"Factura {inv['number']}", author=brand.get("name") or "MoviVIP",
    )

    primary = _hex(brand.get("primary_color"), "#FFD700")
    accent = _hex(brand.get("accent_color"), "#29b6f6")
    ink = colors.HexColor("#1A1A1A")
    muted = colors.HexColor("#6B7280")

    ss = getSampleStyleSheet()
    s_h1 = ParagraphStyle("h1", parent=ss["Normal"], fontName="Helvetica-Bold", fontSize=19,
                          textColor=primary, leading=23, spaceAfter=0)
    s_brand = ParagraphStyle("brand", parent=ss["Normal"], fontName="Helvetica-Bold", fontSize=13,
                             textColor=ink, leading=16)
    s_small = ParagraphStyle("small", parent=ss["Normal"], fontName="Helvetica", fontSize=8, textColor=muted, leading=11)
    s_label = ParagraphStyle("label", parent=ss["Normal"], fontName="Helvetica-Bold", fontSize=8,
                             textColor=accent, leading=10)
    s_val = ParagraphStyle("val", parent=ss["Normal"], fontName="Helvetica", fontSize=10, textColor=ink, leading=14)
    s_num = ParagraphStyle("num", parent=ss["Normal"], fontName="Helvetica-Bold", fontSize=15, textColor=ink, leading=19)
    s_cell = ParagraphStyle("cell", parent=ss["Normal"], fontName="Helvetica", fontSize=9.5, textColor=ink, leading=13)
    s_cellr = ParagraphStyle("cellr", parent=s_cell, alignment=TA_RIGHT)
    s_tot = ParagraphStyle("tot", parent=ss["Normal"], fontName="Helvetica-Bold", fontSize=12,
                           textColor=ink, alignment=TA_RIGHT, leading=16)

    story = []

    # ---- cabecera: logo + datos del emisor + numero
    logo_cell = ""
    if brand.get("logo_path"):
        p = (settings.upload_dir / brand["logo_path"]).resolve()
        if not p.is_file():
            # sin esto el logo se perdia en silencio y la factura salia sin cabecera
            print(f"[facturacion] logo configurado pero ausente en disco: {p}", file=sys.stderr, flush=True)
        else:
            try:
                iw, ih = ImageReader(str(p)).getSize()
                w = 30 * mm
                h = w * ih / iw
                if h > 26 * mm:
                    h = 26 * mm
                    w = h * iw / ih
                logo_cell = Image(str(p), width=w, height=h)
            except Exception as exc:  # noqa: BLE001 - un logo roto no debe tumbar la factura
                print(f"[facturacion] logo ilegible, se omite: {p} ({exc!r})", file=sys.stderr, flush=True)
                logo_cell = ""

    emisor = [Paragraph(brand.get("name") or "JackSneider", s_brand)]
    for line in (brand.get("legal_name"), brand.get("tax_id")):
        if line:
            emisor.append(Paragraph(line, s_small))
    for line in (brand.get("address"), brand.get("website"), brand.get("contact_email"),
                 brand.get("phone"), brand.get("whatsapp")):
        if line:
            emisor.append(Paragraph(line, s_small))

    head = Table(
        [[logo_cell or "", emisor, Paragraph(
            f'<font color="#{accent.hexval()[2:]}"><b>FACTURA</b></font><br/>'
            f'<font size="15"><b>{inv["number"]}</b></font><br/>'
            f'<font size="8" color="#6B7280">Emitida {inv.get("issued_at","")[:10]}</font>', s_val)]],
        colWidths=[34 * mm, 78 * mm, 48 * mm],
    )
    head.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LINEBELOW", (0, 0), (-1, -1), 1.2, primary),
    ]))
    story += [head, Spacer(1, 8 * mm)]

    # ---- cliente
    cliente = [
        [Paragraph("CLIENTE", s_label), Paragraph("DATOS DE LA FACTURA", s_label)],
        [Paragraph(f'<b>{inv.get("customer_name","-")}</b><br/>{inv.get("customer_email","")}'
                   + (f'<br/>{inv["customer_tax_id"]}' if inv.get("customer_tax_id") else ""), s_val),
         Paragraph(f'<b>Operador:</b> {inv.get("operator_label","-")}<br/>'
                   f'<b>Periodo:</b> {period_label(inv.get("billing_period") or "mensual")}<br/>'
                   f'<b>Moneda:</b> {inv.get("currency") or "PEN"}<br/>'
                   f'<b>Estado:</b> {(inv.get("status") or "pending").upper()}', s_val)],
    ]
    t_cli = Table(cliente, colWidths=[80 * mm, 80 * mm])
    t_cli.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#F4F6F8")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#D5DBE1")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D5DBE1")),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story += [t_cli, Spacer(1, 6 * mm)]

    # --- detalle (paginacion automatica: si son muchas filas, la tabla repite cabecera)
    desc = inv.get("description") or f"Servicio {inv.get('operator_label','')} - {period_label(inv.get('billing_period') or 'mensual')}"
    filas = [[
        Paragraph("CONCEPTO", s_label), Paragraph("PERIODO", s_label),
        Paragraph("IMPORTE", s_label),
    ]]
    periodo_txt = "-"
    if inv.get("period_start"):
        fin = inv.get("period_end") or ""
        periodo_txt = inv["period_start"][:10] + (f" &rarr; {fin[:10]}" if fin else "")
    filas.append([
        Paragraph(desc, s_cell), Paragraph(periodo_txt, s_cell),
        Paragraph(money(float(inv.get("subtotal") or 0), inv.get("currency") or "PEN"), s_cellr),
    ])

    t_det = Table(filas, colWidths=[86 * mm, 46 * mm, 28 * mm], repeatRows=1)
    t_det.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BACKGROUND", (0, 0), (-1, 0), primary),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#D5DBE1")),
        ("LINEBELOW", (0, 0), (-1, 0), 0.8, colors.white),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story += [t_det, Spacer(1, 4 * mm)]

    # --- totales
    cur = inv.get("currency") or "PEN"
    tot = [
        [Paragraph("Subtotal", s_val), Paragraph(money(float(inv.get("subtotal") or 0), cur), s_cellr)],
    ]
    if float(inv.get("tax_amount") or 0) > 0:
        tot.append([Paragraph(f"IGV ({float(inv.get('tax_rate') or 0) * 100:.0f}%)", s_val),
                    Paragraph(money(float(inv["tax_amount"]), cur), s_cellr)])
    tot.append([Paragraph("<b>TOTAL</b>", s_tot), Paragraph(money(float(inv.get("total") or 0), cur), s_tot)])

    t_tot = Table(tot, colWidths=[120 * mm, 40 * mm], hAlign="RIGHT")
    t_tot.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("LINEABOVE", (0, -1), (-1, -1), 1.2, primary),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    story += [t_tot]

    if inv.get("notes"):
        story += [Spacer(1, 5 * mm), Paragraph(f"<b>Notas:</b> {inv['notes']}", s_small)]

    # --- pie: soporte + firma
    foot = []
    for label, value in (("Soporte", brand.get("support_handle")), ("Telegram", brand.get("telegram_channel")),
                         ("Web", brand.get("website")), ("Correo", brand.get("contact_email"))):
        if value:
            foot.append(f"{label}: {value}")
    if brand.get("footer_html"):
        foot.append(brand["footer_html"])
    if foot:
        story += [Spacer(1, 10 * mm), Paragraph("<br/>".join(foot), s_small)]

    doc.build(story)
    return buf.getvalue()


def store_pdf(invoice_id: int, inv: dict, brand: dict) -> str | None:
    """Genera y guarda el PDF. Devuelve la ruta relativa o None."""
    pdf = render_invoice_pdf(inv, brand)
    rel = f"branding/{brand['id']}/invoices/{inv['number']}.pdf"
    dest = settings.upload_dir / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(pdf)
    with db() as c:
        c.execute("UPDATE invoices SET pdf_path=? WHERE id=?", (rel, invoice_id))
    return rel
