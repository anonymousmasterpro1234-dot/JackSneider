"""Registro central de contactos — el corazon de la facturacion multi-protocolo.

Por que existe
--------------
El alta de una cuenta vive en scripts distintos segun el protocolo
(`usuarios/add.sh` para SSH, `usuarios/zipvpn.sh`, el panel x-ui para Xray,
etc.). Ninguno de esos scripts sabe de facturacion.

Este modulo es el punto unico de encuentro:

  * `registrar()`  lo llama el hook del ALTA. Guarda el correo associated al
    login del sistema, para cualquier protocolo. Es barato y no envia nada.
  * `buscar()`      lo llama la REANIMACION. Recupera el correo ya guardado
    para no volver a pedirlo.
  * `enlazar()`     engancha un contacto con la ficha de cliente y el servicio
    cuando mas tarde se emite la factura.

Regla de oro: fallar aqui NUNCA debe romper un alta de cuenta. Por eso
`registrar()` es una operacion de un solo INSERT/UPSERT, sin correo ni PDF.
"""
from __future__ import annotations

import re
import sqlite3
from typing import Any

from . import db

# Protocols conocidos. "otro" esta permitido: el hook no debe fallar porque
# aparezca un protocolo nuevo.
PROTOCOLOS = ("ssh", "zipvpn", "xray", "v2ray", "hcr", "socks5", "otro")

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$")


class EmailInvalido(ValueError):
    pass


def validar_email(email: str) -> str:
    e = (email or "").strip().lower()
    if not _EMAIL_RE.match(e):
        raise EmailInvalido(f"correo no valido: {email!r}")
    return e


def _brand_id(branding_id: int | None) -> int:
    if branding_id:
        return int(branding_id)
    from .branding import ensure_default_brand
    return int(ensure_default_brand()["id"])


# ------------------------------------------------------------------ escritura
def registrar(
    account_user: str,
    protocol: str = "ssh",
    email: str | None = None,
    full_name: str | None = None,
    phone: str | None = None,
    notes: str | None = None,
    branding_id: int | None = None,
) -> dict | None:
    """Registra o actualiza el contacto de (usuario, protocolo).

    Devuelve la fila resultante, o None si `account_user` viene vacio.
    Nunca lanza por datos incompletos: si no hay correo, se guarda igual el
    resto (el alta no debe romperse por un campo opcional).
    """
    user = (account_user or "").strip()
    if not user:
        return None

    bid = _brand_id(branding_id)
    mail = (email or "").strip().lower() or None
    if mail:
        mail = validar_email(mail)          # correo basura -> exception clara
    proto = (protocol or "ssh").strip().lower() or "ssh"

    with db.db() as c:
        c.execute(
            """
            INSERT INTO contactos
                (branding_id, account_user, protocol, email, full_name, phone, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(branding_id, account_user, protocol) DO UPDATE SET
                email     = COALESCE(excluded.email, contactos.email),
                full_name = COALESCE(excluded.full_name, contactos.full_name),
                phone     = COALESCE(excluded.phone, contactos.phone),
                notes     = COALESCE(excluded.notes, contactos.notes),
                updated_at = datetime('now')
            """,
            (bid, user, proto, mail, (full_name or None), (phone or None), (notes or None)),
        )
        row = c.execute(
            "SELECT * FROM contactos WHERE branding_id=? AND account_user=? AND protocol=?",
            (bid, user, proto),
        ).fetchone()
    return dict(row) if row else None


def enlazar(
    account_user: str,
    protocol: str = "ssh",
    customer_id: int | None = None,
    service_id: int | None = None,
    branding_id: int | None = None,
) -> None:
    """Engancha el contacto con la ficha de cliente y el servicio ya emitidos."""
    user = (account_user or "").strip()
    if not user:
        return
    bid = _brand_id(branding_id)
    proto = (protocol or "ssh").strip().lower() or "ssh"
    with db.db() as c:
        c.execute(
            """
            UPDATE contactos
               SET customer_id     = COALESCE(?, customer_id),
                   last_service_id = COALESCE(?, last_service_id),
                   updated_at      = datetime('now')
             WHERE branding_id=? AND account_user=? AND protocol=?
            """,
            (customer_id, service_id, bid, user, proto),
        )


def borrar(account_user: str, protocol: str = "ssh", branding_id: int | None = None) -> int:
    bid = _brand_id(branding_id)
    proto = (protocol or "ssh").strip().lower() or "ssh"
    with db.db() as c:
        cur = c.execute(
            "DELETE FROM contactos WHERE branding_id=? AND account_user=? AND protocol=?",
            (bid, (account_user or "").strip(), proto),
        )
        return int(cur.rowcount or 0)


# -------------------------------------------------------------------- lectura
def buscar(
    account_user: str,
    protocol: str | None = None,
    branding_id: int | None = None,
) -> dict | None:
    """Devuelve el contacto de un usuario.

    Sin `protocolo` busca en todos y devuelve el mas reciente, de modo que la
    reanimacion funcione aunque el alta se hiciera por otro protocolo.
    """
    user = (account_user or "").strip()
    if not user:
        return None
    bid = _brand_id(branding_id)
    if protocol:
        r = db.q1(
            "SELECT * FROM contactos WHERE branding_id=? AND account_user=? AND protocol=?",
            (bid, user, protocol.strip().lower()),
        )
        return dict(r) if r else None
    r = db.q1(
        """SELECT * FROM contactos
            WHERE branding_id=? AND account_user=?
            ORDER BY (email IS NOT NULL) DESC, updated_at DESC
            LIMIT 1""",
        (bid, user),
    )
    return dict(r) if r else None


def listar(
    protocolo: str | None = None, solo_con_email: bool = False, branding_id: int | None = None
) -> list[dict]:
    bid = _brand_id(branding_id)
    sql = "SELECT * FROM contactos WHERE branding_id=?"
    args: list[Any] = [bid]
    if protocolo:
        sql += " AND protocol=?"
        args.append(protocolo.strip().lower())
    if solo_con_email:
        sql += " AND email IS NOT NULL"
    sql += " ORDER BY updated_at DESC"
    return [dict(r) for r in db.q(sql, args)]


def sin_correo(branding_id: int | None = None) -> list[dict]:
    """Cuentas creadas sin correo: candidatas a facturacion manual.

    Ojo al filtro: `listar(solo_con_email=True)` devuelve las que SI tienen
    correo, que es justo lo contrario de lo que se pide aqui.
    """
    return [r for r in listar(branding_id=branding_id) if not r.get("email")]


def tiene_correo(account_user: str, protocol: str | None = None, branding_id: int | None = None) -> bool:
    c = buscar(account_user, protocol, branding_id)
    return bool(c and c.get("email"))
