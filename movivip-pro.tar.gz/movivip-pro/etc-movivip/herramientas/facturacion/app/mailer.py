"""Envio de correo: Gmail API (OAuth2) o SMTP. Cola en base de datos.

Decision: NO uso `google-api-python-client` ni `google-auth`. El refresh token
y el envio son dos llamadas REST simples, asi que `requests` basta. Ahorra
~40 MB de dependencias en un servidor con 921 MB de RAM.

Flujo:
  render -> encolar (emails.status='queued') -> procesar cola -> sent/failed
Las alertas de vencimiento usan la misma cola, asi que si Gmail falla se
reintentan sin duplicar el aviso al cliente.
"""
from __future__ import annotations

import base64
import email.utils
import smtplib
import ssl
from email.message import EmailMessage
from email.utils import getaddresses
from mimetypes import guess_type

import requests
from jinja2 import Environment, FileSystemLoader, select_autoescape

from .config import settings
from .db import execute, q, q1, scalar
from .security import dec

TOKEN_URL = "https://oauth2.googleapis.com/token"
GMAIL_SEND_URL = "https://gmail.googleapis.com/gmail/v1/users/me/messages/send"
SCOPE = "https://www.googleapis.com/auth/gmail.send"

_jinja = Environment(
    loader=FileSystemLoader(str(settings.template_dir)),
    autoescape=select_autoescape(["html"]),
    trim_blocks=True,
    lstrip_blocks=True,
)
_jinja_mail = Environment(
    loader=FileSystemLoader(str(settings.template_dir / "mail")),
    autoescape=select_autoescape(["html"]),
    trim_blocks=True,
    lstrip_blocks=True,
)


def render(template: str, ctx: dict) -> str:
    return _jinja.get_template(template).render(**ctx)


def render_mail(template: str, ctx: dict) -> str:
    return _jinja_mail.get_template(template).render(**ctx)


# --------------------------------------------------------------- plantillas MIME
LOGO_CID = "movivip-logo"


def build_mime(
    to_email: str,
    to_name: str | None,
    subject: str,
    html: str,
    sender_email: str,
    sender_name: str,
    attachments: list[tuple[str, bytes, str]] | None = None,
    inline: list[tuple[str, bytes, str]] | None = None,
) -> bytes:
    """Arma el correo.

    `inline` son imagenes embebidas como (cid, contenido, mime). Van dentro de
    un multipart/related, que es lo que usan Gmail, Outlook y los clientes
    moviles para pintar <img src="cid:...">. Asi el logo se ve SIEMPRE, sin
    depender de que el servidor tenga una URL publica abierta.
    """
    msg = EmailMessage()
    msg["From"] = email.utils.formataddr((sender_name, sender_email))
    msg["To"] = email.utils.formataddr((to_name or "", to_email))
    msg["Subject"] = subject
    msg["Date"] = email.utils.formatdate(localtime=True)
    msg["Message-ID"] = email.utils.make_msgid()
    msg.set_content("Este mensaje requiere un cliente compatible con HTML.")
    msg.add_alternative(html, subtype="html")

    if inline:
        # add_alternative deja la parte HTML en get_payload()[1]; al adjuntarle
        # imagenes con add_related, esa parte pasa a ser multipart/related.
        html_part = msg.get_payload()[1]
        for cid, data, mimetype in inline:
            maintype, _, subtype = (mimetype or "image/png").partition("/")
            html_part.add_related(
                data, maintype=maintype, subtype=subtype or "png",
                cid=f"<{cid}>", filename=f"{cid}{'.' + subtype}",
                disposition="inline",
            )

    for filename, data, mimetype in attachments or []:
        maintype, _, subtype = (mimetype or "application/octet-stream").partition("/")
        msg.add_attachment(data, maintype=maintype, subtype=subtype or "octet-stream", filename=filename)
    return msg.as_bytes()


def resolve_logo_html(html: str, brand: dict) -> tuple[str, list[tuple[str, bytes, str]]]:
    """Sustituye cid:movivip-logo por el logo real, o por su URL si no hay.

    El HTML se guarda en la cola con la referencia `cid:`. Si en el momento del
    envio el logo ya no existe, se cambia por la URL publica para no dejar una
    imagen rota; y si tampoco hay URL, se deja vacio.
    """
    if f"cid:{LOGO_CID}" not in html:
        return html, []

    from . import branding

    got = branding.logo_bytes(brand)
    if got:
        return html, [(LOGO_CID, got[0], got[1])]

    rel = (brand or {}).get("logo_path") or ""
    if rel.startswith("http"):
        return html.replace(f"cid:{LOGO_CID}", rel), []
    if rel:
        url = f"{settings.public_url.rstrip('/')}/uploads/{rel.lstrip('/')}"
        return html.replace(f"cid:{LOGO_CID}", url), []
    return html.replace(f"cid:{LOGO_CID}",
                        "data:image/gif;base64,R0lGODlhAQABAAAAACw=",), []


# --------------------------------------------------------------- Gmail API
def _gmail_access_token(cfg: dict) -> str:
    """Canjea el refresh token por un access token. ~1 llamada."""
    client_id = dec(cfg.get("gmail_client_id"))
    client_secret = dec(cfg.get("gmail_client_secret"))
    refresh_token = dec(cfg.get("gmail_refresh_token"))
    if not all((client_id, client_secret, refresh_token)):
        raise RuntimeError("Gmail API: faltan client_id / client_secret / refresh_token")

    r = requests.post(
        TOKEN_URL,
        data={
            "client_id": client_id,
            "client_secret": client_secret,
            "refresh_token": refresh_token,
            "grant_type": "refresh_token",
        },
        timeout=30,
    )
    if r.status_code != 200:
        raise RuntimeError(f"Gmail token {r.status_code}: {r.text[:300]}")
    return r.json()["access_token"]


def _send_gmail(cfg: dict, raw: bytes) -> str:
    token = _gmail_access_token(cfg)
    payload = {"raw": base64.urlsafe_b64encode(raw).decode()}
    send_as = (cfg.get("gmail_send_as") or "").strip()
    url = f"{GMAIL_SEND_URL}?sendAs={send_as}" if send_as else GMAIL_SEND_URL

    r = requests.post(
        url,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json=payload,
        timeout=60,
    )
    if r.status_code not in (200, 202):
        raise RuntimeError(f"Gmail send {r.status_code}: {r.text[:300]}")
    try:
        return r.json().get("id", "")
    except ValueError:
        return ""


def _send_smtp(cfg: dict, raw: bytes) -> str:
    host = cfg.get("smtp_host")
    user = cfg.get("smtp_user")
    password = dec(cfg.get("smtp_pass"))
    if not (host and user and password):
        raise RuntimeError("SMTP: faltan host / usuario / contrase\u00f1a")
    port = int(cfg.get("smtp_port") or 587)
    secure = int(cfg.get("smtp_secure") or 1)
    # Extraer destinatarios de las cabeceras To/Cc/Bcc del mensaje crudo
    msg = email.message_from_bytes(raw)
    header_values = []
    for h in ("To", "Cc", "Bcc"):
        val = msg.get(h)
        if val:
            header_values.append(val)
    recipients = [addr for _, addr in getaddresses(header_values) if addr]

    if secure and port == 465:
        ctx = ssl.create_default_context()
        with smtplib.SMTP_SSL(host, port, timeout=30, context=ctx) as s:
            s.login(user, password)
            refused = s.sendmail(user, recipients, raw)
    else:
        with smtplib.SMTP(host, port, timeout=30) as s:
            s.ehlo()
            if not (port == 465 and secure):
                s.starttls(context=ssl.create_default_context())
                s.ehlo()
            s.login(user, password)
            refused = s.sendmail(user, recipients, raw)

    if refused:
        raise RuntimeError(f"SMTP rechazo destinatarios: {refused}")
    return ""


# --------------------------------------------------------------- API publica
def mail_config(branding_id: int) -> dict | None:
    row = q1("SELECT * FROM mail_config WHERE branding_id=?", (branding_id,))
    return dict(row) if row else None


def enqueue(
    branding_id: int,
    kind: str,
    to_email: str,
    subject: str,
    body_html: str,
    to_name: str | None = None,
    customer_id: int | None = None,
    service_id: int | None = None,
    invoice_id: int | None = None,
) -> int:
    return execute(
        """INSERT INTO emails
           (branding_id, customer_id, service_id, invoice_id, kind,
            to_email, to_name, subject, body_html, status)
           VALUES (?,?,?,?,?,?,?,?,?, 'queued')""",
        (branding_id, customer_id, service_id, invoice_id, kind,
         to_email, to_name, subject, body_html),
    ).lastrowid


def send_now(email_id: int, attachments: list[tuple[str, bytes, str]] | None = None) -> bool:
    """Envia un correo de la cola. True si sale, False si falla (deja el error)."""
    row = q1("SELECT * FROM emails WHERE id=?", (email_id,))
    if row is None:
        return False
    e = dict(row)
    cfg = mail_config(e["branding_id"])
    if not cfg:
        execute("UPDATE emails SET status='failed', last_error=? WHERE id=?",
                ("Marca sin configuracion de correo", email_id))
        return False

    sender_email = cfg.get("sender_email") or settings.from_email
    sender_name = cfg.get("sender_name") or settings.from_name
    if not sender_email:
        execute("UPDATE emails SET status='failed', last_error=? WHERE id=?",
                ("No hay remitente configurado", email_id))
        return False

    execute("UPDATE emails SET status='sending', attempts=attempts+1 WHERE id=?", (email_id,))
    try:
        from . import branding

        body, inline = resolve_logo_html(e["body_html"], branding.get_brand(e["branding_id"]) or {})
        raw = build_mime(
            e["to_email"], e.get("to_name"), e["subject"], body,
            sender_email, sender_name, attachments, inline,
        )
        if (cfg.get("provider") or "gmail_api") == "gmail_api":
            msg_id = _send_gmail(cfg, raw)
        else:
            msg_id = _send_smtp(cfg, raw)

        execute(
            "UPDATE emails SET status='sent', sent_at=datetime('now'), provider_msg_id=?, last_error=NULL WHERE id=?",
            (msg_id, email_id),
        )
        execute("UPDATE mail_config SET last_error=NULL, verified_at=COALESCE(verified_at, datetime('now')) WHERE branding_id=?",
                (e["branding_id"],))
        return True

    except Exception as exc:  # noqa: BLE001 - queremos registrar cualquier fallo
        msg = str(exc)[:500]
        execute("UPDATE emails SET status='failed', last_error=? WHERE id=?", (msg, email_id))
        execute("UPDATE mail_config SET last_error=? WHERE branding_id=?", (msg, e["branding_id"]))
        return False


def process_queue(limit: int = 25) -> dict:
    """Procesa la cola. `attempts >= 3` deja de reintentar para no loops."""
    pending = q(
        """SELECT id FROM emails
           WHERE status IN ('queued','failed') AND attempts < 3
           ORDER BY created_at LIMIT ?""",
        (limit,),
    )
    ok = fail = 0
    for r in pending:
        # Los adjuntos se reconstruyen desde la BD: un reintento de factura
        # debe volver a llevar el PDF, no reenviarse sin adjuntar.
        attachments = None
        try:
            from . import sales
            attachments = sales.attachments_for_email(int(r["id"]))
        except Exception:
            attachments = None
        if send_now(int(r["id"]), attachments):
            ok += 1
        else:
            fail += 1
    return {"sent": ok, "failed": fail, "total": len(pending)}


def test_connection(branding_id: int) -> tuple[bool, str]:
    """Comprueba credenciales enviando un correo al propio remitente."""
    cfg = mail_config(branding_id)
    if not cfg:
        return False, "No hay configuracion de correo para esta marca"
    to = cfg.get("sender_email") or settings.from_email
    if not to:
        return False, "No hay remitente configurado"

    ok, err = _try_send_raw(cfg, to, "MoviVIP Billing - prueba de envio",
                            "<p>Configuracion de correo verificada correctamente.</p>")
    if ok:
        execute("UPDATE mail_config SET verified_at=datetime('now'), last_error=NULL WHERE branding_id=?",
                (branding_id,))
    return ok, err


def _try_send_raw(cfg: dict, to: str, subject: str, html: str) -> tuple[bool, str]:
    sender_email = cfg.get("sender_email") or settings.from_email
    sender_name = cfg.get("sender_name") or settings.from_name
    raw = build_mime(to, None, subject, html, sender_email, sender_name)
    try:
        if (cfg.get("provider") or "gmail_api") == "gmail_api":
            _send_gmail(cfg, raw)
        else:
            _send_smtp(cfg, raw)
        return True, "Enviado"
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)[:400]
