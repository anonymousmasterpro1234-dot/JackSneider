#!/usr/bin/env python3
"""CLI de MoviVIP Billing - dispara facturas sin web.

Ejemplos:
  ./mvb init --admin-correo tu@correo.com --admin-clave clave123
  ./mvb correo-gmail --client-id X --client-secret Y --refresh-token Z --remitente tu@correo.com
  ./mvb correo-smtp --host smtp.gmail.com --puerto 587 --usuario tu@correo.com --clave appclave
  ./mvb correo-probar
  ./mvb logo /ruta/logo.png
  ./mvb facturar --nombre "Juan Perez" --correo juan@correo.com \\
                 --operador "Xray PRO" --precio 50 --modo ambos \\
                 --ip 1.2.3.4 --usuario vipuser --clave 'S3guro#2026' \\
                 --spec "CPU=2 vCPU,RAM=2GB,Disco=30GB"
  ./mvb vencimientos            # envia los avisos que toquen
  ./mvb vencimientos --simular  # solo muestra que se enviaria
  ./mvb cola                    # reintenta correos fallidos
  ./mvb servicios
  ./mvb facturas

Multiproveedor (una marca por proveedor):
  ./mvb --prov movivip facturas            # o: mvb facturas --prov movivip
  PROVEEDOR_SLUG=movivip ./mvb servicios  # por entorno (lo exporta facturas.sh)
  Si el slug no existe el comando aborta: es preferible no facturar a facturar
  con el logo, los colores y el remitente de otro proveedor.
"""
from __future__ import annotations

import argparse
import csv
import getpass
import io
import json
import os
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app import billing, branding, contactos, expiry, mailer, sales  # noqa: E402
from app.config import settings  # noqa: E402
from app.db import init_db, q, q1  # noqa: E402
from app.security import (  # noqa: E402
    dec, enc, hash_password, money, parse_dt, random_password,
)


def die(msg: str, code: int = 2) -> "NoReturn":  # noqa: F821 - anotacion para el IDE
    """Error legible: nunca se factura con la marca de otro proveedor."""
    print(json.dumps({"ok": False, "error": msg}, ensure_ascii=False), file=sys.stderr)
    raise SystemExit(code)


def resolve_branding(slug: str | None = None) -> int:
    """Devuelve el branding_id del proveedor con el que se va a facturar.

    Orden de precedencia:
      1. ``--prov <slug>`` (o ``--proveedor``), en cualquier posicion del argv.
      2. ``PROVEEDOR_SLUG`` / ``MVB_PROVEEDOR`` del entorno (lo exporta
         /etc/movivip/facturas.sh, que ya recibe --prov de los hooks).
      3. El unico proveedor activo, si no hay mas de uno.

    Antes esto era un ``1`` fijo en cinco sitios: cualquier proveedor que no
    fuera el principal facturaba con el logo, los colores y el remitente
    equivocados. Aqui un slug desconocido aborta en vez de caer al principal.
    """
    cand = (slug or _PROV_ARG or os.environ.get("PROVEEDOR_SLUG")
            or os.environ.get("MVB_PROVEEDOR") or "").strip()
    try:
        if cand:
            r = q1("SELECT branding_id FROM providers WHERE slug=?", (cand,))
            if r:
                return int(r["branding_id"])
            die(f"proveedor desconocido: '{cand}'")
        rows = q("SELECT branding_id FROM providers WHERE active=1 ORDER BY id")
        if len(rows) == 1:
            return int(rows[0]["branding_id"])
        if len(rows) > 1:
            die("varios proveedores activos: indica --prov <slug> o exporta PROVEEDOR_SLUG")
    except sqlite3.OperationalError:
        # BD anterior a la migracion de `providers`: se comporta como siempre.
        print("[mvb] aviso: la tabla 'providers' no existe; se usa la marca principal",
              file=sys.stderr)
    return 1


_PROV_ARG = ""


def _admin(branding_id: int | None = None) -> dict:
    bid = resolve_branding() if branding_id is None else branding_id
    return {"branding_id": bid, "brand": branding.get_brand(bid) or {}}


def out(obj) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))


# ------------------------------------------------------------------ init
def cmd_init(a) -> int:
    init_db()
    b = branding.ensure_default_brand(a.marca or "JackSneider")
    out({"ok": True, "marca": b["name"], "branding_id": b["id"]})

    if a.admin_correo:
        pw = a.admin_clave or getpass.getpass("Clave del administrador: ")
        existe = q1("SELECT id FROM users WHERE email=?", (a.admin_correo.lower(),))
        if existe:
            from app.db import db
            with db() as c:
                c.execute("UPDATE users SET password_hash=?, role='admin', updated_at=datetime('now') WHERE id=?",
                          (hash_password(pw), existe["id"]))
            out({"admin": a.admin_correo, "accion": "actualizado"})
        else:
            from app.db import db
            with db() as c:
                c.execute(
                    """INSERT INTO users (branding_id, email, full_name, password_hash, role)
                       VALUES (?,?,?,?, 'admin')""",
                    (b["id"], a.admin_correo.lower(), a.admin_nombre or "Administrador", hash_password(pw)),
                )
            out({"admin": a.admin_correo, "accion": "creado"})
    return 0


# ------------------------------------------------------------------ marca
def cmd_marca(a) -> int:
    init_db()
    branding.ensure_default_brand()
    # `mvb marca --set name=X` y `mvb marca name=X` son equivalentes.
    campos = list(a.set or []) + list(a.campos or [])
    bid = resolve_branding()
    if not campos:
        out(branding.get_brand(bid) or {})
        return 0
    data: dict = {}
    for item in campos:
        if "=" not in item:
            print(f"ignorado (formato clave=valor): {item}", file=sys.stderr)
            continue
        k, v = item.split("=", 1)
        data[k.strip()] = v.strip()
    if not data:
        out(branding.get_brand(bid) or {})
        return 0
    try:
        out(branding.update_brand(bid, data))
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


def cmd_logo(a) -> int:
    init_db()
    branding.ensure_default_brand()
    p = Path(a.ruta)
    if not p.is_file():
        print(f"ERROR: no existe {p}", file=sys.stderr)
        return 1
    mimes = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
             ".webp": "image/webp", ".gif": "image/gif", ".svg": "image/svg+xml"}
    mime = mimes.get(p.suffix.lower(), "application/octet-stream")
    try:
        rel = branding.save_logo(resolve_branding(), p.name, p.read_bytes(), mime)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    out({"ok": True, "logo": rel, "url_publico": f"{settings.public_url.rstrip('/')}/uploads/{rel}"})
    return 0


# ------------------------------------------------------------------ correo
def cmd_correo_gmail(a) -> int:
    init_db()
    branding.ensure_default_brand()
    from app.db import db
    with db() as c:
        c.execute(
            """INSERT INTO mail_config (branding_id, provider, gmail_client_id, gmail_client_secret,
                                       gmail_refresh_token, gmail_send_as, sender_email, sender_name)
               VALUES (?, 'gmail_api', ?,?,?,?,?,?)
               ON CONFLICT(branding_id) DO UPDATE SET
                 provider='gmail_api', gmail_client_id=excluded.gmail_client_id,
                 gmail_client_secret=excluded.gmail_client_secret,
                 gmail_refresh_token=excluded.gmail_refresh_token,
                 gmail_send_as=excluded.gmail_send_as, sender_email=excluded.sender_email,
                 sender_name=excluded.sender_name, updated_at=datetime('now')""",
            (resolve_branding(), enc(a.client_id), enc(a.client_secret), enc(a.refresh_token),
             a.enviar_como, a.remitente or a.client_id, a.nombre_remitente or "JackSneider"),
        )
    out({"ok": True, "metodo": "gmail_api", "remitente": a.remitente or a.client_id})
    return 0


def cmd_correo_smtp(a) -> int:
    init_db()
    branding.ensure_default_brand()
    from app.db import db
    with db() as c:
        c.execute(
            """INSERT INTO mail_config (branding_id, provider, smtp_host, smtp_port, smtp_user,
                                       smtp_pass, smtp_secure, sender_email, sender_name)
               VALUES (?, 'smtp', ?,?,?,?,?,?,?)
               ON CONFLICT(branding_id) DO UPDATE SET
                 provider='smtp', smtp_host=excluded.smtp_host, smtp_port=excluded.smtp_port,
                 smtp_user=excluded.smtp_user, smtp_pass=excluded.smtp_pass,
                 smtp_secure=excluded.smtp_secure, sender_email=excluded.sender_email,
                 sender_name=excluded.sender_name, updated_at=datetime('now')""",
            (resolve_branding(), a.host, a.puerto, a.usuario, enc(a.clave), 1 if a.seguro else 0,
             a.remitente, a.nombre_remitente or "JackSneider"),
        )
    out({"ok": True, "metodo": "smtp", "host": a.host, "remitente": a.remitente})
    return 0


def cmd_correo_probar(a) -> int:
    init_db()
    ok, msg = mailer.test_connection(resolve_branding())
    out({"ok": ok, "detalle": msg})
    return 0 if ok else 1


def cmd_cola(a) -> int:
    init_db()
    out(mailer.process_queue(limit=a.limite))
    return 0


# ------------------------------------------------------------------ venta
def _parse_specs(raw: str | None) -> dict:
    """'CPU=2 vCPU,RAM=2GB' -> {'CPU': '2 vCPU', 'RAM': '2GB'}"""
    if not raw:
        return {}
    d = {}
    for part in raw.split(","):
        if "=" in part:
            k, v = part.split("=", 1)
            d[k.strip()] = v.strip()
    return d


def cmd_facturar(a) -> int:
    init_db()
    branding.ensure_default_brand()
    modo = {"invoice": "invoice", "factura": "invoice",
            "cuenta": "account", "account": "account",
            "ambos": "both", "both": "both"}.get((a.modo or "invoice").lower(), "invoice")

    # --precio llega como texto a proposito: float("15.000") es 15.0 y eso
    # mandaba quince mil a la factura como quince soles. Lo normaliza
    # billing.parse_precio, el mismo que usa el bash.
    try:
        precio = billing.parse_precio(a.precio)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    specs = _parse_specs(a.spec)
    if a.especifico:
        specs["Cliente"] = a.nombre

    clave = a.clave
    if not clave and modo in ("cuenta", "ambos") and not a.solo_registro:
        clave = random_password(12)

    payload = {
        "customer_name": a.nombre, "customer_email": a.correo,
        "phone": a.telefono, "document_id": a.documento,
        "operator_label": a.operador, "price_amount": precio,
        "billing_period": a.periodo, "delivery_mode": modo,
        "start_at": a.inicio, "expires_at": a.fin,
        "server_ip": a.ip, "server_hostname": a.servidor,
        "server_specs": specs, "account_username": a.usuario,
        "account_password": clave, "account_notes": a.notas_cuenta,
        # Enlace de acceso (vmess://, vless://, trojan://, ss://). Antes NO
        # existia esta opcion: la libreria recibia --enlace y lo descartaba, asi
        # que el cliente recibia en el correo solo la clave, sin forma de
        # configurar su app. Viaja en el correo, no en la base de datos.
        "delivery_url": a.enlace,
        "description": a.concepto, "notes": a.notas,
        "generate_invoice": not a.sin_factura,
        "protocol": a.protocolo,
        "quantity": a.cantidad,
        # Estado inicial de la factura. Si no se pasa, billing.estado_invoice
        # lo deduce de "accion": alta/cobro -> paid, resto -> pending.
        "invoice_status": a.estado,
        "accion": a.accion,
        # Antes se ignoraba: los correos salian igual. Ahora se respeta.
        "enviar": not a.solo_registro,
    }
    try:
        res = sales.create_sale(payload, _admin())
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    inv = None
    if res.get("invoice_id"):
        r = q1("SELECT number, total, currency FROM invoices WHERE id=?", (res["invoice_id"],))
        if r:
            inv = {"numero": r["number"], "total": money(r["total"], r["currency"])}
    out({"ok": True, "servicio_id": res["service_id"], "factura": inv,
         "correos_enviados": res["emails_sent"], "correos_fallidos": res["emails_failed"],
         "vence": res.get("expires_at")})
    if res["emails_failed"]:
        print("Revisa ./mvb correos-fallidos", file=sys.stderr)
        return 2
    return 0


def cmd_vencimientos(a) -> int:
    init_db()
    out(expiry.scan(dry_run=a.simular))
    return 0


# ------------------------------------------------------------------ contactos
# Esta es la capa que conecta con MoviVIP. Los hooks de alta (add.sh,
# zipvpn.sh, ...) llaman a `contacto`; la reanimacion usa `reactivar`.
# --------------------------------------------------------- carga masiva de correos
# Los logins del sistema se crean desde scripts que no guardan el correo, asi que
# al darlos de alta sin facturacion el correo se pierde. Estos comandos reparan
# ese hueco: leen usuario<->correo de un CSV o lo preguntan por terminal, y lo
# registran con `contactos.registrar` (UPSERT idempotente, nunca borra un correo
# que ya estaba).

_CAMPOS_CSV = {
    "usuario": ("usuario", "user", "username", "login", "cuenta", "account_user",
                "id", "user_id", "usuario_sistema"),
    "correo": ("correo", "email", "mail", "correo_electronico", "gmail", "e_mail"),
    "nombre": ("nombre", "name", "full_name", "nombre_completo"),
    "telefono": ("telefono", "phone", "tel", "movil", "celular", "whatsapp"),
    "protocolo": ("protocolo", "protocol", "proto"),
    "notas": ("notas", "notes"),
}
_ORDEN_SIN_CABECERA = ("usuario", "correo", "nombre", "telefono", "protocolo")


def _usuarios_sistema(uid_minimo: int = 1000) -> list[str]:
    """Cuentas reales del servidor.

    No se filtra por shell: Dropbear deja a los usuarios de SSH con
    `/usr/sbin/nologin`, asi que un filtro por shell dira que no hay ninguno.
    """
    try:
        import pwd  # noqa: PLC0415 - solo existe en Unix
    except ImportError:
        return []
    salida: list[str] = []
    for p in pwd.getpwall():
        if p.pw_uid < uid_minimo or p.pw_name in ("nobody", "nogroup"):
            continue
        if p.pw_name.startswith((".", "_")):
            continue
        salida.append(p.pw_name)
    return sorted(salida, key=str.lower)


def _parsear_csv(texto: str) -> list[dict]:
    """Lee `usuario,correo[,nombre,telefono,protocolo]`, con o sin cabecera."""
    lineas = [l for l in texto.splitlines() if l.strip() and not l.lstrip().startswith("#")]
    if not lineas:
        return []
    sep = ";" if lineas[0].count(";") > lineas[0].count(",") else ","
    filas = [f for f in csv.reader(io.StringIO("\n".join(lineas)), delimiter=sep) if f]
    cab = [(c or "").replace("﻿", "").strip().lower().replace(" ", "_") for c in filas[0]]

    # Cabecera: 2+ campos reconocidos y ninguna celda con "@" (un correo no es
    # un nombre de columna, asi que un CSV sin cabecera no se confunde).
    mapa: dict[int, str] = {}
    cuerpo = filas
    if sum(1 for c in cab if c in _CAMPOS_CSV) >= 2 and not any("@" in c for c in cab):
        for i, c in enumerate(cab):
            campo = next((f for f, alias in _CAMPOS_CSV.items() if c in alias), None)
            if campo and campo not in mapa.values():
                mapa[i] = campo
        cuerpo = filas[1:]
    else:
        # Sin cabecera. El mapa sale del ancho MAXIMO, no del de la primera fila:
        # si la primera es corta ("jesus,correo@x.com") y las siguientes traen
        # nombre/telefono, esas columnas se perderian.
        ancho = max(len(f) for f in filas)
        mapa = {i: _ORDEN_SIN_CABECERA[i] for i in range(min(ancho, len(_ORDEN_SIN_CABECERA)))}

    salida: list[dict] = []
    for f in cuerpo:
        d: dict[str, str] = {}
        for i, v in enumerate(f):
            campo = mapa.get(i)
            if campo and v and v.strip():
                d[campo] = v.strip()
        if d.get("usuario"):
            salida.append(d)
    return salida


def cmd_importar_contactos(a) -> int:
    """Carga en lote los correos de cuentas ya creadas.

    Modos:
      (ninguno)          informe: que cuentas del sistema no tienen correo
      --archivo CSV      importa usuario<->correo desde un CSV
      --sistema          opera sobre las cuentas reales del servidor
      --interactivo      pregunta el correo que falta (solo con terminal)
      --simular          no escribe nada, solo valida y muestra
    """
    init_db()
    branding.ensure_default_brand()
    bid = resolve_branding()
    sistema = _usuarios_sistema() if a.sistema else []

    if a.archivo:
        try:
            texto = Path(a.archivo).read_text(encoding="utf-8-sig", errors="replace")
        except OSError as exc:
            die(f"no se pudo leer '{a.archivo}': {exc}")
        items = _parsear_csv(texto)
    elif a.interactivo:
        if not sys.stdin.isatty():
            die("el modo interactivo necesita una terminal; usa --archivo en scripts")
        base = sistema or [r["account_user"] for r in contactos.listar(branding_id=bid)]
        items = []
        preguntados = 0
        for i, u in enumerate(base, 1):
            previo = contactos.buscar(u, a.protocolo, bid)
            if previo and previo.get("email"):
                continue
            preguntados += 1
            try:
                mail = input(f"[{i}/{len(base)}] {u}: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("", file=sys.stderr)
                break
            if mail:
                items.append({"usuario": u, "correo": mail})
        if not items:
            if not preguntados:
                die("todos los contactos tienen correo: no hay nada que cargar")
            # Seatios o preguntaaron y no llego nada: no tocar la BD en silencio.
            die("no se leyo ningun correo (stdin no interactivo); no se modifico nada")
    else:
        # Modo informe: que falta y a quien no le corresponde el login.
        con_correo = {r["account_user"] for r in contactos.listar(solo_con_email=True, branding_id=bid)}
        out({
            "ok": True,
            "modo": "informe",
            "cuentas_sistema": len(sistema),
            "contactos": len(contactos.listar(branding_id=bid)),
            "con_correo": len(con_correo),
            "pendientes": [u for u in sistema if u not in con_correo] if sistema
            else [r["account_user"] for r in contactos.sin_correo(bid)],
        })
        return 0

    nuevos = actualizados = omitidos = 0
    errores: list[dict] = []
    detalle: list[dict] = []
    for it in items:
        usuario = (it.get("usuario") or "").strip()
        mail = (it.get("correo") or "").strip()
        proto = (it.get("protocolo") or a.protocolo).strip().lower()
        if not mail:
            omitidos += 1
            detalle.append({"usuario": usuario, "estado": "omitido", "motivo": "sin correo"})
            continue
        # Aviso, no error: los protocolos que no son SSH (xray, v2ray...) no
        # aparecen en /etc/passwd, pero su contacto tambien es valido.
        aviso = ("no es una cuenta del sistema" if sistema and usuario not in sistema else None)
        try:
            previo = contactos.buscar(usuario, proto, bid)
            if a.simular:
                fila = {"email": contactos.validar_email(mail)}
            else:
                fila = contactos.registrar(
                    account_user=usuario, protocol=proto, email=mail,
                    full_name=it.get("nombre"), phone=it.get("telefono"),
                    notes=it.get("notas"), branding_id=bid,
                )
        except contactos.EmailInvalido as exc:
            errores.append({"usuario": usuario, "error": str(exc)})
            continue
        if previo and previo.get("email"):
            actualizados += 1
            estado = "actualizado"
        else:
            nuevos += 1
            estado = "nuevo"
        fila_out = {"usuario": usuario, "correo": fila["email"], "estado": estado}
        if aviso:
            fila_out["aviso"] = aviso
        detalle.append(fila_out)

    out({
        "ok": not errores,
        "modo": "simulacion" if a.simular else "importacion",
        "leidos": len(items), "nuevos": nuevos, "actualizados": actualizados,
        "omitidos": omitidos, "errores": errores, "detalle": detalle,
    })
    return 1 if errores else 0


def cmd_contacto(a) -> int:
    """Registra el correo de un usuario del sistema, para cualquier protocolo."""
    init_db()
    branding.ensure_default_brand()
    if not a.correo and a.interactivo:
        a.correo = input("Correo del cliente: ").strip()
    try:
        fila = contactos.registrar(
            account_user=a.usuario, protocol=a.protocolo, email=a.correo,
            full_name=a.nombre, phone=a.telefono, notes=a.notas,
            branding_id=resolve_branding(),
        )
    except contactos.EmailInvalido as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    out({"ok": True, "contacto": fila})
    return 0


def cmd_contactos(a) -> int:
    init_db()
    filas = contactos.listar(protocolo=a.protocolo, solo_con_email=a.con_correo)
    out({"total": len(filas), "contactos": filas})
    return 0


def cmd_buscar(a) -> int:
    """Consulta el correo guardado. Lo usa la reanimacion para no perguntar."""
    init_db()
    fila = contactos.buscar(a.usuario, a.protocolo)
    if not fila:
        out({"ok": False, "motivo": f"sin registro para '{a.usuario}'"})
        return 1
    if a.solo_correo:
        print(fila.get("email") or "")
        return 0
    if getattr(a, "solo_telefono", False):
        print(fila.get("phone") or "")
        return 0
    out({"ok": True, "contacto": fila})
    return 0


def cmd_reactivar(a) -> int:
    """Reanima una cuenta: reutiliza el correo guardado y factura si corresponde."""
    init_db()
    branding.ensure_default_brand()
    modo = {"invoice": "invoice", "factura": "invoice",
            "cuenta": "account", "account": "account",
            "ambos": "both", "both": "both"}.get((a.modo or "invoice").lower(), "invoice")
    if a.sin_correo:
        contactos.borrar(a.usuario, a.protocolo)
        out({"ok": True, "accion": "contacto_eliminado", "usuario": a.usuario})
        return 0
    try:
        res = sales.facturar_por_usuario(
            a.usuario, _admin(), price_amount=a.precio,
            protocol=a.protocolo, operator_label=a.operador,
            expires_at=a.expira, delivery_mode=modo,
            server_ip=a.ip, server_hostname=a.servidor,
            generate_invoice=not a.sin_factura, enviar=not a.solo_registro,
        )
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    inv = None
    if res.get("invoice_id"):
        r = q1("SELECT number, total, currency FROM invoices WHERE id=?", (res["invoice_id"],))
        if r:
            inv = {"numero": r["number"], "total": money(r["total"], r["currency"])}
    out({"ok": True, "usuario": a.usuario, "servicio_id": res["service_id"],
         "factura": inv, "correos_enviados": res["emails_sent"],
         "correos_fallidos": res["emails_failed"], "vence": res.get("expires_at")})
    return 2 if res["emails_failed"] else 0


# ------------------------------------------------------------------ listados
def cmd_servicios(a) -> int:
    init_db()
    bid = resolve_branding()
    sql = """SELECT s.id, s.operator_label, s.price_amount, s.status, s.expires_at,
                    u.full_name, u.email
             FROM services s JOIN users u ON u.id=s.customer_id
             WHERE s.branding_id=?"""
    args: list = [bid]
    if a.estado:
        sql += " AND s.status=?"
        args.append(a.estado)
    sql += " ORDER BY s.id DESC LIMIT ?"
    args.append(a.limite)
    rows = []
    for r in q(sql, args):
        d = dict(r)
        d["expira"] = (d.get("expires_at") or "")[:10] or None
        d["precio_fmt"] = money(d["price_amount"])
        d.pop("expires_at", None)
        rows.append(d)
    out({"total": len(rows), "servicios": rows})
    return 0


def cmd_facturas(a) -> int:
    init_db()
    sql = "SELECT id, number, customer_name, operator_label, total, currency, status, issued_at FROM invoices WHERE branding_id=?"
    args: list = [resolve_branding()]
    if a.estado:
        sql += " AND status=?"
        args.append(a.estado)
    sql += " ORDER BY id DESC LIMIT ?"
    args.append(a.limite)
    rows = []
    for r in q(sql, args):
        d = dict(r)
        d["total_fmt"] = money(d["total"], d["currency"])
        d["emitida"] = (d.get("issued_at") or "")[:10]
        d.pop("issued_at", None)
        rows.append(d)
    out({"total": len(rows), "facturas": rows})
    return 0


def cmd_correos(a) -> int:
    init_db()
    sql = "SELECT id, kind, to_email, subject, status, attempts, last_error, created_at FROM emails WHERE branding_id=?"
    args: list = [resolve_branding()]
    if a.estado:
        sql += " AND status=?"
        args.append(a.estado)
    sql += " ORDER BY id DESC LIMIT ?"
    args.append(a.limite)
    rows = []
    for r in q(sql, args):
        d = dict(r)
        d["creado"] = (d.get("created_at") or "")[:16]
        d.pop("created_at", None)
        rows.append(d)
    out({"total": len(rows), "correos": rows})
    return 0


# ------------------------------------------------------------------ parser
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="mvb", description="MoviVIP Billing - envia facturas por correo")
    p.add_argument("--prov", "--proveedor", dest="prov", default=None,
                   help="slug del proveedor (por defecto PROVEEDOR_SLUG del entorno)")
    s = p.add_subparsers(dest="cmd", required=True)

    x = s.add_parser("init", help="crea la base de datos y el administrador")
    x.add_argument("--marca")
    x.add_argument("--admin-correo")
    x.add_argument("--admin-clave")
    x.add_argument("--admin-nombre")
    x.set_defaults(fn=cmd_init)

    x = s.add_parser("marca", help="ver o editar la identidad de la marca")
    x.add_argument("--set", nargs="*", metavar="CLAVE=VALOR", help="campos a cambiar")
    x.set_defaults(fn=cmd_marca)
    # permitir: mvb marca nombre="X"  -> se captura en campos
    x.add_argument("campos", nargs="*")

    x = s.add_parser("logo", help="sube el logo (PNG/JPG/WEBP/GIF/SVG)")
    x.add_argument("ruta")
    x.set_defaults(fn=cmd_logo)

    x = s.add_parser("correo-gmail", help="configura Gmail API OAuth2")
    x.add_argument("--client-id", required=True)
    x.add_argument("--client-secret", required=True)
    x.add_argument("--refresh-token", required=True)
    x.add_argument("--remitente")
    x.add_argument("--nombre-remitente")
    x.add_argument("--enviar-como", help="alias si es una cuenta de Google Workspace")
    x.set_defaults(fn=cmd_correo_gmail)

    x = s.add_parser("correo-smtp", help="configura SMTP")
    x.add_argument("--host", required=True)
    x.add_argument("--puerto", type=int, default=587)
    x.add_argument("--usuario", required=True)
    x.add_argument("--clave", required=True)
    x.add_argument("--seguro", type=int, default=1)
    x.add_argument("--remitente", required=True)
    x.add_argument("--nombre-remitente")
    x.set_defaults(fn=cmd_correo_smtp)

    x = s.add_parser("correo-probar", help="envia un correo de prueba")
    x.set_defaults(fn=cmd_correo_probar)

    x = s.add_parser("cola", help="procesa/reintenta la cola de correos")
    x.add_argument("--limite", type=int, default=25)
    x.set_defaults(fn=cmd_cola)

    x = s.add_parser("facturar", help="crea la venta y envia los correos")
    x.add_argument("--nombre", required=True)
    x.add_argument("--correo", required=True)
    x.add_argument("--telefono")
    x.add_argument("--documento")
    x.add_argument("--operador", required=True)
    x.add_argument("--precio", required=True,
                   help="importe TOTAL. Acepta 15000, 15.000, 1.500,50 y 15,50")
    x.add_argument("--cantidad", type=int, default=1, help="dispositivos incluidos (precio total)")
    x.add_argument("--estado", dest="estado", default=None,
                   choices=["pending", "paid", "void", "overdue"],
                   help="estado inicial de la factura. Si se omite se deduce de --accion")
    x.add_argument("--accion", dest="accion", default="alta",
                   help="alta|cobro nacen PAGADAS; reactivar|renovar nacen PENDIENTES")
    x.add_argument("--periodo", default="mensual",
                   choices=["mensual", "bimestral", "trimestral", "semestral", "anual", "unico"])
    x.add_argument("--modo", default="invoice", help="invoice|cuenta|ambos")
    x.add_argument("--inicio", help="YYYY-MM-DD (por defecto hoy)")
    x.add_argument("--fin", help="YYYY-MM-DD (por defecto se calcula segun el periodo)")
    x.add_argument("--ip")
    x.add_argument("--servidor")
    x.add_argument("--protocolo", default="SSH", help="SSH|ZIPVPN|XRAY|etc.")
    x.add_argument("--usuario", dest="usuario", help="usuario de la cuenta creada")
    x.add_argument("--clave", dest="clave", help="contrasena de la cuenta creada")
    x.add_argument("--enlace", dest="enlace", default=None,
                   help="enlace de acceso (vmess://, vless://, trojan://, ss://) "
                        "que se envia en el correo de la cuenta creada")
    x.add_argument("--spec", help='ej: "CPU=2 vCPU,RAM=2GB,Disco=30GB"')
    x.add_argument("--especifico", action="store_true", help="envia copia al cliente del administrador")
    x.add_argument("--notas-cuenta")
    x.add_argument("--concepto")
    x.add_argument("--notas")
    x.add_argument("--sin-factura", action="store_true")
    x.add_argument("--solo-registro", action="store_true", help="registra pero no envia")
    x.set_defaults(fn=cmd_facturar)

    x = s.add_parser("vencimientos", help="envia avisos de vencimiento")
    x.add_argument("--simular", action="store_true", help="solo muestra que se enviaria")
    x.set_defaults(fn=cmd_vencimientos)

    x = s.add_parser("contacto", help="registra el correo de un usuario (cualquier protocolo)")
    x.add_argument("--usuario", required=True, help="login del sistema")
    x.add_argument("--correo")
    x.add_argument("--nombre")
    x.add_argument("--telefono")
    x.add_argument("--notas")
    x.add_argument("--protocolo", default="ssh",
                   help="ssh|zipvpn|xray|hcr|... (por defecto ssh)")
    x.add_argument("--interactivo", action="store_true", help="pregunta el correo si falta")
    x.set_defaults(fn=cmd_contacto)

    x = s.add_parser("contactos", help="lista los contactos registrados")
    x.add_argument("--protocolo")
    x.add_argument("--con-correo", action="store_true", help="solo los que tienen correo")
    x.set_defaults(fn=cmd_contactos)

    x = s.add_parser("contactos-importar",
                     help="carga en lote los correos de cuentas ya creadas")
    x.add_argument("--archivo", help="CSV: usuario,correo[,nombre,telefono,protocolo]")
    x.add_argument("--sistema", action="store_true",
                   help="opera sobre las cuentas reales del servidor (/etc/passwd)")
    x.add_argument("--interactivo", action="store_true",
                   help="pregunta el correo que falte (necesita terminal)")
    x.add_argument("--protocolo", default="ssh", help="protocolo por defecto (ssh)")
    x.add_argument("--simular", action="store_true", help="no escribe, solo valida")
    x.set_defaults(fn=cmd_importar_contactos)

    x = s.add_parser("buscar", help="busca el correo guardado de un usuario")
    x.add_argument("usuario")
    x.add_argument("--protocolo")
    x.add_argument("--solo-correo", action="store_true", help="imprime solo la direccion")
    x.add_argument("--solo-telefono", action="store_true", help="imprime solo el telefono/telegram")
    x.set_defaults(fn=cmd_buscar)

    x = s.add_parser("reactivar", help="factura una cuenta usando el correo ya guardado")
    x.add_argument("usuario")
    x.add_argument("--precio", type=float, default=0)
    x.add_argument("--operador")
    x.add_argument("--protocolo", help="por defecto: el que tenga registrado")
    x.add_argument("--expira", help="YYYY-MM-DD")
    x.add_argument("--modo", default="invoice", help="invoice|cuenta|ambos")
    x.add_argument("--ip")
    x.add_argument("--servidor")
    x.add_argument("--sin-factura", action="store_true")
    x.add_argument("--solo-registro", action="store_true", help="registra pero no envia")
    x.add_argument("--sin-correo", action="store_true", help="borra el contacto y sale")
    x.set_defaults(fn=cmd_reactivar)

    x = s.add_parser("servicios", help="lista los servicios")
    x.add_argument("--estado", choices=["active", "suspended", "expired", "cancelled"])
    x.add_argument("--limite", type=int, default=50)
    x.set_defaults(fn=cmd_servicios)

    x = s.add_parser("facturas", help="lista las facturas")
    x.add_argument("--estado", choices=["pending", "paid", "void", "overdue"])
    x.add_argument("--limite", type=int, default=50)
    x.set_defaults(fn=cmd_facturas)

    x = s.add_parser("correos", help="bitacora de correos")
    x.add_argument("--estado", choices=["queued", "sending", "sent", "failed"])
    x.add_argument("--limite", type=int, default=50)
    x.set_defaults(fn=cmd_correos)

    return p


def _extraer_prov(argv: list[str]) -> list[str]:
    """Saca `--prov <slug>` / `--prov=<slug>` de cualquier posicion del argv.

    argparse solo aceptaria el flag antes del subcomando, pero los hooks y los
    operadores lo escriben despues (`mvb facturas --prov movivip`). Se extrae
    aqui y se guarda en _PROV_ARG; el resto del argv sigue intacto.
    """
    global _PROV_ARG
    resto: list[str] = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("--prov", "--proveedor") and i + 1 < len(argv):
            _PROV_ARG = argv[i + 1]
            i += 2
            continue
        if arg.startswith("--prov=") or arg.startswith("--proveedor="):
            _PROV_ARG = arg.split("=", 1)[1]
            i += 1
            continue
        resto.append(arg)
        i += 1
    return resto


def main() -> int:
    global _PROV_ARG
    argv = _extraer_prov(sys.argv[1:])
    args = build_parser().parse_args(argv)
    _PROV_ARG = (getattr(args, "prov", None) or _PROV_ARG or "")
    try:
        return int(args.fn(args) or 0)
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
