MoviVIP — Bypass de licencia
=============================
Instalación:
  tar -xzf movivip-bypass.tar.gz
  cd bypass-movivip
  bash install-bypass.sh

Desinstalación:
  bash uninstall-bypass.sh

Lee la KEY y HWID del /etc/movivip/licencia.conf de la VPS destino.
NO contiene claves hardcodeadas. Seguro para cualquier sitio.
