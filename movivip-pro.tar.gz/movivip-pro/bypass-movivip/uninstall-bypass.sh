#!/usr/bin/env bash
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "[ERROR] root requerido"; exit 1; }
BASE="/etc/movivip"; BIN_WRAPPER="/usr/local/bin/movivip-lic"
BIN_REAL="$BASE/bin/movivip-lic"; GUARD="$BASE/bin/movivip-guard"
for f in "$BIN_WRAPPER" "$BIN_REAL" "$GUARD" "$BASE/licencia.conf" "$BASE/.plan_cache"; do [[ -e "$f" ]] && chattr -i "$f" 2>/dev/null || true; done
[[ -f "$GUARD.real" ]] && mv -f "$GUARD.real" "$GUARD" && chmod 700 "$GUARD"
[[ -f "/root/movivip-lic.orig" ]] && cp -a "/root/movivip-lic.orig" "$BIN_REAL" && chmod 700 "$BIN_REAL"
rm -f "$BIN_WRAPPER"
echo "[✓] Bypass eliminado. Originales restaurados."
