#!/usr/bin/env bash
# JackSneider — personalización automática post-instalación
set -uo pipefail

TG="https://t.me/+I-VOBBPsGSZjOGE5"
WA="3181882682"
BRAND="JackSneider"
BRAND_UP="JACKSNEIDER"

echo "     [*] Aplicando branding $BRAND..."

python3 - <<'PYEOF'
import os

TG = "https://t.me/+I-VOBBPsGSZjOGE5"
WA = "3181882682"
BRAND = "JackSneider"
BRAND_UP = "JACKSNEIDER"

files = []
for root, dirs, fs in os.walk("/etc/movivip"):
    if "/bin" in root or "/payload" in root:
        continue
    for f in fs:
        if f.endswith((".conf", ".sh", ".md", ".txt", ".html", ".json", ".py", ".dict")):
            p = os.path.join(root, f)
            try:
                with open(p, "r", errors="ignore") as fh:
                    head = fh.read(200)
                if "MOVIVIP-PACKED-V2" in head:
                    continue
            except Exception:
                continue
            files.append(p)

repl = {
    "MoviVIP Network": BRAND,
    "NEBULA CYBER": BRAND_UP,
    "Nebula Cyber": BRAND,
    "t.me/MoviVIPNetwork": TG,
    "t.me/MoviVIPNet": TG,
    "t.me/MoviVIP": TG,
    "t.me/FreeNetZonevip": TG,
    "t.me/FreeNetZonevips": TG,
    "@MoviVIP": BRAND,
    "movivip-network.web.app": "",
    "+57 311 700 8185": WA,
    "311 700 8185": WA,
    "Soporte MoviVIP": "Soporte " + BRAND,
    "MoviVIP Support": BRAND + " Support",
    "Powered by MoviVIP": "Powered by " + BRAND,
}

changed = 0
for p in files:
    try:
        with open(p, "r", errors="ignore") as f:
            content = f.read()
        orig = content
        for a, b in repl.items():
            content = content.replace(a, b)
        # Arreglar doble https://
        while "https://https://" in content:
            content = content.replace("https://https://", "https://")
        if content != orig:
            with open(p, "w") as f:
                f.write(content)
            changed += 1
    except Exception:
        pass

print(f"     [OK] {changed} archivos personalizados")
PYEOF

echo "     [OK] Branding $BRAND aplicado"
