MoviVIP Network — Instalador completo con bypass
=================================================

Contenido:
  install-full.sh          Orquestador (todo-en-uno)
  install-auto.sh          Instalador original del proveedor
  machine-id-fabricado     machine-id que produce el HWID 164a39606c1fdde0
  bypass-movivip/          Bypass de licencia

Uso en VPS limpia (root, x86_64, Ubuntu/Debian):
  1. Sube movivip-instalador-full.tar.gz a /root/
  2. cd /root && tar -xzf movivip-instalador-full.tar.gz
  3. cd movivip-instalador-full
  4. bash install-full.sh

Qué hace:
  1. Backup del machine-id actual
  2. Pone machine-id fabricado (requisito de la licencia)
  3. Instala MoviVIP con tu KEY
  4. Aplica bypass (vitalicio/superadmin)
  5. Verifica

Después:
  - menu
  - Cambia el dominio desde el panel

Requisitos:
  - Root, x86_64, Ubuntu 20.04+/Debian 11+
  - Internet (descarga el payload)

Revertir bypass:
  cd bypass-movivip && bash uninstall-bypass.sh

Nota: el machine-id queda fabricado. Es requisito.
No afecta al sistema ni al panel.
