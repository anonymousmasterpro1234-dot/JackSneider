#!/usr/bin/env bash
# MoviVIP Network — Instalador todo-en-uno con bypass
set -euo pipefail
KEY="Dp41jYRGd3X2rSHgvkmamZVIP1zH2LQZL-TSHaDJaDtEetcdNZ387ANMzDSSzdNW"
HWID_FAB="164a39606c1fdde0"
MACHINE_ID_FAB="164a39606c1fdde00000000000000000"
HERE="$(cd "$(dirname "$0")" && pwd)"

[[ $EUID -eq 0 ]] || { echo "[ERROR] root requerido"; exit 1; }
[[ "$(uname -m)" == "x86_64" ]] || { echo "[ERROR] solo x86_64"; exit 1; }

echo "============================================================"
echo "  MoviVIP Network — Instalación completa + bypass"
echo "============================================================"

echo "[1/7] Backup machine-id..."
cp /etc/machine-id "/root/machine-id.vps-original.$(date +%s)" 2>/dev/null || true

echo "[2/7] Limpiando instalación previa si existe..."
if [[ -d /etc/movivip ]]; then
    chattr -R -i /etc/movivip 2>/dev/null || true
    chattr -i /usr/local/bin/movivip-lic /usr/local/bin/movivip-guard 2>/dev/null || true
    bash /etc/movivip/uninstall.sh -y </dev/null >/dev/null 2>&1 || true
    rm -rf /etc/movivip 2>/dev/null || true
fi
rm -f /usr/local/bin/movivip-lic /usr/local/bin/movivip-guard 2>/dev/null || true
rm -rf /etc/systemd/system/movivip* /etc/systemd/system/badvpn-* \
       /etc/systemd/system/dropbear_custom.service /etc/systemd/system/hcr.service \
       /etc/systemd/system/ssh-ws-internal.service /etc/systemd/system/udp-custom.service \
       /etc/cron.d/movivip* 2>/dev/null || true
echo "     [OK] entorno limpio"

echo "[3/7] Configurando machine-id..."
echo "$MACHINE_ID_FAB" > /etc/machine-id
systemd-machine-id-setup 2>/dev/null || true
echo "     HWID: $HWID_FAB"

echo "[4/7] Instalando MoviVIP con la KEY..."
cd /tmp
[[ -f "$HERE/install-auto.sh" ]] || { echo "[ERROR] falta install-auto.sh"; exit 1; }

# Preguntar dominio (igual que el instalador original)
IP_PUBLICA="$(hostname -I | awk '{print $1}')"
if [[ -z "${MV_DOMINIO:-}" ]]; then
    echo
    echo "  ─────────────────────────────────────────────"
    echo "  Dominio para el panel y los certificados SSL"
    echo "  (Enter para usar la IP: $IP_PUBLICA)"
    echo "  ─────────────────────────────────────────────"
    read -r -p "  Dominio: " DOMINIO
    [[ -z "$DOMINIO" ]] && DOMINIO="$IP_PUBLICA"
else
    DOMINIO="$MV_DOMINIO"
fi
echo "     Dominio: $DOMINIO"

# Alimenta el dominio al setup para todas las preguntas (SSL, v2ray, etc.)
yes "$DOMINIO" | bash "$HERE/install-auto.sh" "$KEY" 2>&1 | tee /root/movivip-install.log || true

if [[ ! -d /etc/movivip ]]; then
    echo "[ERROR] /etc/movivip no existe tras el setup"
    exit 1
fi
echo "     [OK] Panel instalado"

# ── Paso 4.5: Arreglar HAProxy y ACME (fix post-instalación) ──
echo "[4.5/7] Reparando HAProxy y ACME webroot..."
if [[ -f "$HERE/haproxy-fixed.cfg" ]] && [[ -d /etc/haproxy ]]; then
    cp "$HERE/haproxy-fixed.cfg" /etc/haproxy/haproxy.cfg
    /usr/sbin/haproxy -c -f /etc/haproxy/haproxy.cfg >/dev/null 2>&1 && \
        echo "     [OK] HAProxy config completa" || \
        echo "     [!] HAProxy config falló validación"
fi
# Arrancar webroot ACME en 8090 (setsid + stdin cerrado, no hereda job control)
mkdir -p /var/www/acme/.well-known/acme-challenge
pkill -f "http.server 8090" 2>/dev/null || true
sleep 2
cd /var/www/acme && setsid nohup python3 -m http.server 8090 --bind 127.0.0.1 >/tmp/acme-http.log 2>&1 < /dev/null &
sleep 2
ss -tlnp 2>/dev/null | grep -q ":8090" && echo "     [OK] ACME webroot en 8090" || echo "     [!] ACME webroot no arrancó"
# Reiniciar HAProxy
systemctl restart haproxy 2>/dev/null || true
sleep 1
ss -tlnp 2>/dev/null | grep -q ":80" && echo "     [OK] HAProxy en :80" || echo "     [!] HAProxy no escucha en :80"

echo "[5/7] Corrigiendo HWID en licencia.conf..."
if [[ -f /etc/movivip/licencia.conf ]]; then
    chattr -i /etc/movivip/licencia.conf 2>/dev/null || true
    sed -i "s|^HWID=.*|HWID=\"$HWID_FAB\"|" /etc/movivip/licencia.conf
    chmod 600 /etc/movivip/licencia.conf
    echo "     [OK] HWID = $HWID_FAB"
fi

echo "[6/7] Aplicando bypass..."
cd "$HERE/bypass-movivip"
bash install-bypass.sh || true

echo
echo "[7/7] Verificando..."
bash -c 'source /etc/movivip/lib/plancheck.sh; plan_obtener >/dev/null 2>&1; es_proveedor' 2>/dev/null && echo "     [OK] es_proveedor" || echo "     [!] es_proveedor"
bash -c 'source /etc/movivip/lib/plancheck.sh; plan_obtener >/dev/null 2>&1; es_premium' 2>/dev/null && echo "     [OK] es_premium" || echo "     [!] es_premium"

echo
# ── Paso 7.5: Configurar dominio en config.conf si no está ──
if [[ -n "${DOMINIO:-}" ]] && [[ -f /etc/movivip/config.conf ]]; then
    if grep -q "^SERVER_DOMAIN=" /etc/movivip/config.conf; then
        sed -i "s|^SERVER_DOMAIN=.*|SERVER_DOMAIN=\"$DOMINIO\"|" /etc/movivip/config.conf
    else
        echo "SERVER_DOMAIN=\"$DOMINIO\"" >> /etc/movivip/config.conf
    fi
    echo "     [OK] SERVER_DOMAIN=$DOMINIO"
fi

# ── Paso 7.8: Personalización de marca ──
if [[ -f "$HERE/branding.sh" ]]; then
    echo "[7.8/7] Aplicando personalización de marca..."
    bash "$HERE/branding.sh" || echo "     [!] branding falló (revisar)"
fi

echo "============================================================"
echo "  INSTALACIÓN COMPLETA"
echo "============================================================"
echo "  Panel:   /etc/movivip"
echo "  Comando: menu"
echo "  Plan:    vitalicio / superadmin"
echo "  HWID:    $HWID_FAB"
echo "  Log:     /root/movivip-install.log"
echo "============================================================"
