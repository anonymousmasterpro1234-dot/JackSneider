#!/usr/bin/env bash
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "[ERROR] root requerido"; exit 1; }
BASE="/etc/movivip"; LIC="$BASE/licencia.conf"
BIN_WRAPPER="/usr/local/bin/movivip-lic"; BIN_REAL="$BASE/bin/movivip-lic"; GUARD="$BASE/bin/movivip-guard"
[[ -d "$BASE" && -f "$BIN_REAL" && -f "$GUARD" && -f "$LIC" ]] || { echo "[ERROR] MoviVIP no instalado"; exit 1; }
KEY="$(grep -m1 '^KEY=' "$LIC" 2>/dev/null | cut -d= -f2- | tr -d '" \r')"
HWID="$(grep -m1 '^HWID=' "$LIC" 2>/dev/null | cut -d= -f2- | tr -d '" \r')"
IPV="$(grep -m1 '^IP_VINCULADA=' "$LIC" 2>/dev/null | cut -d= -f2- | tr -d '" \r')"
CLIENTE="$(grep -m1 '^CLIENTE=' "$LIC" 2>/dev/null | cut -d= -f2- | tr -d '" \r')"
[[ -n "$KEY" ]] || { echo "[ERROR] KEY no encontrada"; exit 1; }
[[ -n "$HWID" ]] || HWID="$(hostname)"; [[ -n "$CLIENTE" ]] || CLIENTE="Cliente"
EXP=4102444800
echo "[*] KEY: ${KEY:0:8}**** HWID: $HWID Cliente: $CLIENTE"
for f in "$BIN_WRAPPER" "$BIN_REAL" "$GUARD" "$LIC" "$BASE/.plan_cache"; do [[ -e "$f" ]] && chattr -i "$f" 2>/dev/null || true; done
[[ -f "/root/movivip-lic.orig" ]] || cp -a "$BIN_REAL" "/root/movivip-lic.orig"
[[ -f "/root/movivip-guard.orig" ]] || cp -a "$GUARD" "/root/movivip-guard.orig"
chattr +i /root/movivip-lic.orig /root/movivip-guard.orig 2>/dev/null || true
cat > "$BIN_WRAPPER" <<WRAPPER
#!/bin/bash
K="$KEY"; EXP=$EXP; HW="$HWID"
emit_kv(){ printf 'LIC_OK="true"\\nLIC_KEY="%s"\\nLIC_PLAN="vitalicio"\\nLIC_CLIENTE="$CLIENTE"\\nLIC_TIPO="superadmin"\\nLIC_IP=""\\nLIC_EXPIRA=%s\\nLIC_DIAS=9999\\nLIC_HWID="%s"\\nLIC_DETALLE="en vivo"\\nLIC_VERSION="4.0.0"\\n' "\$K" "\$EXP" "\$HW"; }
emit_json(){ printf '{"ok":true,"rc":0,"key":"%s","plan":"vitalicio","cliente":"$CLIENTE","tipo":"superadmin","expira":%s,"dias":9999,"servidor":%s,"hwid":"%s","detalle":"en vivo","firma":false,"version":"4.0.0"}\\n' "\$K" "\$EXP" "\$EXP" "\$HW"; }
case "\$*" in *--json*) emit_json; exit 0;; *--export*) emit_kv; exit 0;; *--gate*) emit_kv; exit 0;; esac
exit 0
WRAPPER
chmod 755 "$BIN_WRAPPER"; chown root:root "$BIN_WRAPPER"
bash -n "$BIN_WRAPPER" || { echo "[ERROR] wrapper roto"; exit 1; }
[[ -f "$GUARD.real" ]] || mv "$GUARD" "$GUARD.real"
cat > "$GUARD" <<GUARDW
#!/bin/bash
REAL="$GUARD.real"; K="$KEY"; EXP=$EXP; HW="$HWID"
case "\$*" in
  *--verify*) echo "OK"; exit 0 ;;
  *--gate*) printf 'LIC_OK="true"\\nLIC_KEY="%s"\\nLIC_PLAN="vitalicio"\\nLIC_CLIENTE="$CLIENTE"\\nLIC_TIPO="superadmin"\\nLIC_EXPIRA=%s\\nLIC_DIAS=9999\\nLIC_HWID="%s"\\nLIC_DETALLE="en vivo"\\nLIC_VERSION="4.0.0"\\n' "\$K" "\$EXP" "\$HW"; exit 0 ;;
esac
exec "\$REAL" "\$@"
GUARDW
chmod 700 "$GUARD"; chown root:root "$GUARD"
bash -n "$GUARD" || { echo "[ERROR] guard roto"; exit 1; }
cat > "$LIC" <<LICF
KEY="$KEY"
IP_VINCULADA="$IPV"
PLAN="vitalicio"
CLIENTE="$CLIENTE"
TIPO="superadmin"
EXPIRA=$EXP
DIAS=9999
VERIFICADO="ed25519-v4.0.0-en-vivo"
ACTIVADA="$(date '+%Y-%m-%d %H:%M:%S')"
HWID="$HWID"
LICF
chmod 600 "$LIC"
KEY_HASH="$(printf '%s' "$KEY" | sha256sum | awk '{print $1}')"
printf "LIC_KEY_HASH='%s'\nexport LIC_PLAN='vitalicio'\nexport LIC_TIPO='superadmin'\n" "$KEY_HASH" > "$BASE/.plan_cache"
chmod 600 "$BASE/.plan_cache"; touch "$BASE/.plan_cache"
for f in "$BIN_WRAPPER" "$BIN_REAL" "$GUARD" "$LIC" "$BASE/.plan_cache"; do chattr +i "$f" 2>/dev/null || true; done
echo
echo "=== Pruebas ==="
"$BIN_WRAPPER" --gate >/dev/null && echo "[OK] wrapper --gate"
"$GUARD" --verify >/dev/null && echo "[OK] guard --verify"
[[ -x "$BASE/lib/licgate.sh" ]] && {
  bash "$BASE/lib/licgate.sh" check-bots >/dev/null 2>&1 && echo "[OK] check-bots" || echo "[!] check-bots"
  bash "$BASE/lib/licgate.sh" check >/dev/null 2>&1 && echo "[OK] check" || echo "[!] check"
  bash "$BASE/lib/licgate.sh" enforce-license >/dev/null 2>&1 && echo "[OK] enforce" || echo "[!] enforce"
}
[[ -f "$BASE/lib/plancheck.sh" ]] && {
  bash -c 'source /etc/movivip/lib/plancheck.sh; plan_obtener >/dev/null 2>&1; es_proveedor' >/dev/null 2>&1 && echo "[OK] es_proveedor" || echo "[!] es_proveedor"
  bash -c 'source /etc/movivip/lib/plancheck.sh; plan_obtener >/dev/null 2>&1; es_premium' >/dev/null 2>&1 && echo "[OK] es_premium" || echo "[!] es_premium"
}
echo
echo "[✓] Listo. Plan vitalicio / superadmin / expira 2100."

# Proteger la caché al final
chmod 600 /etc/movivip/.plan_cache 2>/dev/null || true
chattr +i /etc/movivip/.plan_cache 2>/dev/null || true
